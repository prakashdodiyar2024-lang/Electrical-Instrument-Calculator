package com.example

import com.example.domain.CalculatorRegistry
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.EngineeringDiscipline
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineeringCalculatorsTest {

    private fun runCalc(
        id: String,
        values: Map<String, Double>,
        units: Map<String, String> = emptyMap()
    ) = CalculatorRegistry.getById(id)!!.compute(values, units)

    @Test
    fun registryHasExactly100Calculators50Electrical50Instrumentation() {
        assertEquals(10, CalculatorCategory.entries.size)
        assertEquals(5, CalculatorCategory.forDiscipline(EngineeringDiscipline.ELECTRICAL).size)
        assertEquals(5, CalculatorCategory.forDiscipline(EngineeringDiscipline.INSTRUMENTATION).size)

        assertEquals(50, CalculatorRegistry.electricalCalculators.size)
        assertEquals(50, CalculatorRegistry.instrumentationCalculators.size)
        assertEquals(100, CalculatorRegistry.allCalculators.size)

        // Every category has exactly 10 calculators
        CalculatorCategory.entries.forEach { cat ->
            assertEquals("Category ${cat.id} must have 10 tools", 10, CalculatorRegistry.getByCategory(cat).size)
        }

        // Serial numbers 1..50 for Electrical and 1..50 for Instrumentation, unique IDs
        assertEquals(100, CalculatorRegistry.allCalculators.map { it.id }.toSet().size)
        assertEquals((1..50).toList(), CalculatorRegistry.electricalCalculators.map { it.serialNumber })
        assertEquals((1..50).toList(), CalculatorRegistry.instrumentationCalculators.map { it.serialNumber })
    }

    @Test
    fun all100CalculatorsHaveBilingualFieldsAssumptionsAndComputeCleanly() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            assertFalse(calc.title.en.isBlank())
            assertFalse(calc.title.hi.isBlank())
            assertFalse(calc.subtitle.en.isBlank())
            assertFalse(calc.subtitle.hi.isBlank())
            assertFalse(calc.formulaPreview.isBlank())
            assertNotNull("Missing assumptions in ${calc.id}", calc.assumptions)
            assertFalse(calc.assumptions!!.en.isBlank())
            assertFalse(calc.assumptions!!.hi.isBlank())

            val defVals = calc.fields.associate { it.id to (it.defaultValue.toDoubleOrNull() ?: 1.0) }
            val defUnits = calc.fields.associate { it.id to it.defaultUnit }
            val out = calc.compute(defVals, defUnits).getOrThrow()
            assertFalse("Blank primaryValue in ${calc.id}", out.primaryValue.isBlank())
            assertFalse("Blank formulaUsed in ${calc.id}", out.formulaUsed.isBlank())
            assertFalse("Blank substitutedFormula in ${calc.id}", out.substitutedFormula.isBlank())
            assertTrue("Missing steps in ${calc.id}", out.steps.isNotEmpty())
        }
    }

    @Test
    fun electricalCoreCalculationsAccuracy() {
        // 1. Ohm's Law: I = 230 / 46 = 5 A
        val ohms = runCalc("elec_ohms_law", mapOf("val_a" to 230.0, "val_b" to 46.0), mapOf("solve_for" to "Current I = V/R")).getOrThrow()
        assertEquals("5", ohms.primaryValue)

        // 11. Transformer kVA (3ph): 415V, 100A, 0% margin => 71.88 kVA net, 100 kVA standard
        val txKva = runCalc("xfmr_kva", mapOf("voltage" to 415.0, "current" to 100.0, "margin" to 0.0), mapOf("phase" to "3φ", "voltage" to "V")).getOrThrow()
        assertEquals("100", txKva.primaryValue)
        assertEquals("71.88", txKva.secondaryMetrics[0].value)

        // 24. Motor FLC (3ph): 15 kW, 415V, 90% eff, 0.85 PF -> 27.28 A
        val flc = runCalc("motor_flc", mapOf("power" to 15.0, "voltage" to 415.0, "efficiency" to 90.0, "pf" to 0.85), mapOf("phase" to "3φ", "power" to "kW")).getOrThrow()
        assertEquals("27.28", flc.primaryValue)

        // 29. Motor Slip: 50Hz, 4 poles, 1440 RPM -> 4%
        val slip = runCalc("motor_slip", mapOf("freq" to 50.0, "poles" to 4.0, "rotor_rpm" to 1440.0)).getOrThrow()
        assertEquals("4", slip.primaryValue)

        // 30. Motor Torque: 15 kW @ 1460 RPM -> 98.11 N.m
        val torque = runCalc("motor_torque", mapOf("power" to 15.0, "rpm" to 1460.0), mapOf("power" to "kW")).getOrThrow()
        assertEquals("98.11", torque.primaryValue)

        // 35. Fault Level MVA: Isc = 25 kA @ 11 kV -> sqrt(3) * 11 * 25 = 476.31 MVA
        val fault = runCalc("power_fault_level_mva", mapOf("voltage" to 11.0, "isc_ka" to 25.0), mapOf("voltage" to "kV")).getOrThrow()
        assertEquals("476.31", fault.primaryValue)

        // 42. Capacitor Discharge Time: 100 uF, 470 kOhm, 400V -> 50V: ln(8)*47 = 97.73 s
        val dis = runCalc("more_capacitor_discharge", mapOf("cap_uf" to 100.0, "res_kohm" to 470.0, "v0" to 400.0, "vsafe" to 50.0), mapOf("res_kohm" to "kΩ")).getOrThrow()
        assertEquals("97.73", dis.primaryValue)

        // 43. Battery Backup Time: 12V, 100Ah, 200W, 85% eff, 80% DoD -> 4.08 hr
        val bat = runCalc("more_battery_backup", mapOf("v_bank" to 12.0, "ah" to 100.0, "load" to 200.0, "eff" to 85.0, "dod" to 80.0), mapOf("load" to "W")).getOrThrow()
        assertEquals("4.08", bat.primaryValue)
    }

    @Test
    fun instrumentationCoreCalculationsAccuracy() {
        // 1. 4-20 mA to PV: 12 mA on 0..100 -> 50
        val maPv = runCalc("sig_ma_to_pv", mapOf("ma" to 12.0, "lrv" to 0.0, "urv" to 100.0)).getOrThrow()
        assertEquals("50", maPv.primaryValue)

        // 8. Analog Signal Converter: 12 mA across 250 Ohm -> 3 V
        val sigConv = runCalc("sig_ma_volt_conv", mapOf("sig_val" to 12.0, "res" to 250.0), mapOf("mode" to "mA → V")).getOrThrow()
        assertEquals("3", sigConv.primaryValue)

        // 10. I/P Converter: 12 mA on 0.2..1.0 bar -> 0.6 bar
        val ip = runCalc("sig_ip_converter", mapOf("ma" to 12.0), mapOf("range" to "0.2–1.0 bar", "action" to "Direct")).getOrThrow()
        assertEquals("0.6", ip.primaryValue)

        // 16. DP to Flow (Sqrt): 1600 / 2500 -> 0.8 * 100 = 80 m3/h
        val dpFlow = runCalc("pres_dp_to_flow", mapOf("dp_act" to 1600.0, "dp_max" to 2500.0, "q_max" to 100.0), mapOf("q_max" to "m³/h")).getOrThrow()
        assertEquals("80", dpFlow.primaryValue)

        // 24. Orifice Flow: defaults compute positively
        val orifice = runCalc("flow_orifice_plate", mapOf("d_mm" to 50.0, "pipe_mm" to 100.0, "dp" to 25.0, "rho" to 1000.0, "cd" to 0.61), mapOf("dp" to "kPa")).getOrThrow()
        assertTrue(orifice.primaryValue.toDouble() > 0.0)

        // 31. Vertical Tank Level to Volume: D=2m, H=5m, L=2.5m -> pi*1*2.5 = 7.854 m3
        val vTank = runCalc("lvl_to_vol_vertical", mapOf("dia" to 2.0, "total_h" to 5.0, "level" to 2.5), mapOf("dia" to "m")).getOrThrow()
        assertEquals("7.854", vTank.primaryValue)

        // 32. Horizontal Tank Level to Volume: half full (level=1.0m of D=2.0m, L=4.0m) -> 6.283 m3
        val hTank = runCalc("lvl_to_vol_horizontal", mapOf("dia" to 2.0, "len" to 4.0, "level" to 1.0)).getOrThrow()
        assertEquals("6.283", hTank.primaryValue)

        // 41. RTD PT100 Resistance @ 100°C -> 138.51 Ohm
        val pt100 = runCalc("temp_rtd_res", mapOf("temp_c" to 100.0), mapOf("sensor" to "Pt100 (100 Ω)")).getOrThrow()
        assertEquals("138.51", pt100.primaryValue)

        // 42. RTD PT100 Resistance to Temp @ 138.51 Ohm -> ~100 °C
        val resTemp = runCalc("temp_res_to_temp", mapOf("res" to 138.51), mapOf("sensor" to "Pt100 (100 Ω)")).getOrThrow()
        assertTrue(resTemp.primaryValue.toDouble() in 99.9..100.1)

        // 43. Thermocouple Type K mV to °C: 4.096 mV @ 0°C CJC -> ~100 °C
        val tcK = runCalc("temp_tc_k_mv_to_c", mapOf("mv" to 4.096, "cjc" to 0.0)).getOrThrow()
        assertTrue(tcK.primaryValue.toDouble() in 99.5..100.5)
    }

    @Test
    fun searchSupportsEnglishHindiAndAll100Calculators() {
        assertTrue(CalculatorRegistry.search("4-20 mA").any { it.id == "sig_ma_to_pv" })
        assertTrue(CalculatorRegistry.search("Transformer").any { it.category == CalculatorCategory.ELEC_TRANSFORMER })
        assertTrue(CalculatorRegistry.search("मोटर").any { it.category == CalculatorCategory.ELEC_MOTOR })
        assertTrue(CalculatorRegistry.search("PT100").any { it.id == "temp_rtd_res" })
        assertTrue(CalculatorRegistry.search("Orifice").any { it.id == "flow_orifice_plate" })
    }

    @Test
    fun allCalculatorPresetsAndInvalidInputsHandledSafely() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            calc.presets.forEach { preset ->
                val values = calc.fields.associate { f ->
                    val raw = preset.values[f.id] ?: f.defaultValue
                    f.id to (raw.toDoubleOrNull() ?: 1.0)
                }
                val units = calc.fields.associate { f ->
                    f.id to (preset.units[f.id] ?: f.defaultUnit)
                }
                val output = calc.compute(values, units).getOrThrow()
                assertFalse("Empty primaryValue for ${calc.id} preset", output.primaryValue.isBlank())
            }

            val defVals = calc.fields.associate { it.id to (it.defaultValue.toDoubleOrNull() ?: 1.0) }
            val defUnits = calc.fields.associate { it.id to it.defaultUnit }

            calc.fields.filterNot { it.isSelectorOnly }.forEach { field ->
                val nanRes = calc.compute(defVals + (field.id to Double.NaN), defUnits)
                assertTrue("NaN not rejected for ${calc.id}.${field.id}", nanRes.isFailure)
                assertTrue(nanRes.exceptionOrNull() is BilingualValidationException)

                val infRes = calc.compute(defVals + (field.id to Double.POSITIVE_INFINITY), defUnits)
                assertTrue("Infinity not rejected for ${calc.id}.${field.id}", infRes.isFailure)

                val zeroRes = calc.compute(defVals + (field.id to 0.0), defUnits)
                zeroRes.onSuccess { out ->
                    assertFalse("NaN output on zero for ${calc.id}", out.primaryValue.contains("NaN"))
                    assertFalse("Infinity output on zero for ${calc.id}", out.primaryValue.contains("Infinity"))
                }
            }
        }
    }
}
