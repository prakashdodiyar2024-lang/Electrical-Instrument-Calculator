package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onLast
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import com.example.domain.CalculatorRegistry
import com.example.model.CalculatorCategory
import com.example.ui.theme.EICalculatorTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CalculatorUiAndViewModelTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun homeLanguageToggleSwitchesToHindiAndBack() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("सभी").assertIsDisplayed()

        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("All").assertIsDisplayed()
    }

    @Test
    fun openCalculatorComputeValidateAndReset() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Filter via search to open 4-20mA linear calculator
        composeRule.onNodeWithTag("search_input").performTextInput("4–20 mA ↔ PV")
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_ma_pv_linear"))
        composeRule.onNodeWithTag("calc_card_ma_pv_linear").performClick()

        // Verify calculator screen opened and initial result is rendered inside calculator_list
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("calculate_button"))
        composeRule.onNodeWithTag("calculate_button").performScrollTo()
        composeRule.onNodeWithTag("calculate_button").assertIsDisplayed()

        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
        composeRule.onNodeWithTag("primary_result_value").performScrollTo()
        composeRule.onNodeWithTag("primary_result_value").assertIsDisplayed()

        // Clear input_val and tap Calculate -> expect bilingual error banner
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("input_field_input_val"))
        composeRule.onNodeWithTag("input_field_input_val").performScrollTo()
        composeRule.onNodeWithTag("input_field_input_val").performTextClearance()
        composeRule.onNodeWithTag("calculate_button").performScrollTo()
        composeRule.onNodeWithTag("calculate_button").performClick()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("error_banner"))
        composeRule.onNodeWithTag("error_banner").assertIsDisplayed()

        // Click Clear -> resets to default values and clears previous outcome; click Calculate -> shows clean result card only
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("reset_button"))
        composeRule.onNodeWithTag("reset_button").performScrollTo()
        composeRule.onNodeWithTag("reset_button").performClick()
        composeRule.onNodeWithTag("calculate_button").performScrollTo()
        composeRule.onNodeWithTag("calculate_button").performClick()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
        composeRule.onNodeWithTag("result_card").assertIsDisplayed()
        composeRule.onNodeWithTag("primary_result_value").performScrollTo().assertIsDisplayed()

        // Formula, Substitution, Step-by-Step Calculation, and Explanation must stay hidden automatically
        composeRule.onNodeWithTag("steps_card").assertDoesNotExist()
        composeRule.onNodeWithTag("substituted_formula_box").assertDoesNotExist()
        composeRule.onNodeWithTag("solution_final_answer").assertDoesNotExist()
        composeRule.onNodeWithTag("result_explanation_box").assertDoesNotExist()
        composeRule.onNodeWithTag("practical_example_card").assertDoesNotExist()
        composeRule.onNodeWithTag("assumptions_banner").assertDoesNotExist()
        composeRule.onNodeWithTag("formula_dialog").assertDoesNotExist()

        // Optional "See Formula" button opens formula dialog only when explicitly clicked
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("see_formula_button"))
        composeRule.onNodeWithTag("see_formula_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("formula_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("close_formula_dialog_button").performClick()
        composeRule.onNodeWithTag("formula_dialog").assertDoesNotExist()
    }

    @Test
    fun all9CategoriesOpenAndShowAllCalculators() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        CalculatorCategory.entries.forEach { cat ->
            composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("category_card_${cat.id}"))
            composeRule.onNodeWithTag("category_card_${cat.id}").performClick()
            CalculatorRegistry.getByCategory(cat).forEach { calc ->
                composeRule.onNodeWithTag("category_list").performScrollToNode(hasTestTag("calc_card_${calc.id}"))
                composeRule.onNodeWithTag("calc_card_${calc.id}").assertIsDisplayed()
                composeRule.onNodeWithTag("calc_card_${calc.id}").performClick()

                composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("calculate_button"))
                composeRule.onNodeWithTag("calculate_button").performScrollTo()
                composeRule.onNodeWithTag("calculate_button").performClick()

                composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
                composeRule.onNodeWithTag("primary_result_value").performScrollTo()
                composeRule.onNodeWithTag("primary_result_value").assertIsDisplayed()

                composeRule.onNodeWithTag("steps_card").assertDoesNotExist()
                composeRule.onNodeWithTag("substituted_formula_box").assertDoesNotExist()
                composeRule.onNodeWithTag("solution_final_answer").assertDoesNotExist()
                composeRule.onNodeWithTag("result_explanation_box").assertDoesNotExist()

                composeRule.onNodeWithTag("calculator_back_button").performClick()
            }
            composeRule.onNodeWithTag("category_back_button").performClick()
        }
    }

    @Test
    fun searchAndQuickToolCardsOpenCalculators() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Click Quick Field Tool card for 4-20 mA linear scaling
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("popular_card_ma_pv_linear"))
        composeRule.onNodeWithTag("popular_card_ma_pv_linear").performClick()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
        composeRule.onNodeWithTag("primary_result_value").performScrollTo()
        composeRule.onNodeWithTag("primary_result_value").assertIsDisplayed()
        composeRule.onNodeWithTag("calculator_back_button").performClick()

        // Search using ASCII hyphen and space "4-20 mA" -> all three 4-20 mA calculators appear and open
        composeRule.onNodeWithTag("search_input").performTextInput("4-20 mA")
        listOf("ma_pv_linear", "ma_dp_sqrt", "ma_loop_resistance").forEach { id ->
            composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_$id"))
            composeRule.onNodeWithTag("calc_card_$id").performClick()
            composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
            composeRule.onNodeWithTag("primary_result_value").performScrollTo()
            composeRule.onNodeWithTag("primary_result_value").assertIsDisplayed()
            composeRule.onNodeWithTag("calculator_back_button").performClick()
        }

        // Clear search button resets view
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("search_clear_button"))
        composeRule.onNodeWithTag("search_clear_button").performClick()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("category_card_electrical"))
        composeRule.onNodeWithTag("category_card_electrical").assertIsDisplayed()
    }

    @Test
    fun splashScreenDisplaysLogoAndTransitionsToHome() {
        composeRule.mainClock.autoAdvance = false
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp()
            }
        }

        composeRule.mainClock.advanceTimeByFrame()
        composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()
        composeRule.onNodeWithText("Electrical & Instrument Calculator").assertIsDisplayed()
        composeRule.onNodeWithText("29 Professional Engineering Tools").assertIsDisplayed()

        // Remains visible before 5 seconds (5000 ms) elapse
        composeRule.mainClock.advanceTimeBy(2500L)
        composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
        composeRule.mainClock.advanceTimeBy(2300L)
        composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()

        // Automatically transitions smoothly to Home Screen after 5 seconds (5000 ms)
        composeRule.mainClock.advanceTimeBy(400L)
        composeRule.mainClock.autoAdvance = true
        composeRule.onNodeWithTag("home_list").assertIsDisplayed()
        composeRule.onNodeWithTag("home_brand_logo").assertIsDisplayed()
        composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()
    }

    @Test
    fun aboutUsScreenDisplaysDeveloperBrandAndYoutubeLink() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Open About Us via header button
        composeRule.onNodeWithTag("about_us_button").performClick()
        composeRule.onNodeWithTag("about_brand_logo").assertIsDisplayed()
        composeRule.onAllNodesWithText("Electrical & Instrument Calculator").onFirst().assertIsDisplayed()
        composeRule.onAllNodesWithText("Electrical & Instrumentation").onFirst().assertIsDisplayed()

        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("developer_details_card"))
        composeRule.onAllNodesWithText("Electrical & Instrument Calculator").onLast().assertIsDisplayed()
        composeRule.onNodeWithText("Er. Prakash Dodiyar").assertIsDisplayed()
        composeRule.onAllNodesWithText("Electrical & Instrumentation").onLast().assertIsDisplayed()

        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("youtube_card"))
        composeRule.onNodeWithText("https://youtube.com/@Electricalandinstrument").assertIsDisplayed()
        composeRule.onNodeWithTag("youtube_channel_button").assertIsDisplayed()

        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("contact_us_card"))
        composeRule.onNodeWithTag("contact_us_card").assertIsDisplayed()

        // Toggle Hindi on About screen and back to English
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("हमारे बारे में और डेवलपर").assertIsDisplayed()
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("About Us & Developer").assertIsDisplayed()

        // Navigate back to Home and also verify bottom About Us card works
        composeRule.onNodeWithTag("about_back_button").performClick()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("about_us_home_card"))
        composeRule.onNodeWithTag("about_us_home_card").performClick()
        composeRule.onNodeWithTag("about_brand_logo").assertIsDisplayed()
    }
}
