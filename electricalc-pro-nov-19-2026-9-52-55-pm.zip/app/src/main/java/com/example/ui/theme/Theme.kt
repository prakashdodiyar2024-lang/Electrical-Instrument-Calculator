package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val DarkEngineeringColorScheme = darkColorScheme(
    primary = LightBluePrimary,
    onPrimary = ObsidianBlack,
    primaryContainer = LightBlueContainer,
    onPrimaryContainer = CrispLightText,
    secondary = SafetyOrange,
    onSecondary = PureWhite,
    secondaryContainer = DarkOrangeContainer,
    onSecondaryContainer = BrightOrangeAccent,
    tertiary = ElectricBlueBright,
    onTertiary = ObsidianBlack,
    tertiaryContainer = DarkElectricTint,
    onTertiaryContainer = CrispLightText,
    background = DarkBlueprintBg,
    onBackground = CrispLightText,
    surface = DarkBlueprintSurface,
    onSurface = CrispLightText,
    surfaceVariant = DarkBlueprintSurfaceVariant,
    onSurfaceVariant = MutedLightText,
    outline = BlueBorder,
    outlineVariant = DarkBorderSubtle,
    error = StatusErrorRed,
    onError = ObsidianBlack,
    errorContainer = StatusErrorBg,
    onErrorContainer = StatusErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = CobaltBlue,
    onPrimary = PureWhite,
    primaryContainer = SkyBlueTint,
    onPrimaryContainer = DeepNavy,
    secondary = SafetyOrange,
    onSecondary = PureWhite,
    secondaryContainer = SoftOrangeTint,
    onSecondaryContainer = WarmOrange,
    tertiary = ElectricBlue,
    onTertiary = PureWhite,
    tertiaryContainer = SkyBlueTint,
    onTertiaryContainer = DeepNavy,
    background = CoolIceBackground,
    onBackground = InkDark,
    surface = ElevatedWhite,
    onSurface = InkDark,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = SlateMuted,
    outline = BlueBorder,
    outlineVariant = OutlineSubtle,
    error = StatusErrorRed,
    onError = PureWhite,
    errorContainer = StatusErrorBg,
    onErrorContainer = StatusErrorRed
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun EICalculatorTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkEngineeringColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
