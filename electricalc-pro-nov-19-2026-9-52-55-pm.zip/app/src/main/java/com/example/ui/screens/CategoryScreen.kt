package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.CalculatorListCard
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.BrightOrangeAccent
import com.example.ui.theme.CrispLightText
import com.example.ui.theme.DarkBlueprintBg
import com.example.ui.theme.DarkBlueprintSurface
import com.example.ui.theme.DarkBlueprintSurfaceElevated
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkElectricTint
import com.example.ui.theme.DarkOrangeTint
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBluePrimary
import com.example.ui.theme.MutedLightText
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SafetyOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryScreen(
    category: CalculatorCategory,
    language: AppLanguage,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onOpenCalculator: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val calculators = CalculatorRegistry.getByCategory(category)
    val playClick = rememberTouchClickSound()
    val isOrange = category.isOrangeAccent
    val accentColor = if (isOrange) SafetyOrange else ElectricBlue
    val accentText = if (isOrange) BrightOrangeAccent else LightBluePrimary
    val iconBg = if (isOrange) DarkOrangeTint else DarkElectricTint

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ObsidianBlack,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = category.title.get(language),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            playClick()
                            onBack()
                        },
                        modifier = Modifier.testTag("category_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = if (language == AppLanguage.ENGLISH) "Back" else "वापस जाएं",
                            tint = PureWhite
                        )
                    }
                },
                actions = {
                    LanguageToggleChip(
                        language = language,
                        onToggle = onToggleLanguage,
                        darkSurface = true,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavy
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DarkBlueprintBg, ObsidianBlack)
                    )
                )
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .align(Alignment.TopCenter)
                    .testTag("category_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = DarkBlueprintSurface,
                        border = BorderStroke(1.dp, DarkBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp)
                                    .background(accentColor)
                            )
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(iconBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = category.icon,
                                        contentDescription = null,
                                        tint = accentText,
                                        modifier = Modifier.size(27.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = category.title.get(language),
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = CrispLightText,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(50),
                                            color = DarkBlueprintSurfaceElevated,
                                            border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
                                        ) {
                                            Text(
                                                text = if (language == AppLanguage.ENGLISH) {
                                                    "${calculators.size} Tools"
                                                } else {
                                                    "${calculators.size} टूल्स"
                                                },
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = JetBrainsMonoFontFamily,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                color = accentText,
                                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = category.description.get(language),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedLightText
                                    )
                                }
                            }
                        }
                    }
                }

                items(calculators, key = { it.id }) { calc ->
                    CalculatorListCard(
                        calculator = calc,
                        language = language,
                        onClick = { onOpenCalculator(calc.id) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
                }
            }
        }
    }
}
