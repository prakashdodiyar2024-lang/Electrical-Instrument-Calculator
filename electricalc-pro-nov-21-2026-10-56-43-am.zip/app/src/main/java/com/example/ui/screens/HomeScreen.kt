package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.model.EngineeringDiscipline
import com.example.ui.CalculatorScreenUiState
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.CalculatorListCard
import com.example.ui.components.CategoryBlueHeader
import com.example.ui.components.EngineeringHeroHeader
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.SoftBlueChip
import com.example.ui.theme.SubtleGreyBorder
import com.example.ui.theme.TabUnderlineRed
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun HomeScreen(
    uiState: CalculatorScreenUiState,
    onToggleLanguage: () -> Unit,
    onSelectDiscipline: (EngineeringDiscipline) -> Unit,
    onSelectCategoryTab: (CalculatorCategory) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onOpenCalculator: (String) -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val isSearching = uiState.searchQuery.isNotBlank()
    val keyboardController = LocalSoftwareKeyboardController.current
    val playClick = rememberTouchClickSound()

    val disciplineCategories = remember(uiState.selectedDiscipline) {
        CalculatorCategory.forDiscipline(uiState.selectedDiscipline)
    }
    val activeCategory = if (uiState.selectedCategory.discipline == uiState.selectedDiscipline) {
        uiState.selectedCategory
    } else {
        disciplineCategories.first()
    }
    val categoryCalculators = remember(activeCategory) {
        CalculatorRegistry.getByCategory(activeCategory)
    }

    val electricalCount = CalculatorRegistry.electricalCalculators.size
    val instrumentationCount = CalculatorRegistry.instrumentationCalculators.size
    val combinedCount = CalculatorRegistry.allCalculators.size

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .align(Alignment.TopCenter)
                .testTag("home_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RoyalBlue)
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    EngineeringHeroHeader(
                        language = lang,
                        totalCalculators = combinedCount,
                        onToggleLanguage = onToggleLanguage,
                        onOpenAbout = onOpenAbout
                    )
                }
            }

            // Total Counter Summary Strip (50 Electrical + 50 Instrumentation = 100 Calculators)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CounterPill(
                        label = if (lang == AppLanguage.ENGLISH) "Electrical" else "इलेक्ट्रिकल",
                        countText = "$electricalCount",
                        highlighted = uiState.selectedDiscipline == EngineeringDiscipline.ELECTRICAL,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("counter_electrical")
                    )
                    CounterPill(
                        label = if (lang == AppLanguage.ENGLISH) "Instrumentation" else "इंस्ट्रूमेंट",
                        countText = "$instrumentationCount",
                        highlighted = uiState.selectedDiscipline == EngineeringDiscipline.INSTRUMENTATION,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("counter_instrumentation")
                    )
                    CounterPill(
                        label = if (lang == AppLanguage.ENGLISH) "Combined" else "कुल टूल्स",
                        countText = "$combinedCount",
                        highlighted = false,
                        isTotal = true,
                        modifier = Modifier
                            .weight(0.95f)
                            .testTag("counter_total")
                    )
                }
            }

            // Discipline Switcher: Electrical Calculator (50) vs Instrumentation Calculator (50)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DisciplineCard(
                        discipline = EngineeringDiscipline.ELECTRICAL,
                        icon = Icons.Rounded.Bolt,
                        toolCount = electricalCount,
                        selected = uiState.selectedDiscipline == EngineeringDiscipline.ELECTRICAL,
                        language = lang,
                        onClick = {
                            playClick()
                            onSelectDiscipline(EngineeringDiscipline.ELECTRICAL)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("discipline_electrical")
                    )
                    DisciplineCard(
                        discipline = EngineeringDiscipline.INSTRUMENTATION,
                        icon = Icons.Rounded.Speed,
                        toolCount = instrumentationCount,
                        selected = uiState.selectedDiscipline == EngineeringDiscipline.INSTRUMENTATION,
                        language = lang,
                        onClick = {
                            playClick()
                            onSelectDiscipline(EngineeringDiscipline.INSTRUMENTATION)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("discipline_instrumentation")
                    )
                }
            }

            // Clean Search Bar across all 100 calculators
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("search_input"),
                    placeholder = {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) {
                                "Search 100 calculators (Ohm, Motor, 4-20mA, Orifice, Pt100)..."
                            } else {
                                "100 कैलकुलेटर खोजें (Ohm, मोटर, 4-20mA, ऑरिफिस, Pt100)..."
                            },
                            color = TextSecondaryDark,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = RoyalBlue
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    playClick()
                                    onSearchQueryChange("")
                                },
                                modifier = Modifier.testTag("search_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = TextPrimaryDark
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = { keyboardController?.hide() }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = CardLightGrey,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark,
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = LightBlueBorder,
                        cursorColor = RoyalBlue
                    )
                )
            }

            if (isSearching) {
                item {
                    Text(
                        text = if (lang == AppLanguage.ENGLISH) {
                            "Matching Calculators (${uiState.searchResults.size})"
                        } else {
                            "मिले हुए कैलकुलेटर (${uiState.searchResults.size})"
                        },
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = DarkNavyBlue,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                    )
                }

                if (uiState.searchResults.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                            border = BorderStroke(1.dp, LightBlueBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.SearchOff,
                                    contentDescription = null,
                                    tint = RoyalBlue,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "No calculators found for \"${uiState.searchQuery}\""
                                    } else {
                                        "\"${uiState.searchQuery}\" के लिए कोई कैलकुलेटर नहीं मिला"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Try terms like Ohm, Transformer, FLC, 4-20mA, Orifice, Tank, PT100"
                                    } else {
                                        "कृपया Ohm, ट्रांसफॉर्मर, FLC, 4-20mA, ऑरिफिस, टैंक या PT100 खोजें"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                } else {
                    items(uiState.searchResults, key = { it.id }) { calc ->
                        CalculatorListCard(
                            calculator = calc,
                            language = lang,
                            isFavorite = calc.id in uiState.favoriteIds,
                            onToggleFavorite = { onToggleFavorite(calc.id) },
                            showCategoryTag = true,
                            onClick = { onOpenCalculator(calc.id) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                // 5 Horizontal Category Tabs with Royal Blue text & Red Underline for selected tab
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp)
                                .testTag("category_tabs_row"),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            disciplineCategories.forEach { cat ->
                                val selected = activeCategory == cat
                                Column(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                                        .background(if (selected) SoftBlueChip else PureWhite)
                                        .clickable {
                                            playClick()
                                            onSelectCategoryTab(cat)
                                        }
                                        .minimumInteractiveComponentSize()
                                        .padding(horizontal = 12.dp)
                                        .testTag("cat_tab_${cat.id}"),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = cat.tabTitle.get(lang),
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                                            fontSize = 13.5.sp
                                        ),
                                        color = if (selected) RoyalBlue else TextPrimaryDark,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .width(42.dp)
                                            .height(3.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(if (selected) TabUnderlineRed else PureWhite)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = HairlineGrey)
                    }
                }

                // Category Blue Header Card (10 Tools)
                item {
                    CategoryBlueHeader(
                        category = activeCategory,
                        calculatorCount = categoryCalculators.size,
                        language = lang,
                        modifier = Modifier
                            .padding(horizontal = 16.dp)
                            .testTag("active_category_header")
                    )
                }

                // 10 Calculator Cards for the selected category
                items(categoryCalculators, key = { it.id }) { calc ->
                    CalculatorListCard(
                        calculator = calc,
                        language = lang,
                        isFavorite = calc.id in uiState.favoriteIds,
                        onToggleFavorite = { onToggleFavorite(calc.id) },
                        onClick = { onOpenCalculator(calc.id) },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                // Recent Calculations strip if any
                if (uiState.recentHistory.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) "Recent Results" else "हाल के परिणाम",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = DarkNavyBlue
                            )
                        }
                    }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(uiState.recentHistory) { item ->
                                Surface(
                                    onClick = {
                                        playClick()
                                        onOpenCalculator(item.calculatorId)
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = CardLightGrey,
                                    border = BorderStroke(1.dp, LightBlueBorder),
                                    modifier = Modifier.testTag("recent_card_${item.calculatorId}")
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                        Text(
                                            text = item.title.get(lang),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextSecondaryDark,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = item.resultSummary,
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontFamily = JetBrainsMonoFontFamily,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = DarkNavyBlue
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CounterPill(
    label: String,
    countText: String,
    highlighted: Boolean,
    modifier: Modifier = Modifier,
    isTotal: Boolean = false
) {
    val bgColor = when {
        highlighted -> RoyalBlueTint
        isTotal -> DarkNavyBlue
        else -> CardLightGrey
    }
    val borderColor = when {
        highlighted -> RoyalBlue
        isTotal -> DarkNavyBlue
        else -> SubtleGreyBorder
    }
    val titleColor = if (isTotal) PureWhite.copy(alpha = 0.85f) else TextSecondaryDark
    val valueColor = when {
        isTotal -> PureWhite
        highlighted -> RoyalBlue
        else -> DarkNavyBlue
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.5.sp
                ),
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = countText,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                color = valueColor,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DisciplineCard(
    discipline: EngineeringDiscipline,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    toolCount: Int,
    selected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = if (selected) RoyalBlue else PureWhite
    val borderColor = if (selected) DarkNavyBlue else LightBlueBorder
    val titleColor = if (selected) PureWhite else DarkNavyBlue
    val subtitleColor = if (selected) PureWhite.copy(alpha = 0.90f) else TextSecondaryDark
    val iconBg = if (selected) PureWhite.copy(alpha = 0.20f) else RoyalBlueTint
    val iconTint = if (selected) PureWhite else RoyalBlue

    Card(
        onClick = onClick,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 3.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (selected) PureWhite.copy(alpha = 0.20f) else SoftBlueChip,
                    border = BorderStroke(
                        1.dp,
                        if (selected) PureWhite.copy(alpha = 0.35f) else LightBlueBorder
                    )
                ) {
                    Text(
                        text = "$toolCount",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (selected) PureWhite else RoyalBlue,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Column {
                Text(
                    text = discipline.title.get(language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        lineHeight = 18.sp
                    ),
                    color = titleColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = discipline.subtitle.get(language),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = subtitleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
