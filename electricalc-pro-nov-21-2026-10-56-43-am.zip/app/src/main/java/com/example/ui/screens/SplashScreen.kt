package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.components.BrandLogoBadge
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.SoftBlueChip
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

const val SPLASH_DURATION_MS = 5000L

@Composable
fun SplashScreen(
    language: AppLanguage,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
    sessionKey: Int = 0,
    durationMillis: Long = SPLASH_DURATION_MS
) {
    val scale = remember(sessionKey) { Animatable(0.88f) }
    val contentAlpha = remember(sessionKey) { Animatable(0.4f) }
    val progress = remember(sessionKey) { Animatable(0f) }
    var hasFinished by remember(sessionKey) { mutableStateOf(false) }
    val currentOnFinish by rememberUpdatedState(onFinish)

    LaunchedEffect(sessionKey) {
        if (hasFinished) return@LaunchedEffect
        val effectiveDuration = durationMillis.coerceAtLeast(0L)
        withFrameNanos { }
        launch {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            contentAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 550)
            )
        }
        launch {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = effectiveDuration.toInt().coerceAtLeast(1),
                    easing = LinearEasing
                )
            )
        }
        delay(effectiveDuration)
        if (!hasFinished) {
            hasFinished = true
            currentOnFinish()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .testTag("splash_screen")
    ) {
        // Blueprint grid, royal-blue reticle arcs, and AC waveform on crisp white
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 32.dp.toPx()
            val gridColor = HairlineGrey.copy(alpha = 0.75f)
            var x = 0f
            while (x < size.width) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }

            val glowCenter = Offset(size.width / 2f, size.height * 0.41f)
            val glowRadius = size.minDimension * 0.45f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        RoyalBlue.copy(alpha = 0.08f),
                        LightBlueBorder.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = glowCenter,
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = glowCenter
            )

            val outerArcRadius = 114.dp.toPx()
            drawArc(
                color = RoyalBlue.copy(alpha = 0.22f),
                startAngle = 140f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = Offset(glowCenter.x - outerArcRadius, glowCenter.y - outerArcRadius),
                size = Size(outerArcRadius * 2, outerArcRadius * 2),
                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
            )

            val innerArcRadius = 96.dp.toPx()
            drawArc(
                color = DarkNavyBlue.copy(alpha = 0.16f),
                startAngle = -35f,
                sweepAngle = 210f,
                useCenter = false,
                topLeft = Offset(glowCenter.x - innerArcRadius, glowCenter.y - innerArcRadius),
                size = Size(innerArcRadius * 2, innerArcRadius * 2),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )

            val wavePath = Path()
            val amp = 12.dp.toPx()
            val baseY = size.height * 0.84f
            wavePath.moveTo(0f, baseY)
            var wx = 0f
            while (wx <= size.width) {
                val wy = baseY + sin(wx / 42f) * amp
                wavePath.lineTo(wx, wy)
                wx += 8f
            }
            drawPath(
                path = wavePath,
                color = LightBlueBorder.copy(alpha = 0.55f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .alpha(contentAlpha.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(scale.value)
            ) {
                BrandLogoBadge(
                    size = 128.dp,
                    modifier = Modifier.testTag("splash_logo")
                )

                Spacer(modifier = Modifier.height(24.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = RoyalBlueTint,
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Text(
                        text = "ELECTRICAL & INSTRUMENTATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.9.sp
                        ),
                        color = RoyalBlue,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Electrical & Instrument Calculator",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        lineHeight = 32.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("splash_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = SoftBlueChip,
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            "100 Professional Engineering Tools"
                        } else {
                            "100 प्रोफेशनल इंजीनियरिंग टूल्स"
                        },
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.3.sp
                        ),
                        color = DarkNavyBlue,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 7.dp)
                            .testTag("splash_subtitle")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (language == AppLanguage.ENGLISH) {
                        "50 Electrical • 50 Instrumentation • EN / हिं"
                    } else {
                        "50 इलेक्ट्रिकल • 50 इंस्ट्रूमेंटेशन • EN / हिं"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                CircularProgressIndicator(
                    color = RoyalBlue,
                    trackColor = HairlineGrey,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress.value },
                    color = RoyalBlue,
                    trackColor = HairlineGrey,
                    modifier = Modifier
                        .width(200.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(50))
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (language == AppLanguage.ENGLISH) {
                        "Developed by Er. Prakash Dodiyar"
                    } else {
                        "डेवलपर: Er. प्रकाश डोडियार (Er. Prakash Dodiyar)"
                    },
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (language == AppLanguage.ENGLISH) {
                        "Loading 100 engineering calculators..."
                    } else {
                        "100 इंजीनियरिंग कैलकुलेटर लोड हो रहे हैं..."
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryDark
                )
            }
        }
    }
}
