package com.example.domain

import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculationOutput
import com.example.model.CalculationStep
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.CalculatorPreset
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireFinite
import com.example.model.requireNonNegative
import com.example.model.requireNonZero
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.sqrt

object InstrumentationProcessCalculators {

    val all: List<CalculatorDefinition> = listOf(
        controlValveCvCalculator(),
        transmitterCalibrationErrorCalculator(),
        dpOrificeFlowCalculator(),
        rtdPt100Calculator(),
        thermocoupleCalculator(),
        temperatureConverterCalculator(),
        pressureConverterCalculator(),
        hydrostaticLevelCalculator(),
        pipeFlowVelocityCalculator(),
        reynoldsNumberCalculator(),
        cableSizingCalculator(),
        cableDeratingCalculator()
    )

    private fun controlValveCvCalculator() = CalculatorDefinition(
        id = "inst_control_valve_cv",
        category = CalculatorCategory.INSTRUMENTATION,
        title = BilingualText("Control Valve Cv & Kv Sizing", "कंट्रोल वाल्व Cv और Kv साइजिंग"),
        subtitle = BilingualText(
            "Calculate Liquid Control Valve flow coefficient Cv & Kv from flow & ΔP",
            "लिक्विड फ्लो, स्पेसिफिक ग्रेविटी और प्रेशर ड्रॉप (ΔP) से कंट्रोल वाल्व Cv व Kv निकालें"
        ),
        formulaPreview = "Cv = Q_gpm × √(SG / ΔP_psi)   |   Kv = 0.865 × Cv",
        keywords = listOf("control valve", "cv", "kv", "flow", "delta p", "कंट्रोल वाल्व", "सीवी"),
        fields = listOf(
            CalculatorField("flow", BilingualText("Liquid Flow Rate (Q)", "लिक्विड फ्लो रेट (Q)"), "25", "m³/h", listOf("m³/h", "LPM", "GPM")),
            CalculatorField("p1", BilingualText("Upstream Pressure (P₁)", "इनलेट प्रेशर (P₁)"), "6.0", "bar", listOf("bar", "psi")),
            CalculatorField("p2", BilingualText("Downstream Pressure (P₂)", "आउटलेट प्रेशर (P₂)"), "4.5", "bar", listOf("bar", "psi")),
            CalculatorField("sg", BilingualText("Specific Gravity (SG)", "स्पेसिफिक ग्रेविटी (पानी=1)"), "1.0", "SG")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Water 25 m³/h, ΔP 1.5 bar", "पानी 25 m³/h, ΔP 1.5 bar"),
                values = mapOf("flow" to "25", "p1" to "6.0", "p2" to "4.5", "sg" to "1.0"),
                units = mapOf("flow" to "m³/h", "p1" to "bar", "p2" to "bar")
            )
        ),
        compute = { values, units ->
            runCatching {
                val rawQ = requirePositive(values["flow"], BilingualText("Flow Rate", "फ्लो रेट"))
                val rawP1 = requirePositive(values["p1"], BilingualText("Upstream Pressure P₁", "इनलेट प्रेशर P₁"))
                val rawP2 = requireNonNegative(values["p2"], BilingualText("Downstream Pressure P₂", "आउटलेट प्रेशर P₂"))
                val sg = requirePositive(values["sg"], BilingualText("Specific Gravity", "स्पेसिफिक ग्रेविटी"))

                val qM3h = when (units["flow"]) {
                    "LPM" -> rawQ * 0.06
                    "GPM" -> rawQ * 0.2271247
                    else -> rawQ
                }
                val qGpm = qM3h / 0.2271247
                val p1Bar = if (units["p1"] == "psi") rawP1 * 0.06894757 else rawP1
                val p2Bar = if (units["p2"] == "psi") rawP2 * 0.06894757 else rawP2
                val dpBar = p1Bar - p2Bar
                if (dpBar <= 0.0) {
                    throw BilingualValidationException(
                        BilingualText(
                            "Upstream pressure P₁ must be higher than downstream pressure P₂.",
                            "इनलेट प्रेशर P₁, आउटलेट प्रेशर P₂ से अधिक होना चाहिए।"
                        )
                    )
                }

                val dpPsi = dpBar * 14.50377
                val cv = qGpm * sqrt(sg / dpPsi)
                val kv = cv * 0.865

                val sgOverDp = sg / dpPsi
                val sqrtFactor = sqrt(sgOverDp)

                CalculationOutput(
                    primaryLabel = BilingualText("Required Valve Cv", "आवश्यक वाल्व Cv"),
                    primaryValue = formatEng(cv, 2),
                    primaryUnit = "Cv (GPM/√psi)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Metric Kv", "मेट्रिक Kv"), formatEng(kv, 2), "m³/h"),
                        SecondaryMetric(BilingualText("Pressure Drop ΔP", "प्रेशर ड्रॉप ΔP"), formatEng(dpBar, 2), "bar (${formatEng(dpPsi, 1)} psi)"),
                        SecondaryMetric(BilingualText("Flow (GPM)", "फ्लो (GPM)"), formatEng(qGpm, 1), "GPM")
                    ),
                    formulaUsed = "Cv = Q_gpm × √(SG / ΔP_psi)   |   Kv = 0.865 × Cv",
                    substitutedFormula = "Cv = ${formatEng(qGpm, 2)} × √(${formatEng(sg, 2)} / ${formatEng(dpPsi, 2)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Flow to GPM & Calculate ΔP in psi", "फ्लो को GPM और ΔP को psi में बदलें"),
                            "Q = ${formatEng(qM3h, 2)} m³/h = ${formatEng(qGpm, 2)} GPM  |  ΔP = ${formatEng(p1Bar, 2)} − ${formatEng(p2Bar, 2)} = ${formatEng(dpBar, 2)} bar (${formatEng(dpPsi, 2)} psi)",
                            BilingualText(
                                "Standard ISA Cv equation requires flow in US GPM and pressure drop in psi.",
                                "ISA Cv सूत्र के लिए फ्लो को US GPM और प्रेशर ड्रॉप (ΔP = P₁ − P₂) को psi में बदलते हैं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Compute SG / ΔP Ratio & Square Root", "SG / ΔP अनुपात और वर्गमूल निकालें"),
                            "√(${formatEng(sg, 2)} / ${formatEng(dpPsi, 2)}) = √(${formatEng(sgOverDp, 4)}) = ${formatEng(sqrtFactor, 4)}",
                            BilingualText(
                                "Accounts for fluid specific gravity relative to water and available pressure drop.",
                                "यह पानी की तुलना में द्रव के घनत्व और वाल्व पर उपलब्ध प्रेशर ड्रॉप को दर्शाता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Multiply by Flow for Cv & Convert to Kv", "फ्लो से गुणा कर Cv और Kv निकालें"),
                            "Cv = ${formatEng(qGpm, 2)} × ${formatEng(sqrtFactor, 4)} = ${formatEng(cv, 2)}  |  Kv = 0.865 × ${formatEng(cv, 2)} = ${formatEng(kv, 2)}",
                            BilingualText(
                                "Select a control valve whose rated Cv at 70–80% travel matches ${formatEng(cv, 1)}.",
                                "ऐसा कंट्रोल वाल्व चुनें जिसका 70–80% ओपनिंग पर Cv लगभग ${formatEng(cv, 1)} हो।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Passing ${formatEng(qM3h, 2)} m³/h (${formatEng(qGpm, 1)} GPM) of SG ${formatEng(sg, 2)} liquid across ΔP = ${formatEng(dpBar, 2)} bar requires Cv = ${formatEng(cv, 2)} (Kv = ${formatEng(kv, 2)}).",
                        "${formatEng(dpBar, 2)} bar प्रेशर ड्रॉप पर ${formatEng(qM3h, 2)} m³/h फ्लो के लिए वाल्व का आवश्यक Cv = ${formatEng(cv, 2)} (Kv = ${formatEng(kv, 2)}) होगा।"
                    ),
                    assumptions = BilingualText(
                        "Assumes non-flashing, non-choked, non-viscous incompressible liquid flow (ISA-75.01 / IEC 60534).",
                        "मान्यता: नॉन-फ्लैशिंग, नॉन-चोक्ड इनकम्प्रेसिबल लिक्विड फ्लो (ISA-75.01)।"
                    )
                )
            }
        }
    )

    private fun transmitterCalibrationErrorCalculator() = CalculatorDefinition(
        id = "inst_tx_error",
        category = CalculatorCategory.INSTRUMENTATION,
        title = BilingualText("Transmitter Calibration Error %", "ट्रांसमीटर कैलिब्रेशन त्रुटि %"),
        subtitle = BilingualText(
            "Check As-Found / As-Left error % of span and expected mA during calibration",
            "कैलिब्रेशन के समय अपेक्षित mA और % स्पैन त्रुटि (Error %) की जांच करें"
        ),
        formulaPreview = "Error% = ((mA_actual − mA_expected) / 16) × 100",
        keywords = listOf("calibration", "error", "transmitter", "span", "zero", "कैलिब्रेशन", "त्रुटि"),
        fields = listOf(
            CalculatorField("applied_pv", BilingualText("Applied Standard Input (PV)", "दिया गया मानक इनपुट (PV)"), "50", "EU", allowNegative = true),
            CalculatorField("lrv", BilingualText("Transmitter LRV (4 mA)", "ट्रांसमीटर LRV (4 mA)"), "0", "EU", allowNegative = true),
            CalculatorField("urv", BilingualText("Transmitter URV (20 mA)", "ट्रांसमीटर URV (20 mA)"), "100", "EU", allowNegative = true),
            CalculatorField("measured_ma", BilingualText("Measured Output (mA)", "मापा गया आउटपुट (mA)"), "12.08", "mA"),
            CalculatorField("tolerance", BilingualText("Max Allowable Tolerance (%)", "स्वीकार्य सीमा (%)"), "0.25", "%")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("50% Point Check (12.08 mA)", "50% पॉइंट जांच (12.08 mA)"),
                values = mapOf("applied_pv" to "50", "lrv" to "0", "urv" to "100", "measured_ma" to "12.08", "tolerance" to "0.25")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val pv = requireFinite(values["applied_pv"], BilingualText("Applied Standard Input (PV)", "दिया गया मानक इनपुट (PV)"))
                val lrv = requireFinite(values["lrv"] ?: 0.0, BilingualText("Transmitter LRV", "ट्रांसमीटर LRV"))
                val urv = requireFinite(values["urv"] ?: 100.0, BilingualText("Transmitter URV", "ट्रांसमीटर URV"))
                val measMa = requireRange(values["measured_ma"], 0.0, 30.0, BilingualText("Measured Output (mA)", "मापा गया आउटपुट (mA)"))
                val tol = requireRange(values["tolerance"], 0.01, 10.0, BilingualText("Tolerance (%)", "स्वीकार्य सीमा (%)"))

                val span = requireNonZero(urv - lrv, BilingualText("Span (URV − LRV)", "स्पैन (URV − LRV)"))
                val expFraction = (pv - lrv) / span
                val expPct = expFraction * 100.0
                val expMa = 4.0 + (expPct / 100.0) * 16.0
                val errMa = measMa - expMa
                val errPct = (errMa / 16.0) * 100.0
                val errPv = (errPct / 100.0) * span
                val pass = abs(errPct) <= tol

                val statusLabel = if (pass) {
                    BilingualText("PASS (≤ ±${formatEng(tol, 2)}%)", "पास (≤ ±${formatEng(tol, 2)}%)")
                } else {
                    BilingualText("ADJUST (> ±${formatEng(tol, 2)}%)", "सुधारें (> ±${formatEng(tol, 2)}%)")
                }

                CalculationOutput(
                    primaryLabel = BilingualText("Calibration Error (% Span)", "कैलिब्रेशन त्रुटि (% स्पैन)"),
                    primaryValue = "${if (errPct >= 0) "+" else ""}${formatEng(errPct, 3)} %",
                    primaryUnit = statusLabel.en,
                    primaryUnitLocalized = statusLabel,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Expected mA", "अपेक्षित mA"), formatEng(expMa, 3), "mA"),
                        SecondaryMetric(BilingualText("Deviation (mA)", "अंतर (mA)"), formatEng(errMa, 3), "mA"),
                        SecondaryMetric(BilingualText("Deviation (PV)", "अंतर (PV)"), formatEng(errPv, 3), "EU")
                    ),
                    formulaUsed = "mA_exp = 4 + 16×[(PV − LRV)/(URV − LRV)]   |   Error% = [(mA_meas − mA_exp)/16] × 100",
                    substitutedFormula = "mA_exp = 4 + 16×[(${formatEng(pv, 2)} − ${formatEng(lrv, 2)})/(${formatEng(urv, 2)} − ${formatEng(lrv, 2)})]   |   Error% = [(${formatEng(measMa, 3)} − ${formatEng(expMa, 3)})/16] × 100",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Calculate Span & Applied Input %", "स्पैन व इनपुट प्रतिशत (%) निकालें"),
                            "Span = ${formatEng(urv, 2)} − ${formatEng(lrv, 2)} = ${formatEng(span, 2)}  |  Input% = (${formatEng(pv - lrv, 2)} / ${formatEng(span, 2)}) × 100 = ${formatEng(expPct, 2)}%",
                            BilingualText(
                                "Determines the exact percentage of calibrated range applied by the calibrator.",
                                "कैलिब्रेटर द्वारा दिए गए इनपुट का कुल स्पैन में प्रतिशत निकालें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Compute Expected Ideal Output (mA_exp)", "अपेक्षित आदर्श आउटपुट (mA_exp) निकालें"),
                            "mA_exp = 4 + (16 × ${formatEng(expFraction, 4)}) = ${formatEng(expMa, 3)} mA",
                            BilingualText(
                                "Ideal 4–20 mA output for ${formatEng(expPct, 1)}% applied input.",
                                "${formatEng(expPct, 1)}% इनपुट पर ट्रांसमीटर का आदर्श आउटपुट ${formatEng(expMa, 3)} mA होना चाहिए।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Find Deviation (mA) & Error (% of 16 mA Span)", "अंतर (mA) और स्पैन त्रुटि % निकालें"),
                            "ΔmA = ${formatEng(measMa, 3)} − ${formatEng(expMa, 3)} = ${formatEng(errMa, 3)} mA  →  Error% = (${formatEng(errMa, 3)} / 16) × 100 = ${formatEng(errPct, 3)}%",
                            BilingualText(
                                if (pass) "Within tolerance (±${formatEng(tol, 2)}%). No trim needed."
                                else "Out of tolerance! Perform Zero/Span trim via HART communicator.",
                                if (pass) "त्रुटि तय सीमा (±${formatEng(tol, 2)}%) के अंदर है — कैलिब्रेशन पास है।"
                                else "त्रुटि सीमा से बाहर है! HART से Zero/Span ट्रिम करें।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        if (pass) "Measured ${formatEng(measMa, 3)} mA differs from ideal ${formatEng(expMa, 3)} mA by ${formatEng(errPct, 3)}% (${formatEng(errPv, 3)} EU), passing the ±${formatEng(tol, 2)}% limit."
                        else "Measured ${formatEng(measMa, 3)} mA deviates by ${formatEng(errPct, 3)}% (${formatEng(errPv, 3)} EU) from ${formatEng(expMa, 3)} mA, exceeding ±${formatEng(tol, 2)}% — trim required.",
                        if (pass) "मापा गया ${formatEng(measMa, 3)} mA आदर्श ${formatEng(expMa, 3)} mA से केवल ${formatEng(errPct, 3)}% दूर है, जो ±${formatEng(tol, 2)}% सीमा के भीतर (पास) है।"
                        else "मापा गया ${formatEng(measMa, 3)} mA, ${formatEng(expMa, 3)} mA से ${formatEng(errPct, 3)}% अलग है जो ±${formatEng(tol, 2)}% सीमा से अधिक है — ट्रिम करें।"
                    ),
                    statusLevel = if (pass) StatusLevel.NORMAL else StatusLevel.WARNING
                )
            }
        }
    )

    private fun dpOrificeFlowCalculator() = CalculatorDefinition(
        id = "inst_dp_orifice_flow",
        category = CalculatorCategory.INSTRUMENTATION,
        title = BilingualText("Orifice DP Flow Rate", "ऑरिफिस DP फ्लो रेट गणना"),
        subtitle = BilingualText(
            "Calculate actual flow rate from Differential Pressure (ΔP) across orifice",
            "ऑरिफिस प्लेट पर मापे गए ΔP से वास्तविक फ्लो रेट निकालें"
        ),
        formulaPreview = "Q = Q_design × √(ΔP_actual / ΔP_design)",
        keywords = listOf("orifice", "dp", "flow", "differential pressure", "ऑरिफिस", "फ्लो"),
        fields = listOf(
            CalculatorField("dp_actual", BilingualText("Measured ΔP", "मापा गया ΔP"), "1600", "mmH₂O"),
            CalculatorField("dp_max", BilingualText("Design Max ΔP (at Q_max)", "डिजाइन अधिकतम ΔP"), "2500", "mmH₂O"),
            CalculatorField("q_max", BilingualText("Design Max Flow (Q_max)", "डिजाइन अधिकतम फ्लो"), "120", "m³/h", listOf("m³/h", "LPM", "kg/h", "TPH"))
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("1600 / 2500 mmH₂O → 80% Flow", "1600 / 2500 mmH₂O → 80% फ्लो"),
                values = mapOf("dp_actual" to "1600", "dp_max" to "2500", "q_max" to "120"),
                units = mapOf("q_max" to "m³/h")
            )
        ),
        compute = { values, units ->
            runCatching {
                val dp = requireNonNegative(values["dp_actual"], BilingualText("Measured ΔP", "मापा गया ΔP"))
                val dpMax = requirePositive(values["dp_max"], BilingualText("Design Max ΔP", "डिजाइन अधिकतम ΔP"))
                val qMax = requirePositive(values["q_max"], BilingualText("Design Max Flow", "डिजाइन अधिकतम फ्लो"))
                val qUnit = units["q_max"] ?: "m³/h"

                val ratio = dp / dpMax
                val flowRatio = sqrt(ratio)
                val qActual = qMax * flowRatio
                val maLinear = 4.0 + 16.0 * ratio
                val maSqrt = 4.0 + 16.0 * flowRatio
                val overRange = dp > dpMax

                CalculationOutput(
                    primaryLabel = BilingualText("Actual Flow Rate (Q)", "वास्तविक फ्लो रेट (Q)"),
                    primaryValue = formatEng(qActual, 2),
                    primaryUnit = "$qUnit (${formatEng(flowRatio * 100.0, 1)}%)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Linear DP %", "लीनियर DP %"), formatEng(ratio * 100.0, 1), "%"),
                        SecondaryMetric(BilingualText("Tx Linear Output", "लीनियर mA"), formatEng(maLinear, 2), "mA"),
                        SecondaryMetric(BilingualText("Tx √ Output", "वर्गमूल mA"), formatEng(maSqrt, 2), "mA")
                    ),
                    formulaUsed = "Q = Q_max × √(ΔP / ΔP_max)",
                    substitutedFormula = "Q = ${formatEng(qMax, 1)} × √(${formatEng(dp, 1)} / ${formatEng(dpMax, 1)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Compute Differential Pressure Ratio", "ΔP अनुपात निकालें"),
                            "ΔP / ΔP_max = ${formatEng(dp, 1)} / ${formatEng(dpMax, 1)} = ${formatEng(ratio, 4)}  (${formatEng(ratio * 100.0, 1)}% DP)",
                            BilingualText(
                                "Express measured ΔP as a fraction of the design full-scale ΔP.",
                                "मापे गए ΔP को डिजाइन अधिकतम ΔP के अनुपात में बदलें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Take Square Root of DP Ratio", "DP अनुपात का वर्गमूल (√) निकालें"),
                            "Flow_frac = √(${formatEng(ratio, 4)}) = ${formatEng(flowRatio, 4)}  (${formatEng(flowRatio * 100.0, 1)}% Flow)",
                            BilingualText(
                                "Bernoulli's principle: flow through a restriction is proportional to √ΔP.",
                                "बर्नौली नियम के अनुसार ऑरिफिस से बहने वाला फ्लो ΔP के वर्गमूल के समानुपाती होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Multiply by Design Max Flow (Q_max)", "डिजाइन अधिकतम फ्लो से गुणा करें"),
                            "Q = ${formatEng(qMax, 1)} × ${formatEng(flowRatio, 4)} = ${formatEng(qActual, 2)} $qUnit",
                            BilingualText(
                                "Scales the square-root flow fraction to engineering flow units.",
                                "फ्लो अनुपात को अधिकतम डिजाइन फ्लो (Q_max) से गुणा करके असली फ्लो प्राप्त करें।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Expected 4–20 mA Signals (Linear vs √)", "अपेक्षित 4–20 mA सिग्नल (लीनियर बनाम वर्गमूल)"),
                            "Linear mA = ${formatEng(maLinear, 2)} mA  |  √ Extracted mA = ${formatEng(maSqrt, 2)} mA",
                            BilingualText(
                                "Compare against PLC/DCS readout depending on whether square-root is enabled in the transmitter.",
                                "ट्रांसमीटर की सेटिंग (Linear या √) के अनुसार लूप mA से मिलान करें।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "At ΔP = ${formatEng(dp, 1)} (${formatEng(ratio * 100.0, 1)}% of ${formatEng(dpMax, 1)}), actual flow is ${formatEng(flowRatio * 100.0, 1)}% of Q_max = ${formatEng(qActual, 2)} $qUnit.",
                        "${formatEng(dp, 1)} ΔP (फुल ΔP का ${formatEng(ratio * 100.0, 1)}%) पर वास्तविक फ्लो ${formatEng(flowRatio * 100.0, 1)}% यानी ${formatEng(qActual, 2)} $qUnit है।"
                    ),
                    assumptions = BilingualText(
                        "Assumes constant fluid density, discharge coefficient, and same DP unit for ΔP and ΔP_max.",
                        "मान्यता: द्रव का घनत्व स्थिर है और दोनों ΔP एक ही यूनिट में हैं।"
                    ),
                    statusLevel = if (overRange) StatusLevel.WARNING else StatusLevel.NORMAL,
                    engineeringNote = if (overRange) BilingualText(
                        "Measured ΔP exceeds design ΔP_max — transmitter is in overrange!",
                        "मापा गया ΔP डिजाइन सीमा से अधिक है — ट्रांसमीटर ओवररेंज में है!"
                    ) else null
                )
            }
        }
    )

    private fun rtdPt100Calculator() = CalculatorDefinition(
        id = "rtd_pt100_pt1000",
        category = CalculatorCategory.RTD_THERMOCOUPLE,
        title = BilingualText("Pt100 / Pt1000 RTD Calculator", "Pt100 / Pt1000 RTD कैलकुलेटर"),
        subtitle = BilingualText(
            "Convert °C ↔ Ohms (Ω) using IEC 60751 Callendar–Van Dusen standard",
            "IEC 60751 मानक से Pt100 या Pt1000 के तापमान (°C) ↔ रेजिस्टेंस (Ω) की गणना करें"
        ),
        formulaPreview = "R(T) = R₀(1 + A·T + B·T² + C(T−100)T³)",
        keywords = listOf("rtd", "pt100", "pt1000", "ohm", "temperature", "iec 60751", "आरटीडी", "पीटी100"),
        fields = listOf(
            CalculatorField(
                id = "sensor_r0",
                label = BilingualText("RTD Sensor Type", "RTD सेंसर प्रकार चुनें"),
                defaultValue = "100",
                defaultUnit = "Pt100 (100Ω)",
                unitOptions = listOf("Pt100 (100Ω)", "Pt1000 (1000Ω)"),
                isSelectorOnly = true
            ),
            CalculatorField(
                id = "input_val",
                label = BilingualText("Input (°C or Ω)", "इनपुट (°C या Ω)"),
                defaultValue = "100",
                defaultUnit = "°C",
                unitOptions = listOf("°C", "Ω"),
                allowNegative = true
            ),
            CalculatorField(
                id = "lead_ohm",
                label = BilingualText("Lead Wire Resistance (per wire, 2-wire)", "लीड वायर रेजिस्टेंस (यदि 2-वायर है)"),
                defaultValue = "0",
                defaultUnit = "Ω"
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Pt100 @ 100 °C → 138.51 Ω", "Pt100 @ 100 °C → 138.51 Ω"),
                values = mapOf("input_val" to "100", "lead_ohm" to "0"),
                units = mapOf("input_val" to "°C", "sensor_r0" to "Pt100 (100Ω)")
            ),
            CalculatorPreset(
                label = BilingualText("Pt100 @ 157.33 Ω → 150 °C", "Pt100 @ 157.33 Ω → 150 °C"),
                values = mapOf("input_val" to "157.33", "lead_ohm" to "0"),
                units = mapOf("input_val" to "Ω", "sensor_r0" to "Pt100 (100Ω)")
            ),
            CalculatorPreset(
                label = BilingualText("Pt1000 @ -50 °C → 803.06 Ω", "Pt1000 @ -50 °C → 803.06 Ω"),
                values = mapOf("input_val" to "-50", "lead_ohm" to "0"),
                units = mapOf("input_val" to "°C", "sensor_r0" to "Pt1000 (1000Ω)")
            )
        ),
        compute = { values, units ->
            runCatching {
                val a = 3.9083e-3
                val b = -5.775e-7
                val c = -4.183e-12

                val r0Unit = units["sensor_r0"] ?: "Pt100 (100Ω)"
                val r0 = if (r0Unit.contains("1000")) 1000.0 else 100.0
                val lead = requireNonNegative(values["lead_ohm"], BilingualText("Lead Resistance", "लीड रेजिस्टेंस"))
                val input = requireFinite(values["input_val"], BilingualText("Input Value", "इनपुट मान"))
                val inputIsTemp = (units["input_val"] ?: "°C") == "°C"

                fun rFromT(t: Double): Double {
                    return if (t >= 0.0) {
                        r0 * (1.0 + a * t + b * t * t)
                    } else {
                        r0 * (1.0 + a * t + b * t * t + c * (t - 100.0) * t * t * t)
                    }
                }

                if (inputIsTemp) {
                    val tC = requireRange(input, -200.0, 850.0, BilingualText("Temperature (°C)", "तापमान (°C)"))
                    val rElement = rFromT(tC)
                    val rTotal2Wire = rElement + 2.0 * lead
                    val tF = tC * 9.0 / 5.0 + 32.0
                    val alpha = if (r0 == 1000.0) "3.85 Ω/°C" else "0.385 Ω/°C"
                    val polyTerm = rElement / r0

                    CalculationOutput(
                        primaryLabel = BilingualText("RTD Element Resistance", "RTD सेंसर रेजिस्टेंस"),
                        primaryValue = formatEng(rElement, 2),
                        primaryUnit = "Ω",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("2-Wire Measured", "2-वायर कुल Ω"), formatEng(rTotal2Wire, 2), "Ω"),
                            SecondaryMetric(BilingualText("Temp (°F)", "तापमान (°F)"), formatEng(tF, 1), "°F"),
                            SecondaryMetric(BilingualText("Sensitivity", "संवेदनशीलता"), alpha, "IEC 60751")
                        ),
                        formulaUsed = if (tC >= 0) "R(T) = R₀ × (1 + A·T + B·T²)" else "R(T) = R₀ × (1 + A·T + B·T² + C·(T−100)·T³)",
                        substitutedFormula = if (tC >= 0) {
                            "R(${formatEng(tC, 1)}) = ${formatEng(r0, 0)} × (1 + 3.9083×10⁻³×(${formatEng(tC, 1)}) − 5.775×10⁻⁷×(${formatEng(tC, 1)})²)"
                        } else {
                            "R(${formatEng(tC, 1)}) = ${formatEng(r0, 0)} × (1 + 3.9083×10⁻³×(${formatEng(tC, 1)}) − 5.775×10⁻⁷×(${formatEng(tC, 1)})² − 4.183×10⁻¹²×(${formatEng(tC, 1)}−100)×(${formatEng(tC, 1)})³)"
                        },
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Identify Base R₀ & IEC 60751 Constants", "बेस R₀ और IEC 60751 स्थिरांक चुनें"),
                                "R₀ = ${formatEng(r0, 0)} Ω,  A = 3.9083×10⁻³,  B = −5.775×10⁻⁷" + if (tC < 0) ",  C = −4.183×10⁻¹²" else "",
                                BilingualText(
                                    "Standard Platinum RTD Callendar–Van Dusen coefficients (α = 0.00385).",
                                    "औद्योगिक प्लेटिनम RTD के मानक Callendar–Van Dusen गुणांक (α = 0.00385)।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Evaluate Resistance Multiplier (R / R₀)", "रेजिस्टेंस गुणांक (R / R₀) निकालें"),
                                "R/R₀ = ${formatEng(polyTerm, 5)}  at T = ${formatEng(tC, 1)} °C",
                                BilingualText(
                                    "Substitutes T = ${formatEng(tC, 1)} °C into the IEC 60751 polynomial.",
                                    "T = ${formatEng(tC, 1)} °C को IEC 60751 समीकरण में रखकर मान निकाला गया।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Multiply by R₀ for Element Ohms", "R₀ से गुणा कर सेंसर का रेजिस्टेंस निकालें"),
                                "R_element = ${formatEng(r0, 0)} × ${formatEng(polyTerm, 5)} = ${formatEng(rElement, 2)} Ω",
                                BilingualText(
                                    "True RTD resistance measured at the sensor element (3-wire/4-wire reading).",
                                    "सेंसर पर वास्तविक रेजिस्टेंस (3-वायर/4-वायर RTD में यही मान मापा जाता है)।"
                                )
                            ),
                            CalculationStep(
                                4,
                                BilingualText("Add 2-Wire Lead Resistance & Convert °F", "2-वायर लीड रेजिस्टेंस और °F निकालें"),
                                "R_2wire = ${formatEng(rElement, 2)} + 2×${formatEng(lead, 2)} = ${formatEng(rTotal2Wire, 2)} Ω  |  T = ${formatEng(tF, 1)} °F",
                                BilingualText(
                                    "3-wire/4-wire RTD circuits cancel lead resistance automatically.",
                                    "3-वायर और 4-वायर RTD लीड वायर के रेजिस्टेंस त्रुटि को स्वतः हटा देते हैं।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "At ${formatEng(tC, 1)} °C (${formatEng(tF, 1)} °F), a ${if (r0 == 1000.0) "Pt1000" else "Pt100"} element reads ${formatEng(rElement, 2)} Ω (sensitivity $alpha).",
                            "${formatEng(tC, 1)} °C (${formatEng(tF, 1)} °F) पर ${if (r0 == 1000.0) "Pt1000" else "Pt100"} सेंसर का शुद्ध रेजिस्टेंस ${formatEng(rElement, 2)} Ω होगा।"
                        ),
                        assumptions = BilingualText(
                            "IEC 60751 Class A/B curve (α = 0.00385 Ω/Ω/°C); valid from −200 °C to +850 °C.",
                            "मान्यता: IEC 60751 मानक (α = 0.00385); मान्य सीमा −200 °C से +850 °C।"
                        )
                    )
                } else {
                    val rMin = rFromT(-200.0)
                    val rMax = rFromT(850.0)
                    val rMeas = input
                    val rNet = rMeas - 2.0 * lead
                    if (rNet < rMin - 0.05 || rNet > rMax + 0.05) {
                        throw BilingualValidationException(
                            BilingualText(
                                "Net RTD resistance (${formatEng(rNet, 2)} Ω) is outside IEC 60751 range (${formatEng(rMin, 2)}–${formatEng(rMax, 2)} Ω).",
                                "शुद्ध RTD रेजिस्टेंस (${formatEng(rNet, 2)} Ω) IEC 60751 सीमा (${formatEng(rMin, 2)}–${formatEng(rMax, 2)} Ω) से बाहर है।"
                            )
                        )
                    }
                    val ratio = rNet / r0
                    val tC = if (rNet >= r0) {
                        val disc = a * a - 4.0 * b * (1.0 - ratio)
                        (-a + sqrt(disc.coerceAtLeast(0.0))) / (2.0 * b)
                    } else {
                        var t = (ratio - 1.0) / 0.00385
                        repeat(12) {
                            val f = rFromT(t) - rNet
                            val df = r0 * (a + 2.0 * b * t + c * (4.0 * t * t * t - 300.0 * t * t))
                            if (abs(df) < 1e-12) return@repeat
                            t -= f / df
                        }
                        t
                    }
                    val tF = tC * 9.0 / 5.0 + 32.0
                    val leadErrorC = (2.0 * lead) / (r0 * 0.00385)

                    CalculationOutput(
                        primaryLabel = BilingualText("Measured Temperature", "मापा गया तापमान"),
                        primaryValue = formatEng(tC, 2),
                        primaryUnit = "°C",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Temp (°F)", "तापमान (°F)"), formatEng(tF, 2), "°F"),
                            SecondaryMetric(BilingualText("Net Element Ω", "शुद्ध सेंसर Ω"), formatEng(rNet, 2), "Ω"),
                            SecondaryMetric(BilingualText("2-Wire Lead Error", "लीड त्रुटि"), formatEng(leadErrorC, 2), "°C")
                        ),
                        formulaUsed = "R_net = R_meas − 2·R_lead   |   T = (−A + √(A² − 4B(1 − R_net/R₀))) / (2B)",
                        substitutedFormula = "R_net = ${formatEng(rMeas, 2)} − 2×${formatEng(lead, 2)} = ${formatEng(rNet, 2)} Ω   |   R_net/R₀ = ${formatEng(ratio, 5)}",
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Subtract 2-Wire Lead Resistance", "लीड वायर रेजिस्टेंस घटाएं"),
                                "R_net = ${formatEng(rMeas, 2)} − (2 × ${formatEng(lead, 2)}) = ${formatEng(rNet, 2)} Ω",
                                BilingualText(
                                    "Each 1 Ω of lead resistance on Pt100 causes ~2.6 °C false high reading.",
                                    "Pt100 में हर 1 Ω लीड रेजिस्टेंस लगभग 2.6 °C की गलत रीडिंग जोड़ देता है।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Compute Normalized Resistance Ratio (R_net / R₀)", "रेजिस्टेंस अनुपात (R_net / R₀) निकालें"),
                                "R_net / R₀ = ${formatEng(rNet, 2)} / ${formatEng(r0, 0)} = ${formatEng(ratio, 5)}",
                                BilingualText(
                                    "Ratio ≥ 1.0 indicates temperature ≥ 0 °C; ratio < 1.0 indicates sub-zero temperature.",
                                    "अनुपात ≥ 1.0 मतलब तापमान ≥ 0 °C, और < 1.0 मतलब शून्य से कम तापमान।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Solve Callendar–Van Dusen Inverse Equation", "Callendar–Van Dusen समीकरण हल करें"),
                                "T = ${formatEng(tC, 2)} °C  (${formatEng(tF, 2)} °F)",
                                BilingualText(
                                    "Computed using full IEC 60751 quadratic/polynomial inverse.",
                                    "IEC 60751 मानक के सटीक समीकरण से तापमान प्राप्त हुआ।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "Net sensor resistance ${formatEng(rNet, 2)} Ω on ${if (r0 == 1000.0) "Pt1000" else "Pt100"} corresponds to ${formatEng(tC, 2)} °C (${formatEng(tF, 2)} °F).",
                            "${if (r0 == 1000.0) "Pt1000" else "Pt100"} पर शुद्ध ${formatEng(rNet, 2)} Ω का मतलब ${formatEng(tC, 2)} °C (${formatEng(tF, 2)} °F) तापमान है।"
                        ),
                        assumptions = BilingualText(
                            "IEC 60751 α = 0.00385 platinum sensor; lead compensation assumes equal resistance in both leads.",
                            "मान्यता: IEC 60751 α = 0.00385 सेंसर; दोनों लीड वायर का रेजिस्टेंस बराबर माना गया है।"
                        )
                    )
                }
            }
        }
    )

    // Official NIST ITS-90 Thermocouple Reference Tables (Temp °C -> mV at 0°C reference)
    private val tcTables: Map<String, List<Pair<Double, Double>>> = mapOf(
        "Type K" to listOf(
            -200.0 to -5.891, -150.0 to -4.913, -100.0 to -3.554, -50.0 to -1.889,
            0.0 to 0.000, 25.0 to 1.000, 50.0 to 2.023, 100.0 to 4.096,
            150.0 to 6.138, 200.0 to 8.138, 250.0 to 10.153, 300.0 to 12.209,
            350.0 to 14.293, 400.0 to 16.397, 450.0 to 18.516, 500.0 to 20.644,
            600.0 to 24.905, 700.0 to 29.129, 800.0 to 33.275, 900.0 to 37.326,
            1000.0 to 41.276, 1100.0 to 45.119, 1200.0 to 48.838, 1300.0 to 52.410
        ),
        "Type J" to listOf(
            -200.0 to -7.890, -150.0 to -6.500, -100.0 to -4.633, -50.0 to -2.431,
            0.0 to 0.000, 25.0 to 1.277, 50.0 to 2.585, 100.0 to 5.269,
            150.0 to 8.010, 200.0 to 10.779, 250.0 to 13.555, 300.0 to 16.327,
            350.0 to 19.090, 400.0 to 21.848, 500.0 to 27.393, 600.0 to 33.102,
            700.0 to 39.132, 800.0 to 45.494, 900.0 to 51.877, 1000.0 to 57.953,
            1100.0 to 63.792, 1200.0 to 69.553
        ),
        "Type T" to listOf(
            -200.0 to -5.603, -150.0 to -4.648, -100.0 to -3.379, -50.0 to -1.819,
            0.0 to 0.000, 25.0 to 0.992, 50.0 to 2.036, 100.0 to 4.279,
            150.0 to 6.704, 200.0 to 9.288, 250.0 to 12.013, 300.0 to 14.862,
            350.0 to 17.819, 400.0 to 20.872
        ),
        "Type E" to listOf(
            -200.0 to -8.825, -150.0 to -7.279, -100.0 to -5.237, -50.0 to -2.787,
            0.0 to 0.000, 25.0 to 1.495, 50.0 to 3.048, 100.0 to 6.319,
            150.0 to 9.789, 200.0 to 13.421, 250.0 to 17.181, 300.0 to 21.036,
            400.0 to 28.946, 500.0 to 37.005, 600.0 to 45.093, 700.0 to 53.112,
            800.0 to 61.017, 900.0 to 68.787, 1000.0 to 76.373
        )
    )

    private fun interpolateMvFromTemp(table: List<Pair<Double, Double>>, t: Double): Double {
        if (t <= table.first().first) return table.first().second
        if (t >= table.last().first) return table.last().second
        for (i in 0 until table.size - 1) {
            val (t1, mv1) = table[i]
            val (t2, mv2) = table[i + 1]
            if (t >= t1 && t <= t2) {
                return mv1 + ((t - t1) / (t2 - t1)) * (mv2 - mv1)
            }
        }
        return table.last().second
    }

    private fun interpolateTempFromMv(table: List<Pair<Double, Double>>, mv: Double): Double {
        if (mv < table.first().second || mv > table.last().second) {
            throw BilingualValidationException(
                BilingualText(
                    "Total mV (${formatEng(mv, 3)} mV) is outside NIST ITS-90 range (${table.first().second} to ${table.last().second} mV).",
                    "कुल mV (${formatEng(mv, 3)} mV) NIST ITS-90 सीमा (${table.first().second} से ${table.last().second} mV) से बाहर है।"
                )
            )
        }
        for (i in 0 until table.size - 1) {
            val (t1, mv1) = table[i]
            val (t2, mv2) = table[i + 1]
            if (mv >= mv1 && mv <= mv2) {
                return t1 + ((mv - mv1) / (mv2 - mv1)) * (t2 - t1)
            }
        }
        return table.last().first
    }

    private fun thermocoupleCalculator() = CalculatorDefinition(
        id = "tc_mv_temp",
        category = CalculatorCategory.RTD_THERMOCOUPLE,
        title = BilingualText("Thermocouple mV ↔ °C (with CJC)", "थर्मोकपल mV ↔ °C (CJC सहित)"),
        subtitle = BilingualText(
            "NIST ITS-90 Type K, J, T, E millivolt ↔ temperature with Cold Junction Compensation",
            "NIST ITS-90 मानक से Type K, J, T, E थर्मोकपल mV ↔ तापमान (CJC सहित) की गणना"
        ),
        formulaPreview = "E_total = E_measured + E(T_cjc)",
        keywords = listOf("thermocouple", "type k", "type j", "mv", "cjc", "cold junction", "थर्मोकपल"),
        fields = listOf(
            CalculatorField(
                id = "tc_type",
                label = BilingualText("Thermocouple Type", "थर्मोकपल प्रकार"),
                defaultValue = "1",
                defaultUnit = "Type K",
                unitOptions = listOf("Type K", "Type J", "Type T", "Type E"),
                isSelectorOnly = true
            ),
            CalculatorField(
                id = "input_val",
                label = BilingualText("Measured Signal (mV or °C)", "मापा गया सिग्नल (mV या °C)"),
                defaultValue = "11.209",
                defaultUnit = "mV",
                unitOptions = listOf("mV", "°C"),
                allowNegative = true
            ),
            CalculatorField(
                id = "cjc_temp",
                label = BilingualText("Ambient / Terminal CJC Temp (°C)", "कमरे/टर्मिनल का तापमान CJC (°C)"),
                defaultValue = "25",
                defaultUnit = "°C",
                allowNegative = true
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Type K: 11.209 mV @ 25°C → 300°C", "Type K: 11.209 mV @ 25°C → 300°C"),
                values = mapOf("input_val" to "11.209", "cjc_temp" to "25"),
                units = mapOf("tc_type" to "Type K", "input_val" to "mV")
            ),
            CalculatorPreset(
                label = BilingualText("Type K: 500 °C @ 0°C → 20.644 mV", "Type K: 500 °C @ 0°C → 20.644 mV"),
                values = mapOf("input_val" to "500", "cjc_temp" to "0"),
                units = mapOf("tc_type" to "Type K", "input_val" to "°C")
            ),
            CalculatorPreset(
                label = BilingualText("Type J: 400 °C @ 25°C CJC", "Type J: 400 °C @ 25°C CJC"),
                values = mapOf("input_val" to "400", "cjc_temp" to "25"),
                units = mapOf("tc_type" to "Type J", "input_val" to "°C")
            )
        ),
        compute = { values, units ->
            runCatching {
                val tcType = units["tc_type"] ?: "Type K"
                val table = tcTables[tcType] ?: tcTables.getValue("Type K")
                val minT = table.first().first
                val maxT = table.last().first

                val input = requireFinite(values["input_val"], BilingualText("Measured Signal", "मापा गया सिग्नल"))
                val tCjc = requireRange(values["cjc_temp"], -50.0, 100.0, BilingualText("CJC Temperature (°C)", "CJC तापमान (°C)"))
                val isInputMv = (units["input_val"] ?: "mV") == "mV"

                val eCjc = interpolateMvFromTemp(table, tCjc)

                if (isInputMv) {
                    val eMeas = input
                    val eTotal = eMeas + eCjc
                    val tHot = interpolateTempFromMv(table, eTotal)
                    val tUncorrected = if (eMeas in table.first().second..table.last().second) {
                        interpolateTempFromMv(table, eMeas)
                    } else Double.NaN

                    CalculationOutput(
                        primaryLabel = BilingualText("Process Temperature ($tcType)", "प्रोसेस तापमान ($tcType)"),
                        primaryValue = formatEng(tHot, 1),
                        primaryUnit = "°C",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("CJC Correction mV", "CJC करेक्शन mV"), formatEng(eCjc, 3), "mV"),
                            SecondaryMetric(BilingualText("Total Equivalent mV", "कुल समतुल्य mV"), formatEng(eTotal, 3), "mV"),
                            SecondaryMetric(
                                BilingualText("Without CJC", "बिना CJC के"),
                                if (tUncorrected.isNaN()) "Out of Range" else formatEng(tUncorrected, 1),
                                if (tUncorrected.isNaN()) "" else "°C"
                            )
                        ),
                        formulaUsed = "E_total(T_hot) = E_measured + E(T_cjc)   [NIST ITS-90]",
                        substitutedFormula = "E_total = ${formatEng(eMeas, 3)} + ${formatEng(eCjc, 3)} = ${formatEng(eTotal, 3)} mV",
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Lookup Cold Junction mV at ${formatEng(tCjc, 1)} °C", "${formatEng(tCjc, 1)} °C पर CJC mV निकालें"),
                                "E(T_cjc) = E(${formatEng(tCjc, 1)} °C) = ${formatEng(eCjc, 3)} mV  ($tcType)",
                                BilingualText(
                                    "Because meter terminals sit at ambient ${formatEng(tCjc, 1)} °C instead of 0 °C ice point, find the CJC mV offset.",
                                    "मीटर टर्मिनल 0 °C के बजाय ${formatEng(tCjc, 1)} °C पर हैं, इसलिए इस तापमान का समतुल्य mV निकालते हैं।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Add CJC Offset to Measured mV", "मापे गए mV में CJC mV जोड़ें"),
                                "E_total = ${formatEng(eMeas, 3)} + ${formatEng(eCjc, 3)} = ${formatEng(eTotal, 3)} mV",
                                BilingualText(
                                    "Gives the 0 °C-referenced thermocouple voltage.",
                                    "इससे 0 °C संदर्भ वाला कुल थर्मोकपल वोल्टेज प्राप्त होता है।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Convert Total mV to Temperature (ITS-90)", "कुल mV से तापमान निकालें (ITS-90)"),
                                "${formatEng(eTotal, 3)} mV → T_hot = ${formatEng(tHot, 1)} °C",
                                BilingualText(
                                    "Always use matching compensating cable (e.g. KX for Type K) from sensor head to PLC.",
                                    "सेंसर से PLC तक हमेशा सही कंपेंसेटिंग केबल (जैसे Type K के लिए KX) उपयोग करें।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "Measured ${formatEng(eMeas, 3)} mV at ${formatEng(tCjc, 1)} °C terminal ambient equals ${formatEng(eTotal, 3)} mV (0°C ref), giving ${formatEng(tHot, 1)} °C for $tcType.",
                            "${formatEng(tCjc, 1)} °C कमरे के तापमान पर ${formatEng(eMeas, 3)} mV का मतलब 0°C संदर्भ पर ${formatEng(eTotal, 3)} mV यानी ${formatEng(tHot, 1)} °C ($tcType) है।"
                        ),
                        assumptions = BilingualText(
                            "Uses NIST ITS-90 reference table interpolation ($tcType valid: ${formatEng(minT, 0)}..${formatEng(maxT, 0)} °C).",
                            "मान्यता: NIST ITS-90 मानक टेबल इंटरपोलेशन ($tcType सीमा: ${formatEng(minT, 0)}..${formatEng(maxT, 0)} °C)।"
                        )
                    )
                } else {
                    val tHot = requireRange(input, minT, maxT, BilingualText("$tcType Temperature (°C)", "$tcType तापमान (°C)"))
                    val eTotal = interpolateMvFromTemp(table, tHot)
                    val eMeas = eTotal - eCjc
                    CalculationOutput(
                        primaryLabel = BilingualText("Expected Meter mV ($tcType)", "मीटर पर अपेक्षित mV ($tcType)"),
                        primaryValue = formatEng(eMeas, 3),
                        primaryUnit = "mV",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("0°C Ref Table mV", "0°C मानक टेबल mV"), formatEng(eTotal, 3), "mV"),
                            SecondaryMetric(BilingualText("CJC Offset mV", "CJC ऑफसेट mV"), formatEng(eCjc, 3), "mV")
                        ),
                        formulaUsed = "E_measured = E(T_hot) − E(T_cjc)   [NIST ITS-90]",
                        substitutedFormula = "E_measured = ${formatEng(eTotal, 3)} − ${formatEng(eCjc, 3)}",
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Lookup 0°C Reference mV at ${formatEng(tHot, 1)} °C", "${formatEng(tHot, 1)} °C का 0°C मानक mV देखें"),
                                "E(${formatEng(tHot, 1)} °C) = ${formatEng(eTotal, 3)} mV  ($tcType)",
                                BilingualText(
                                    "Interpolate the NIST ITS-90 table for the hot junction temperature.",
                                    "हॉट जंक्शन तापमान के लिए NIST ITS-90 टेबल से 0°C मानक mV निकालें।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Lookup Ambient CJC Offset at ${formatEng(tCjc, 1)} °C", "टर्मिनल CJC तापमान (${formatEng(tCjc, 1)} °C) का mV निकालें"),
                                "E(${formatEng(tCjc, 1)} °C) = ${formatEng(eCjc, 3)} mV",
                                BilingualText(
                                    "Ambient terminals create a counter-EMF equal to E(T_cjc).",
                                    "टर्मिनल के तापमान के कारण E(T_cjc) के बराबर विपरीत EMF बनता है।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Subtract CJC Offset for Meter Reading", "मीटर रीडिंग हेतु CJC घटाएं"),
                                "E_meas = ${formatEng(eTotal, 3)} − ${formatEng(eCjc, 3)} = ${formatEng(eMeas, 3)} mV",
                                BilingualText(
                                    "This is the actual millivolt reading expected on a multimeter at ${formatEng(tCjc, 1)} °C ambient.",
                                    "मल्टीमीटर से टर्मिनल पर मापने पर आपको ${formatEng(eMeas, 3)} mV दिखाई देगा।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "For a $tcType probe at ${formatEng(tHot, 1)} °C with ${formatEng(tCjc, 1)} °C ambient terminals, expect ${formatEng(eMeas, 3)} mV across the leads.",
                            "${formatEng(tHot, 1)} °C पर $tcType थर्मोकपल (${formatEng(tCjc, 1)} °C टर्मिनल तापमान के साथ) मल्टीमीटर पर ${formatEng(eMeas, 3)} mV देगा।"
                        ),
                        assumptions = BilingualText(
                            "Uses NIST ITS-90 reference table ($tcType valid: ${formatEng(minT, 0)}..${formatEng(maxT, 0)} °C).",
                            "मान्यता: NIST ITS-90 मानक टेबल ($tcType सीमा: ${formatEng(minT, 0)}..${formatEng(maxT, 0)} °C)।"
                        )
                    )
                }
            }
        }
    )

    private fun temperatureConverterCalculator() = CalculatorDefinition(
        id = "temp_unit_converter",
        category = CalculatorCategory.RTD_THERMOCOUPLE,
        title = BilingualText("Temperature Unit Converter", "तापमान यूनिट कन्वर्टर"),
        subtitle = BilingualText(
            "Convert between Celsius (°C), Fahrenheit (°F), Kelvin (K) & Rankine (°R)",
            "सेल्सियस (°C), फ़ारेनहाइट (°F), केल्विन (K) और रैंकिन (°R) में बदलें"
        ),
        formulaPreview = "°F = (°C × 9/5) + 32   |   K = °C + 273.15",
        keywords = listOf("temperature", "celsius", "fahrenheit", "kelvin", "तापमान", "सेल्सियस"),
        fields = listOf(
            CalculatorField(
                id = "temp",
                label = BilingualText("Temperature Value", "तापमान मान"),
                defaultValue = "100",
                defaultUnit = "°C",
                unitOptions = listOf("°C", "°F", "K"),
                allowNegative = true
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Boiling Water (100 °C)", "उबलता पानी (100 °C)"),
                values = mapOf("temp" to "100"),
                units = mapOf("temp" to "°C")
            )
        ),
        compute = { values, units ->
            runCatching {
                val input = requireFinite(values["temp"], BilingualText("Temperature Value", "तापमान मान"))
                val inUnit = units["temp"] ?: "°C"
                val c = when (inUnit) {
                    "°F" -> (input - 32.0) * 5.0 / 9.0
                    "K" -> input - 273.15
                    else -> input
                }
                if (c < -273.15) {
                    throw BilingualValidationException(
                        BilingualText(
                            "Temperature cannot be below absolute zero (−273.15 °C / 0 K / −459.67 °F).",
                            "तापमान परम शून्य (−273.15 °C / 0 K) से कम नहीं हो सकता।"
                        )
                    )
                }
                val f = c * 9.0 / 5.0 + 32.0
                val k = c + 273.15
                val r = f + 459.67

                val step1Expr = when (inUnit) {
                    "°F" -> "°C = (${formatEng(input, 2)} − 32) × 5 / 9 = ${formatEng(c, 2)} °C"
                    "K" -> "°C = ${formatEng(input, 2)} − 273.15 = ${formatEng(c, 2)} °C"
                    else -> "°C = ${formatEng(c, 2)} °C"
                }

                CalculationOutput(
                    primaryLabel = BilingualText("Celsius / Fahrenheit", "सेल्सियस / फ़ारेनहाइट"),
                    primaryValue = "${formatEng(c, 2)} °C",
                    primaryUnit = "/ ${formatEng(f, 2)} °F",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Kelvin", "केल्विन"), formatEng(k, 2), "K"),
                        SecondaryMetric(BilingualText("Rankine", "रैंकिन"), formatEng(r, 2), "°R")
                    ),
                    formulaUsed = "°C = (°F − 32) × 5/9   |   °F = (°C × 1.8) + 32   |   K = °C + 273.15",
                    substitutedFormula = when (inUnit) {
                        "°F" -> "°C = (${formatEng(input, 2)} − 32) × 5/9   |   K = ${formatEng(c, 2)} + 273.15"
                        "K" -> "°C = ${formatEng(input, 2)} − 273.15   |   °F = (${formatEng(c, 2)} × 1.8) + 32"
                        else -> "°F = (${formatEng(c, 2)} × 1.8) + 32   |   K = ${formatEng(c, 2)} + 273.15"
                    },
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Input ($inUnit) to Base Celsius (°C)", "इनपुट ($inUnit) को सेल्सियस (°C) में बदलें"),
                            step1Expr,
                            BilingualText(
                                "Normalize the input temperature to Celsius before computing all other scales.",
                                "सभी स्केल निकालने से पहले इनपुट तापमान को सेल्सियस (°C) में बदलते हैं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Calculate Fahrenheit (°F)", "फ़ारेनहाइट (°F) निकालें"),
                            "°F = (${formatEng(c, 2)} × 1.8) + 32 = ${formatEng(f, 2)} °F",
                            BilingualText(
                                "Multiply Celsius by 1.8 (9/5) and add 32° freezing-point offset.",
                                "सेल्सियस को 1.8 से गुणा कर 32 जोड़ने पर फ़ारेनहाइट मिलता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Absolute Scales (Kelvin & Rankine)", "एब्सोल्यूट स्केल (केल्विन व रैंकिन) निकालें"),
                            "K = ${formatEng(c, 2)} + 273.15 = ${formatEng(k, 2)} K  |  °R = ${formatEng(f, 2)} + 459.67 = ${formatEng(r, 2)} °R",
                            BilingualText(
                                "Adds absolute zero offset (273.15 K / 459.67 °R) used in thermodynamic and gas flow calculations.",
                                "थर्मोडायनामिक और गैस फ्लो गणना के लिए केल्विन व रैंकिन मान निकाले गए।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "${formatEng(input, 2)} $inUnit equals ${formatEng(c, 2)} °C, ${formatEng(f, 2)} °F, ${formatEng(k, 2)} K, and ${formatEng(r, 2)} °R.",
                        "${formatEng(input, 2)} $inUnit बराबर है ${formatEng(c, 2)} °C, ${formatEng(f, 2)} °F, ${formatEng(k, 2)} K और ${formatEng(r, 2)} °R के।"
                    )
                )
            }
        }
    )

    private fun pressureConverterCalculator() = CalculatorDefinition(
        id = "pfl_pressure_conv",
        category = CalculatorCategory.PRESSURE_FLOW_LEVEL,
        title = BilingualText("Pressure Unit Converter", "प्रेशर यूनिट कन्वर्टर"),
        subtitle = BilingualText(
            "Convert bar, psi, kPa, MPa, kg/cm², mmH₂O & mmHg simultaneously",
            "bar, psi, kPa, MPa, kg/cm², mmH₂O और mmHg में तुरंत बदलें"
        ),
        formulaPreview = "1 bar = 100 kPa = 14.5038 psi = 1.0197 kg/cm² = 10197.2 mmH₂O",
        keywords = listOf("pressure", "bar", "psi", "kpa", "kg/cm2", "mmh2o", "प्रेशर", "बार"),
        fields = listOf(
            CalculatorField(
                id = "pressure",
                label = BilingualText("Pressure Value", "प्रेशर मान"),
                defaultValue = "6.0",
                defaultUnit = "bar",
                unitOptions = listOf("bar", "psi", "kPa", "MPa", "kg/cm²", "mmH₂O", "mmHg"),
                allowNegative = true
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Instrument Air (6 bar)", "इंस्ट्रूमेंट एयर (6 bar)"),
                values = mapOf("pressure" to "6.0"),
                units = mapOf("pressure" to "bar")
            ),
            CalculatorPreset(
                label = BilingualText("2500 mmH₂O DP Range", "2500 mmH₂O DP रेंज"),
                values = mapOf("pressure" to "2500"),
                units = mapOf("pressure" to "mmH₂O")
            )
        ),
        compute = { values, units ->
            runCatching {
                val raw = requireFinite(values["pressure"], BilingualText("Pressure Value", "प्रेशर मान"))
                val inUnit = units["pressure"] ?: "bar"
                val bar = when (inUnit) {
                    "psi" -> raw / 14.5037738
                    "kPa" -> raw / 100.0
                    "MPa" -> raw * 10.0
                    "kg/cm²" -> raw / 1.0197162
                    "mmH₂O" -> raw / 10197.162
                    "mmHg" -> raw / 750.06168
                    else -> raw
                }
                if (bar < -1.01325) {
                    throw BilingualValidationException(
                        BilingualText(
                            "Gauge pressure cannot be below full vacuum (−1.013 bar / −14.7 psi).",
                            "गेज प्रेशर पूर्ण वैक्यूम (−1.013 bar / −14.7 psi) से कम नहीं हो सकता।"
                        )
                    )
                }
                val psi = bar * 14.5037738
                val kpa = bar * 100.0
                val kgCm2 = bar * 1.0197162
                val mmH2o = bar * 10197.162
                val mmHg = bar * 750.06168

                val baseConversionExpr = when (inUnit) {
                    "psi" -> "P_bar = ${formatEng(raw, 4)} / 14.5038 = ${formatEng(bar, 4)} bar"
                    "kPa" -> "P_bar = ${formatEng(raw, 4)} / 100 = ${formatEng(bar, 4)} bar"
                    "MPa" -> "P_bar = ${formatEng(raw, 4)} × 10 = ${formatEng(bar, 4)} bar"
                    "kg/cm²" -> "P_bar = ${formatEng(raw, 4)} / 1.01972 = ${formatEng(bar, 4)} bar"
                    "mmH₂O" -> "P_bar = ${formatEng(raw, 4)} / 10197.16 = ${formatEng(bar, 4)} bar"
                    "mmHg" -> "P_bar = ${formatEng(raw, 4)} / 750.062 = ${formatEng(bar, 4)} bar"
                    else -> "P_bar = ${formatEng(bar, 4)} bar"
                }

                CalculationOutput(
                    primaryLabel = BilingualText("Pressure in bar / kPa", "प्रेशर (bar / kPa में)"),
                    primaryValue = formatEng(bar, 4),
                    primaryUnit = "bar (${formatEng(kpa, 2)} kPa)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("PSI", "PSI"), formatEng(psi, 3), "psi"),
                        SecondaryMetric(BilingualText("kg/cm²", "kg/cm²"), formatEng(kgCm2, 4), "kg/cm²"),
                        SecondaryMetric(BilingualText("mmH₂O", "mmH₂O"), formatEng(mmH2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("mmHg", "mmHg"), formatEng(mmHg, 1), "mmHg")
                    ),
                    formulaUsed = "1 bar = 100 kPa = 14.5038 psi = 1.01972 kg/cm² = 10197.16 mmH₂O = 750.06 mmHg",
                    substitutedFormula = "$baseConversionExpr   |   psi = ${formatEng(bar, 4)} × 14.5038",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Input ($inUnit) to Base bar", "इनपुट ($inUnit) को बार (bar) में बदलें"),
                            baseConversionExpr,
                            BilingualText(
                                "Normalize the entered pressure to bar as the common intermediate unit.",
                                "सभी इकाइयों में बदलने से पहले इनपुट प्रेशर को bar में बदलते हैं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Convert bar to kPa & psi", "bar को kPa और psi में बदलें"),
                            "kPa = ${formatEng(bar, 4)} × 100 = ${formatEng(kpa, 2)} kPa  |  psi = ${formatEng(bar, 4)} × 14.5038 = ${formatEng(psi, 3)} psi",
                            BilingualText(
                                "SI kilopascals (kPa) and US pounds per square inch (psi).",
                                "SI यूनिट किलोपास्कल (kPa) और psi में प्रेशर मान।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Convert bar to kg/cm², mmH₂O & mmHg", "kg/cm², mmH₂O और mmHg निकालें"),
                            "kg/cm² = ${formatEng(kgCm2, 4)}  |  mmH₂O = ${formatEng(mmH2o, 1)}  |  mmHg = ${formatEng(mmHg, 1)}",
                            BilingualText(
                                "1 kg/cm² ≈ 0.9807 bar (~1 bar); mmH₂O and mmHg are widely used in DP transmitters and vacuum gauges.",
                                "1 kg/cm² लगभग 0.9807 bar होता है; mmH₂O और mmHg का उपयोग DP व वैक्यूम गेज में होता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "${formatEng(raw, 4)} $inUnit equals ${formatEng(bar, 4)} bar (${formatEng(kpa, 2)} kPa, ${formatEng(psi, 3)} psi, ${formatEng(kgCm2, 4)} kg/cm²).",
                        "${formatEng(raw, 4)} $inUnit बराबर है ${formatEng(bar, 4)} bar (${formatEng(kpa, 2)} kPa, ${formatEng(psi, 3)} psi, ${formatEng(kgCm2, 4)} kg/cm²) के।"
                    ),
                    assumptions = BilingualText(
                        "Water column mmH₂O uses standard 4°C density (1000 kg/m³, g = 9.80665 m/s²).",
                        "मान्यता: mmH₂O मानक 4°C पानी (1000 kg/m³) पर आधारित है।"
                    )
                )
            }
        }
    )

    private fun hydrostaticLevelCalculator() = CalculatorDefinition(
        id = "pfl_hydrostatic_level",
        category = CalculatorCategory.PRESSURE_FLOW_LEVEL,
        title = BilingualText("Hydrostatic Tank Level & DP LRV/URV", "टैंक लेवल और DP ट्रांसमीटर LRV/URV"),
        subtitle = BilingualText(
            "Calculate DP Transmitter LRV, URV & Span for Open or Wet-Leg Closed Tanks",
            "ओपन या क्लोज्ड (Wet-Leg) टैंक के लिए DP लेवल ट्रांसमीटर का LRV, URV और स्पैन निकालें"
        ),
        formulaPreview = "ΔP = H × SG   |   Wet-Leg LRV = −(H_wet × SG_seal)",
        keywords = listOf("level", "hydrostatic", "tank", "wet leg", "lrv", "urv", "dp transmitter", "टैंक लेवल"),
        fields = listOf(
            CalculatorField("max_height", BilingualText("Tank Level Span (H_max)", "टैंक लेवल ऊंचाई (H_max)"), "5000", "mm"),
            CalculatorField("sg_process", BilingualText("Process Liquid Specific Gravity (SG)", "प्रोसेस लिक्विड की SG"), "0.95", "SG"),
            CalculatorField("wet_leg_h", BilingualText("Wet-Leg Height (0 for Open Tank)", "वेट-लेग ऊंचाई (ओपन टैंक में 0)"), "5500", "mm"),
            CalculatorField("sg_seal", BilingualText("Wet-Leg Seal Liquid SG", "सील लिक्विड की SG (पानी=1)"), "1.0", "SG"),
            CalculatorField("cur_level", BilingualText("Current Level (to check mA)", "वर्तमान लेवल (mA जांचने हेतु)"), "2500", "mm")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Open Water Tank (0–5000 mm)", "ओपन वॉटर टैंक (0–5000 mm)"),
                values = mapOf("max_height" to "5000", "sg_process" to "1.0", "wet_leg_h" to "0", "sg_seal" to "1.0", "cur_level" to "2500")
            ),
            CalculatorPreset(
                label = BilingualText("Boiler Drum Wet-Leg (5500 mm)", "बॉयलर ड्रम वेट-लेग (5500 mm)"),
                values = mapOf("max_height" to "5000", "sg_process" to "0.85", "wet_leg_h" to "5500", "sg_seal" to "1.0", "cur_level" to "2500")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val hMax = requirePositive(values["max_height"], BilingualText("Tank Level Span (H_max)", "टैंक लेवल ऊंचाई"))
                val sgProc = requirePositive(values["sg_process"], BilingualText("Process Liquid SG", "प्रोसेस लिक्विड SG"))
                val hWet = requireNonNegative(values["wet_leg_h"], BilingualText("Wet-Leg Height", "वेट-लेग ऊंचाई"))
                val sgSeal = requirePositive(values["sg_seal"], BilingualText("Seal Liquid SG", "सील लिक्विड SG"))
                val hCur = requireRange(values["cur_level"], 0.0, hMax, BilingualText("Current Level", "वर्तमान लेवल"))

                val spanMmH2o = hMax * sgProc
                val lrvMmH2o = -(hWet * sgSeal)
                val urvMmH2o = lrvMmH2o + spanMmH2o
                val curDpMmH2o = lrvMmH2o + hCur * sgProc
                val levelPct = (hCur / hMax) * 100.0
                val maOut = 4.0 + 16.0 * (hCur / hMax)

                CalculationOutput(
                    primaryLabel = BilingualText("DP Span (LRV to URV)", "DP ट्रांसमीटर स्पैन (LRV से URV)"),
                    primaryValue = "${formatEng(lrvMmH2o, 0)} .. ${formatEng(urvMmH2o, 0)}",
                    primaryUnit = "mmH₂O (Span: ${formatEng(spanMmH2o, 0)})",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("LRV (at 0%)", "LRV (0% पर)"), formatEng(lrvMmH2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("URV (at 100%)", "URV (100% पर)"), formatEng(urvMmH2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("Current DP & mA", "वर्तमान DP व mA"), "${formatEng(curDpMmH2o, 0)} mmH₂O", "${formatEng(maOut, 2)} mA (${formatEng(levelPct, 0)}%)")
                    ),
                    formulaUsed = "Span = H_max × SG_proc   |   LRV = −(H_wet × SG_seal)   |   URV = LRV + Span",
                    substitutedFormula = "Span = ${formatEng(hMax, 0)} × ${formatEng(sgProc, 3)}   |   LRV = −(${formatEng(hWet, 0)} × ${formatEng(sgSeal, 2)})   |   URV = ${formatEng(lrvMmH2o, 1)} + ${formatEng(spanMmH2o, 1)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Calculate Hydrostatic Span", "हाइड्रोस्टैटिक स्पैन निकालें"),
                            "Span = ${formatEng(hMax, 0)} × ${formatEng(sgProc, 3)} = ${formatEng(spanMmH2o, 1)} mmH₂O",
                            BilingualText(
                                "1 mm of water column = 1 mmH₂O; multiply level height by process specific gravity.",
                                "1 mm पानी का दबाव = 1 mmH₂O; ऊंचाई को प्रोसेस तरल की SG से गुणा करें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Compute Wet-Leg Zero Suppression (LRV)", "वेट-लेग ऑफसेट (LRV) निकालें"),
                            "LRV = −(${formatEng(hWet, 0)} × ${formatEng(sgSeal, 2)}) = ${formatEng(lrvMmH2o, 1)} mmH₂O",
                            BilingualText(
                                if (hWet > 0) "Wet-leg liquid presses continuously on the LP port, making LRV negative (zero elevation)."
                                else "Open tank has no wet leg, so LRV at 0% level is 0 mmH₂O.",
                                if (hWet > 0) "वेट-लेग LP साइड पर लगातार दबाव डालती है, इसलिए 0% पर LRV नेगेटिव होता है।"
                                else "ओपन टैंक में वेट-लेग नहीं होती, इसलिए 0% लेवल पर LRV = 0 होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Upper Range Value (URV)", "URV (100% लेवल मान) निकालें"),
                            "URV = ${formatEng(lrvMmH2o, 1)} + ${formatEng(spanMmH2o, 1)} = ${formatEng(urvMmH2o, 1)} mmH₂O",
                            BilingualText(
                                "Adding span to LRV gives the 20 mA calibration point at 100% tank level.",
                                "LRV में स्पैन जोड़ने पर 100% लेवल (20 mA) का URV मान प्राप्त होता है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Check Live DP & 4–20 mA at ${formatEng(hCur, 0)} mm", "${formatEng(hCur, 0)} mm पर लाइव DP व mA जांचें"),
                            "DP_cur = ${formatEng(lrvMmH2o, 1)} + (${formatEng(hCur, 0)} × ${formatEng(sgProc, 3)}) = ${formatEng(curDpMmH2o, 1)} mmH₂O  →  ${formatEng(maOut, 2)} mA (${formatEng(levelPct, 1)}%)",
                            BilingualText(
                                "Use these values to verify transmitter calibration on site with a pressure hand pump.",
                                "साइट पर हैंड-पंप से ट्रांसमीटर जांचने हेतु इन मानों का उपयोग करें।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Calibrate the DP transmitter from ${formatEng(lrvMmH2o, 1)} mmH₂O (4 mA) to ${formatEng(urvMmH2o, 1)} mmH₂O (20 mA); at ${formatEng(hCur, 0)} mm (${formatEng(levelPct, 1)}%) it sees ${formatEng(curDpMmH2o, 0)} mmH₂O and outputs ${formatEng(maOut, 2)} mA.",
                        "DP ट्रांसमीटर को ${formatEng(lrvMmH2o, 1)} mmH₂O (4 mA) से ${formatEng(urvMmH2o, 1)} mmH₂O (20 mA) पर कैलिब्रेट करें; ${formatEng(hCur, 0)} mm पर आउटपुट ${formatEng(maOut, 2)} mA होगा।"
                    ),
                    assumptions = BilingualText(
                        "Assumes transmitter HP port at bottom tap (0% level) and LP port on wet-leg (or vented for open tank).",
                        "मान्यता: ट्रांसमीटर का HP पोर्ट निचले टैप (0%) पर और LP पोर्ट वेट-लेग (या खुले वातावरण) में है।"
                    )
                )
            }
        }
    )

    private fun pipeFlowVelocityCalculator() = CalculatorDefinition(
        id = "pfl_pipe_flow",
        category = CalculatorCategory.PRESSURE_FLOW_LEVEL,
        title = BilingualText("Pipe Flow Rate & Velocity", "पाइप फ्लो रेट और वेलोसिटी"),
        subtitle = BilingualText(
            "Calculate Volumetric Flow Rate (m³/h, LPM) and Flow Velocity (m/s)",
            "पाइप के अंदर के व्यास (ID) और फ्लो/वेग से फ्लो रेट व वेलोसिटी (m/s) निकालें"
        ),
        formulaPreview = "Q = A × v = (π × D² / 4) × v",
        keywords = listOf("pipe", "velocity", "flow rate", "diameter", "पाइप", "फ्लो", "वेलोसिटी"),
        fields = listOf(
            CalculatorField("diameter_mm", BilingualText("Pipe Inner Diameter (mm)", "पाइप का आंतरिक व्यास (mm)"), "100", "mm"),
            CalculatorField(
                id = "vel_or_flow",
                label = BilingualText("Velocity (m/s) or Flow (m³/h)", "वेग (m/s) या फ्लो (m³/h)"),
                defaultValue = "2.0",
                defaultUnit = "m/s",
                unitOptions = listOf("m/s", "m³/h")
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("DN100 Pipe @ 2.0 m/s", "DN100 पाइप @ 2.0 m/s"),
                values = mapOf("diameter_mm" to "100", "vel_or_flow" to "2.0"),
                units = mapOf("vel_or_flow" to "m/s")
            )
        ),
        compute = { values, units ->
            runCatching {
                val dMm = requirePositive(values["diameter_mm"], BilingualText("Pipe Inner Diameter", "पाइप व्यास"))
                val inp = requirePositive(values["vel_or_flow"], BilingualText("Velocity/Flow", "वेग/फ्लो"))

                val dM = dMm / 1000.0
                val areaM2 = (PI * dM * dM) / 4.0
                val isVel = (units["vel_or_flow"] ?: "m/s") == "m/s"

                val vMs: Double
                val qM3h: Double
                if (isVel) {
                    vMs = inp
                    qM3h = areaM2 * vMs * 3600.0
                } else {
                    qM3h = inp
                    vMs = (qM3h / 3600.0) / areaM2
                }
                val qLpm = qM3h * 1000.0 / 60.0
                val status = if (vMs > 3.5) StatusLevel.WARNING else StatusLevel.NORMAL

                CalculationOutput(
                    primaryLabel = if (isVel) BilingualText("Volumetric Flow Rate", "वॉल्यूमेट्रिक फ्लो रेट") else BilingualText("Fluid Velocity", "द्रव का वेग (Velocity)"),
                    primaryValue = if (isVel) formatEng(qM3h, 2) else formatEng(vMs, 2),
                    primaryUnit = if (isVel) "m³/h" else "m/s",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Flow (LPM)", "फ्लो (LPM)"), formatEng(qLpm, 1), "L/min"),
                        SecondaryMetric(BilingualText("Velocity", "वेलोसिटी"), formatEng(vMs, 2), "m/s"),
                        SecondaryMetric(BilingualText("Pipe Area", "पाइप क्षेत्रफल"), formatEng(areaM2 * 10000.0, 2), "cm²")
                    ),
                    formulaUsed = if (isVel) "A = π × D² / 4   |   Q(m³/h) = A × v × 3600" else "A = π × D² / 4   |   v = Q / (A × 3600)",
                    substitutedFormula = if (isVel) {
                        "A = π × (${formatEng(dM, 3)})² / 4   |   Q = ${formatEng(areaM2, 5)} × ${formatEng(vMs, 2)} × 3600"
                    } else {
                        "A = π × (${formatEng(dM, 3)})² / 4   |   v = ${formatEng(qM3h, 2)} / (${formatEng(areaM2, 5)} × 3600)"
                    },
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Pipe ID to Meters & Compute Area", "पाइप व्यास को मीटर में बदलकर क्षेत्रफल निकालें"),
                            "D = ${formatEng(dMm, 1)} / 1000 = ${formatEng(dM, 3)} m  →  A = π × (${formatEng(dM, 3)})² / 4 = ${formatEng(areaM2, 5)} m² (${formatEng(areaM2 * 10000.0, 2)} cm²)",
                            BilingualText(
                                "Cross-sectional area in m² is required to match velocity in m/s.",
                                "m/s के साथ गणना के लिए पाइप का क्षेत्रफल वर्ग मीटर (m²) में निकालते हैं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText(
                                if (isVel) "Multiply Area × Velocity × 3600 for m³/h" else "Divide Flow Rate by (Area × 3600) for Velocity",
                                if (isVel) "क्षेत्रफल × वेग × 3600 से m³/h निकालें" else "फ्लो रेट को (क्षेत्रफल × 3600) से भाग देकर वेग निकालें"
                            ),
                            if (isVel) "Q = ${formatEng(areaM2, 5)} × ${formatEng(vMs, 2)} × 3600 = ${formatEng(qM3h, 2)} m³/h"
                            else "v = ${formatEng(qM3h, 2)} / (${formatEng(areaM2, 5)} × 3600) = ${formatEng(vMs, 2)} m/s",
                            BilingualText(
                                "Factor 3600 converts m³/s into cubic meters per hour (m³/h).",
                                "3600 से गुणा/भाग करने पर प्रति सेकंड और प्रति घंटे के फ्लो में रूपांतरण होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Convert to Liters/Min & Check Velocity Limit", "LPM निकालें और वेग सीमा जांचें"),
                            "Q_LPM = (${formatEng(qM3h, 2)} × 1000) / 60 = ${formatEng(qLpm, 1)} L/min  |  v = ${formatEng(vMs, 2)} m/s",
                            BilingualText(
                                if (vMs > 3.5) "High velocity (>3.5 m/s) increases pressure drop, noise, and pipe erosion!"
                                else "Typical water pipe velocity is 1.0–2.5 m/s (safe against erosion/water hammer).",
                                if (vMs > 3.5) "वेग बहुत अधिक (>3.5 m/s) है — पाइप में शोर, घिसाव और प्रेशर लॉस बढ़ेगा!"
                                else "पानी के पाइप में आदर्श वेग 1.0–2.5 m/s होता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Through a ${formatEng(dMm, 0)} mm bore pipe, ${formatEng(qM3h, 2)} m³/h (${formatEng(qLpm, 1)} LPM) flows at an average velocity of ${formatEng(vMs, 2)} m/s.",
                        "${formatEng(dMm, 0)} mm पाइप में ${formatEng(qM3h, 2)} m³/h (${formatEng(qLpm, 1)} LPM) फ्लो का औसत वेग ${formatEng(vMs, 2)} m/s है।"
                    ),
                    assumptions = BilingualText(
                        "Assumes full-bore circular pipe flow with average cross-sectional velocity.",
                        "मान्यता: पाइप पूरी तरह भरा हुआ है (Full-bore flow)।"
                    ),
                    statusLevel = status
                )
            }
        }
    )

    private fun reynoldsNumberCalculator() = CalculatorDefinition(
        id = "pfl_reynolds",
        category = CalculatorCategory.PRESSURE_FLOW_LEVEL,
        title = BilingualText("Reynolds Number (Flow Regime)", "रेनॉल्ड्स नंबर (फ्लो प्रकृति)"),
        subtitle = BilingualText(
            "Check Laminar (<2100), Transitional, or Turbulent (>4000) flow for Flow Meters",
            "फ्लो मीटर के लिए पाइप फ्लो लैमिनार (<2100) है या टर्बुलेंट (>4000) जांचें"
        ),
        formulaPreview = "Re = (ρ × v × D) / μ",
        keywords = listOf("reynolds", "laminar", "turbulent", "viscosity", "रेनॉल्ड्स", "फ्लो"),
        fields = listOf(
            CalculatorField("diameter_mm", BilingualText("Pipe ID (mm)", "पाइप व्यास (mm)"), "50", "mm"),
            CalculatorField("velocity", BilingualText("Velocity (m/s)", "वेग (m/s)"), "1.8", "m/s"),
            CalculatorField("density", BilingualText("Fluid Density (kg/m³)", "घनत्व (पानी=1000)"), "1000", "kg/m³"),
            CalculatorField("viscosity_cp", BilingualText("Dynamic Viscosity (cP)", "विस्कोसिटी (पानी=1 cP)"), "1.0", "cP")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Water DN50 @ 1.8 m/s", "पानी DN50 @ 1.8 m/s"),
                values = mapOf("diameter_mm" to "50", "velocity" to "1.8", "density" to "1000", "viscosity_cp" to "1.0")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val dMm = requirePositive(values["diameter_mm"], BilingualText("Pipe ID", "पाइप व्यास"))
                val v = requirePositive(values["velocity"], BilingualText("Velocity", "वेग"))
                val rho = requirePositive(values["density"], BilingualText("Fluid Density", "घनत्व"))
                val muCp = requirePositive(values["viscosity_cp"], BilingualText("Viscosity", "विस्कोसिटी"))

                val dM = dMm / 1000.0
                val muPas = muCp / 1000.0
                val re = (rho * v * dM) / muPas
                val regimeShort = when {
                    re < 2100.0 -> BilingualText("Laminar", "लैमिनार")
                    re <= 4000.0 -> BilingualText("Transitional", "ट्रांजिशनल")
                    else -> BilingualText("Turbulent", "टर्बुलेंट")
                }
                val regimeDesc = when {
                    re < 2100.0 -> BilingualText("Laminar Flow (<2100)", "लैमिनार फ्लो (<2100)")
                    re <= 4000.0 -> BilingualText("Transitional (2100–4000)", "ट्रांजिशनल (2100–4000)")
                    else -> BilingualText("Turbulent Flow (>4000)", "टर्बुलेंट फ्लो (>4000)")
                }

                val numerator = rho * v * dM

                CalculationOutput(
                    primaryLabel = BilingualText("Reynolds Number (Re)", "रेनॉल्ड्स नंबर (Re)"),
                    primaryValue = formatEng(re, 0),
                    primaryUnit = regimeShort.en,
                    primaryUnitLocalized = regimeShort,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Flow Regime", "फ्लो प्रकार"), regimeDesc.en, localizedValue = regimeDesc),
                        SecondaryMetric(BilingualText("Viscosity (Pa·s)", "विस्कोसिटी"), formatEng(muPas, 4), "Pa·s")
                    ),
                    formulaUsed = "Re = (ρ × v × D) / μ   (D in m, μ in Pa·s = cP / 1000)",
                    substitutedFormula = "Re = (${formatEng(rho, 0)} × ${formatEng(v, 2)} × ${formatEng(dM, 3)}) / ${formatEng(muPas, 4)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Diameter & Viscosity to SI Units", "व्यास और विस्कोसिटी को SI यूनिट में बदलें"),
                            "D = ${formatEng(dMm, 1)} / 1000 = ${formatEng(dM, 3)} m  |  μ = ${formatEng(muCp, 2)} / 1000 = ${formatEng(muPas, 4)} Pa·s",
                            BilingualText(
                                "Reynolds number is dimensionless, so mm becomes meters and centipoise (cP) becomes Pa·s.",
                                "रेनॉल्ड्स नंबर की कोई इकाई नहीं होती, इसलिए mm को मीटर और cP को Pa·s में बदलते हैं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Compute Inertial Forces (ρ × v × D)", "इनर्शियल बल गुणनफल (ρ × v × D) निकालें"),
                            "ρ × v × D = ${formatEng(rho, 0)} × ${formatEng(v, 2)} × ${formatEng(dM, 3)} = ${formatEng(numerator, 2)}",
                            BilingualText(
                                "Represents fluid momentum tending to create turbulent eddies.",
                                "यह द्रव के संवेग को दर्शाता है जो प्रवाह में टर्बुलेंस पैदा करता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Divide by Viscosity μ & Classify Regime", "विस्कोसिटी μ से भाग दें और फ्लो प्रकार जांचें"),
                            "Re = ${formatEng(numerator, 2)} / ${formatEng(muPas, 4)} = ${formatEng(re, 0)} → ${regimeDesc.en}",
                            BilingualText(
                                "Orifice & Vortex flow meters require Turbulent flow (typically Re > 10,000) for high accuracy.",
                                "ऑरिफिस और वोर्टेक्स फ्लो मीटर की सटीकता के लिए टर्बुलेंट फ्लो (Re > 10,000) बेहतर होता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        when {
                            re < 2100.0 -> "Re = ${formatEng(re, 0)} (<2100) indicates smooth Laminar flow; orifice/vortex meters lose accuracy unless compensated."
                            re <= 4000.0 -> "Re = ${formatEng(re, 0)} (2100–4000) is unstable Transitional flow where discharge coefficient fluctuates."
                            else -> "Re = ${formatEng(re, 0)} (>4000) confirms fully Turbulent flow, ideal for differential-pressure, vortex, and magnetic flow meters."
                        },
                        when {
                            re < 2100.0 -> "Re = ${formatEng(re, 0)} (<2100) लैमिनार फ्लो दर्शाता है; इसमें ऑरिफिस/वोर्टेक्स मीटर की सटीकता कम हो सकती है।"
                            re <= 4000.0 -> "Re = ${formatEng(re, 0)} (2100–4000) अस्थिर ट्रांजिशनल फ्लो है जहाँ रीडिंग बदल सकती है।"
                            else -> "Re = ${formatEng(re, 0)} (>4000) टर्बुलेंट फ्लो है, जो ऑरिफिस, वोर्टेक्स और मैग-फ्लो मीटर के लिए सबसे उपयुक्त है।"
                        }
                    ),
                    statusLevel = if (re in 2100.0..4000.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun cableSizingCalculator() = CalculatorDefinition(
        id = "cable_sizing_ac",
        category = CalculatorCategory.CABLE_SIZE,
        title = BilingualText("Power Cable Size Calculator", "पावर केबल साइज कैलकुलेटर"),
        subtitle = BilingualText(
            "Select standard Copper or Aluminum cable (mm²) by Current & Max Voltage Drop %",
            "करंट, केबल की लंबाई और वोल्टेज ड्रॉप % के अनुसार सही कॉपर/एल्युमिनियम केबल (mm²) चुनें"
        ),
        formulaPreview = "A_min = (K × I × L × ρ) / (V × Max_Drop%)",
        keywords = listOf("cable size", "mm2", "copper", "aluminum", "ampacity", "केबल साइज", "कॉपर"),
        fields = listOf(
            CalculatorField(
                id = "cable_type",
                label = BilingualText("Conductor & Phase", "कंडक्टर और फेज़ चुनें"),
                defaultValue = "1",
                defaultUnit = "3φ Copper",
                unitOptions = listOf("3φ Copper", "3φ Aluminum", "1φ/DC Copper"),
                isSelectorOnly = true
            ),
            CalculatorField("current", BilingualText("Load Current (I)", "लोड करंट (I)"), "45", "A"),
            CalculatorField("voltage", BilingualText("System Voltage (V)", "सिस्टम वोल्टेज (V)"), "415", "V"),
            CalculatorField("length", BilingualText("Cable Run Length (one way)", "केबल की लंबाई (मीटर)"), "90", "m"),
            CalculatorField("max_drop_pct", BilingualText("Max Allowable Drop (%)", "अधिकतम वोल्टेज ड्रॉप (%)"), "3.0", "%")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("22kW Motor (42A, 90m, 3φ Cu)", "22kW मोटर (42A, 90m, 3φ कॉपर)"),
                values = mapOf("current" to "42", "voltage" to "415", "length" to "90", "max_drop_pct" to "3.0"),
                units = mapOf("cable_type" to "3φ Copper")
            ),
            CalculatorPreset(
                label = BilingualText("100A Feeder (150m, 3φ Al)", "100A फीडर (150m, 3φ एल्युमिनियम)"),
                values = mapOf("current" to "100", "voltage" to "415", "length" to "150", "max_drop_pct" to "3.0"),
                units = mapOf("cable_type" to "3φ Aluminum")
            )
        ),
        compute = { values, units ->
            runCatching {
                val i = requirePositive(values["current"], BilingualText("Load Current", "लोड करंट"))
                val v = requirePositive(values["voltage"], BilingualText("System Voltage", "सिस्टम वोल्टेज"))
                val len = requirePositive(values["length"], BilingualText("Cable Length", "केबल की लंबाई"))
                val maxDropPct = requireRange(values["max_drop_pct"], 0.5, 15.0, BilingualText("Max Voltage Drop (%)", "अधिकतम वोल्टेज ड्रॉप (%)"))
                val type = units["cable_type"] ?: "3φ Copper"

                val isAl = type.contains("Aluminum")
                val is3Ph = type.startsWith("3φ")
                val rho = if (isAl) 0.034 else 0.021
                val factor = if (is3Ph) sqrt(3.0) else 2.0

                val vDropAllowed = v * (maxDropPct / 100.0)
                val areaByDrop = (factor * i * len * rho) / vDropAllowed

                val cuSizes = listOf(
                    1.5 to 18.0, 2.5 to 25.0, 4.0 to 34.0, 6.0 to 43.0, 10.0 to 60.0,
                    16.0 to 80.0, 25.0 to 105.0, 35.0 to 130.0, 50.0 to 160.0,
                    70.0 to 200.0, 95.0 to 245.0, 120.0 to 285.0, 150.0 to 325.0,
                    185.0 to 370.0, 240.0 to 435.0, 300.0 to 495.0
                )
                val alSizes = listOf(
                    4.0 to 26.0, 6.0 to 33.0, 10.0 to 46.0, 16.0 to 62.0,
                    25.0 to 82.0, 35.0 to 101.0, 50.0 to 125.0, 70.0 to 156.0,
                    95.0 to 190.0, 120.0 to 220.0, 150.0 to 250.0, 185.0 to 285.0,
                    240.0 to 335.0, 300.0 to 385.0
                )
                val table = if (isAl) alSizes else cuSizes
                val maxSingle = table.last()

                // Support multi-run parallel cables when current or drop exceeds single 300 mm² cable
                val runsNeeded = maxOf(
                    ceil(i / maxSingle.second).toInt(),
                    ceil(areaByDrop / maxSingle.first).toInt()
                ).coerceAtLeast(1)

                val iPerRun = i / runsNeeded
                val dropAreaPerRun = areaByDrop / runsNeeded
                val chosenPerRun = table.firstOrNull { it.first >= dropAreaPerRun && it.second >= iPerRun } ?: maxSingle
                val totalArea = chosenPerRun.first * runsNeeded
                val totalAmpacity = chosenPerRun.second * runsNeeded
                val actualDropV = (factor * i * len * rho) / totalArea
                val actualDropPct = (actualDropV / v) * 100.0

                val sizeText = if (runsNeeded == 1) {
                    "${formatEng(chosenPerRun.first, 1)} mm²"
                } else {
                    "$runsNeeded × ${formatEng(chosenPerRun.first, 1)} mm²"
                }

                CalculationOutput(
                    primaryLabel = BilingualText("Recommended Cable Size", "अनुशंसित केबल साइज"),
                    primaryValue = sizeText,
                    primaryUnit = if (isAl) "Al XLPE" else "Cu XLPE",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Total Ampacity", "कुल करंट क्षमता"), formatEng(totalAmpacity, 0), "A"),
                        SecondaryMetric(BilingualText("Actual Voltage Drop", "वास्तविक वोल्टेज ड्रॉप"), formatEng(actualDropV, 2), "V (${formatEng(actualDropPct, 2)}%)"),
                        SecondaryMetric(BilingualText("Min Area (Drop)", "न्यूनतम साइज (ड्रॉप से)"), formatEng(areaByDrop, 2), "mm²")
                    ),
                    formulaUsed = "ΔV_max = V × (Drop% / 100)   |   A_drop = (K × I × L × ρ) / ΔV_max",
                    substitutedFormula = "A_drop = (${formatEng(factor, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 0)} × $rho) / (${formatEng(v, 0)} × ${formatEng(maxDropPct, 1)} / 100)",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Compute Maximum Allowable Drop (ΔV_max)", "अधिकतम स्वीकार्य वोल्टेज ड्रॉप निकालें"),
                            "ΔV_max = ${formatEng(v, 0)} × (${formatEng(maxDropPct, 1)} / 100) = ${formatEng(vDropAllowed, 2)} V",
                            BilingualText(
                                "Maximum permitted voltage loss along the ${formatEng(len, 0)} m cable run.",
                                "${formatEng(len, 0)} m केबल में अधिकतम अनुमत वोल्टेज लॉस।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Calculate Minimum Area for Voltage Drop", "वोल्टेज ड्रॉप हेतु न्यूनतम साइज (mm²) निकालें"),
                            "A_drop = (${formatEng(factor, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 0)} × $rho) / ${formatEng(vDropAllowed, 2)} = ${formatEng(areaByDrop, 2)} mm²",
                            BilingualText(
                                "Uses K = ${formatEng(factor, 3)} and 70°C resistivity ρ = $rho Ω·mm²/m.",
                                "यहाँ K = ${formatEng(factor, 3)} और 70°C रेजिस्टिविटी ρ = $rho Ω·mm²/m लिया गया है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Pick Standard Size for Both Area & Ampacity", "क्षेत्रफल व करंट क्षमता से मानक केबल चुनें"),
                            "Need ≥ ${formatEng(areaByDrop, 2)} mm² & ≥ ${formatEng(i, 1)} A → Selected: $sizeText (Rated ${formatEng(totalAmpacity, 0)} A)",
                            BilingualText(
                                if (runsNeeded > 1) "Load exceeds single 300 mm² cable, so $runsNeeded parallel runs per phase are selected."
                                else "First standard XLPE size meeting both thermal ampacity and drop area.",
                                if (runsNeeded > 1) "लोड एक 300 mm² केबल से अधिक है, इसलिए $runsNeeded समानांतर केबल चुनी गई हैं।"
                                else "यह मानक XLPE केबल करंट और वोल्टेज ड्रॉप दोनों सीमाओं को पूरा करती है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Verify Actual Voltage Drop on Selected Cable", "चुनी गई केबल पर वास्तविक वोल्टेज ड्रॉप जांचें"),
                            "ΔV_actual = (${formatEng(factor, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 0)} × $rho) / ${formatEng(totalArea, 1)} = ${formatEng(actualDropV, 2)} V (${formatEng(actualDropPct, 2)}%)",
                            BilingualText(
                                "Actual drop ${formatEng(actualDropPct, 2)}% stays safely below the ${formatEng(maxDropPct, 1)}% limit.",
                                "वास्तविक वोल्टेज ड्रॉप ${formatEng(actualDropPct, 2)}% तय सीमा ${formatEng(maxDropPct, 1)}% से कम है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Use $sizeText (${if (isAl) "Al" else "Cu"} XLPE), rated ${formatEng(totalAmpacity, 0)} A for a ${formatEng(i, 1)} A load over ${formatEng(len, 0)} m; actual drop is ${formatEng(actualDropV, 2)} V (${formatEng(actualDropPct, 2)}%).",
                        "${formatEng(len, 0)} m दूरी पर ${formatEng(i, 1)} A लोड के लिए $sizeText (${if (isAl) "एल्युमिनियम" else "कॉपर"} XLPE, क्षमता ${formatEng(totalAmpacity, 0)} A) उपयुक्त है, जिस पर ड्रॉप केवल ${formatEng(actualDropPct, 2)}% होगा।"
                    ),
                    assumptions = BilingualText(
                        "XLPE 90°C insulated cable in air/tray at 30°C ambient; ρ_Cu=0.021, ρ_Al=0.034 Ω·mm²/m.",
                        "मान्यता: XLPE 90°C केबल (30°C तापमान पर); ρ_Cu=0.021, ρ_Al=0.034 Ω·mm²/m।"
                    ),
                    engineeringNote = BilingualText(
                        "For long cable runs, voltage drop governs size; for short runs, thermal ampacity governs size.",
                        "लंबी दूरी की केबल में वोल्टेज ड्रॉप मुख्य होता है, जबकि छोटी केबल में करंट क्षमता मुख्य होती है।"
                    )
                )
            }
        }
    )

    private fun cableDeratingCalculator() = CalculatorDefinition(
        id = "cable_ampacity_derate",
        category = CalculatorCategory.CABLE_SIZE,
        title = BilingualText("Cable Ampacity Derating", "केबल क्षमता डीरेटिंग (Derating)"),
        subtitle = BilingualText(
            "Adjust rated cable current for Ambient Temperature & Tray Grouping",
            "अधिक तापमान और ट्रे में एक साथ बिछी केबलों के अनुसार सुरक्षित करंट क्षमता निकालें"
        ),
        formulaPreview = "I_safe = I_rated × K_temp × K_group",
        keywords = listOf("derating", "ampacity", "temperature", "grouping", "cable", "डीरेटिंग"),
        fields = listOf(
            CalculatorField("rated_amp", BilingualText("Base Cable Rating (at 30°C)", "बेस केबल क्षमता (30°C पर)"), "105", "A"),
            CalculatorField("k_temp", BilingualText("Ambient Temp Factor (0.2–1.3)", "तापमान फैक्टर (45°C पर 0.87)"), "0.87", "K_t"),
            CalculatorField("k_group", BilingualText("Grouping Factor (0.2–1.0)", "ग्रुपिंग फैक्टर (4 केबल = 0.75)"), "0.75", "K_g")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("25mm² Cu (105A) @ 45°C, 4 Cables", "25mm² Cu (105A) @ 45°C, 4 केबल"),
                values = mapOf("rated_amp" to "105", "k_temp" to "0.87", "k_group" to "0.75")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val iBase = requirePositive(values["rated_amp"], BilingualText("Base Cable Rating", "बेस केबल क्षमता"))
                val kt = requireRange(values["k_temp"], 0.2, 1.3, BilingualText("Ambient Temp Factor", "तापमान फैक्टर"))
                val kg = requireRange(values["k_group"], 0.2, 1.0, BilingualText("Grouping Factor", "ग्रुपिंग फैक्टर"))

                val kTotal = kt * kg
                val iSafe = iBase * kTotal
                val reductionPct = (1.0 - kTotal) * 100.0

                CalculationOutput(
                    primaryLabel = BilingualText("Derated Safe Ampacity", "डीरेटेड सुरक्षित करंट क्षमता"),
                    primaryValue = formatEng(iSafe, 1),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Combined Factor", "कुल डीरेटिंग गुणांक"), formatEng(kTotal, 3), "×"),
                        SecondaryMetric(BilingualText("Capacity Change", "क्षमता परिवर्तन"), formatEng(reductionPct, 1), "%")
                    ),
                    formulaUsed = "K_total = K_temp × K_group   |   I_safe = I_rated × K_total",
                    substitutedFormula = "I_safe = ${formatEng(iBase, 1)} × (${formatEng(kt, 2)} × ${formatEng(kg, 2)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Multiply Ambient & Grouping Factors", "तापमान और ग्रुपिंग फैक्टर गुणा करें"),
                            "K_total = ${formatEng(kt, 2)} × ${formatEng(kg, 2)} = ${formatEng(kTotal, 3)}",
                            BilingualText(
                                "XLPE 90°C cable ambient factor: 35°C=0.96, 40°C=0.91, 45°C=0.87, 50°C=0.82.",
                                "XLPE 90°C केबल तापमान फैक्टर: 35°C=0.96, 40°C=0.91, 45°C=0.87, 50°C=0.82।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Multiply Base Rating by Combined Factor", "बेस करंट क्षमता को कुल फैक्टर से गुणा करें"),
                            "I_safe = ${formatEng(iBase, 1)} × ${formatEng(kTotal, 3)} = ${formatEng(iSafe, 1)} A",
                            BilingualText(
                                "Never load the cable continuously above ${formatEng(iSafe, 1)} A under these site conditions.",
                                "इन परिस्थितियों में केबल पर ${formatEng(iSafe, 1)} A से अधिक लोड न डालें।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Check Percentage Capacity Change", "क्षमता में प्रतिशत परिवर्तन निकालें"),
                            "Change = (1 − ${formatEng(kTotal, 3)}) × 100 = ${formatEng(reductionPct, 1)}%",
                            BilingualText(
                                "Shows how much ampacity headroom is lost due to ambient heat and adjacent bundled cables.",
                                "आसपास की गर्मी और पास-पास बिछी केबलों के कारण करंट क्षमता में हुई कमी दर्शाता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "With K_temp = ${formatEng(kt, 2)} and K_group = ${formatEng(kg, 2)} (combined ${formatEng(kTotal, 3)}×), the cable's continuous rating adjusts from ${formatEng(iBase, 1)} A to ${formatEng(iSafe, 1)} A.",
                        "K_temp = ${formatEng(kt, 2)} और K_group = ${formatEng(kg, 2)} (कुल ${formatEng(kTotal, 3)}×) के कारण केबल की सुरक्षित क्षमता ${formatEng(iBase, 1)} A से बदलकर ${formatEng(iSafe, 1)} A हो जाती है।"
                    ),
                    assumptions = BilingualText(
                        "Based on IEC 60364-5-52 / IS 3961 derating factors relative to 30°C reference ambient.",
                        "मान्यता: IEC 60364-5-52 मानक (30°C आधार तापमान के सापेक्ष डीरेटिंग)।"
                    )
                )
            }
        }
    )
}
