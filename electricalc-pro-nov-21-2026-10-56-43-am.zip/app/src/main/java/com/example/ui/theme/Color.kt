package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Royal Blue & Dark Navy Theme Palette (Reference Design)
val RoyalBlue = Color(0xFF1565C0)
val RoyalBlueBright = Color(0xFF1E56D9)
val RoyalBlueHeaderStart = Color(0xFF1565C0)
val RoyalBlueHeaderEnd = Color(0xFF0D2B5B)
val DarkNavyBlue = Color(0xFF0D2B5B)
val DeepNavyInk = Color(0xFF0A1E3D)
val RoyalBlueTint = Color(0xFFEAF2FF)
val SoftBlueChip = Color(0xFFEFF6FF)
val LightBlueBorder = Color(0xFFBFD7F8)
val TabUnderlineRed = Color(0xFFD32F2F)

// Clean White & Very Light Grey Surfaces
val PureWhite = Color(0xFFFFFFFF)
val CardLightGrey = Color(0xFFF5F7FA)
val CleanSurfaceAlt = Color(0xFFF8FAFC)
val SubtleGreyBorder = Color(0xFFDDE5F0)
val LightGreyBorder = Color(0xFFD1D9E6)
val HairlineGrey = Color(0xFFE5EAF2)

// Crisp High-Contrast Text Tokens
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF475569)

// Action & Semantic Status Accents
val ActionBlue = Color(0xFF1565C0)
val ActionRed = Color(0xFFD32F2F)
val ClearRed = Color(0xFFD32F2F)
val SoftRedTint = Color(0xFFFEF2F2)
val SoftRedBorder = Color(0xFFFCA5A5)
val ErrorRedDark = Color(0xFFB91C1C)
val WarningAmberDark = Color(0xFFB45309)
val SoftAmberTint = Color(0xFFFFFBEB)
val SoftAmberBorder = Color(0xFFFCD34D)
val SuccessGreenDark = Color(0xFF15803D)
val SoftGreenTint = Color(0xFFF0FDF4)
val FavoriteGold = Color(0xFFF59E0B)
