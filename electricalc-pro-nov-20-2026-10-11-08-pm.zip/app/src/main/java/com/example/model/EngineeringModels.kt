package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.material.icons.rounded.ElectricMeter
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PrecisionManufacturing
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector
import java.util.Locale
import kotlin.math.abs

enum class AppLanguage {
    ENGLISH,
    HINDI
}

data class BilingualText(
    val en: String,
    val hi: String
) {
    fun get(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> en
        AppLanguage.HINDI -> hi
    }
}

class BilingualValidationException(val bilingualMessage: BilingualText) :
    IllegalArgumentException(bilingualMessage.en)

enum class CalculatorCategory(
    val id: String,
    val title: BilingualText,
    val shortTitle: BilingualText,
    val description: BilingualText,
    val icon: ImageVector,
    val isOrangeAccent: Boolean = false
) {
    ELECTRICAL(
        id = "electrical",
        title = BilingualText("Electrical Calculations", "इलेक्ट्रिकल गणनाएँ"),
        shortTitle = BilingualText("Electrical", "इलेक्ट्रिकल"),
        description = BilingualText(
            "Ohm's law, 1-phase & 3-phase power, PF capacitor, voltage drop",
            "ओम का नियम, 1-फेज़ व 3-फेज़ पावर, PF कैपेसिटर, वोल्टेज ड्रॉप"
        ),
        icon = Icons.Rounded.Bolt,
        isOrangeAccent = false
    ),
    INSTRUMENTATION(
        id = "instrumentation",
        title = BilingualText("Instrumentation", "इंस्ट्रूमेंटेशन"),
        shortTitle = BilingualText("Instrumentation", "इंस्ट्रूमेंट"),
        description = BilingualText(
            "Control valve Cv/Kv, DP orifice flow, transmitter calibration error",
            "कंट्रोल वाल्व Cv/Kv, DP ऑरिफिस फ्लो, ट्रांसमीटर कैलिब्रेशन त्रुटि"
        ),
        icon = Icons.Rounded.PrecisionManufacturing,
        isOrangeAccent = true
    ),
    MOTOR(
        id = "motor",
        title = BilingualText("Motor Calculations", "मोटर गणनाएँ"),
        shortTitle = BilingualText("Motor", "मोटर"),
        description = BilingualText(
            "3-phase FLC current, RPM & slip, DOL/Star-Delta starter, shaft torque",
            "3-फेज़ FLC करंट, RPM व स्लिप, DOL/स्टार-डेल्टा स्टार्टर, टॉर्क"
        ),
        icon = Icons.Rounded.ElectricMeter,
        isOrangeAccent = false
    ),
    VFD(
        id = "vfd",
        title = BilingualText("VFD Calculations", "वीएफडी (VFD) गणनाएँ"),
        shortTitle = BilingualText("VFD", "वीएफडी"),
        description = BilingualText(
            "Hz to RPM, V/f ratio, affinity energy saving, DC bus & braking",
            "Hz से RPM, V/f अनुपात, ऊर्जा बचत नियम, DC बस व ब्रेकिंग"
        ),
        icon = Icons.Rounded.Speed,
        isOrangeAccent = true
    ),
    PLC_DCS(
        id = "plc_dcs",
        title = BilingualText("PLC & DCS", "पीएलसी और डीसीएस"),
        shortTitle = BilingualText("PLC & DCS", "PLC / DCS"),
        description = BilingualText(
            "Raw counts scaling (0-27648 / 32767), HSC pulse RPM, 24V SMPS load",
            "रॉ काउंट्स स्केलिंग (0-27648), एनकोडर RPM, 24V SMPS लोड"
        ),
        icon = Icons.Rounded.Memory,
        isOrangeAccent = false
    ),
    SIGNAL_4_20MA(
        id = "signal_4_20ma",
        title = BilingualText("4–20 mA Signal", "4–20 mA सिग्नल"),
        shortTitle = BilingualText("4–20 mA", "4–20 mA"),
        description = BilingualText(
            "Linear & square-root PV to mA scaling, max loop resistance check",
            "लीनियर और वर्गमूल PV से mA स्केलिंग, लूप रेजिस्टेंस जांच"
        ),
        icon = Icons.AutoMirrored.Rounded.ShowChart,
        isOrangeAccent = true
    ),
    RTD_THERMOCOUPLE(
        id = "rtd_thermocouple",
        title = BilingualText("RTD & Thermocouple", "आरटीडी और थर्मोकपल"),
        shortTitle = BilingualText("RTD / TC", "RTD / TC"),
        description = BilingualText(
            "Pt100 / Pt1000 Ohm <-> °C (IEC 60751), Type K/J/T/E mV with CJC",
            "Pt100/Pt1000 ओम से °C, टाइप K/J/T/E mV व CJC गणना"
        ),
        icon = Icons.Rounded.DeviceThermostat,
        isOrangeAccent = false
    ),
    PRESSURE_FLOW_LEVEL(
        id = "pressure_flow_level",
        title = BilingualText("Pressure, Flow & Level", "प्रेशर, फ्लो और लेवल"),
        shortTitle = BilingualText("Process P/F/L", "प्रेशर/फ्लो"),
        description = BilingualText(
            "Pressure converter, hydrostatic DP tank level, pipe velocity & flow",
            "प्रेशर कन्वर्टर, टैंक लेवल (DP), पाइप वेलोसिटी और फ्लो रेट"
        ),
        icon = Icons.Rounded.WaterDrop,
        isOrangeAccent = true
    ),
    CABLE_SIZE(
        id = "cable_size",
        title = BilingualText("Cable Size", "केबल साइज गणना"),
        shortTitle = BilingualText("Cable Size", "केबल साइज"),
        description = BilingualText(
            "Cu/Al cable size by voltage drop %, standard mm² recommendation",
            "कॉपर/एल्युमिनियम केबल साइज, वोल्टेज ड्रॉप % और डीरेटिंग"
        ),
        icon = Icons.Rounded.Cable,
        isOrangeAccent = false
    )
}

data class CalculatorField(
    val id: String,
    val label: BilingualText,
    val defaultValue: String,
    val defaultUnit: String,
    val unitOptions: List<String> = listOf(defaultUnit),
    val helperText: BilingualText? = null,
    val allowNegative: Boolean = false,
    val isSelectorOnly: Boolean = false
)

data class CalculatorPreset(
    val label: BilingualText,
    val values: Map<String, String>,
    val units: Map<String, String> = emptyMap()
)

enum class StatusLevel {
    NORMAL,
    WARNING,
    INFO
}

data class SecondaryMetric(
    val label: BilingualText,
    val value: String,
    val unit: String = "",
    val localizedValue: BilingualText? = null
)

data class CalculationStep(
    val stepNumber: Int,
    val title: BilingualText,
    val expression: String,
    val explanation: BilingualText
)

data class CalculationOutput(
    val primaryLabel: BilingualText,
    val primaryValue: String,
    val primaryUnit: String,
    val primaryUnitLocalized: BilingualText? = null,
    val secondaryMetrics: List<SecondaryMetric> = emptyList(),
    val formulaUsed: String,
    val substitutedFormula: String = "",
    val steps: List<CalculationStep>,
    val resultExplanation: BilingualText? = null,
    val assumptions: BilingualText? = null,
    val engineeringNote: BilingualText? = null,
    val statusLevel: StatusLevel = StatusLevel.NORMAL
)

data class CalculatorDefinition(
    val id: String,
    val category: CalculatorCategory,
    val title: BilingualText,
    val subtitle: BilingualText,
    val formulaPreview: String,
    val keywords: List<String>,
    val fields: List<CalculatorField>,
    val presets: List<CalculatorPreset> = emptyList(),
    val compute: (values: Map<String, Double>, units: Map<String, String>) -> Result<CalculationOutput>
)

data class CalculationHistoryItem(
    val calculatorId: String,
    val title: BilingualText,
    val resultSummary: String,
    val category: CalculatorCategory
)

fun formatEng(value: Double, decimals: Int = 3): String {
    if (value.isNaN() || value.isInfinite()) return "—"
    val safeVal = if (abs(value) < 1e-12) 0.0 else value
    val rounded = String.format(Locale.US, "%.${decimals}f", safeVal)
    val result = if (rounded.contains('.')) {
        rounded.trimEnd('0').trimEnd('.')
    } else {
        rounded
    }
    return if (result == "-0") "0" else result
}

fun requirePositive(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value <= 0.0) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be greater than 0.",
                "${fieldLabel.hi} का मान 0 से अधिक होना चाहिए।"
            )
        )
    }
    return value
}

fun requireNonNegative(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value < 0.0) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} cannot be negative.",
                "${fieldLabel.hi} का मान नेगेटिव (ऋणात्मक) नहीं हो सकता।"
            )
        )
    }
    return value
}

fun requireNonZero(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || abs(value) < 1e-12) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} cannot be zero.",
                "${fieldLabel.hi} का मान शून्य (0) नहीं हो सकता।"
            )
        )
    }
    return value
}

fun requireFinite(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite()) {
        throw BilingualValidationException(
            BilingualText(
                "Please enter a valid finite number for ${fieldLabel.en}.",
                "कृपया ${fieldLabel.hi} के लिए एक मान्य संख्या दर्ज करें।"
            )
        )
    }
    return value
}

fun requireRange(
    value: Double?,
    min: Double,
    max: Double,
    fieldLabel: BilingualText
): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value < min || value > max) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be between ${formatEng(min, 2)} and ${formatEng(max, 2)}.",
                "${fieldLabel.hi} का मान ${formatEng(min, 2)} से ${formatEng(max, 2)} के बीच होना चाहिए।"
            )
        )
    }
    return value
}

fun requireEvenPoles(value: Double?, fieldLabel: BilingualText): Int {
    if (value == null || value.isNaN() || value.isInfinite()) {
        throw BilingualValidationException(
            BilingualText("Enter valid number of poles.", "पोल की सही संख्या दर्ज करें।")
        )
    }
    val rounded = value.toInt()
    if (abs(value - rounded) > 1e-6 || rounded < 2 || rounded % 2 != 0 || rounded > 24) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be an even number (2, 4, 6, 8, ... 24).",
                "${fieldLabel.hi} सम संख्या (2, 4, 6, 8, ... 24) होनी चाहिए।"
            )
        )
    }
    return rounded
}
