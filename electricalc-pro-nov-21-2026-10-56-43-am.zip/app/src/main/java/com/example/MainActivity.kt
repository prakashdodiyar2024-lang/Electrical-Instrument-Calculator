package com.example

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.model.AppLanguage
import com.example.model.BilingualText
import com.example.model.CalculatorCategory
import com.example.ui.CalculatorViewModel
import com.example.ui.audio.TouchSoundController
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.CategoryScreen
import com.example.ui.screens.FavoriteScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.EICalculatorTheme
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.TextSecondaryDark

const val ROUTE_SPLASH = "splash"
const val ROUTE_HOME = "home"
const val ROUTE_FAVORITE = "favorite"
const val ROUTE_ABOUT = "about"
const val ROUTE_SETTINGS = "settings"
const val ROUTE_CATEGORY = "category/{categoryId}"
const val ROUTE_CALCULATOR = "calculator/{calcId}"

private data class BottomNavTab(
    val route: String,
    val label: BilingualText,
    val icon: ImageVector,
    val testTag: String
)

private val bottomNavTabs = listOf(
    BottomNavTab(
        route = ROUTE_HOME,
        label = BilingualText("Home", "होम"),
        icon = Icons.Rounded.Home,
        testTag = "bottom_nav_home"
    ),
    BottomNavTab(
        route = ROUTE_FAVORITE,
        label = BilingualText("Favorite", "पसंदीदा"),
        icon = Icons.Rounded.Star,
        testTag = "bottom_nav_favorite"
    ),
    BottomNavTab(
        route = ROUTE_ABOUT,
        label = BilingualText("About", "परिचय"),
        icon = Icons.Rounded.Info,
        testTag = "bottom_nav_about"
    ),
    BottomNavTab(
        route = ROUTE_SETTINGS,
        label = BilingualText("Settings", "सेटिंग्स"),
        icon = Icons.Rounded.Settings,
        testTag = "bottom_nav_settings"
    )
)

class MainActivity : ComponentActivity() {

    private var showSplashState by mutableStateOf(true)
    private var splashSessionKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TouchSoundController.getOrCreate(applicationContext)
        val skipSplashFromLauncher = intent?.getBooleanExtra(EXTRA_SKIP_SPLASH, false) == true
        if (skipSplashFromLauncher) {
            intent?.removeExtra(EXTRA_SKIP_SPLASH)
        }
        val wasConfigChange = savedInstanceState?.getBoolean(KEY_WAS_CONFIG_CHANGE, false) == true
        if (skipSplashFromLauncher) {
            showSplashState = false
        } else if (wasConfigChange) {
            showSplashState = savedInstanceState?.getBoolean(KEY_SHOW_SPLASH, false) ?: false
            splashSessionKey = savedInstanceState?.getInt(KEY_SPLASH_SESSION_KEY, 0) ?: 0
        } else {
            showSplashState = true
            splashSessionKey = (savedInstanceState?.getInt(KEY_SPLASH_SESSION_KEY, 0) ?: 0) + 1
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        setContent {
            LaunchedEffect(showSplashState) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                )
            }
            EICalculatorTheme {
                EICalculatorApp(
                    showSplashInitially = !skipSplashFromLauncher,
                    splashSessionKey = splashSessionKey,
                    externalShowSplash = showSplashState,
                    onSplashFinished = {
                        if (showSplashState) {
                            showSplashState = false
                        }
                    }
                )
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_WAS_CONFIG_CHANGE, changingConfigurations != 0)
        outState.putBoolean(KEY_SHOW_SPLASH, showSplashState)
        outState.putInt(KEY_SPLASH_SESSION_KEY, splashSessionKey)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val skipSplashFromLauncher = intent.getBooleanExtra(EXTRA_SKIP_SPLASH, false)
        if (skipSplashFromLauncher) {
            intent.removeExtra(EXTRA_SKIP_SPLASH)
            showSplashState = false
        } else if (!showSplashState) {
            splashSessionKey += 1
            showSplashState = true
        }
    }

    companion object {
        const val EXTRA_SKIP_SPLASH = "extra_skip_splash"
        private const val KEY_WAS_CONFIG_CHANGE = "key_was_config_change"
        private const val KEY_SHOW_SPLASH = "key_show_splash"
        private const val KEY_SPLASH_SESSION_KEY = "key_splash_session_key"
    }
}

@Composable
fun EICalculatorApp(
    viewModel: CalculatorViewModel = viewModel(),
    showSplashInitially: Boolean = true,
    splashSessionKey: Int = 0,
    externalShowSplash: Boolean? = null,
    onSplashFinished: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var internalShowSplash by remember(splashSessionKey, showSplashInitially) {
        mutableStateOf(showSplashInitially)
    }
    val showSplash = externalShowSplash ?: internalShowSplash

    AnimatedContent(
        targetState = showSplash,
        transitionSpec = {
            (fadeIn(animationSpec = tween(durationMillis = 600)) +
                scaleIn(initialScale = 0.98f, animationSpec = tween(durationMillis = 600))) togetherWith
                fadeOut(animationSpec = tween(durationMillis = 500))
        },
        label = "splashToHomeTransition"
    ) { splashVisible ->
        if (splashVisible) {
            SplashScreen(
                language = uiState.language,
                sessionKey = splashSessionKey,
                onFinish = {
                    if (externalShowSplash == null) {
                        if (internalShowSplash) {
                            internalShowSplash = false
                        }
                    }
                    onSplashFinished?.invoke()
                }
            )
        } else {
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route
            val showBottomBar = currentRoute in setOf(
                ROUTE_HOME,
                ROUTE_FAVORITE,
                ROUTE_ABOUT,
                ROUTE_SETTINGS
            )
            val playClick = rememberTouchClickSound()

            Scaffold(
                containerColor = PureWhite,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (showBottomBar) {
                        Column {
                            HorizontalDivider(color = HairlineGrey)
                            NavigationBar(
                                containerColor = PureWhite,
                                tonalElevation = 0.dp
                            ) {
                                bottomNavTabs.forEach { tab ->
                                    val selected = currentRoute == tab.route
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            playClick()
                                            if (currentRoute != tab.route) {
                                                navController.navigate(tab.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) {
                                                        saveState = true
                                                    }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = tab.icon,
                                                contentDescription = tab.label.get(uiState.language)
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = tab.label.get(uiState.language),
                                                fontSize = 11.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = RoyalBlue,
                                            selectedTextColor = RoyalBlue,
                                            indicatorColor = RoyalBlueTint,
                                            unselectedIconColor = TextSecondaryDark,
                                            unselectedTextColor = TextSecondaryDark
                                        ),
                                        modifier = Modifier.testTag(tab.testTag)
                                    )
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = ROUTE_HOME,
                    modifier = Modifier.padding(innerPadding)
                ) {
                    composable(route = ROUTE_HOME) {
                        HomeScreen(
                            uiState = uiState,
                            onToggleLanguage = viewModel::toggleLanguage,
                            onSelectDiscipline = viewModel::selectDiscipline,
                            onSelectCategoryTab = viewModel::selectCategoryTab,
                            onSearchQueryChange = viewModel::onSearchQueryChange,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onOpenCalculator = { calcId ->
                                viewModel.openCalculator(calcId)
                                navController.navigate("calculator/$calcId") {
                                    launchSingleTop = true
                                }
                            },
                            onOpenAbout = {
                                navController.navigate(ROUTE_ABOUT) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }

                    composable(route = ROUTE_FAVORITE) {
                        FavoriteScreen(
                            favoriteIds = uiState.favoriteIds,
                            language = uiState.language,
                            onToggleLanguage = viewModel::toggleLanguage,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onOpenCalculator = { calcId ->
                                viewModel.openCalculator(calcId)
                                navController.navigate("calculator/$calcId") {
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(route = ROUTE_ABOUT) {
                        AboutScreen(
                            language = uiState.language,
                            onBack = null,
                            onToggleLanguage = viewModel::toggleLanguage
                        )
                    }

                    composable(route = ROUTE_SETTINGS) {
                        SettingsScreen(
                            uiState = uiState,
                            onSetLanguage = viewModel::setLanguage,
                            onToggleTouchSound = viewModel::setTouchSoundEnabled,
                            onSetDefaultDiscipline = viewModel::setDefaultDiscipline,
                            onClearFavorites = viewModel::clearFavorites,
                            onClearRecentHistory = viewModel::clearRecentHistory
                        )
                    }

                    composable(
                        route = ROUTE_CATEGORY,
                        arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val catId = backStackEntry.arguments?.getString("categoryId")
                        val category = CalculatorCategory.entries.firstOrNull { it.id == catId }
                            ?: CalculatorCategory.ELEC_BASIC
                        CategoryScreen(
                            category = category,
                            language = uiState.language,
                            favoriteIds = uiState.favoriteIds,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onBack = {
                                if (navController.previousBackStackEntry != null) {
                                    navController.popBackStack()
                                }
                            },
                            onToggleLanguage = viewModel::toggleLanguage,
                            onOpenCalculator = { calcId ->
                                viewModel.openCalculator(calcId)
                                navController.navigate("calculator/$calcId") {
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(
                        route = ROUTE_CALCULATOR,
                        arguments = listOf(navArgument("calcId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val calcId = backStackEntry.arguments?.getString("calcId")
                        LaunchedEffect(calcId) {
                            if (calcId != null && uiState.activeCalculator?.id != calcId) {
                                viewModel.openCalculator(calcId)
                            }
                        }
                        CalculatorScreen(
                            uiState = uiState,
                            onBack = {
                                if (navController.previousBackStackEntry != null) {
                                    navController.popBackStack()
                                }
                            },
                            onToggleLanguage = viewModel::toggleLanguage,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onFieldValueChange = viewModel::onFieldValueChange,
                            onToggleSign = viewModel::toggleFieldSign,
                            onFieldUnitChange = viewModel::onFieldUnitChange,
                            onApplyPreset = viewModel::applyPreset,
                            onCalculate = { viewModel.calculate(addToHistory = true) },
                            onReset = viewModel::resetActiveCalculator
                        )
                    }
                }
            }
        }
    }
}
