package com.example.domain.electrical

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryStd
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.ViewColumn
import com.example.domain.STANDARD_CABLE_MM2
import com.example.domain.engOutput
import com.example.domain.nearestStandardRating
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.sqrt

object ElecMoreCalculators {

    val all: List<CalculatorDefinition> = listOf(
        capacitorKvar(),            // 41
        capacitorDischargeTime(),   // 42
        batteryBackupTime(),        // 43
        upsBatterySize(),           // 44
        inverterLoad(),             // 45
        earthResistance(),          // 46
        conductorSizeDensity(),     // 47
        conduitCableTray(),         // 48
        lightingLoad(),             // 49
        powerCostBill()             // 50
    )

    private fun capacitorKvar() = CalculatorDefinition(
        id = "more_capacitor_kvar",
        serialNumber = 41,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.ElectricBolt,
        title = BilingualText("Capacitor kVAr Calculator", "कैपेसिटर kVAr कैलकुलेटर"),
        subtitle = BilingualText("Compute kVAr Output & Current from Capacitance (µF) & Voltage", "कैपेसिटेंस (µF) और वोल्टेज से कैपेसिटर kVAr व करंट निकालें"),
        formulaPreview = "kVAr_3φΔ = 3 × 2πf × C × V² × 10⁻⁹",
        assumptions = BilingualText(
            "Assumes rated sinusoidal voltage and frequency without harmonic overload.",
            "मान्यता: रेटेड वोल्टेज और साइनूसॉइडल फ्रीक्वेंसी।"
        ),
        keywords = listOf("capacitor kvar", "microfarad", "uf", "reactive power"),
        fields = listOf(
            CalculatorField("conn", BilingualText("Connection", "कनेक्शन"), "1", "3φ Delta", listOf("3φ Delta", "3φ Star", "1φ"), isSelectorOnly = true),
            CalculatorField("cap_uf", BilingualText("Capacitance (µF per Phase / Unit)", "कैपेसिटेंस (µF)"), "100", "µF"),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V"),
            CalculatorField("freq", BilingualText("Frequency (Hz)", "फ्रीक्वेंसी (Hz)"), "50", "Hz")
        ),
        compute = { values, units ->
            runCatching {
                val cUf = requirePositive(values["cap_uf"], BilingualText("Capacitance", "कैपेसिटेंस"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val f = requireRange(values["freq"], 20.0, 400.0, BilingualText("Frequency", "फ्रीक्वेंसी"))
                val cF = cUf * 1e-6
                val conn = units["conn"] ?: "3φ Delta"
                val kvar = when (conn) {
                    "3φ Star" -> (2.0 * PI * f * cF * v * v) / 1000.0
                    "1φ" -> (2.0 * PI * f * cF * v * v) / 1000.0
                    else -> (3.0 * 2.0 * PI * f * cF * v * v) / 1000.0
                }
                val xc = 1.0 / (2.0 * PI * f * cF)
                val lineCurrent = if (conn == "1φ") (kvar * 1000.0) / v else (kvar * 1000.0) / (sqrt(3.0) * v)
                engOutput(
                    primaryLabel = BilingualText("Capacitor Reactive Power", "कैपेसिटर रिएक्टिव पावर"),
                    primaryValue = formatEng(kvar, 2),
                    primaryUnit = "kVAr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Line Current", "लाइन करंट"), formatEng(lineCurrent, 2), "A"),
                        SecondaryMetric(BilingualText("Reactance (X_c)", "रिएक्टेंस (X_c)"), formatEng(xc, 2), "Ω")
                    ),
                    formulaUsed = "Q = k × 2πf × C × V² / 1000",
                    substitutedFormula = "$conn → ${formatEng(kvar, 2)} kVAr",
                    stepExplanation = BilingualText("Reactive Output = ${formatEng(kvar, 2)} kVAr, Current = ${formatEng(lineCurrent, 2)} A", "आउटपुट = ${formatEng(kvar, 2)} kVAr")
                )
            }
        }
    )

    private fun capacitorDischargeTime() = CalculatorDefinition(
        id = "more_capacitor_discharge",
        serialNumber = 42,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.Timer,
        title = BilingualText("Capacitor Discharge Time", "कैपेसिटर डिस्चार्ज समय"),
        subtitle = BilingualText("Calculate Safe RC Bleeder Discharge Time & Stored Energy", "कैपेसिटर को सुरक्षित वोल्टेज तक डिस्चार्ज होने का समय निकालें"),
        formulaPreview = "t = −R × C × ln(V_safe / V_0)   |   E = ½ × C × V_0²",
        assumptions = BilingualText(
            "Assumes purely resistive bleeder discharge; IEC 60831 requires < 50 V within 60 s (or 75 V in 3 min).",
            "मान्यता: शुद्ध RC डिस्चार्ज; सुरक्षा के लिए 60 सेकंड में < 50 V होना चाहिए।"
        ),
        keywords = listOf("capacitor discharge", "rc time constant", "bleeder", "safety"),
        fields = listOf(
            CalculatorField("cap_uf", BilingualText("Capacitance (µF)", "कैपेसिटेंस (µF)"), "4700", "µF"),
            CalculatorField("res_kohm", BilingualText("Bleeder Resistance (kΩ)", "ब्लीडर रेजिस्टेंस (kΩ)"), "22", "kΩ", listOf("kΩ", "Ω")),
            CalculatorField("v0", BilingualText("Initial Voltage (V₀)", "प्रारंभिक वोल्टेज (V₀)"), "600", "V"),
            CalculatorField("vsafe", BilingualText("Safe Target Voltage", "सुरक्षित वोल्टेज लक्ष्य"), "50", "V")
        ),
        compute = { values, units ->
            runCatching {
                val cUf = requirePositive(values["cap_uf"], BilingualText("Capacitance", "कैपेसिटेंस"))
                val rawR = requirePositive(values["res_kohm"], BilingualText("Resistance", "रेजिस्टेंस"))
                val v0 = requirePositive(values["v0"], BilingualText("Initial Voltage", "प्रारंभिक वोल्टेज"))
                val vSafe = requirePositive(values["vsafe"], BilingualText("Safe Voltage", "सुरक्षित वोल्टेज"))
                if (vSafe >= v0) {
                    throw BilingualValidationException(
                        BilingualText("Safe target voltage must be lower than initial voltage V₀.", "सुरक्षित वोल्टेज, प्रारंभिक वोल्टेज से कम होना चाहिए।")
                    )
                }
                val rOhm = if (units["res_kohm"] == "kΩ") rawR * 1000.0 else rawR
                val cF = cUf * 1e-6
                val tau = rOhm * cF
                val tSec = -tau * ln(vSafe / v0)
                val energyJ = 0.5 * cF * v0 * v0
                val bleederW = (v0 * v0) / rOhm
                engOutput(
                    primaryLabel = BilingualText("Safe Discharge Time (t)", "सुरक्षित डिस्चार्ज समय (t)"),
                    primaryValue = formatEng(tSec, 2),
                    primaryUnit = "s",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Time Constant (τ=RC)", "टाइम कॉन्स्टेंट (τ)"), formatEng(tau, 2), "s"),
                        SecondaryMetric(BilingualText("Stored Energy", "संचित ऊर्जा"), formatEng(energyJ, 1), "J"),
                        SecondaryMetric(BilingualText("Peak Bleeder Power", "रेजिस्टर पावर"), formatEng(bleederW, 2), "W")
                    ),
                    formulaUsed = "t = −R × C × ln(V_safe / V₀)",
                    substitutedFormula = "t = −${formatEng(tau, 3)} × ln(${formatEng(vSafe, 1)} / ${formatEng(v0, 1)})",
                    stepExplanation = BilingualText("Discharges from ${formatEng(v0, 0)}V to ${formatEng(vSafe, 0)}V in ${formatEng(tSec, 2)} s", "डिस्चार्ज समय = ${formatEng(tSec, 2)} सेकंड"),
                    statusLevel = if (tSec > 60.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun batteryBackupTime() = CalculatorDefinition(
        id = "more_battery_backup",
        serialNumber = 43,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.BatteryChargingFull,
        title = BilingualText("Battery Backup Time Calculator", "बैटरी बैकअप समय कैलकुलेटर"),
        subtitle = BilingualText("Estimate UPS / Inverter Runtime from Ah, Voltage & Load", "बैटरी Ah, वोल्टेज और लोड से बैकअप समय (घंटे) निकालें"),
        formulaPreview = "Time (hr) = (Ah × V_bank × DoD × η) / Load_W",
        assumptions = BilingualText(
            "Accounts for Depth of Discharge (80% LiFePO4 / 50–80% Lead-Acid) and inverter efficiency.",
            "मान्यता: DoD% (बैटरी सुरक्षा सीमा) व इन्वर्टर एफिशिएंसी शामिल है।"
        ),
        keywords = listOf("battery backup", "runtime", "ups", "ah", "बैटरी बैकअप"),
        fields = listOf(
            CalculatorField("ah", BilingualText("Battery Capacity (Ah)", "बैटरी क्षमता (Ah)"), "150", "Ah"),
            CalculatorField("v_bank", BilingualText("Battery Bank Voltage (V)", "बैटरी वोल्टेज (V)"), "24", "V"),
            CalculatorField("load", BilingualText("Connected AC Load", "कुल लोड पावर"), "600", "W", listOf("W", "kW")),
            CalculatorField("dod", BilingualText("Usable DoD (%)", "उपयोगी DoD (%)"), "80", "%"),
            CalculatorField("eff", BilingualText("Inverter Efficiency (%)", "इन्वर्टर एफिशिएंसी (%)"), "88", "%")
        ),
        compute = { values, units ->
            runCatching {
                val ah = requirePositive(values["ah"], BilingualText("Battery Ah", "बैटरी Ah"))
                val vBank = requirePositive(values["v_bank"], BilingualText("Battery Voltage", "बैटरी वोल्टेज"))
                val rawLoad = requirePositive(values["load"], BilingualText("Connected Load", "लोड"))
                val dod = requireRange(values["dod"], 10.0, 100.0, BilingualText("DoD %", "DoD %"))
                val eff = requireRange(values["eff"], 30.0, 100.0, BilingualText("Efficiency %", "एफिशिएंसी %"))
                val loadW = if (units["load"] == "kW") rawLoad * 1000.0 else rawLoad
                val usableWh = ah * vBank * (dod / 100.0) * (eff / 100.0)
                val hours = usableWh / loadW
                val mins = hours * 60.0
                val dcCurrent = loadW / (vBank * (eff / 100.0))
                engOutput(
                    primaryLabel = BilingualText("Estimated Backup Time", "अनुमानित बैकअप समय"),
                    primaryValue = formatEng(hours, 2),
                    primaryUnit = "Hours",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Backup (Minutes)", "बैकअप (मिनट)"), formatEng(mins, 0), "min"),
                        SecondaryMetric(BilingualText("Battery Draw", "बैटरी करंट"), formatEng(dcCurrent, 1), "A DC"),
                        SecondaryMetric(BilingualText("Usable Energy", "उपयोगी ऊर्जा"), formatEng(usableWh / 1000.0, 2), "kWh")
                    ),
                    formulaUsed = "t = (Ah × V × DoD × η) / Load_W",
                    substitutedFormula = "t = (${formatEng(ah, 0)} × ${formatEng(vBank, 0)} × ${formatEng(dod / 100, 2)} × ${formatEng(eff / 100, 2)}) / ${formatEng(loadW, 0)}",
                    stepExplanation = BilingualText("Runtime ≈ ${formatEng(hours, 2)} hrs (${formatEng(mins, 0)} min)", "बैकअप समय ≈ ${formatEng(hours, 2)} घंटे")
                )
            }
        }
    )

    private fun upsBatterySize() = CalculatorDefinition(
        id = "more_ups_battery_size",
        serialNumber = 44,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.BatteryStd,
        title = BilingualText("UPS Battery Size Calculator", "UPS बैटरी साइज कैलकुलेटर"),
        subtitle = BilingualText("Calculate Required Battery Bank Ah & 12V Block Count", "UPS लोड और बैकअप समय के लिए आवश्यक बैटरी Ah निकालें"),
        formulaPreview = "Ah = (Load_W × Hours) / (V_dc × DoD × η)",
        assumptions = BilingualText(
            "Calculates Ah capacity at target backup rate; Peukert effect may require +15% on fast <1 hr discharge.",
            "मान्यता: 1 घंटे से कम तेज डिस्चार्ज में 15% अतिरिक्त Ah मार्जिन रखें।"
        ),
        keywords = listOf("ups battery", "battery sizing", "ah", "12v blocks", "ups"),
        fields = listOf(
            CalculatorField("load_w", BilingualText("UPS Active Load", "UPS लोड पावर"), "3000", "W", listOf("W", "kW")),
            CalculatorField("hours", BilingualText("Required Backup (Hours)", "आवश्यक बैकअप (घंटे)"), "2", "hr"),
            CalculatorField("v_dc", BilingualText("UPS DC Bus Voltage (V)", "UPS DC वोल्टेज (V)"), "96", "V"),
            CalculatorField("eff", BilingualText("Inverter Efficiency (%)", "इन्वर्टर एफिशिएंसी (%)"), "90", "%"),
            CalculatorField("dod", BilingualText("Max DoD (%)", "अधिकतम DoD (%)"), "80", "%")
        ),
        compute = { values, units ->
            runCatching {
                val rawLoad = requirePositive(values["load_w"], BilingualText("UPS Load", "UPS लोड"))
                val hrs = requirePositive(values["hours"], BilingualText("Backup Hours", "बैकअप घंटे"))
                val vDc = requirePositive(values["v_dc"], BilingualText("DC Voltage", "DC वोल्टेज"))
                val eff = requireRange(values["eff"], 30.0, 100.0, BilingualText("Efficiency", "एफिशिएंसी"))
                val dod = requireRange(values["dod"], 10.0, 100.0, BilingualText("DoD", "DoD"))
                val loadW = if (units["load_w"] == "kW") rawLoad * 1000.0 else rawLoad
                val reqAh = (loadW * hrs) / (vDc * (eff / 100.0) * (dod / 100.0))
                val stdAhList = listOf(7.0, 12.0, 18.0, 26.0, 42.0, 65.0, 100.0, 120.0, 150.0, 200.0, 250.0)
                val stdAh = nearestStandardRating(reqAh, stdAhList)
                val blocks12V = ceil(vDc / 12.0).toInt()
                engOutput(
                    primaryLabel = BilingualText("Required Battery Capacity", "आवश्यक बैटरी क्षमता"),
                    primaryValue = formatEng(reqAh, 1),
                    primaryUnit = "Ah",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Nearest Standard", "निकटतम मानक बैटरी"), formatEng(stdAh, 0), "Ah"),
                        SecondaryMetric(BilingualText("12V Blocks in Series", "12V बैटरी संख्या"), "$blocks12V", "nos")
                    ),
                    formulaUsed = "Ah = (Load_W × Hours) / (V_dc × η × DoD)",
                    substitutedFormula = "Ah = (${formatEng(loadW, 0)} × ${formatEng(hrs, 1)}) / (${formatEng(vDc, 0)} × ${formatEng(eff / 100, 2)} × ${formatEng(dod / 100, 2)})",
                    stepExplanation = BilingualText("Need ${formatEng(reqAh, 1)} Ah (${blocks12V}×12V ${formatEng(stdAh, 0)}Ah)", "आवश्यक क्षमता = ${formatEng(reqAh, 1)} Ah")
                )
            }
        }
    )

    private fun inverterLoad() = CalculatorDefinition(
        id = "more_inverter_load",
        serialNumber = 45,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Inverter Load Calculator", "इन्वर्टर लोड कैलकुलेटर"),
        subtitle = BilingualText("Size Inverter VA / kVA Rating & Battery DC Current", "कुल लोड (W) से इन्वर्टर क्षमता (VA/kVA) व DC करंट निकालें"),
        formulaPreview = "Inverter VA = (Load_W / PF) × (1 + Margin%)",
        assumptions = BilingualText(
            "Includes 25% surge/expansion headroom and typical 0.8 inverter output power factor.",
            "मान्यता: 25% सर्ज/सुरक्षा मार्जिन और 0.8 आउटपुट पावर फैक्टर।"
        ),
        keywords = listOf("inverter", "va sizing", "ups load", "dc current", "इन्वर्टर"),
        fields = listOf(
            CalculatorField("load_w", BilingualText("Total Connected Load", "कुल लोड पावर"), "1200", "W", listOf("W", "kW")),
            CalculatorField("pf", BilingualText("Inverter Power Factor", "इन्वर्टर पावर फैक्टर"), "0.8", "cos φ"),
            CalculatorField("margin", BilingualText("Surge / Margin (%)", "सर्ज / मार्जिन (%)"), "25", "%"),
            CalculatorField("v_bat", BilingualText("Battery Voltage (V DC)", "बैटरी वोल्टेज (V)"), "24", "V")
        ),
        compute = { values, units ->
            runCatching {
                val rawLoad = requirePositive(values["load_w"], BilingualText("Connected Load", "लोड पावर"))
                val pf = requireRange(values["pf"], 0.4, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val margin = requireRange(values["margin"], 0.0, 100.0, BilingualText("Margin %", "मार्जिन %"))
                val vBat = requirePositive(values["v_bat"], BilingualText("Battery Voltage", "बैटरी वोल्टेज"))
                val loadW = if (units["load_w"] == "kW") rawLoad * 1000.0 else rawLoad
                val baseVa = loadW / pf
                val reqVa = baseVa * (1.0 + margin / 100.0)
                val dcAmps = loadW / (vBat * 0.88)
                val useKva = reqVa >= 1000.0
                engOutput(
                    primaryLabel = BilingualText("Recommended Inverter Rating", "सुझावित इन्वर्टर क्षमता"),
                    primaryValue = if (useKva) formatEng(reqVa / 1000.0, 2) else formatEng(reqVa, 0),
                    primaryUnit = if (useKva) "kVA" else "VA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Base Apparent Load", "बेस लोड VA"), formatEng(baseVa, 0), "VA"),
                        SecondaryMetric(BilingualText("DC Battery Current", "बैटरी DC करंट"), formatEng(dcAmps, 1), "A")
                    ),
                    formulaUsed = "VA_inv = (W / PF) × (1 + margin%)",
                    substitutedFormula = "VA_inv = (${formatEng(loadW, 0)} / ${formatEng(pf, 2)}) × (1 + ${formatEng(margin, 0)}%)",
                    stepExplanation = BilingualText("Select ≥ ${formatEng(reqVa, 0)} VA inverter", "कम से कम ${formatEng(reqVa, 0)} VA इन्वर्टर चुनें")
                )
            }
        }
    )

    private fun earthResistance() = CalculatorDefinition(
        id = "more_earth_resistance",
        serialNumber = 46,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.Shield,
        title = BilingualText("Earth Resistance Calculator", "अर्थ रेजिस्टेंस कैलकुलेटर"),
        subtitle = BilingualText("Estimate Vertical Earth Rod / Pit Resistance (IEEE 80 / IS 3043)", "मिट्टी की प्रतिरोधकता और रॉड लंबाई से अर्थ पिट रेजिस्टेंस (Ω) निकालें"),
        formulaPreview = "R = (ρ / (2πL)) × (ln(4L/r) − 1) / N_eff",
        assumptions = BilingualText(
            "Uniform soil resistivity ρ; parallel pits spaced ≥ 2× rod length use mutual coupling factor.",
            "मान्यता: एकसमान मिट्टी प्रतिरोधकता ρ और समानांतर रॉड में पर्याप्त दूरी।"
        ),
        keywords = listOf("earth resistance", "earthing", "grounding", "soil resistivity", "अर्थिंग"),
        fields = listOf(
            CalculatorField("rho", BilingualText("Soil Resistivity (ρ)", "मिट्टी प्रतिरोधकता (ρ)"), "100", "Ω·m"),
            CalculatorField("length", BilingualText("Electrode Length (L)", "इलेक्ट्रोड लंबाई (L)"), "3.0", "m"),
            CalculatorField("dia_mm", BilingualText("Rod / Pipe Diameter", "पाइप/रॉड व्यास (mm)"), "25", "mm"),
            CalculatorField("rods", BilingualText("Parallel Earth Pits", "समानांतर अर्थ पिट संख्या"), "2", "nos")
        ),
        compute = { values, _ ->
            runCatching {
                val rho = requirePositive(values["rho"], BilingualText("Soil Resistivity", "मिट्टी प्रतिरोधकता"))
                val len = requirePositive(values["length"], BilingualText("Electrode Length", "लंबाई"))
                val diaMm = requireRange(values["dia_mm"], 5.0, 300.0, BilingualText("Rod Diameter", "व्यास"))
                val nRods = requireRange(values["rods"], 1.0, 20.0, BilingualText("Parallel Pits", "पिट संख्या")).toInt()
                val rM = (diaMm / 1000.0) / 2.0
                val singleR = (rho / (2.0 * PI * len)) * (ln((4.0 * len) / rM) - 1.0)
                // Practical parallel factor accounting for ~10% mutual resistance per extra pit
                val effParallel = if (nRods == 1) 1.0 else nRods / (1.0 + 0.15 * (nRods - 1))
                val totalR = singleR / effParallel
                engOutput(
                    primaryLabel = BilingualText("Combined Earth Resistance", "कुल अर्थ रेजिस्टेंस"),
                    primaryValue = formatEng(totalR, 2),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Single Pit Resistance", "सिंगल पिट रेजिस्टेंस"), formatEng(singleR, 2), "Ω"),
                        SecondaryMetric(BilingualText("IS 3043 General (<5Ω)", "मानक जांच"), if (totalR <= 5.0) "PASS (≤5 Ω)" else "HIGH (>5 Ω)", "")
                    ),
                    formulaUsed = "R₁ = (ρ / 2πL)·(ln(4L/r) − 1)",
                    substitutedFormula = "R₁ = (${formatEng(rho, 0)} / (2π×${formatEng(len, 1)})) × (ln(4L/r)−1)",
                    stepExplanation = BilingualText("Combined R = ${formatEng(totalR, 2)} Ω (Single = ${formatEng(singleR, 2)} Ω)", "कुल अर्थ रेजिस्टेंस = ${formatEng(totalR, 2)} Ω"),
                    statusLevel = if (totalR > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun conductorSizeDensity() = CalculatorDefinition(
        id = "more_conductor_size",
        serialNumber = 47,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.Cable,
        title = BilingualText("Conductor Size Calculator (Current Density)", "कंडक्टर साइज कैलकुलेटर (करंट डेंसिटी)"),
        subtitle = BilingualText("Determine Busbar / Cable Cross-Section mm² from Current Density", "करंट और करंट डेंसिटी (A/mm²) से कंडक्टर साइज निकालें"),
        formulaPreview = "A (mm²) = (I × Safety_Factor) / Current_Density",
        assumptions = BilingualText(
            "Typical continuous design density: Copper ≈ 2.0–3.5 A/mm², Aluminum ≈ 1.2–1.8 A/mm².",
            "मान्यता: सामान्य डिजाइन डेंसिटी — कॉपर 2.0–3.5 A/mm², एल्युमिनियम 1.2–1.8 A/mm²।"
        ),
        keywords = listOf("conductor size", "current density", "busbar", "mm2", "कंडक्टर"),
        fields = listOf(
            CalculatorField("current", BilingualText("Design Current (A)", "डिजाइन करंट (A)"), "250", "A"),
            CalculatorField("density", BilingualText("Current Density (J)", "करंट डेंसिटी (A/mm²)"), "2.5", "A/mm²"),
            CalculatorField("sf", BilingualText("Safety Factor", "सेफ्टी फैक्टर"), "1.2", "×")
        ),
        compute = { values, _ ->
            runCatching {
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val j = requireRange(values["density"], 0.3, 15.0, BilingualText("Current Density", "करंट डेंसिटी"))
                val sf = requireRange(values["sf"], 1.0, 2.0, BilingualText("Safety Factor", "सेफ्टी फैक्टर"))
                val designI = i * sf
                val area = designI / j
                val stdCable = nearestStandardRating(area, STANDARD_CABLE_MM2)
                engOutput(
                    primaryLabel = BilingualText("Required Cross-Section Area", "आवश्यक कंडक्टर क्षेत्रफल"),
                    primaryValue = formatEng(area, 2),
                    primaryUnit = "mm²",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Nearest Standard Cable", "निकटतम मानक साइज"), formatEng(stdCable, 0), "mm²"),
                        SecondaryMetric(BilingualText("Design Current", "डिजाइन करंट"), formatEng(designI, 1), "A")
                    ),
                    formulaUsed = "A = (I × SF) / J",
                    substitutedFormula = "A = (${formatEng(i, 1)} × ${formatEng(sf, 2)}) / ${formatEng(j, 2)}",
                    stepExplanation = BilingualText("Min Area = ${formatEng(area, 2)} mm² (Std ${formatEng(stdCable, 0)} mm²)", "न्यूनतम साइज = ${formatEng(area, 2)} mm²")
                )
            }
        }
    )

    private fun conduitCableTray() = CalculatorDefinition(
        id = "more_conduit_tray",
        serialNumber = 48,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.ViewColumn,
        title = BilingualText("Conduit / Cable Tray Sizing Calculator", "कंड्यूट / केबल ट्रे साइजिंग"),
        subtitle = BilingualText("Size PVC/GI Conduit or Ladder Tray for Cable Fill %", "केबल संख्या व व्यास से कंड्यूट या केबल ट्रे चौड़ाई निकालें"),
        formulaPreview = "A_req = N × (π × d² / 4) / Fill_Factor",
        assumptions = BilingualText(
            "Uses NEC/IEC standard 40% fill for multi-cable Conduit and 50% fill for Cable Tray.",
            "मान्यता: कंड्यूट के लिए 40% फिल और केबल ट्रे के लिए 50% फिल मानक।"
        ),
        keywords = listOf("conduit", "cable tray", "fill ratio", "tray width", "केबल ट्रे"),
        fields = listOf(
            CalculatorField("type", BilingualText("Raceway Type", "रेसवे प्रकार"), "1", "Conduit (40% fill)", listOf("Conduit (40% fill)", "Cable Tray (50% fill)"), isSelectorOnly = true),
            CalculatorField("count", BilingualText("Number of Cables", "केबलों की संख्या"), "6", "cables"),
            CalculatorField("dia_mm", BilingualText("Cable Outer Diameter", "केबल का बाहरी व्यास (OD)"), "18", "mm"),
            CalculatorField("tray_h", BilingualText("Tray Height (if Tray)", "ट्रे ऊँचाई (mm)"), "50", "mm")
        ),
        compute = { values, units ->
            runCatching {
                val n = requireRange(values["count"], 1.0, 200.0, BilingualText("Cable Count", "केबल संख्या")).toInt()
                val od = requirePositive(values["dia_mm"], BilingualText("Cable OD", "केबल व्यास"))
                val trayH = requireRange(values["tray_h"], 20.0, 200.0, BilingualText("Tray Height", "ट्रे ऊँचाई"))
                val singleArea = PI * od * od / 4.0
                val totalCableArea = n * singleArea
                val isTray = units["type"] == "Cable Tray (50% fill)"
                if (isTray) {
                    val reqTrayArea = totalCableArea / 0.50
                    val reqWidth = reqTrayArea / trayH
                    val stdWidths = listOf(50.0, 75.0, 100.0, 150.0, 200.0, 300.0, 450.0, 600.0, 750.0, 900.0)
                    val stdW = nearestStandardRating(reqWidth, stdWidths)
                    engOutput(
                        primaryLabel = BilingualText("Recommended Cable Tray Width", "सुझावित केबल ट्रे चौड़ाई"),
                        primaryValue = formatEng(stdW, 0),
                        primaryUnit = "mm",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Calculated Min Width", "न्यूनतम चौड़ाई"), formatEng(reqWidth, 1), "mm"),
                            SecondaryMetric(BilingualText("Total Cable Area", "कुल केबल क्षेत्रफल"), formatEng(totalCableArea, 0), "mm²")
                        ),
                        formulaUsed = "Width = (N × πd²/4) / (0.50 × Height)",
                        substitutedFormula = "Width = ${formatEng(totalCableArea, 0)} / (0.50 × ${formatEng(trayH, 0)})",
                        stepExplanation = BilingualText("Use ${formatEng(stdW, 0)} × ${formatEng(trayH, 0)} mm tray", "${formatEng(stdW, 0)} mm चौड़ी ट्रे चुनें")
                    )
                } else {
                    val reqConduitArea = totalCableArea / 0.40
                    val minId = sqrt((4.0 * reqConduitArea) / PI)
                    val stdConduits = listOf(20.0, 25.0, 32.0, 40.0, 50.0, 63.0, 75.0, 100.0, 150.0)
                    val stdConduit = nearestStandardRating(minId, stdConduits)
                    engOutput(
                        primaryLabel = BilingualText("Recommended Conduit Size", "सुझावित कंड्यूट साइज"),
                        primaryValue = formatEng(stdConduit, 0),
                        primaryUnit = "mm",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Calculated Min ID", "न्यूनतम आंतरिक व्यास"), formatEng(minId, 1), "mm"),
                            SecondaryMetric(BilingualText("Total Cable Area", "कुल केबल क्षेत्रफल"), formatEng(totalCableArea, 0), "mm²")
                        ),
                        formulaUsed = "D_min = √((4 × N × A_cable) / (0.40 × π))",
                        substitutedFormula = "D_min = ${formatEng(minId, 1)} mm → Std ${formatEng(stdConduit, 0)} mm",
                        stepExplanation = BilingualText("Use ${formatEng(stdConduit, 0)} mm conduit (40% fill)", "${formatEng(stdConduit, 0)} mm कंड्यूट चुनें")
                    )
                }
            }
        }
    )

    private fun lightingLoad() = CalculatorDefinition(
        id = "more_lighting_load",
        serialNumber = 49,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.Lightbulb,
        title = BilingualText("Lighting Load Calculator", "लाइटिंग लोड कैलकुलेटर"),
        subtitle = BilingualText("Calculate LED Fixture Count & Total kW using Lumen Method", "कक्ष क्षेत्रफल और Lux आवश्यकता से लाइट संख्या व लोड निकालें"),
        formulaPreview = "Fixtures = (Lux × Area) / (Lumens × UF × MF)",
        assumptions = BilingualText(
            "Standard indoor Lumen Method with default UF = 0.65 and Maintenance Factor MF = 0.80.",
            "मान्यता: इनडोर ल्यूमेन विधि (UF = 0.65, MF = 0.80)।"
        ),
        keywords = listOf("lighting", "lux", "lumen", "fixtures", "led", "लाइटिंग"),
        fields = listOf(
            CalculatorField("area", BilingualText("Room / Floor Area (m²)", "कमरे का क्षेत्रफल (m²)"), "100", "m²"),
            CalculatorField("lux", BilingualText("Required Illumination (Lux)", "आवश्यक रोशनी (Lux)"), "300", "Lux"),
            CalculatorField("lumens", BilingualText("Lumens per Fixture (lm)", "प्रति लाइट ल्यूमेन (lm)"), "4000", "lm"),
            CalculatorField("watts", BilingualText("Wattage per Fixture (W)", "प्रति लाइट वाट (W)"), "36", "W"),
            CalculatorField("uf", BilingualText("Utilization Factor (UF)", "यूटिलाइजेशन फैक्टर"), "0.65", "UF"),
            CalculatorField("mf", BilingualText("Maintenance Factor (MF)", "मेंटेनेंस फैक्टर"), "0.80", "MF")
        ),
        compute = { values, _ ->
            runCatching {
                val area = requirePositive(values["area"], BilingualText("Area", "क्षेत्रफल"))
                val lux = requirePositive(values["lux"], BilingualText("Target Lux", "लक्ष्य Lux"))
                val lm = requirePositive(values["lumens"], BilingualText("Lumens", "ल्यूमेन"))
                val watts = requirePositive(values["watts"], BilingualText("Wattage", "वाट"))
                val uf = requireRange(values["uf"], 0.1, 1.0, BilingualText("UF", "UF"))
                val mf = requireRange(values["mf"], 0.1, 1.0, BilingualText("MF", "MF"))
                val exactN = (lux * area) / (lm * uf * mf)
                val fixtures = ceil(exactN).toInt().coerceAtLeast(1)
                val totalW = fixtures * watts
                val wPerM2 = totalW / area
                engOutput(
                    primaryLabel = BilingualText("Required Light Fixtures", "आवश्यक लाइटों की संख्या"),
                    primaryValue = "$fixtures",
                    primaryUnit = "Nos",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Total Lighting Load", "कुल लाइटिंग लोड"), formatEng(totalW / 1000.0, 2), "kW (${formatEng(totalW, 0)} W)"),
                        SecondaryMetric(BilingualText("Lighting Power Density", "पावर डेंसिटी"), formatEng(wPerM2, 2), "W/m²")
                    ),
                    formulaUsed = "N = (E_lux × Area) / (Φ_lm × UF × MF)",
                    substitutedFormula = "N = (${formatEng(lux, 0)} × ${formatEng(area, 1)}) / (${formatEng(lm, 0)} × ${formatEng(uf, 2)} × ${formatEng(mf, 2)})",
                    stepExplanation = BilingualText("$fixtures fixtures needed, Total Load = ${formatEng(totalW, 0)} W", "$fixtures लाइटें, कुल लोड = ${formatEng(totalW, 0)} W")
                )
            }
        }
    )

    private fun powerCostBill() = CalculatorDefinition(
        id = "more_power_cost",
        serialNumber = 50,
        category = CalculatorCategory.ELEC_MORE,
        icon = Icons.Rounded.ReceiptLong,
        title = BilingualText("Power Cost (Electricity Bill) Calculator", "पावर कॉस्ट (बिजली बिल) कैलकुलेटर"),
        subtitle = BilingualText("Estimate Daily, Monthly & Annual Electricity Cost from Tariff", "लोड, घंटे व यूनिट रेट से बिजली बिल की लागत निकालें"),
        formulaPreview = "Cost = Power (kW) × Hours/Day × Days × Tariff",
        assumptions = BilingualText(
            "Calculates pure energy unit charges; utility fixed demand charges & taxes excluded.",
            "मान्यता: केवल ऊर्जा यूनिट (kWh) शुल्क; फिक्स्ड चार्ज व टैक्स अलग से लागू।"
        ),
        keywords = listOf("electricity bill", "power cost", "tariff", "kwh cost", "बिजली बिल"),
        fields = listOf(
            CalculatorField("power", BilingualText("Load Power", "लोड पावर"), "10", "kW", listOf("kW", "W")),
            CalculatorField("hours", BilingualText("Hours / Day", "प्रतिदिन घंटे"), "8", "hr/day"),
            CalculatorField("days", BilingualText("Billing Days", "दिनों की संख्या"), "30", "days"),
            CalculatorField("rate", BilingualText("Tariff Rate (per kWh)", "बिजली दर (प्रति यूनिट)"), "8.5", "₹/kWh")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Load Power", "लोड पावर"))
                val hrs = requireRange(values["hours"], 0.1, 24.0, BilingualText("Hours", "घंटे"))
                val days = requirePositive(values["days"], BilingualText("Days", "दिन"))
                val rate = requirePositive(values["rate"], BilingualText("Tariff Rate", "यूनिट दर"))
                val pKw = if (units["power"] == "W") rawP / 1000.0 else rawP
                val kwhTotal = pKw * hrs * days
                val totalCost = kwhTotal * rate
                val dailyCost = (pKw * hrs) * rate
                val yearlyCost = dailyCost * 365.0
                engOutput(
                    primaryLabel = BilingualText("Estimated Electricity Cost", "अनुमानित बिजली बिल"),
                    primaryValue = formatEng(totalCost, 2),
                    primaryUnit = "Currency",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Total Units", "कुल यूनिट"), formatEng(kwhTotal, 1), "kWh"),
                        SecondaryMetric(BilingualText("Daily Cost", "दैनिक खर्च"), formatEng(dailyCost, 2), "/day"),
                        SecondaryMetric(BilingualText("Annual Est.", "वार्षिक अनुमान"), formatEng(yearlyCost, 0), "/yr")
                    ),
                    formulaUsed = "Cost = kW × Hours × Days × Rate",
                    substitutedFormula = "Cost = ${formatEng(kwhTotal, 1)} kWh × ${formatEng(rate, 2)}",
                    stepExplanation = BilingualText("${formatEng(kwhTotal, 1)} kWh × ${formatEng(rate, 2)} = ${formatEng(totalCost, 2)}", "कुल खर्च = ${formatEng(totalCost, 2)}")
                )
            }
        }
    )
}
