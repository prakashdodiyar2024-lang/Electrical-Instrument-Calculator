package com.example.domain.instrumentation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PrecisionManufacturing
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Tune
import com.example.domain.engOutput
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireFinite
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import com.example.model.requireRange

object InstSignalCalculators {

    val all: List<CalculatorDefinition> = listOf(
        maToPv(),               // 1
        pvToMa(),               // 2
        maToPercentage(),       // 3
        percentageToMa(),       // 4
        voltageToPv(),          // 5
        pvToVoltage(),          // 6
        signalScaling(),        // 7
        analogMaVoltConv(),     // 8
        loopCheck(),            // 9
        ipConverterOutput()     // 10
    )

    private fun maToPv() = CalculatorDefinition(
        id = "sig_ma_to_pv",
        serialNumber = 1,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.AutoMirrored.Rounded.ShowChart,
        title = BilingualText("4–20 mA to Process Value Calculator", "4–20 mA से प्रोसेस वैल्यू (PV)"),
        subtitle = BilingualText("Convert Transmitter mA Signal to Linear Engineering PV", "4–20 mA सिग्नल को LRV/URV के अनुसार प्रोसेस वैल्यू में बदलें"),
        formulaPreview = "PV = LRV + ((mA − 4) / 16) × (URV − LRV)",
        assumptions = BilingualText(
            "Assumes linear 4–20 mA signal scaling across calibrated LRV to URV span.",
            "मान्यता: LRV से URV के बीच रैखिक (Linear) 4–20 mA सिग्नल स्केलिंग।"
        ),
        keywords = listOf("4-20ma", "ma to pv", "transmitter", "lrv", "urv", "सिग्नल"),
        fields = listOf(
            CalculatorField("ma", BilingualText("Measured Current (mA)", "मापा गया करंट (mA)"), "12", "mA", allowNegative = false),
            CalculatorField("lrv", BilingualText("Lower Range Value (LRV)", "लोअर रेंज मान (LRV)"), "0", "unit", allowNegative = true),
            CalculatorField("urv", BilingualText("Upper Range Value (URV)", "अपर रेंज मान (URV)"), "100", "unit", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val ma = requireRange(values["ma"], 0.0, 25.0, BilingualText("Current (mA)", "करंट (mA)"))
                val lrv = requireFinite(values["lrv"], BilingualText("LRV", "LRV"))
                val urv = requireFinite(values["urv"], BilingualText("URV", "URV"))
                val span = urv - lrv
                if (kotlin.math.abs(span) < 1e-12) {
                    throw BilingualValidationException(BilingualText("LRV and URV cannot be equal.", "LRV और URV बराबर नहीं हो सकते।"))
                }
                val pct = ((ma - 4.0) / 16.0) * 100.0
                val pv = lrv + ((ma - 4.0) / 16.0) * span
                val v250 = (ma / 1000.0) * 250.0
                engOutput(
                    primaryLabel = BilingualText("Process Value (PV)", "प्रोसेस वैल्यू (PV)"),
                    primaryValue = formatEng(pv, 3),
                    primaryUnit = "EU",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span Percentage", "स्पैन %"), formatEng(pct, 2), "%"),
                        SecondaryMetric(BilingualText("Voltage across 250 Ω", "250 Ω पर वोल्टेज"), formatEng(v250, 3), "V")
                    ),
                    formulaUsed = "PV = LRV + ((mA − 4)/16) × (URV − LRV)",
                    substitutedFormula = "PV = ${formatEng(lrv, 1)} + ((${formatEng(ma, 2)} − 4)/16) × ${formatEng(span, 1)}",
                    stepExplanation = BilingualText("${formatEng(ma, 2)} mA = ${formatEng(pv, 3)} (${formatEng(pct, 1)}%)", "${formatEng(ma, 2)} mA = ${formatEng(pv, 3)}"),
                    statusLevel = if (ma < 3.6 || ma > 20.5) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun pvToMa() = CalculatorDefinition(
        id = "sig_pv_to_ma",
        serialNumber = 2,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.Timeline,
        title = BilingualText("Process Value to 4–20 mA Calculator", "प्रोसेस वैल्यू (PV) से 4–20 mA"),
        subtitle = BilingualText("Calculate Expected mA Output for Any Process Reading", "किसी भी प्रोसेस मान (PV) के लिए अपेक्षित 4–20 mA करंट निकालें"),
        formulaPreview = "mA = 4 + ((PV − LRV) / (URV − LRV)) × 16",
        assumptions = BilingualText(
            "Linear transmitter characteristic with 4 mA = LRV and 20 mA = URV.",
            "मान्यता: 4 mA = LRV और 20 mA = URV पर रैखिक ट्रांसमीटर आउटपुट।"
        ),
        keywords = listOf("pv to ma", "4-20ma", "calibration", "lrv", "urv"),
        fields = listOf(
            CalculatorField("pv", BilingualText("Process Value (PV)", "प्रोसेस वैल्यू (PV)"), "50", "unit", allowNegative = true),
            CalculatorField("lrv", BilingualText("Lower Range Value (LRV)", "लोअर रेंज (LRV)"), "0", "unit", allowNegative = true),
            CalculatorField("urv", BilingualText("Upper Range Value (URV)", "अपर रेंज (URV)"), "100", "unit", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val pv = requireFinite(values["pv"], BilingualText("Process Value", "प्रोसेस वैल्यू"))
                val lrv = requireFinite(values["lrv"], BilingualText("LRV", "LRV"))
                val urv = requireFinite(values["urv"], BilingualText("URV", "URV"))
                val span = urv - lrv
                if (kotlin.math.abs(span) < 1e-12) {
                    throw BilingualValidationException(BilingualText("LRV and URV cannot be equal.", "LRV और URV बराबर नहीं हो सकते।"))
                }
                val ratio = (pv - lrv) / span
                val ma = 4.0 + ratio * 16.0
                val v250 = (ma / 1000.0) * 250.0
                engOutput(
                    primaryLabel = BilingualText("Output Signal (mA)", "आउटपुट करंट (mA)"),
                    primaryValue = formatEng(ma, 3),
                    primaryUnit = "mA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span Percentage", "स्पैन %"), formatEng(ratio * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("1–5 V Equivalent", "250 Ω पर वोल्टेज"), formatEng(v250, 3), "V")
                    ),
                    formulaUsed = "mA = 4 + ((PV − LRV) / (URV − LRV)) × 16",
                    substitutedFormula = "mA = 4 + ((${formatEng(pv, 2)} − ${formatEng(lrv, 2)}) / ${formatEng(span, 2)}) × 16",
                    stepExplanation = BilingualText("PV ${formatEng(pv, 2)} → ${formatEng(ma, 3)} mA", "आउटपुट = ${formatEng(ma, 3)} mA"),
                    statusLevel = if (ma < 3.8 || ma > 20.5) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun maToPercentage() = CalculatorDefinition(
        id = "sig_ma_to_pct",
        serialNumber = 3,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.Speed,
        title = BilingualText("mA to Percentage Calculator", "mA से प्रतिशत (%) कैलकुलेटर"),
        subtitle = BilingualText("Convert 4–20 mA Signal to % Span & NAMUR NE43 Status", "4–20 mA सिग्नल को % और NAMUR NE43 स्थिति में बदलें"),
        formulaPreview = "% = ((mA − 4) / 16) × 100",
        assumptions = BilingualText(
            "NAMUR NE43 diagnostics: < 3.6 mA = Low Fault, > 20.5 mA = High Fault.",
            "मान्यता: NAMUR NE43 के अनुसार < 3.6 mA या > 20.5 mA फॉल्ट सिग्नल है।"
        ),
        keywords = listOf("ma to percentage", "namur", "4-20ma", "percent"),
        fields = listOf(
            CalculatorField("ma", BilingualText("Current Signal (mA)", "करंट सिग्नल (mA)"), "16", "mA")
        ),
        compute = { values, _ ->
            runCatching {
                val ma = requireRange(values["ma"], 0.0, 25.0, BilingualText("Current (mA)", "करंट (mA)"))
                val pct = ((ma - 4.0) / 16.0) * 100.0
                val status = when {
                    ma < 3.6 -> BilingualText("Under-Fault (<3.6 mA)", "लो फॉल्ट (<3.6 mA)")
                    ma > 20.5 -> BilingualText("Over-Fault (>20.5 mA)", "हाई फॉल्ट (>20.5 mA)")
                    else -> BilingualText("Valid Live Zero (4–20 mA)", "सामान्य लाइव रेंज")
                }
                engOutput(
                    primaryLabel = BilingualText("Span Percentage", "स्पैन प्रतिशत (%)"),
                    primaryValue = formatEng(pct, 2),
                    primaryUnit = "%",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("NAMUR Status", "NAMUR स्थिति"), status.en, "", localizedValue = status),
                        SecondaryMetric(BilingualText("1–5 V Equiv.", "1–5 V मान"), formatEng((ma / 1000.0) * 250.0, 3), "V")
                    ),
                    formulaUsed = "% = ((mA − 4) / 16) × 100",
                    substitutedFormula = "% = ((${formatEng(ma, 2)} − 4) / 16) × 100",
                    stepExplanation = BilingualText("${formatEng(ma, 2)} mA = ${formatEng(pct, 2)}%", "${formatEng(ma, 2)} mA = ${formatEng(pct, 2)}%"),
                    statusLevel = if (ma < 3.6 || ma > 20.5) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun percentageToMa() = CalculatorDefinition(
        id = "sig_pct_to_ma",
        serialNumber = 4,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.Tune,
        title = BilingualText("Percentage to mA Calculator", "प्रतिशत (%) से mA कैलकुलेटर"),
        subtitle = BilingualText("Find Exact 4–20 mA, 1–5 V & 0–10 V for Any % Opening", "किसी भी % मान के लिए 4–20 mA, 1–5 V और 0–10 V निकालें"),
        formulaPreview = "mA = 4 + (0.16 × %)",
        assumptions = BilingualText(
            "Supports -25% to +125% span (0 mA to 24 mA instrument range).",
            "मान्यता: -25% से +125% रेंज (0 से 24 mA)।"
        ),
        keywords = listOf("percentage to ma", "valve opening", "4-20ma"),
        fields = listOf(
            CalculatorField("pct", BilingualText("Percentage (%)", "प्रतिशत (%)"), "75", "%", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val pct = requireRange(values["pct"], -25.0, 125.0, BilingualText("Percentage", "प्रतिशत"))
                val ma = 4.0 + 0.16 * pct
                val v15 = 1.0 + 0.04 * pct
                val v010 = 0.10 * pct
                engOutput(
                    primaryLabel = BilingualText("Loop Current (mA)", "लूप करंट (mA)"),
                    primaryValue = formatEng(ma, 3),
                    primaryUnit = "mA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("1–5 V Signal", "1–5 V सिग्नल"), formatEng(v15, 3), "V"),
                        SecondaryMetric(BilingualText("0–10 V Signal", "0–10 V सिग्नल"), formatEng(v010, 3), "V")
                    ),
                    formulaUsed = "mA = 4 + (0.16 × %)",
                    substitutedFormula = "mA = 4 + (0.16 × ${formatEng(pct, 2)})",
                    stepExplanation = BilingualText("${formatEng(pct, 2)}% = ${formatEng(ma, 3)} mA", "${formatEng(pct, 2)}% = ${formatEng(ma, 3)} mA")
                )
            }
        }
    )

    private fun voltageToPv() = CalculatorDefinition(
        id = "sig_v_to_pv",
        serialNumber = 5,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Voltage to Process Value Calculator", "वोल्टेज से प्रोसेस वैल्यू (PV)"),
        subtitle = BilingualText("Convert 0–10 V, 1–5 V, 0–5 V or 2–10 V to Engineering PV", "0–10 V या 1–5 V सिग्नल को प्रोसेस वैल्यू (PV) में बदलें"),
        formulaPreview = "PV = LRV + ((V − V_min) / (V_max − V_min)) × (URV − LRV)",
        assumptions = BilingualText(
            "Linear voltage input scaling across selected analog standard.",
            "मान्यता: चुने गए एनालॉग वोल्टेज मानक के अनुसार रैखिक स्केलिंग।"
        ),
        keywords = listOf("0-10v", "1-5v", "voltage to pv", "analog input"),
        fields = listOf(
            CalculatorField("range", BilingualText("Voltage Signal Range", "वोल्टेज सिग्नल रेंज"), "1", "0–10 V", listOf("0–10 V", "1–5 V", "0–5 V", "2–10 V"), isSelectorOnly = true),
            CalculatorField("volt", BilingualText("Measured Voltage (V)", "मापा गया वोल्टेज (V)"), "5.0", "V"),
            CalculatorField("lrv", BilingualText("LRV", "LRV"), "0", "unit", allowNegative = true),
            CalculatorField("urv", BilingualText("URV", "URV"), "100", "unit", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val (vMin, vMax) = when (units["range"]) {
                    "1–5 V" -> 1.0 to 5.0
                    "0–5 V" -> 0.0 to 5.0
                    "2–10 V" -> 2.0 to 10.0
                    else -> 0.0 to 10.0
                }
                val v = requireRange(values["volt"], 0.0, 15.0, BilingualText("Voltage", "वोल्टेज"))
                val lrv = requireFinite(values["lrv"], BilingualText("LRV", "LRV"))
                val urv = requireFinite(values["urv"], BilingualText("URV", "URV"))
                val span = urv - lrv
                if (kotlin.math.abs(span) < 1e-12) throw BilingualValidationException(BilingualText("LRV and URV cannot be equal.", "LRV और URV बराबर नहीं हो सकते।"))
                val ratio = (v - vMin) / (vMax - vMin)
                val pv = lrv + ratio * span
                engOutput(
                    primaryLabel = BilingualText("Process Value (PV)", "प्रोसेस वैल्यू (PV)"),
                    primaryValue = formatEng(pv, 3),
                    primaryUnit = "EU",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span %", "स्पैन %"), formatEng(ratio * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("4–20 mA Equiv.", "4–20 mA मान"), formatEng(4.0 + ratio * 16.0, 2), "mA")
                    ),
                    formulaUsed = "PV = LRV + ((V − V_min)/(V_max − V_min)) × (URV − LRV)",
                    substitutedFormula = "PV = ${formatEng(lrv, 1)} + ((${formatEng(v, 2)} − $vMin)/${vMax - vMin}) × ${formatEng(span, 1)}",
                    stepExplanation = BilingualText("${formatEng(v, 2)} V → ${formatEng(pv, 3)} (${formatEng(ratio * 100, 1)}%)", "प्रोसेस वैल्यू = ${formatEng(pv, 3)}")
                )
            }
        }
    )

    private fun pvToVoltage() = CalculatorDefinition(
        id = "sig_pv_to_v",
        serialNumber = 6,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.CompareArrows,
        title = BilingualText("Process Value to Voltage Calculator", "प्रोसेस वैल्यू से वोल्टेज सिग्नल"),
        subtitle = BilingualText("Convert Engineering PV to 0–10 V, 1–5 V, 0–5 V or 2–10 V", "प्रोसेस वैल्यू (PV) को 0–10 V या 1–5 V आउटपुट में बदलें"),
        formulaPreview = "V = V_min + ((PV − LRV) / (URV − LRV)) × (V_max − V_min)",
        assumptions = BilingualText(
            "Linear voltage transmitter/AO output across calibrated LRV–URV span.",
            "मान्यता: LRV–URV रेंज पर रैखिक एनालॉग वोल्टेज आउटपुट।"
        ),
        keywords = listOf("pv to voltage", "0-10v", "1-5v", "analog output"),
        fields = listOf(
            CalculatorField("range", BilingualText("Output Signal Range", "आउटपुट वोल्टेज रेंज"), "1", "0–10 V", listOf("0–10 V", "1–5 V", "0–5 V", "2–10 V"), isSelectorOnly = true),
            CalculatorField("pv", BilingualText("Process Value (PV)", "प्रोसेस वैल्यू (PV)"), "65", "unit", allowNegative = true),
            CalculatorField("lrv", BilingualText("LRV", "LRV"), "0", "unit", allowNegative = true),
            CalculatorField("urv", BilingualText("URV", "URV"), "100", "unit", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val (vMin, vMax) = when (units["range"]) {
                    "1–5 V" -> 1.0 to 5.0
                    "0–5 V" -> 0.0 to 5.0
                    "2–10 V" -> 2.0 to 10.0
                    else -> 0.0 to 10.0
                }
                val pv = requireFinite(values["pv"], BilingualText("Process Value", "प्रोसेस वैल्यू"))
                val lrv = requireFinite(values["lrv"], BilingualText("LRV", "LRV"))
                val urv = requireFinite(values["urv"], BilingualText("URV", "URV"))
                val span = urv - lrv
                if (kotlin.math.abs(span) < 1e-12) throw BilingualValidationException(BilingualText("LRV and URV cannot be equal.", "LRV और URV बराबर नहीं हो सकते।"))
                val ratio = (pv - lrv) / span
                val vOut = vMin + ratio * (vMax - vMin)
                engOutput(
                    primaryLabel = BilingualText("Output Voltage (V)", "आउटपुट वोल्टेज (V)"),
                    primaryValue = formatEng(vOut, 3),
                    primaryUnit = "V",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span %", "स्पैन %"), formatEng(ratio * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("4–20 mA Equiv.", "4–20 mA मान"), formatEng(4.0 + ratio * 16.0, 2), "mA")
                    ),
                    formulaUsed = "V = V_min + ((PV − LRV)/(URV − LRV)) × (V_max − V_min)",
                    substitutedFormula = "V = $vMin + ${formatEng(ratio, 4)} × ${vMax - vMin}",
                    stepExplanation = BilingualText("PV ${formatEng(pv, 2)} → ${formatEng(vOut, 3)} V", "आउटपुट = ${formatEng(vOut, 3)} V")
                )
            }
        }
    )

    private fun signalScaling() = CalculatorDefinition(
        id = "sig_scaling",
        serialNumber = 7,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.Memory,
        title = BilingualText("Signal Scaling Calculator", "सिग्नल स्केलिंग कैलकुलेटर"),
        subtitle = BilingualText("Universal PLC / DCS Linear Scaling (Raw Counts ↔ Engineering)", "किसी भी रॉ इनपुट (0–27648 / 32767) को आउटपुट में स्केल करें"),
        formulaPreview = "Out = Out_min + ((In − In_min)/(In_max − In_min)) × (Out_max − Out_min)",
        assumptions = BilingualText(
            "Supports Siemens (0–27648), Allen-Bradley (0–32767 / 4000–20000), or custom ranges.",
            "मान्यता: Siemens (0–27648), AB (0–32767) या किसी भी कस्टम रेंज की रैखिक स्केलिंग।"
        ),
        keywords = listOf("plc scaling", "raw counts", "27648", "32767", "linear scaling"),
        fields = listOf(
            CalculatorField("input_val", BilingualText("Input Value", "इनपुट मान"), "13824", "in", allowNegative = true),
            CalculatorField("in_min", BilingualText("Input Min", "इनपुट न्यूनतम"), "0", "in", allowNegative = true),
            CalculatorField("in_max", BilingualText("Input Max", "इनपुट अधिकतम"), "27648", "in", allowNegative = true),
            CalculatorField("out_min", BilingualText("Output Min", "आउटपुट न्यूनतम"), "0", "out", allowNegative = true),
            CalculatorField("out_max", BilingualText("Output Max", "आउटपुट अधिकतम"), "150", "out", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val x = requireFinite(values["input_val"], BilingualText("Input Value", "इनपुट मान"))
                val inMin = requireFinite(values["in_min"], BilingualText("Input Min", "इनपुट न्यूनतम"))
                val inMax = requireFinite(values["in_max"], BilingualText("Input Max", "इनपुट अधिकतम"))
                val outMin = requireFinite(values["out_min"], BilingualText("Output Min", "आउटपुट न्यूनतम"))
                val outMax = requireFinite(values["out_max"], BilingualText("Output Max", "आउटपुट अधिकतम"))
                val inSpan = inMax - inMin
                if (kotlin.math.abs(inSpan) < 1e-12) throw BilingualValidationException(BilingualText("Input Min and Max cannot be equal.", "इनपुट न्यूनतम और अधिकतम बराबर नहीं हो सकते।"))
                val ratio = (x - inMin) / inSpan
                val y = outMin + ratio * (outMax - outMin)
                engOutput(
                    primaryLabel = BilingualText("Scaled Output Value", "स्केल्ड आउटपुट मान"),
                    primaryValue = formatEng(y, 3),
                    primaryUnit = "EU",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span %", "स्पैन %"), formatEng(ratio * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("4–20 mA Equiv.", "4–20 mA मान"), formatEng(4.0 + ratio * 16.0, 2), "mA")
                    ),
                    formulaUsed = "Out = Out_min + ((In − In_min)/(In_max − In_min)) × (Out_max − Out_min)",
                    substitutedFormula = "Out = ${formatEng(outMin, 1)} + ${formatEng(ratio, 4)} × ${formatEng(outMax - outMin, 1)}",
                    stepExplanation = BilingualText("Scaled Output = ${formatEng(y, 3)} (${formatEng(ratio * 100, 1)}%)", "स्केल्ड मान = ${formatEng(y, 3)}")
                )
            }
        }
    )

    private fun analogMaVoltConv() = CalculatorDefinition(
        id = "sig_ma_volt_conv",
        serialNumber = 8,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("Analog Signal Converter (mA ⇄ V)", "एनालॉग सिग्नल कन्वर्टर (mA ⇄ V)"),
        subtitle = BilingualText("Convert mA ⇄ Volts across 250 Ω / 500 Ω Loop Shunt Resistor", "250 Ω या 500 Ω रेजिस्टर पर mA और वोल्ट सिग्नल बदलें"),
        formulaPreview = "V = (mA / 1000) × R   |   mA = (V / R) × 1000",
        assumptions = BilingualText(
            "Assumes precision ±0.1% shunt resistor (standard 250 Ω yields 1–5 V from 4–20 mA).",
            "मान्यता: सटीक शंट रेजिस्टर (250 Ω पर 4–20 mA = 1–5 V बनता है)।"
        ),
        keywords = listOf("ma to volt", "volt to ma", "250 ohm", "shunt resistor"),
        fields = listOf(
            CalculatorField("mode", BilingualText("Conversion Mode", "कन्वर्जन मोड"), "1", "mA → V", listOf("mA → V", "V → mA"), isSelectorOnly = true),
            CalculatorField("sig_val", BilingualText("Input Signal (mA or V)", "इनपुट सिग्नल (mA या V)"), "12", "val"),
            CalculatorField("res", BilingualText("Shunt Resistor (Ω)", "शंट रेजिस्टर (Ω)"), "250", "Ω", listOf("Ω"))
        ),
        compute = { values, units ->
            runCatching {
                val input = requireNonNegative(values["sig_val"], BilingualText("Signal Value", "सिग्नल मान"))
                val r = requirePositive(values["res"], BilingualText("Resistor", "रेजिस्टर"))
                val isVtoMa = units["mode"] == "V → mA"
                if (isVtoMa) {
                    val ma = (input / r) * 1000.0
                    val pMw = (input * input / r) * 1000.0
                    engOutput(
                        primaryLabel = BilingualText("Converted Current", "परिवर्तित करंट"),
                        primaryValue = formatEng(ma, 3),
                        primaryUnit = "mA",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("4–20 mA Span %", "4–20 mA %"), formatEng(((ma - 4.0) / 16.0) * 100.0, 1), "%"),
                            SecondaryMetric(BilingualText("Resistor Dissipation", "रेजिस्टर पावर"), formatEng(pMw, 1), "mW")
                        ),
                        formulaUsed = "mA = (V / R) × 1000",
                        substitutedFormula = "mA = (${formatEng(input, 3)} / ${formatEng(r, 1)}) × 1000",
                        stepExplanation = BilingualText("${formatEng(input, 3)} V across ${formatEng(r, 0)} Ω = ${formatEng(ma, 3)} mA", "करंट = ${formatEng(ma, 3)} mA")
                    )
                } else {
                    val volts = (input / 1000.0) * r
                    val pMw = (input / 1000.0) * (input / 1000.0) * r * 1000.0
                    engOutput(
                        primaryLabel = BilingualText("Converted Voltage", "परिवर्तित वोल्टेज"),
                        primaryValue = formatEng(volts, 3),
                        primaryUnit = "V",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("4–20 mA Span %", "4–20 mA %"), formatEng(((input - 4.0) / 16.0) * 100.0, 1), "%"),
                            SecondaryMetric(BilingualText("Resistor Dissipation", "रेजिस्टर पावर"), formatEng(pMw, 1), "mW")
                        ),
                        formulaUsed = "V = (mA / 1000) × R",
                        substitutedFormula = "V = (${formatEng(input, 2)} / 1000) × ${formatEng(r, 1)}",
                        stepExplanation = BilingualText("${formatEng(input, 2)} mA across ${formatEng(r, 0)} Ω = ${formatEng(volts, 3)} V", "वोल्टेज = ${formatEng(volts, 3)} V")
                    )
                }
            }
        }
    )

    private fun loopCheck() = CalculatorDefinition(
        id = "sig_loop_check",
        serialNumber = 9,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.CheckCircle,
        title = BilingualText("Loop Check Calculator", "लूप चेक कैलकुलेटर"),
        subtitle = BilingualText("Verify 4–20 mA Max Loop Resistance & HART Compatibility", "24V लूप पावर, केबल व 250Ω HART रेजिस्टर जांचें"),
        formulaPreview = "R_max = (V_supply − V_tx_min) / 0.020 A",
        assumptions = BilingualText(
            "Checks worst-case 20 mA saturation (22 mA fault allowance noted); HART needs ≥ 230–250 Ω.",
            "मान्यता: 20 mA फुल लोड पर वोल्टेज बजट जांच; HART के लिए ≥ 250 Ω आवश्यक।"
        ),
        keywords = listOf("loop check", "loop resistance", "hart", "24v", "transmitter"),
        fields = listOf(
            CalculatorField("v_supply", BilingualText("Loop Supply Voltage (V DC)", "लूप सप्लाई वोल्टेज (V)"), "24", "V"),
            CalculatorField("v_tx_min", BilingualText("Transmitter Min Voltage", "ट्रांसमीटर न्यूनतम वोल्टेज"), "10.5", "V"),
            CalculatorField("r_ai", BilingualText("PLC AI / HART Resistor", "PLC AI / HART रेजिस्टर"), "250", "Ω"),
            CalculatorField("r_cable", BilingualText("Total Cable Loop Resistance", "केबल लूप रेजिस्टेंस"), "45", "Ω")
        ),
        compute = { values, _ ->
            runCatching {
                val vs = requirePositive(values["v_supply"], BilingualText("Supply Voltage", "सप्लाई वोल्टेज"))
                val vmin = requirePositive(values["v_tx_min"], BilingualText("Tx Min Voltage", "न्यूनतम वोल्टेज"))
                val rAi = requireNonNegative(values["r_ai"], BilingualText("AI Resistor", "AI रेजिस्टर"))
                val rCab = requireNonNegative(values["r_cable"], BilingualText("Cable Resistance", "केबल रेजिस्टेंस"))
                if (vs <= vmin) throw BilingualValidationException(BilingualText("Supply voltage must exceed transmitter minimum voltage.", "सप्लाई वोल्टेज, ट्रांसमीटर न्यूनतम वोल्टेज से अधिक होना चाहिए।"))
                val rMax = (vs - vmin) / 0.020
                val rTotal = rAi + rCab
                val vAtTx = vs - 0.020 * rTotal
                val pass = rTotal <= rMax
                engOutput(
                    primaryLabel = BilingualText("Max Allowable Loop Load", "अधिकतम अनुमत लूप रेजिस्टेंस"),
                    primaryValue = formatEng(rMax, 0),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Actual Loop Load", "कुल लूप लोड"), formatEng(rTotal, 1), "Ω"),
                        SecondaryMetric(BilingualText("Tx Voltage @ 20mA", "20mA पर Tx वोल्टेज"), formatEng(vAtTx, 2), "V"),
                        SecondaryMetric(BilingualText("Loop Status", "लूप स्थिति"), if (pass) "PASS" else "OVERLOAD", "")
                    ),
                    formulaUsed = "R_max = (V_s − V_tx_min) / 0.020",
                    substitutedFormula = "R_max = (${formatEng(vs, 1)} − ${formatEng(vmin, 1)}) / 0.020",
                    stepExplanation = BilingualText("Max R = ${formatEng(rMax, 0)} Ω vs Actual ${formatEng(rTotal, 1)} Ω (${if (pass) "PASS" else "OVERLOAD"})", "अधिकतम सीमा = ${formatEng(rMax, 0)} Ω"),
                    statusLevel = if (pass) StatusLevel.NORMAL else StatusLevel.WARNING
                )
            }
        }
    )

    private fun ipConverterOutput() = CalculatorDefinition(
        id = "sig_ip_converter",
        serialNumber = 10,
        category = CalculatorCategory.INST_SIGNAL,
        icon = Icons.Rounded.PrecisionManufacturing,
        title = BilingualText("I/P Converter Output Calculator", "I/P कन्वर्टर आउटपुट कैलकुलेटर"),
        subtitle = BilingualText("Convert 4–20 mA to Pneumatic 3–15 psi / 0.2–1.0 bar Output", "4–20 mA से न्यूमैटिक 3–15 psi या 0.2–1.0 bar प्रेशर निकालें"),
        formulaPreview = "P_out = P_min + ((mA − 4) / 16) × (P_max − P_min)",
        assumptions = BilingualText(
            "Supports Direct (4mA=0%) and Reverse (4mA=100%) acting control valve positioners.",
            "मान्यता: डायरेक्ट (4mA=0%) और रिवर्स (4mA=100%) I/P पोजिशनर सपोर्ट।"
        ),
        keywords = listOf("i/p converter", "3-15 psi", "pneumatic", "control valve", "0.2-1.0 bar"),
        fields = listOf(
            CalculatorField("ma", BilingualText("Input Current (mA)", "इनपुट करंट (mA)"), "12", "mA"),
            CalculatorField("range", BilingualText("Pneumatic Range", "न्यूमैटिक आउटपुट रेंज"), "1", "3–15 psi", listOf("3–15 psi", "0.2–1.0 bar", "0.2–1.0 kg/cm²"), isSelectorOnly = true),
            CalculatorField("action", BilingualText("Action", "एक्शन"), "1", "Direct", listOf("Direct", "Reverse"), isSelectorOnly = true)
        ),
        compute = { values, units ->
            runCatching {
                val ma = requireRange(values["ma"], 3.5, 21.0, BilingualText("Input mA", "इनपुट mA"))
                val rawFrac = (ma - 4.0) / 16.0
                val isReverse = units["action"] == "Reverse"
                val frac = if (isReverse) 1.0 - rawFrac else rawFrac
                val range = units["range"] ?: "3–15 psi"
                val psi = 3.0 + frac * 12.0
                val bar = 0.2 + frac * 0.8
                val kgcm2 = 0.2 + frac * 0.8
                val (primaryVal, primaryUnit) = when (range) {
                    "0.2–1.0 bar" -> formatEng(bar, 3) to "bar"
                    "0.2–1.0 kg/cm²" -> formatEng(kgcm2, 3) to "kg/cm²"
                    else -> formatEng(psi, 2) to "psi"
                }
                engOutput(
                    primaryLabel = BilingualText("Pneumatic Output ($range)", "न्यूमैटिक आउटपुट"),
                    primaryValue = primaryVal,
                    primaryUnit = primaryUnit,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Signal %", "सिग्नल %"), formatEng(frac * 100.0, 1), "%"),
                        SecondaryMetric(BilingualText("PSI Equivalent", "PSI मान"), formatEng(psi, 2), "psi"),
                        SecondaryMetric(BilingualText("Bar Equivalent", "Bar मान"), formatEng(bar, 3), "bar")
                    ),
                    formulaUsed = "P = P_min + ((mA − 4)/16) × Span",
                    substitutedFormula = "$range ($isReverse) @ ${formatEng(ma, 2)} mA → $primaryVal $primaryUnit",
                    stepExplanation = BilingualText("Output = $primaryVal $primaryUnit (${formatEng(frac * 100, 1)}%)", "आउटपुट = $primaryVal $primaryUnit")
                )
            }
        }
    )
}
