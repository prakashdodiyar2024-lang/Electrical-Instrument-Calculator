package com.example

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.LanguagePreferences
import com.example.model.AppLanguage
import com.example.ui.audio.TouchSoundController
import com.example.ui.screens.SPLASH_DURATION_MS
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.EICalculatorTheme

class SplashActivity : ComponentActivity() {

    private var startedAtElapsedMs: Long = 0L
    private var hasNavigatedToMain: Boolean = false
    private var splashSessionKey by androidx.compose.runtime.mutableIntStateOf(0)
    private var splashDurationMillis by androidx.compose.runtime.mutableLongStateOf(SPLASH_DURATION_MS)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TouchSoundController.getOrCreate(applicationContext)
        startedAtElapsedMs = savedInstanceState?.getLong(KEY_STARTED_AT_MS)
            ?: SystemClock.elapsedRealtime()
        hasNavigatedToMain = savedInstanceState?.getBoolean(KEY_HAS_NAVIGATED) == true
        splashSessionKey = savedInstanceState?.getInt(KEY_SPLASH_SESSION) ?: 0

        splashDurationMillis = if (savedInstanceState == null) {
            SPLASH_DURATION_MS
        } else {
            val elapsed = (SystemClock.elapsedRealtime() - startedAtElapsedMs).coerceAtLeast(0L)
            (SPLASH_DURATION_MS - elapsed).coerceAtLeast(0L)
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )

        setContent {
            val prefs = remember { LanguagePreferences(applicationContext) }
            val language by prefs.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.ENGLISH)
            EICalculatorTheme {
                SplashScreen(
                    language = language,
                    sessionKey = splashSessionKey,
                    durationMillis = splashDurationMillis,
                    onFinish = ::navigateToHomeOnce
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (!hasNavigatedToMain && !isFinishing && !isDestroyed) {
            startedAtElapsedMs = SystemClock.elapsedRealtime()
            splashDurationMillis = SPLASH_DURATION_MS
            splashSessionKey += 1
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(KEY_STARTED_AT_MS, startedAtElapsedMs)
        outState.putBoolean(KEY_HAS_NAVIGATED, hasNavigatedToMain)
        outState.putInt(KEY_SPLASH_SESSION, splashSessionKey)
    }

    private fun navigateToHomeOnce() {
        if (hasNavigatedToMain || isFinishing || isDestroyed) return
        hasNavigatedToMain = true
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_SKIP_SPLASH, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        val animBundle = ActivityOptions.makeCustomAnimation(
            this,
            android.R.anim.fade_in,
            android.R.anim.fade_out
        ).toBundle()
        startActivity(mainIntent, animBundle)
        finish()
    }

    private companion object {
        const val KEY_STARTED_AT_MS = "key_splash_started_at_ms"
        const val KEY_HAS_NAVIGATED = "key_splash_has_navigated"
        const val KEY_SPLASH_SESSION = "key_splash_session"
    }
}
