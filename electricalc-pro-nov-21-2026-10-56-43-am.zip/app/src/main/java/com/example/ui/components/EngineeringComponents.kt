package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueHeaderEnd
import com.example.ui.theme.RoyalBlueHeaderStart
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.SoftBlueChip
import com.example.ui.theme.SubtleGreyBorder
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.util.Locale
import kotlin.math.sin

@Composable
fun LanguageToggleChip(
    language: AppLanguage,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    darkSurface: Boolean = false
) {
    val playClick = rememberTouchClickSound()
    val bg by animateColorAsState(
        targetValue = if (darkSurface) PureWhite.copy(alpha = 0.16f) else SoftBlueChip,
        label = "langBg"
    )
    val borderColor = if (darkSurface) PureWhite.copy(alpha = 0.35f) else LightBlueBorder
    val contentColor = if (darkSurface) PureWhite else DarkNavyBlue
    val iconColor = if (darkSurface) PureWhite else RoyalBlue

    Surface(
        onClick = {
            playClick()
            onToggle()
        },
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(width = 1.dp, color = borderColor),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("language_toggle_button")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Translate,
                contentDescription = if (language == AppLanguage.ENGLISH) {
                    "Switch language to Hindi"
                } else {
                    "भाषा बदलें"
                },
                tint = iconColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = if (language == AppLanguage.ENGLISH) "EN | हिं" else "हिं | EN",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                ),
                color = contentColor
            )
        }
    }
}

@Composable
fun BrandLogoBadge(
    size: Dp,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(percent = 18),
        color = PureWhite,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, LightBlueBorder)
    ) {
        Image(
            painter = painterResource(id = R.drawable.channel_logo),
            contentDescription = "Electrical & Instrumentation Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp)
        )
    }
}

@Composable
fun EngineeringHeroHeader(
    language: AppLanguage,
    totalCalculators: Int,
    onToggleLanguage: () -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(RoyalBlueHeaderStart, RoyalBlueHeaderEnd)
                )
            )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Subtle Engineering Blueprint Watermark on Royal Blue Header
            Canvas(modifier = Modifier.matchParentSize()) {
                val step = 28.dp.toPx()
                val gridColor = PureWhite.copy(alpha = 0.06f)
                var x = 0f
                while (x < size.width) {
                    drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }

                val arcRadius = 70.dp.toPx()
                val center = Offset(size.width - 26.dp.toPx(), size.height * 0.65f)
                drawArc(
                    color = PureWhite.copy(alpha = 0.12f),
                    startAngle = 150f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = Offset(center.x - arcRadius, center.y - arcRadius),
                    size = androidx.compose.ui.geometry.Size(arcRadius * 2, arcRadius * 2),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                val wavePath = Path()
                val amp = 6.dp.toPx()
                val baseY = size.height - 12.dp.toPx()
                wavePath.moveTo(0f, baseY)
                var wx = 0f
                while (wx <= size.width) {
                    val wy = baseY + sin(wx / 36f) * amp
                    wavePath.lineTo(wx, wy)
                    wx += 8f
                }
                drawPath(
                    path = wavePath,
                    color = PureWhite.copy(alpha = 0.14f),
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = PureWhite.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.30f))
                    ) {
                        Text(
                            text = if (language == AppLanguage.ENGLISH) {
                                "ELECTRICALCALC PRO • $totalCalculators TOOLS"
                            } else {
                                "इलेक्ट्रिकलकैलक प्रो • $totalCalculators टूल्स"
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = PureWhite,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = {
                                playClick()
                                onOpenAbout()
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("about_us_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = if (language == AppLanguage.ENGLISH) {
                                    "About Us & Developer"
                                } else {
                                    "हमारे बारे में"
                                },
                                tint = PureWhite
                            )
                        }

                        LanguageToggleChip(
                            language = language,
                            onToggle = onToggleLanguage,
                            darkSurface = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BrandLogoBadge(
                        size = 52.dp,
                        modifier = Modifier.testTag("home_brand_logo")
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Electrical & Instrument Calculator",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                color = PureWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                lineHeight = 24.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (language == AppLanguage.ENGLISH) {
                                "50 Electrical + 50 Instrumentation • Engineering Suite"
                            } else {
                                "50 इलेक्ट्रिकल + 50 इंस्ट्रूमेंटेशन • इंजीनियरिंग सूट"
                            },
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = PureWhite.copy(alpha = 0.90f),
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
        HorizontalDivider(color = HairlineGrey)
    }
}

@Composable
fun CategoryBlueHeader(
    category: CalculatorCategory,
    calculatorCount: Int,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = RoyalBlue,
        shadowElevation = 2.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(RoyalBlueHeaderStart, RoyalBlueHeaderEnd)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = PureWhite.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.30f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.title.get(language),
                            tint = PureWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = category.title.get(language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        color = PureWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = category.description.get(language),
                        style = MaterialTheme.typography.bodySmall,
                        color = PureWhite.copy(alpha = 0.90f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = PureWhite.copy(alpha = 0.20f),
                    border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            "$calculatorCount Tools"
                        } else {
                            "$calculatorCount टूल्स"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        ),
                        color = PureWhite,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CalculatorListCard(
    calculator: CalculatorDefinition,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isFavorite: Boolean = false,
    onToggleFavorite: (() -> Unit)? = null,
    showCategoryTag: Boolean = false
) {
    val playClick = rememberTouchClickSound()
    val serialStr = String.format(Locale.US, "%02d", calculator.serialNumber)

    Card(
        onClick = {
            playClick()
            onClick()
        },
        modifier = modifier
            .fillMaxWidth()
            .testTag("calc_card_${calculator.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
        border = BorderStroke(1.dp, SubtleGreyBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RoyalBlueTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = calculator.icon,
                    contentDescription = calculator.title.get(language),
                    tint = RoyalBlue,
                    modifier = Modifier.size(23.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = RoyalBlueTint,
                        border = BorderStroke(1.dp, LightBlueBorder)
                    ) {
                        Text(
                            text = serialStr,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            ),
                            color = DarkNavyBlue,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (showCategoryTag) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = PureWhite,
                            border = BorderStroke(1.dp, SubtleGreyBorder)
                        ) {
                            Text(
                                text = calculator.category.shortTitle.get(language),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                ),
                                color = RoyalBlue,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = calculator.title.get(language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 19.sp
                    ),
                    color = TextPrimaryDark,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = calculator.subtitle.get(language),
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    ),
                    color = TextSecondaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (onToggleFavorite != null) {
                IconButton(
                    onClick = {
                        playClick()
                        onToggleFavorite()
                    },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("fav_toggle_${calculator.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                        contentDescription = if (isFavorite) "Remove favorite" else "Add favorite",
                        tint = if (isFavorite) FavoriteGold else TextSecondaryDark,
                        modifier = Modifier.size(22.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(6.dp))
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(PureWhite),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = null,
                    tint = RoyalBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
