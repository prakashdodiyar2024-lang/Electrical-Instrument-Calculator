package com.example

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.model.CalculatorCategory
import com.example.ui.CalculatorViewModel
import com.example.ui.audio.TouchSoundController
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.CategoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.EICalculatorTheme

const val ROUTE_SPLASH = "splash"
const val ROUTE_HOME = "home"
const val ROUTE_CATEGORY = "category/{categoryId}"
const val ROUTE_CALCULATOR = "calculator/{calcId}"
const val ROUTE_ABOUT = "about"

class MainActivity : ComponentActivity() {

    private var showSplashState by mutableStateOf(true)
    private var splashSessionKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TouchSoundController.getOrCreate(applicationContext)
        val skipSplashFromLauncher = intent?.getBooleanExtra(EXTRA_SKIP_SPLASH, false) == true
        if (skipSplashFromLauncher) {
            intent?.removeExtra(EXTRA_SKIP_SPLASH)
        }
        val wasConfigChange = savedInstanceState?.getBoolean(KEY_WAS_CONFIG_CHANGE, false) == true
        if (skipSplashFromLauncher) {
            showSplashState = false
        } else if (wasConfigChange) {
            showSplashState = savedInstanceState?.getBoolean(KEY_SHOW_SPLASH, false) ?: false
            splashSessionKey = savedInstanceState?.getInt(KEY_SPLASH_SESSION_KEY, 0) ?: 0
        } else {
            showSplashState = true
            splashSessionKey = (savedInstanceState?.getInt(KEY_SPLASH_SESSION_KEY, 0) ?: 0) + 1
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            EICalculatorTheme {
                EICalculatorApp(
                    showSplashInitially = !skipSplashFromLauncher,
                    splashSessionKey = splashSessionKey,
                    externalShowSplash = showSplashState,
                    onSplashFinished = {
                        if (showSplashState) {
                            showSplashState = false
                        }
                    }
                )
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_WAS_CONFIG_CHANGE, changingConfigurations != 0)
        outState.putBoolean(KEY_SHOW_SPLASH, showSplashState)
        outState.putInt(KEY_SPLASH_SESSION_KEY, splashSessionKey)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val skipSplashFromLauncher = intent.getBooleanExtra(EXTRA_SKIP_SPLASH, false)
        if (skipSplashFromLauncher) {
            intent.removeExtra(EXTRA_SKIP_SPLASH)
            showSplashState = false
        } else if (!showSplashState) {
            splashSessionKey += 1
            showSplashState = true
        }
    }

    companion object {
        const val EXTRA_SKIP_SPLASH = "extra_skip_splash"
        private const val KEY_WAS_CONFIG_CHANGE = "key_was_config_change"
        private const val KEY_SHOW_SPLASH = "key_show_splash"
        private const val KEY_SPLASH_SESSION_KEY = "key_splash_session_key"
    }
}

@Composable
fun EICalculatorApp(
    viewModel: CalculatorViewModel = viewModel(),
    showSplashInitially: Boolean = true,
    splashSessionKey: Int = 0,
    externalShowSplash: Boolean? = null,
    onSplashFinished: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var internalShowSplash by remember(splashSessionKey, showSplashInitially) {
        mutableStateOf(showSplashInitially)
    }
    val showSplash = externalShowSplash ?: internalShowSplash

    AnimatedContent(
        targetState = showSplash,
        transitionSpec = {
            (fadeIn(animationSpec = tween(durationMillis = 600)) +
                scaleIn(initialScale = 0.98f, animationSpec = tween(durationMillis = 600))) togetherWith
                fadeOut(animationSpec = tween(durationMillis = 500))
        },
        label = "splashToHomeTransition"
    ) { splashVisible ->
        if (splashVisible) {
            SplashScreen(
                language = uiState.language,
                sessionKey = splashSessionKey,
                onFinish = {
                    if (externalShowSplash == null) {
                        if (internalShowSplash) {
                            internalShowSplash = false
                        }
                    }
                    onSplashFinished?.invoke()
                }
            )
        } else {
            val navController = rememberNavController()
            NavHost(
                navController = navController,
                startDestination = ROUTE_HOME
            ) {
                composable(route = ROUTE_HOME) {
            HomeScreen(
                uiState = uiState,
                onToggleLanguage = viewModel::toggleLanguage,
                onSearchQueryChange = viewModel::onSearchQueryChange,
                onCategoryChipSelected = viewModel::onCategoryChipSelected,
                onOpenCategory = { category ->
                    navController.navigate("category/${category.id}") {
                        launchSingleTop = true
                    }
                },
                onOpenCalculator = { calcId ->
                    viewModel.openCalculator(calcId)
                    navController.navigate("calculator/$calcId") {
                        launchSingleTop = true
                    }
                },
                onOpenAbout = {
                    navController.navigate(ROUTE_ABOUT) {
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(
            route = ROUTE_CATEGORY,
            arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
        ) { backStackEntry ->
            val catId = backStackEntry.arguments?.getString("categoryId")
            val category = CalculatorCategory.entries.firstOrNull { it.id == catId }
                ?: CalculatorCategory.ELECTRICAL
            CategoryScreen(
                category = category,
                language = uiState.language,
                onBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    }
                },
                onToggleLanguage = viewModel::toggleLanguage,
                onOpenCalculator = { calcId ->
                    viewModel.openCalculator(calcId)
                    navController.navigate("calculator/$calcId") {
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(
            route = ROUTE_CALCULATOR,
            arguments = listOf(navArgument("calcId") { type = NavType.StringType })
        ) { backStackEntry ->
            val calcId = backStackEntry.arguments?.getString("calcId")
            LaunchedEffect(calcId) {
                if (calcId != null && uiState.activeCalculator?.id != calcId) {
                    viewModel.openCalculator(calcId)
                }
            }
            CalculatorScreen(
                uiState = uiState,
                onBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    }
                },
                onToggleLanguage = viewModel::toggleLanguage,
                onFieldValueChange = viewModel::onFieldValueChange,
                onToggleSign = viewModel::toggleFieldSign,
                onFieldUnitChange = viewModel::onFieldUnitChange,
                onApplyPreset = viewModel::applyPreset,
                onCalculate = { viewModel.calculate(addToHistory = true) },
                onReset = viewModel::resetActiveCalculator
            )
        }

                composable(ROUTE_ABOUT) {
                    AboutScreen(
                        language = uiState.language,
                        onBack = {
                            if (navController.previousBackStackEntry != null) {
                                navController.popBackStack()
                            }
                        },
                        onToggleLanguage = viewModel::toggleLanguage
                    )
                }
            }
        }
    }
}
