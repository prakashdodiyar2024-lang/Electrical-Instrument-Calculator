package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Industrial Dark Navy & Midnight Black Surfaces
val ObsidianBlack = Color(0xFF040811)
val DarkBlueprintBg = Color(0xFF070D1A)
val DarkBlueprintSurface = Color(0xFF0E192D)
val DarkBlueprintSurfaceElevated = Color(0xFF13233F)
val DarkBlueprintSurfaceVariant = Color(0xFF192D4E)
val DarkBorderSubtle = Color(0xFF233B63)

// Primary Engineering & Electric Blue Accents
val DeepNavy = Color(0xFF08265C)
val CobaltBlue = Color(0xFF0D47A1)
val ElectricBlue = Color(0xFF1E88E5)
val ElectricBlueBright = Color(0xFF4DA3FF)
val ElectricBlueInner = Color(0xFF1565C0)
val LightBluePrimary = Color(0xFF7BB7FF)
val LightBlueContainer = Color(0xFF123266)
val DarkElectricTint = Color(0xFF10284E)
val SkyBlueTint = Color(0xFFE8F1FC)
val BlueBorder = Color(0xFF2B4D82)

// Secondary / Accent Safety Orange Palette
val SafetyOrange = Color(0xFFFF6D00)
val WarmOrange = Color(0xFFFF8F2B)
val BrightOrangeAccent = Color(0xFFFF9E40)
val DarkOrangeContainer = Color(0xFF3E1E06)
val DarkOrangeTint = Color(0xFF2D1807)
val SoftOrangeTint = Color(0xFFFFF3E0)
val OrangeBorder = Color(0xFFFFB74D)

// High-Contrast Text & Neutral Tokens
val PureWhite = Color(0xFFFFFFFF)
val CrispLightText = Color(0xFFF1F5FC)
val MutedLightText = Color(0xFFA0B4D0)
val CoolIceBackground = Color(0xFFF4F7FB)
val ElevatedWhite = Color(0xFFFFFFFF)
val SlateSurfaceVariant = Color(0xFFE7EEF8)
val InkDark = Color(0xFF0F1B2D)
val SlateMuted = Color(0xFF4E607A)
val OutlineSubtle = Color(0xFFD0DCEB)

// Semantic Engineering Status Colors
val StatusSuccessGreen = Color(0xFF4ADE80)
val StatusSuccessBg = Color(0xFF0B291B)
val StatusWarningAmber = Color(0xFFFFB74D)
val StatusWarningBg = Color(0xFF2E1C07)
val StatusErrorRed = Color(0xFFFF7B7B)
val StatusErrorBg = Color(0xFF341117)

// Clean White Engineering UI Tokens
val CleanSurfaceAlt = Color(0xFFF8FAFC)
val LightGreyBorder = Color(0xFFD1D5DB)
val HairlineGrey = Color(0xFFE5E7EB)
val TextPrimaryDark = Color(0xFF111827)
val TextSecondaryDark = Color(0xFF4B5563)
val ActionRed = Color(0xFFD32F2F)
val ClearRed = Color(0xFFE53935)
val SoftRedTint = Color(0xFFFEF2F2)
val SoftRedBorder = Color(0xFFFCA5A5)
val ErrorRedDark = Color(0xFFB91C1C)

// Home Category Card Colors (Clean High-Contrast Engineering Palette)
val CategoryElectricalBlue = Color(0xFF1976D2)
val CategoryElectricalBlueDeep = Color(0xFF1565C0)
val CategoryInstrumentationTeal = Color(0xFF00796B)
val CategoryInstrumentationTealDeep = Color(0xFF00695C)
val CategoryMotorOrange = Color(0xFFD84315)
val CategoryMotorOrangeDeep = Color(0xFFBF360C)
val CategoryVfdIndigo = Color(0xFF283593)
val CategoryVfdIndigoDeep = Color(0xFF1A237E)
val CategoryPlcPurple = Color(0xFF6A1B9A)
val CategoryPlcPurpleDeep = Color(0xFF4A148C)
val CategorySignalGreen = Color(0xFF2E7D32)
val CategorySignalGreenDeep = Color(0xFF1B5E20)
val CategoryRtdCrimson = Color(0xFFC62828)
val CategoryRtdCrimsonDeep = Color(0xFFB71C1C)
val CategoryProcessCyan = Color(0xFF0277BD)
val CategoryProcessCyanDeep = Color(0xFF01579B)
val CategoryCableSlate = Color(0xFF37474F)
val CategoryCableSlateDeep = Color(0xFF263238)

