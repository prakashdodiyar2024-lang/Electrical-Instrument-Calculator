package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.material.icons.rounded.ElectricMeter
import androidx.compose.material.icons.rounded.ElectricalServices
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Water
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector
import java.util.Locale
import kotlin.math.abs

enum class AppLanguage {
    ENGLISH,
    HINDI
}

enum class EngineeringDiscipline(
    val id: String,
    val title: BilingualText,
    val subtitle: BilingualText
) {
    ELECTRICAL(
        id = "electrical",
        title = BilingualText("Electrical Calculator", "इलेक्ट्रिकल कैलकुलेटर"),
        subtitle = BilingualText("50 Professional Electrical Tools", "50 प्रोफेशनल इलेक्ट्रिकल टूल्स")
    ),
    INSTRUMENTATION(
        id = "instrumentation",
        title = BilingualText("Instrumentation Calculator", "इंस्ट्रूमेंटेशन कैलकुलेटर"),
        subtitle = BilingualText("50 Professional Instrumentation Tools", "50 प्रोफेशनल इंस्ट्रूमेंटेशन टूल्स")
    )
}

data class BilingualText(
    val en: String,
    val hi: String
) {
    fun get(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> en
        AppLanguage.HINDI -> hi
    }
}

class BilingualValidationException(val bilingualMessage: BilingualText) :
    IllegalArgumentException(bilingualMessage.en)

enum class CalculatorCategory(
    val id: String,
    val discipline: EngineeringDiscipline,
    val tabTitle: BilingualText,
    val title: BilingualText,
    val shortTitle: BilingualText,
    val description: BilingualText,
    val icon: ImageVector,
    val serialRange: String
) {
    // --- 5 ELECTRICAL CATEGORIES (50 Tools) ---
    ELEC_BASIC(
        id = "elec_basic",
        discipline = EngineeringDiscipline.ELECTRICAL,
        tabTitle = BilingualText("Home", "बेसिक"),
        title = BilingualText("Basic Electrical Calculators", "बेसिक इलेक्ट्रिकल कैलकुलेटर"),
        shortTitle = BilingualText("Basic Electrical", "बेसिक इलेक्ट्रिकल"),
        description = BilingualText(
            "Ohm's Law, Power (P=VI), Current, Voltage, R, X, Z, PF, kWh & Frequency",
            "ओम का नियम, पावर, करंट, वोल्टेज, रेजिस्टेंस, रिएक्टेंस, इम्पीडेंस व kWh"
        ),
        icon = Icons.Rounded.Bolt,
        serialRange = "1–10"
    ),
    ELEC_TRANSFORMER(
        id = "elec_transformer",
        discipline = EngineeringDiscipline.ELECTRICAL,
        tabTitle = BilingualText("Transformer", "ट्रांसफॉर्मर"),
        title = BilingualText("Transformer Calculators", "ट्रांसफॉर्मर कैलकुलेटर"),
        shortTitle = BilingualText("Transformer", "ट्रांसफॉर्मर"),
        description = BilingualText(
            "kVA, kVA↔kW, FLC, Efficiency, Regulation, Turns Ratio, Core Area & Losses",
            "ट्रांसफॉर्मर kVA, FLC, एफिशिएंसी, रेगुलेशन, टर्न रेशियो, कोर एरिया और लॉस"
        ),
        icon = Icons.Rounded.ElectricalServices,
        serialRange = "11–20"
    ),
    ELEC_MOTOR(
        id = "elec_motor",
        discipline = EngineeringDiscipline.ELECTRICAL,
        tabTitle = BilingualText("Motor", "मोटर"),
        title = BilingualText("Motor Calculators", "मोटर कैलकुलेटर"),
        shortTitle = BilingualText("Motor", "मोटर"),
        description = BilingualText(
            "kW/HP, FLC, Motor Cable, Star-Delta, Starting Current, Efficiency, Slip & Torque",
            "मोटर kW/HP, FLC, केबल साइज, स्टार-डेल्टा, स्टार्टिंग करंट, स्लिप और टॉर्क"
        ),
        icon = Icons.Rounded.ElectricMeter,
        serialRange = "21–30"
    ),
    ELEC_POWER(
        id = "elec_power",
        discipline = EngineeringDiscipline.ELECTRICAL,
        tabTitle = BilingualText("Power", "पावर"),
        title = BilingualText("Power System Calculators", "पावर सिस्टम कैलकुलेटर"),
        shortTitle = BilingualText("Power System", "पावर सिस्टम"),
        description = BilingualText(
            "3φ/1φ Power, Line Current, Short Circuit, Fault MVA, Voltage Drop, Ampacity & PF",
            "3-फेज़/1-फेज़ पावर, शॉर्ट सर्किट, फॉल्ट MVA, वोल्टेज ड्रॉप, एम्पैसिटी व MD"
        ),
        icon = Icons.Rounded.Power,
        serialRange = "31–40"
    ),
    ELEC_MORE(
        id = "elec_more",
        discipline = EngineeringDiscipline.ELECTRICAL,
        tabTitle = BilingualText("More", "अन्य"),
        title = BilingualText("Other Electrical Calculators", "अन्य इलेक्ट्रिकल कैलकुलेटर"),
        shortTitle = BilingualText("Other Electrical", "अन्य इलेक्ट्रिकल"),
        description = BilingualText(
            "Capacitor kVAr, Discharge, Battery, UPS, Inverter, Earthing, Tray, Lighting & Bill",
            "कैपेसिटर, बैटरी बैकअप, UPS, इन्वर्टर, अर्थिंग, केबल ट्रे, लाइटिंग और बिजली बिल"
        ),
        icon = Icons.Rounded.Build,
        serialRange = "41–50"
    ),

    // --- 5 INSTRUMENTATION CATEGORIES (50 Tools) ---
    INST_SIGNAL(
        id = "inst_signal",
        discipline = EngineeringDiscipline.INSTRUMENTATION,
        tabTitle = BilingualText("Signal", "सिग्नल"),
        title = BilingualText("Signal Calculators", "सिग्नल कैलकुलेटर"),
        shortTitle = BilingualText("Signal", "सिग्नल"),
        description = BilingualText(
            "4–20 mA ↔ PV, mA ↔ %, 0–10 V Scaling, mA ⇄ V Converter, Loop Check & I/P",
            "4–20 mA ↔ PV, %, 0–10 V स्केलिंग, mA ⇄ V कन्वर्टर, लूप चेक और I/P"
        ),
        icon = Icons.AutoMirrored.Rounded.ShowChart,
        serialRange = "1–10"
    ),
    INST_PRESSURE(
        id = "inst_pressure",
        discipline = EngineeringDiscipline.INSTRUMENTATION,
        tabTitle = BilingualText("Pressure", "प्रेशर"),
        title = BilingualText("Pressure Calculators", "प्रेशर कैलकुलेटर"),
        shortTitle = BilingualText("Pressure", "प्रेशर"),
        description = BilingualText(
            "Bar/PSI/kg/cm², mmH₂O↔Bar, TX Range, ΔP, DP Flow, Hydrostatic, Head & Gauge↔Abs",
            "प्रेशर यूनिट, mmH₂O↔Bar, TX रेंज, ΔP, DP फ्लो, हाइड्रोस्टैटिक और गेज↔एब्सोल्यूट"
        ),
        icon = Icons.Rounded.Speed,
        serialRange = "11–20"
    ),
    INST_FLOW(
        id = "inst_flow",
        discipline = EngineeringDiscipline.INSTRUMENTATION,
        tabTitle = BilingualText("Flow", "फ्लो"),
        title = BilingualText("Flow Calculators", "फ्लो कैलकुलेटर"),
        shortTitle = BilingualText("Flow", "फ्लो"),
        description = BilingualText(
            "m³/hr, Mass TPH, Velocity, Orifice, Venturi, Nozzle, Rotameter, Gas Comp & Totalizer",
            "फ्लो रेट, मास TPH, वेलोसिटी, ऑरिफिस, वेंचुरी, नोजल, रोटामीटर व टोटलाइजर"
        ),
        icon = Icons.Rounded.Water,
        serialRange = "21–30"
    ),
    INST_LEVEL(
        id = "inst_level",
        discipline = EngineeringDiscipline.INSTRUMENTATION,
        tabTitle = BilingualText("Level", "लेवल"),
        title = BilingualText("Level Calculators", "लेवल कैलकुलेटर"),
        shortTitle = BilingualText("Level", "लेवल"),
        description = BilingualText(
            "Vertical/Horizontal Tank Volume, Level TX Range, SG, Height, Density Corr & Mass",
            "वर्टिकल/हॉरिजॉन्टल टैंक वॉल्यूम, लेवल TX रेंज, SG, हाइट और डेंसिटी करेक्शन"
        ),
        icon = Icons.Rounded.WaterDrop,
        serialRange = "31–40"
    ),
    INST_TEMPERATURE(
        id = "inst_temperature",
        discipline = EngineeringDiscipline.INSTRUMENTATION,
        tabTitle = BilingualText("Temperature", "तापमान"),
        title = BilingualText("Temperature Calculators", "तापमान कैलकुलेटर"),
        shortTitle = BilingualText("Temperature", "तापमान"),
        description = BilingualText(
            "RTD PT100 (Ω↔°C), Type K (mV↔°C), °C/°F/K, Temp TX, ΔL Expansion, Heat Q, ΔT & Avg",
            "RTD PT100, टाइप K थर्मोकपल, °C/°F/K, Temp TX, तापीय प्रसार, हीट Q और औसत"
        ),
        icon = Icons.Rounded.DeviceThermostat,
        serialRange = "41–50"
    );

    companion object {
        fun forDiscipline(discipline: EngineeringDiscipline): List<CalculatorCategory> =
            entries.filter { it.discipline == discipline }
    }
}

data class CalculatorField(
    val id: String,
    val label: BilingualText,
    val defaultValue: String,
    val defaultUnit: String,
    val unitOptions: List<String> = listOf(defaultUnit),
    val helperText: BilingualText? = null,
    val allowNegative: Boolean = false,
    val isSelectorOnly: Boolean = false
)

data class CalculatorPreset(
    val label: BilingualText,
    val values: Map<String, String>,
    val units: Map<String, String> = emptyMap()
)

enum class StatusLevel {
    NORMAL,
    WARNING,
    INFO
}

data class SecondaryMetric(
    val label: BilingualText,
    val value: String,
    val unit: String = "",
    val localizedValue: BilingualText? = null
)

data class CalculationStep(
    val stepNumber: Int,
    val title: BilingualText,
    val expression: String,
    val explanation: BilingualText
)

data class CalculationOutput(
    val primaryLabel: BilingualText,
    val primaryValue: String,
    val primaryUnit: String,
    val primaryUnitLocalized: BilingualText? = null,
    val secondaryMetrics: List<SecondaryMetric> = emptyList(),
    val formulaUsed: String,
    val substitutedFormula: String = "",
    val steps: List<CalculationStep>,
    val resultExplanation: BilingualText? = null,
    val assumptions: BilingualText? = null,
    val engineeringNote: BilingualText? = null,
    val statusLevel: StatusLevel = StatusLevel.NORMAL
)

data class CalculatorDefinition(
    val id: String,
    val serialNumber: Int,
    val category: CalculatorCategory,
    val icon: ImageVector,
    val title: BilingualText,
    val subtitle: BilingualText,
    val formulaPreview: String,
    val assumptions: BilingualText? = null,
    val keywords: List<String>,
    val fields: List<CalculatorField>,
    val presets: List<CalculatorPreset> = emptyList(),
    val compute: (values: Map<String, Double>, units: Map<String, String>) -> Result<CalculationOutput>
)

data class CalculationHistoryItem(
    val calculatorId: String,
    val title: BilingualText,
    val resultSummary: String,
    val category: CalculatorCategory
)

fun formatEng(value: Double, decimals: Int = 3): String {
    if (value.isNaN() || value.isInfinite()) return "—"
    val safeVal = if (abs(value) < 1e-12) 0.0 else value
    val rounded = String.format(Locale.US, "%.${decimals}f", safeVal)
    val result = if (rounded.contains('.')) {
        rounded.trimEnd('0').trimEnd('.')
    } else {
        rounded
    }
    return if (result == "-0") "0" else result
}

fun requirePositive(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value <= 0.0) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be greater than 0.",
                "${fieldLabel.hi} का मान 0 से अधिक होना चाहिए।"
            )
        )
    }
    return value
}

fun requireNonNegative(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value < 0.0) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} cannot be negative.",
                "${fieldLabel.hi} का मान नेगेटिव (ऋणात्मक) नहीं हो सकता।"
            )
        )
    }
    return value
}

fun requireNonZero(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite() || abs(value) < 1e-12) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} cannot be zero.",
                "${fieldLabel.hi} का मान शून्य (0) नहीं हो सकता।"
            )
        )
    }
    return value
}

fun requireFinite(value: Double?, fieldLabel: BilingualText): Double {
    if (value == null || value.isNaN() || value.isInfinite()) {
        throw BilingualValidationException(
            BilingualText(
                "Please enter a valid finite number for ${fieldLabel.en}.",
                "कृपया ${fieldLabel.hi} के लिए एक मान्य संख्या दर्ज करें।"
            )
        )
    }
    return value
}

fun requireRange(
    value: Double?,
    min: Double,
    max: Double,
    fieldLabel: BilingualText
): Double {
    if (value == null || value.isNaN() || value.isInfinite() || value < min || value > max) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be between ${formatEng(min, 2)} and ${formatEng(max, 2)}.",
                "${fieldLabel.hi} का मान ${formatEng(min, 2)} से ${formatEng(max, 2)} के बीच होना चाहिए।"
            )
        )
    }
    return value
}

fun requireEvenPoles(value: Double?, fieldLabel: BilingualText): Int {
    if (value == null || value.isNaN() || value.isInfinite()) {
        throw BilingualValidationException(
            BilingualText("Enter valid number of poles.", "पोल की सही संख्या दर्ज करें।")
        )
    }
    val rounded = value.toInt()
    if (abs(value - rounded) > 1e-6 || rounded < 2 || rounded % 2 != 0 || rounded > 24) {
        throw BilingualValidationException(
            BilingualText(
                "${fieldLabel.en} must be an even number (2, 4, 6, 8, ... 24).",
                "${fieldLabel.hi} सम संख्या (2, 4, 6, 8, ... 24) होनी चाहिए।"
            )
        )
    }
    return rounded
}
