package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.theme.BrightOrangeAccent
import com.example.ui.theme.CrispLightText
import com.example.ui.theme.DarkBlueprintBg
import com.example.ui.theme.DarkBlueprintSurface
import com.example.ui.theme.DarkBlueprintSurfaceElevated
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkElectricTint
import com.example.ui.theme.DarkOrangeTint
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueBright
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBluePrimary
import com.example.ui.theme.MutedLightText
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SafetyOrange
import kotlin.math.sin

@Composable
fun LanguageToggleChip(
    language: AppLanguage,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    darkSurface: Boolean = true
) {
    val playClick = rememberTouchClickSound()
    val bg by animateColorAsState(
        targetValue = if (darkSurface) Color(0x26FFFFFF) else DarkBlueprintSurfaceElevated,
        label = "langBg"
    )

    Surface(
        onClick = {
            playClick()
            onToggle()
        },
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(
            width = 1.dp,
            color = if (darkSurface) ElectricBlueBright.copy(alpha = 0.45f) else DarkBorderSubtle
        ),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("language_toggle_button")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Translate,
                contentDescription = if (language == AppLanguage.ENGLISH) {
                    "Switch language to Hindi"
                } else {
                    "भाषा बदलें"
                },
                tint = SafetyOrange,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = if (language == AppLanguage.ENGLISH) "EN | हिं" else "हिं | EN",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                ),
                color = PureWhite
            )
        }
    }
}

@Composable
fun BrandLogoBadge(
    size: Dp,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(percent = 14),
        color = PureWhite,
        shadowElevation = 4.dp,
        border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.55f))
    ) {
        Image(
            painter = painterResource(id = R.drawable.channel_logo),
            contentDescription = "Electrical & Instrumentation Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
        )
    }
}

@Composable
fun EngineeringHeroHeader(
    language: AppLanguage,
    totalCalculators: Int,
    onToggleLanguage: () -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(DeepNavy, DarkBlueprintBg, ObsidianBlack)
                )
            )
    ) {
        // Custom Canvas Blueprint Grid + Engineering Sine Wave & Gauge Arc
        Canvas(modifier = Modifier.matchParentSize()) {
            val step = 28.dp.toPx()
            val gridColor = ElectricBlue.copy(alpha = 0.09f)
            var x = 0f
            while (x < size.width) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }

            // Decorative orange gauge arc on top-right
            val arcRadius = 72.dp.toPx()
            val center = Offset(size.width - 28.dp.toPx(), size.height * 0.65f)
            drawArc(
                color = SafetyOrange.copy(alpha = 0.22f),
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(center.x - arcRadius, center.y - arcRadius),
                size = androidx.compose.ui.geometry.Size(arcRadius * 2, arcRadius * 2),
                style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
            )

            // Subtle AC sine wave near bottom
            val wavePath = Path()
            val amp = 10.dp.toPx()
            val baseY = size.height - 18.dp.toPx()
            wavePath.moveTo(0f, baseY)
            var wx = 0f
            while (wx <= size.width) {
                val wy = baseY + sin(wx / 36f) * amp
                wavePath.lineTo(wx, wy)
                wx += 8f
            }
            drawPath(
                path = wavePath,
                color = ElectricBlueBright.copy(alpha = 0.16f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = SafetyOrange,
                    contentColor = PureWhite
                ) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            "PRO SUITE • $totalCalculators TOOLS"
                        } else {
                            "प्रो सूट • $totalCalculators टूल्स"
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            playClick()
                            onOpenAbout()
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("about_us_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = if (language == AppLanguage.ENGLISH) {
                                "About Us & Developer"
                            } else {
                                "हमारे बारे में"
                            },
                            tint = LightBluePrimary
                        )
                    }

                    LanguageToggleChip(
                        language = language,
                        onToggle = onToggleLanguage,
                        darkSurface = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BrandLogoBadge(
                    size = 54.dp,
                    modifier = Modifier.testTag("home_brand_logo")
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Electrical & Instrumentation",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = BrightOrangeAccent,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.4.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            "Electrical & Instrument\nCalculator"
                        } else {
                            "इलेक्ट्रिकल एवं इंस्ट्रूमेंट\nकैलकुलेटर"
                        },
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 21.sp,
                            lineHeight = 25.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (language == AppLanguage.ENGLISH) {
                    "Accurate formulas, input summary, step-by-step solutions & examples"
                } else {
                    "सटीक सूत्र, इनपुट विवरण, स्टेप-बाय-स्टेप समाधान और उदाहरण"
                },
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MutedLightText
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CategoryGridCard(
    category: CalculatorCategory,
    calculatorCount: Int,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    val isOrange = category.isOrangeAccent
    val accentColor = if (isOrange) SafetyOrange else ElectricBlue
    val iconBg = if (isOrange) DarkOrangeTint else DarkElectricTint
    val iconTint = if (isOrange) BrightOrangeAccent else LightBluePrimary

    Card(
        onClick = {
            playClick()
            onClick()
        },
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_card_${category.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = DarkBlueprintSurface
        ),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Sleek top electric-blue or safety-orange indicator strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accentColor)
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(iconBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.title.get(language),
                            tint = iconTint,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = DarkBlueprintSurfaceElevated,
                        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "$calculatorCount",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = iconTint,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = category.title.get(language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = CrispLightText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = category.description.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedLightText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun CalculatorListCard(
    calculator: CalculatorDefinition,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    val isOrange = calculator.category.isOrangeAccent
    val accentColor = if (isOrange) BrightOrangeAccent else LightBluePrimary
    val iconBg = if (isOrange) DarkOrangeTint else DarkElectricTint

    Card(
        onClick = {
            playClick()
            onClick()
        },
        modifier = modifier
            .fillMaxWidth()
            .testTag("calc_card_${calculator.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkBlueprintSurface),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = calculator.category.icon,
                    contentDescription = calculator.title.get(language),
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = calculator.title.get(language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = CrispLightText
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = calculator.subtitle.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedLightText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkBlueprintSurfaceElevated,
                    border = BorderStroke(1.dp, DarkBorderSubtle)
                ) {
                    Text(
                        text = calculator.formulaPreview,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp
                        ),
                        color = LightBluePrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(DarkBlueprintSurfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
