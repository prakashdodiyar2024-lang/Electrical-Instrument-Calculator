package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.CalculatorListCard
import com.example.ui.components.CategoryBlueHeader
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryScreen(
    category: CalculatorCategory,
    language: AppLanguage,
    favoriteIds: Set<String> = emptySet(),
    onToggleFavorite: ((String) -> Unit)? = null,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onOpenCalculator: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val calculators = CalculatorRegistry.getByCategory(category)
    val playClick = rememberTouchClickSound()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = PureWhite,
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(
                            text = category.title.get(language),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                playClick()
                                onBack()
                            },
                            modifier = Modifier.testTag("category_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = if (language == AppLanguage.ENGLISH) "Back" else "वापस जाएं",
                                tint = PureWhite
                            )
                        }
                    },
                    actions = {
                        LanguageToggleChip(
                            language = language,
                            onToggle = onToggleLanguage,
                            darkSurface = true,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = RoyalBlue
                    )
                )
                HorizontalDivider(color = DarkNavyBlue)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(PureWhite)
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .align(Alignment.TopCenter)
                    .testTag("category_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    CategoryBlueHeader(
                        category = category,
                        calculatorCount = calculators.size,
                        language = language
                    )
                }

                items(calculators, key = { it.id }) { calc ->
                    CalculatorListCard(
                        calculator = calc,
                        language = language,
                        isFavorite = calc.id in favoriteIds,
                        onToggleFavorite = onToggleFavorite?.let { toggle -> { toggle(calc.id) } },
                        onClick = { onOpenCalculator(calc.id) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
                }
            }
        }
    }
}
