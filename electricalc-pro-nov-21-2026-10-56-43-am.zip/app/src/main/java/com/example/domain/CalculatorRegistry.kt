package com.example.domain

import com.example.domain.electrical.ElecBasicCalculators
import com.example.domain.electrical.ElecMoreCalculators
import com.example.domain.electrical.ElecMotorCalculators
import com.example.domain.electrical.ElecPowerCalculators
import com.example.domain.electrical.ElecTransformerCalculators
import com.example.domain.instrumentation.InstFlowCalculators
import com.example.domain.instrumentation.InstLevelCalculators
import com.example.domain.instrumentation.InstPressureCalculators
import com.example.domain.instrumentation.InstSignalCalculators
import com.example.domain.instrumentation.InstTemperatureCalculators
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.EngineeringDiscipline

object CalculatorRegistry {

    val electricalCalculators: List<CalculatorDefinition> =
        ElecBasicCalculators.all +
            ElecTransformerCalculators.all +
            ElecMotorCalculators.all +
            ElecPowerCalculators.all +
            ElecMoreCalculators.all

    val instrumentationCalculators: List<CalculatorDefinition> =
        InstSignalCalculators.all +
            InstPressureCalculators.all +
            InstFlowCalculators.all +
            InstLevelCalculators.all +
            InstTemperatureCalculators.all

    val allCalculators: List<CalculatorDefinition> =
        electricalCalculators + instrumentationCalculators

    private val byIdMap: Map<String, CalculatorDefinition> =
        allCalculators.associateBy { it.id }

    fun getById(id: String): CalculatorDefinition? = byIdMap[id]

    fun getByCategory(category: CalculatorCategory): List<CalculatorDefinition> =
        allCalculators.filter { it.category == category }

    fun getByDiscipline(discipline: EngineeringDiscipline): List<CalculatorDefinition> =
        when (discipline) {
            EngineeringDiscipline.ELECTRICAL -> electricalCalculators
            EngineeringDiscipline.INSTRUMENTATION -> instrumentationCalculators
        }

    fun countForCategory(category: CalculatorCategory): Int =
        allCalculators.count { it.category == category }

    val popularIds: List<String> = listOf(
        "elec_ohms_law",
        "motor_flc",
        "power_three_phase",
        "sig_ma_to_pv",
        "temp_rtd_res",
        "flow_orifice_plate"
    )

    val popularCalculators: List<CalculatorDefinition> =
        popularIds.mapNotNull { byIdMap[it] }

    private fun normalizeSearchText(text: String): String =
        text.lowercase()
            .replace('\u2013', '-') // en-dash –
            .replace('\u2014', '-') // em-dash —
            .replace('\u2212', '-') // minus −
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun compactSearchText(text: String): String =
        normalizeSearchText(text)
            .replace("-", "")
            .replace(" ", "")

    fun search(
        query: String,
        disciplineFilter: EngineeringDiscipline? = null,
        categoryFilter: CalculatorCategory? = null
    ): List<CalculatorDefinition> {
        val normQuery = normalizeSearchText(query)
        val compactQuery = compactSearchText(query)
        val base = when {
            categoryFilter != null -> getByCategory(categoryFilter)
            disciplineFilter != null -> getByDiscipline(disciplineFilter)
            else -> allCalculators
        }
        if (normQuery.isEmpty()) return base
        return base.filter { calc ->
            val fields = listOf(
                calc.title.en,
                calc.title.hi,
                calc.subtitle.en,
                calc.subtitle.hi,
                calc.formulaPreview,
                calc.category.title.en,
                calc.category.title.hi,
                calc.serialNumber.toString()
            ) + calc.keywords

            fields.any { field ->
                val normField = normalizeSearchText(field)
                normField.contains(normQuery) ||
                    (compactQuery.isNotEmpty() && compactSearchText(field).contains(compactQuery))
            }
        }
    }
}
