package com.example.domain.instrumentation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Height
import androidx.compose.material.icons.rounded.Opacity
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Water
import androidx.compose.material.icons.rounded.Waves
import com.example.domain.engOutput
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireFinite
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.sqrt

object InstPressureCalculators {

    val all: List<CalculatorDefinition> = listOf(
        pressureUnitConverter(),    // 11
        mmh2oToBar(),               // 12
        barToMmh2o(),               // 13
        pressureTxRange(),          // 14
        differentialPressure(),     // 15
        dpToFlowSqrt(),             // 16
        hydrostaticPressure(),      // 17
        headToPressure(),           // 18
        pressureAtDepth(),          // 19
        gaugeToAbsolute()           // 20
    )

    private fun pressureUnitConverter() = CalculatorDefinition(
        id = "pres_unit_conv",
        serialNumber = 11,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("Pressure Unit Converter (Bar, PSI, kg/cm²)", "प्रेशर यूनिट कन्वर्टर (Bar, PSI, kg/cm²)"),
        subtitle = BilingualText("Convert Bar, PSI, kg/cm², kPa, MPa & mmH₂O", "प्रेशर को Bar, PSI, kg/cm², kPa और mmH₂O में बदलें"),
        formulaPreview = "1 bar = 100 kPa = 14.5038 psi = 1.01972 kg/cm² = 10197.2 mmH₂O",
        assumptions = BilingualText(
            "Standard gravity g = 9.80665 m/s² and water density 1000 kg/m³ at 4 °C.",
            "मान्यता: मानक गुरुत्व g = 9.80665 m/s²।"
        ),
        keywords = listOf("pressure converter", "bar", "psi", "kg/cm2", "kpa", "प्रेशर"),
        fields = listOf(
            CalculatorField("val", BilingualText("Pressure Value", "प्रेशर मान"), "6.0", "bar", listOf("bar", "psi", "kg/cm²", "kPa", "MPa", "mmH₂O", "mbar"), allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val raw = requireFinite(values["val"], BilingualText("Pressure", "प्रेशर"))
                val u = units["val"] ?: "bar"
                val bar = when (u) {
                    "psi" -> raw * 0.06894757
                    "kg/cm²" -> raw * 0.980665
                    "kPa" -> raw * 0.01
                    "MPa" -> raw * 10.0
                    "mmH₂O" -> raw * 9.80665e-5
                    "mbar" -> raw * 0.001
                    else -> raw
                }
                val psi = bar * 14.50377
                val kgcm2 = bar * 1.019716
                val kpa = bar * 100.0
                val mmh2o = bar * 10197.16
                engOutput(
                    primaryLabel = BilingualText("Pressure in Bar", "Bar में प्रेशर"),
                    primaryValue = formatEng(bar, 4),
                    primaryUnit = "bar",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("PSI", "PSI"), formatEng(psi, 3), "psi"),
                        SecondaryMetric(BilingualText("kg/cm²", "kg/cm²"), formatEng(kgcm2, 4), "kg/cm²"),
                        SecondaryMetric(BilingualText("kPa", "kPa"), formatEng(kpa, 2), "kPa"),
                        SecondaryMetric(BilingualText("mmH₂O", "mmH₂O"), formatEng(mmh2o, 1), "mmH₂O")
                    ),
                    formulaUsed = "1 bar = 14.5038 psi = 1.0197 kg/cm² = 100 kPa",
                    substitutedFormula = "${formatEng(raw, 3)} $u = ${formatEng(bar, 4)} bar",
                    stepExplanation = BilingualText("${formatEng(bar, 4)} bar = ${formatEng(psi, 2)} psi = ${formatEng(kgcm2, 3)} kg/cm²", "${formatEng(bar, 4)} bar = ${formatEng(psi, 2)} psi")
                )
            }
        }
    )

    private fun mmh2oToBar() = CalculatorDefinition(
        id = "pres_mmh2o_to_bar",
        serialNumber = 12,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.CompareArrows,
        title = BilingualText("mmH2O to Bar Converter", "mmH₂O से Bar कन्वर्टर"),
        subtitle = BilingualText("Convert Millimeters Water Column to Bar, mbar, kPa & PSI", "mmH₂O प्रेशर को Bar, mbar, kPa और PSI में बदलें"),
        formulaPreview = "1 mmH₂O = 0.0000980665 bar = 0.0980665 mbar = 9.80665 Pa",
        assumptions = BilingualText(
            "Based on standard water column density 1000 kg/m³ and g = 9.80665 m/s².",
            "मान्यता: मानक जल घनत्व 1000 kg/m³।"
        ),
        keywords = listOf("mmh2o to bar", "mmwc", "water column", "draft"),
        fields = listOf(
            CalculatorField("mmh2o", BilingualText("Water Column Pressure", "जल स्तंभ प्रेशर"), "2500", "mmH₂O", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val mm = requireFinite(values["mmh2o"], BilingualText("mmH₂O", "mmH₂O"))
                val bar = mm * 9.80665e-5
                val mbar = bar * 1000.0
                val kpa = bar * 100.0
                val psi = bar * 14.50377
                engOutput(
                    primaryLabel = BilingualText("Pressure in Bar", "Bar में प्रेशर"),
                    primaryValue = formatEng(bar, 5),
                    primaryUnit = "bar",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Millibar (mbar)", "मिलीबार (mbar)"), formatEng(mbar, 2), "mbar"),
                        SecondaryMetric(BilingualText("kPa", "kPa"), formatEng(kpa, 3), "kPa"),
                        SecondaryMetric(BilingualText("PSI", "PSI"), formatEng(psi, 3), "psi")
                    ),
                    formulaUsed = "bar = mmH₂O × 9.80665 × 10⁻⁵",
                    substitutedFormula = "${formatEng(mm, 1)} × 0.00009807 = ${formatEng(bar, 5)} bar",
                    stepExplanation = BilingualText("${formatEng(mm, 1)} mmH₂O = ${formatEng(bar, 5)} bar (${formatEng(mbar, 2)} mbar)", "${formatEng(mm, 1)} mmH₂O = ${formatEng(bar, 5)} bar")
                )
            }
        }
    )

    private fun barToMmh2o() = CalculatorDefinition(
        id = "pres_bar_to_mmh2o",
        serialNumber = 13,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Waves,
        title = BilingualText("Bar to mmH2O Converter", "Bar से mmH₂O कन्वर्टर"),
        subtitle = BilingualText("Convert Bar or mbar to mmH₂O, mH₂O & kPa", "Bar या mbar प्रेशर को mmH₂O और mH₂O में बदलें"),
        formulaPreview = "mmH₂O = bar × 10197.16",
        assumptions = BilingualText(
            "1 bar ≈ 10.197 meters of water column at 4 °C.",
            "मान्यता: 1 bar ≈ 10.197 मीटर जल स्तंभ।"
        ),
        keywords = listOf("bar to mmh2o", "mmwc", "water column"),
        fields = listOf(
            CalculatorField("bar", BilingualText("Pressure", "प्रेशर"), "0.25", "bar", listOf("bar", "mbar"), allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val raw = requireFinite(values["bar"], BilingualText("Pressure", "प्रेशर"))
                val bar = if (units["bar"] == "mbar") raw / 1000.0 else raw
                val mmh2o = bar * 10197.162
                val mh2o = mmh2o / 1000.0
                val kpa = bar * 100.0
                engOutput(
                    primaryLabel = BilingualText("Water Column (mmH₂O)", "जल स्तंभ (mmH₂O)"),
                    primaryValue = formatEng(mmh2o, 1),
                    primaryUnit = "mmH₂O",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Meters H₂O (mWC)", "मीटर जल स्तंभ"), formatEng(mh2o, 3), "mH₂O"),
                        SecondaryMetric(BilingualText("kPa", "kPa"), formatEng(kpa, 2), "kPa")
                    ),
                    formulaUsed = "mmH₂O = bar × 10197.16",
                    substitutedFormula = "${formatEng(bar, 4)} × 10197.16 = ${formatEng(mmh2o, 1)} mmH₂O",
                    stepExplanation = BilingualText("${formatEng(bar, 4)} bar = ${formatEng(mmh2o, 1)} mmH₂O", "${formatEng(bar, 4)} bar = ${formatEng(mmh2o, 1)} mmH₂O")
                )
            }
        }
    )

    private fun pressureTxRange() = CalculatorDefinition(
        id = "pres_tx_range",
        serialNumber = 14,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Tune,
        title = BilingualText("Pressure Transmitter Range Calculator", "प्रेशर ट्रांसमीटर रेंज कैलकुलेटर"),
        subtitle = BilingualText("Determine LRV, URV, Span & 5-Point Calibration mA Table", "प्रोसेस प्रेशर से PT की LRV, URV रेंज और कैलिब्रेशन पॉइंट निकालें"),
        formulaPreview = "URV = LRV + Operating_Max × (1 + Margin%)",
        assumptions = BilingualText(
            "Adds 25% default safety over-range headroom above normal operating max pressure.",
            "मान्यता: अधिकतम प्रेशर से 25% सेफ्टी मार्जिन जोड़कर URV सेट किया जाता है।"
        ),
        keywords = listOf("pressure transmitter", "lrv", "urv", "span", "calibration"),
        fields = listOf(
            CalculatorField("p_min", BilingualText("Min Operating Pressure (LRV)", "न्यूनतम प्रेशर (LRV)"), "0", "bar", listOf("bar", "psi", "kg/cm²", "kPa"), allowNegative = true),
            CalculatorField("p_max", BilingualText("Max Operating Pressure", "अधिकतम कार्य प्रेशर"), "8.0", "bar"),
            CalculatorField("margin", BilingualText("Over-Range Margin (%)", "सेफ्टी मार्जिन (%)"), "25", "%")
        ),
        compute = { values, units ->
            runCatching {
                val pMin = requireFinite(values["p_min"], BilingualText("Min Pressure", "न्यूनतम प्रेशर"))
                val pMax = requireFinite(values["p_max"], BilingualText("Max Pressure", "अधिकतम प्रेशर"))
                val margin = requireRange(values["margin"], 0.0, 100.0, BilingualText("Margin %", "मार्जिन %"))
                if (pMax <= pMin) throw BilingualValidationException(BilingualText("Max pressure must exceed Min pressure.", "अधिकतम प्रेशर, न्यूनतम से बड़ा होना चाहिए।"))
                val opSpan = pMax - pMin
                val urv = pMin + opSpan * (1.0 + margin / 100.0)
                val span = urv - pMin
                val unit = units["p_min"] ?: "bar"
                val p50 = pMin + 0.50 * span
                val p25 = pMin + 0.25 * span
                val p75 = pMin + 0.75 * span
                engOutput(
                    primaryLabel = BilingualText("Recommended Transmitter URV", "सुझावित ट्रांसमीटर URV"),
                    primaryValue = formatEng(urv, 2),
                    primaryUnit = unit,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span (URV−LRV)", "स्पैन"), formatEng(span, 2), unit),
                        SecondaryMetric(BilingualText("8 mA (25%)", "8 mA (25%)"), formatEng(p25, 2), unit),
                        SecondaryMetric(BilingualText("12 mA (50%)", "12 mA (50%)"), formatEng(p50, 2), unit),
                        SecondaryMetric(BilingualText("16 mA (75%)", "16 mA (75%)"), formatEng(p75, 2), unit)
                    ),
                    formulaUsed = "URV = LRV + (P_max − LRV) × (1 + Margin%)",
                    substitutedFormula = "URV = ${formatEng(pMin, 1)} + ${formatEng(opSpan, 2)} × (1 + ${formatEng(margin, 0)}%)",
                    stepExplanation = BilingualText("Calibrate LRV = ${formatEng(pMin, 2)} to URV = ${formatEng(urv, 2)} $unit", "रेंज: ${formatEng(pMin, 2)} से ${formatEng(urv, 2)} $unit")
                )
            }
        }
    )

    private fun differentialPressure() = CalculatorDefinition(
        id = "pres_dp_calc",
        serialNumber = 15,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Equalizer,
        title = BilingualText("Differential Pressure Calculator", "डिफरेंशियल प्रेशर (ΔP) कैलकुलेटर"),
        subtitle = BilingualText("Calculate ΔP = P₁ − P₂ across Filters, Pumps & Orifice Plates", "हाई साइड P₁ व लो साइड P₂ से ΔP और mmH₂O समतुल्य निकालें"),
        formulaPreview = "ΔP = P_high − P_low",
        assumptions = BilingualText(
            "Both P₁ and P₂ must be measured in the same pressure unit (gauge or absolute).",
            "मान्यता: P₁ और P₂ दोनों एक ही प्रेशर संदर्भ (गेज या एब्सोल्यूट) में हों।"
        ),
        keywords = listOf("differential pressure", "delta p", "dp", "filter", "orifice"),
        fields = listOf(
            CalculatorField("p1", BilingualText("High Side Pressure (P₁)", "हाई साइड प्रेशर (P₁)"), "6.5", "bar", listOf("bar", "psi", "kPa", "kg/cm²", "mmH₂O"), allowNegative = true),
            CalculatorField("p2", BilingualText("Low Side Pressure (P₂)", "लो साइड प्रेशर (P₂)"), "5.8", "bar", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val p1 = requireFinite(values["p1"], BilingualText("P₁", "P₁"))
                val p2 = requireFinite(values["p2"], BilingualText("P₂", "P₂"))
                val u = units["p1"] ?: "bar"
                val dp = p1 - p2
                val dpBar = when (u) {
                    "psi" -> dp * 0.06894757
                    "kPa" -> dp * 0.01
                    "kg/cm²" -> dp * 0.980665
                    "mmH₂O" -> dp * 9.80665e-5
                    else -> dp
                }
                val dpMmh2o = dpBar * 10197.16
                val pctDrop = if (kotlin.math.abs(p1) > 1e-9) (dp / p1) * 100.0 else 0.0
                engOutput(
                    primaryLabel = BilingualText("Differential Pressure (ΔP)", "डिफरेंशियल प्रेशर (ΔP)"),
                    primaryValue = formatEng(dp, 3),
                    primaryUnit = u,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("In mmH₂O", "mmH₂O में"), formatEng(dpMmh2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("Relative Drop %", "सापेक्ष अंतर %"), formatEng(pctDrop, 2), "%")
                    ),
                    formulaUsed = "ΔP = P₁ − P₂",
                    substitutedFormula = "ΔP = ${formatEng(p1, 3)} − ${formatEng(p2, 3)} = ${formatEng(dp, 3)} $u",
                    stepExplanation = BilingualText("ΔP = ${formatEng(dp, 3)} $u (${formatEng(dpMmh2o, 1)} mmH₂O)", "ΔP = ${formatEng(dp, 3)} $u"),
                    statusLevel = if (dp < 0.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun dpToFlowSqrt() = CalculatorDefinition(
        id = "pres_dp_to_flow",
        serialNumber = 16,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Water,
        title = BilingualText("DP to Flow Calculator (Square Root)", "DP से फ्लो कैलकुलेटर (वर्गमूल विधि)"),
        subtitle = BilingualText("Extract Flow Rate Q = Q_max × √(ΔP / ΔP_max) from DP", "ΔP से वर्गमूल निकालकर वास्तविक फ्लो और 4–20 mA सिग्नल निकालें"),
        formulaPreview = "Q = Q_max × √(ΔP_actual / ΔP_max)",
        assumptions = BilingualText(
            "Assumes constant fluid density and discharge coefficient over operating range.",
            "मान्यता: संचालन रेंज में द्रव घनत्व व डिस्चार्ज गुणांक स्थिर माना गया है।"
        ),
        keywords = listOf("dp to flow", "square root", "orifice", "differential pressure"),
        fields = listOf(
            CalculatorField("dp_act", BilingualText("Measured ΔP", "वर्तमान ΔP"), "1600", "mmH₂O"),
            CalculatorField("dp_max", BilingualText("Design Full-Scale ΔP_max", "अधिकतम ΔP_max"), "2500", "mmH₂O"),
            CalculatorField("q_max", BilingualText("Full-Scale Flow Q_max", "अधिकतम फ्लो Q_max"), "120", "m³/h", listOf("m³/h", "TPH", "LPM", "GPM"))
        ),
        compute = { values, units ->
            runCatching {
                val dpAct = requireNonNegative(values["dp_act"], BilingualText("Measured ΔP", "मापा गया ΔP"))
                val dpMax = requirePositive(values["dp_max"], BilingualText("Max ΔP", "अधिकतम ΔP"))
                val qMax = requirePositive(values["q_max"], BilingualText("Max Flow", "अधिकतम फ्लो"))
                val ratio = dpAct / dpMax
                val flowFrac = sqrt(ratio)
                val q = qMax * flowFrac
                val qUnit = units["q_max"] ?: "m³/h"
                val maLinearDp = 4.0 + ratio * 16.0
                val maSqrtFlow = 4.0 + flowFrac * 16.0
                engOutput(
                    primaryLabel = BilingualText("Calculated Flow Rate", "वास्तविक फ्लो रेट"),
                    primaryValue = formatEng(q, 2),
                    primaryUnit = qUnit,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Flow % of FS", "फ्लो %"), formatEng(flowFrac * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("Linear DP mA", "लीनियर DP mA"), formatEng(maLinearDp, 2), "mA"),
                        SecondaryMetric(BilingualText("Sqrt Flow mA", "स्क्वायर-रूट mA"), formatEng(maSqrtFlow, 2), "mA")
                    ),
                    formulaUsed = "Q = Q_max × √(ΔP / ΔP_max)",
                    substitutedFormula = "Q = ${formatEng(qMax, 1)} × √(${formatEng(dpAct, 1)} / ${formatEng(dpMax, 1)})",
                    stepExplanation = BilingualText("Flow = ${formatEng(q, 2)} $qUnit (${formatEng(flowFrac * 100, 1)}%)", "फ्लो = ${formatEng(q, 2)} $qUnit"),
                    statusLevel = if (dpAct > dpMax) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun hydrostaticPressure() = CalculatorDefinition(
        id = "pres_hydrostatic",
        serialNumber = 17,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Opacity,
        title = BilingualText("Hydrostatic Pressure Calculator", "हाइड्रोस्टैटिक प्रेशर कैलकुलेटर"),
        subtitle = BilingualText("Calculate Liquid Column Pressure P = ρ × g × h", "द्रव की ऊँचाई और स्पेसिफिक ग्रेविटी से प्रेशर निकालें"),
        formulaPreview = "P (kPa) = SG × 9.80665 × h (m)",
        assumptions = BilingualText(
            "Incompressible liquid column with standard g = 9.80665 m/s².",
            "मान्यता: असंपीड्य द्रव और मानक गुरुत्व g = 9.80665 m/s²।"
        ),
        keywords = listOf("hydrostatic pressure", "liquid column", "rho g h", "tank bottom"),
        fields = listOf(
            CalculatorField("height", BilingualText("Liquid Height (h)", "द्रव की ऊँचाई (h)"), "5.0", "m", listOf("m", "mm", "ft")),
            CalculatorField("sg", BilingualText("Specific Gravity (SG)", "स्पेसिफिक ग्रेविटी (SG)"), "1.0", "SG")
        ),
        compute = { values, units ->
            runCatching {
                val rawH = requireNonNegative(values["height"], BilingualText("Liquid Height", "ऊँचाई"))
                val sg = requirePositive(values["sg"], BilingualText("Specific Gravity", "SG"))
                val hM = when (units["height"]) {
                    "mm" -> rawH / 1000.0
                    "ft" -> rawH * 0.3048
                    else -> rawH
                }
                val pKpa = sg * 9.80665 * hM
                val pBar = pKpa / 100.0
                val pMmh2o = hM * 1000.0 * sg
                val pPsi = pBar * 14.50377
                engOutput(
                    primaryLabel = BilingualText("Hydrostatic Pressure", "हाइड्रोस्टैटिक प्रेशर"),
                    primaryValue = formatEng(pBar, 4),
                    primaryUnit = "bar",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("kPa", "kPa"), formatEng(pKpa, 2), "kPa"),
                        SecondaryMetric(BilingualText("mmH₂O", "mmH₂O"), formatEng(pMmh2o, 0), "mmH₂O"),
                        SecondaryMetric(BilingualText("PSI", "PSI"), formatEng(pPsi, 2), "psi")
                    ),
                    formulaUsed = "P = SG × 9.80665 × h(m) kPa",
                    substitutedFormula = "P = ${formatEng(sg, 3)} × 9.80665 × ${formatEng(hM, 3)}",
                    stepExplanation = BilingualText("Hydrostatic Pressure = ${formatEng(pBar, 4)} bar (${formatEng(pKpa, 2)} kPa)", "प्रेशर = ${formatEng(pBar, 4)} bar")
                )
            }
        }
    )

    private fun headToPressure() = CalculatorDefinition(
        id = "pres_head_to_pressure",
        serialNumber = 18,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Height,
        title = BilingualText("Head to Pressure Calculator", "हेड से प्रेशर कैलकुलेटर"),
        subtitle = BilingualText("Convert Pump / Static Head (m or ft) & Density to Pressure", "पंप हेड (मीटर/फीट) और घनत्व से प्रेशर निकालें"),
        formulaPreview = "P (bar) = (ρ × g × H) / 100000",
        assumptions = BilingualText(
            "Assumes fluid density ρ (kg/m³) is constant across the pump/pipe elevation.",
            "मान्यता: द्रव का घनत्व ρ (kg/m³) स्थिर माना गया है।"
        ),
        keywords = listOf("head to pressure", "pump head", "meters head", "bar"),
        fields = listOf(
            CalculatorField("head", BilingualText("Pump / Static Head (H)", "हेड (H)"), "35", "m", listOf("m", "ft")),
            CalculatorField("density", BilingualText("Fluid Density (ρ)", "द्रव घनत्व (ρ)"), "1000", "kg/m³")
        ),
        compute = { values, units ->
            runCatching {
                val rawH = requireNonNegative(values["head"], BilingualText("Head", "हेड"))
                val rho = requirePositive(values["density"], BilingualText("Density", "घनत्व"))
                val hM = if (units["head"] == "ft") rawH * 0.3048 else rawH
                val pPa = rho * 9.80665 * hM
                val pBar = pPa / 1e5
                val pKpa = pPa / 1000.0
                val pKgcm2 = pBar * 1.019716
                val pPsi = pBar * 14.50377
                engOutput(
                    primaryLabel = BilingualText("Converted Pressure", "समतुल्य प्रेशर"),
                    primaryValue = formatEng(pBar, 3),
                    primaryUnit = "bar",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("kg/cm²", "kg/cm²"), formatEng(pKgcm2, 3), "kg/cm²"),
                        SecondaryMetric(BilingualText("PSI", "PSI"), formatEng(pPsi, 2), "psi"),
                        SecondaryMetric(BilingualText("kPa", "kPa"), formatEng(pKpa, 1), "kPa")
                    ),
                    formulaUsed = "P = ρ × g × H",
                    substitutedFormula = "P = ${formatEng(rho, 1)} × 9.80665 × ${formatEng(hM, 2)} Pa",
                    stepExplanation = BilingualText("${formatEng(hM, 2)} m head = ${formatEng(pBar, 3)} bar (${formatEng(pPsi, 2)} psi)", "प्रेशर = ${formatEng(pBar, 3)} bar")
                )
            }
        }
    )

    private fun pressureAtDepth() = CalculatorDefinition(
        id = "pres_at_depth",
        serialNumber = 19,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Compress,
        title = BilingualText("Pressure at Depth (Liquid Column)", "गहराई पर प्रेशर (लिक्विड कॉलम)"),
        subtitle = BilingualText("Compute Total Absolute & Gauge Pressure at Submerged Depth", "द्रव के अंदर किसी गहराई पर कुल एब्सोल्यूट और गेज प्रेशर निकालें"),
        formulaPreview = "P_abs = P_surface + (ρ × g × h)",
        assumptions = BilingualText(
            "Default surface pressure = 1.01325 bar (1 atm) for open vessels/wells.",
            "मान्यता: खुले टैंक/समुद्र के लिए सतह प्रेशर 1.01325 bar (1 atm)।"
        ),
        keywords = listOf("pressure at depth", "submerged", "hydrostatic", "absolute"),
        fields = listOf(
            CalculatorField("depth", BilingualText("Submerged Depth (h)", "गहराई (h)"), "10", "m", listOf("m", "ft")),
            CalculatorField("sg", BilingualText("Fluid SG (Water = 1.0)", "द्रव SG (पानी=1.0)"), "1.0", "SG"),
            CalculatorField("p_surf", BilingualText("Surface Pressure", "सतह प्रेशर"), "1.01325", "bar abs")
        ),
        compute = { values, units ->
            runCatching {
                val rawD = requireNonNegative(values["depth"], BilingualText("Depth", "गहराई"))
                val sg = requirePositive(values["sg"], BilingualText("SG", "SG"))
                val pSurf = requireNonNegative(values["p_surf"], BilingualText("Surface Pressure", "सतह प्रेशर"))
                val dM = if (units["depth"] == "ft") rawD * 0.3048 else rawD
                val pGaugeBar = (sg * 1000.0 * 9.80665 * dM) / 1e5
                val pAbsBar = pSurf + pGaugeBar
                engOutput(
                    primaryLabel = BilingualText("Total Absolute Pressure", "कुल एब्सोल्यूट प्रेशर"),
                    primaryValue = formatEng(pAbsBar, 4),
                    primaryUnit = "bar abs",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Hydrostatic Gauge", "हाइड्रोस्टैटिक गेज"), formatEng(pGaugeBar, 4), "bar g"),
                        SecondaryMetric(BilingualText("Total PSI (abs)", "कुल PSI (abs)"), formatEng(pAbsBar * 14.50377, 2), "psia")
                    ),
                    formulaUsed = "P_abs = P_surf + ρ·g·h",
                    substitutedFormula = "P_abs = ${formatEng(pSurf, 4)} + ${formatEng(pGaugeBar, 4)}",
                    stepExplanation = BilingualText("Total = ${formatEng(pAbsBar, 4)} bar abs (Gauge ${formatEng(pGaugeBar, 4)} bar)", "कुल प्रेशर = ${formatEng(pAbsBar, 4)} bar abs")
                )
            }
        }
    )

    private fun gaugeToAbsolute() = CalculatorDefinition(
        id = "pres_gauge_abs",
        serialNumber = 20,
        category = CalculatorCategory.INST_PRESSURE,
        icon = Icons.Rounded.Speed,
        title = BilingualText("Gauge to Absolute Pressure Converter", "गेज से एब्सोल्यूट प्रेशर कन्वर्टर"),
        subtitle = BilingualText("Convert Between Gauge (barg/psig) & Absolute (bara/psia)", "गेज प्रेशर और एब्सोल्यूट प्रेशर के बीच सटीक रूपांतरण"),
        formulaPreview = "P_abs = P_gauge + P_atm   |   P_gauge = P_abs − P_atm",
        assumptions = BilingualText(
            "Standard sea-level atmospheric pressure P_atm = 1.01325 bar (14.696 psi).",
            "मान्यता: मानक वायुमंडलीय दाब P_atm = 1.01325 bar (14.696 psi)।"
        ),
        keywords = listOf("gauge to absolute", "psig", "psia", "barg", "bara", "vacuum"),
        fields = listOf(
            CalculatorField("mode", BilingualText("Conversion", "रूपांतरण"), "1", "Gauge → Absolute", listOf("Gauge → Absolute", "Absolute → Gauge"), isSelectorOnly = true),
            CalculatorField("press", BilingualText("Input Pressure", "प्रेशर मान"), "5.0", "bar", listOf("bar", "psi", "kPa"), allowNegative = true),
            CalculatorField("patm", BilingualText("Local Atmospheric P_atm (bar)", "वायुमंडलीय प्रेशर (bar)"), "1.01325", "bar")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requireFinite(values["press"], BilingualText("Pressure", "प्रेशर"))
                val pAtmBar = requireRange(values["patm"], 0.4, 1.2, BilingualText("Atmospheric Pressure", "वायुमंडलीय प्रेशर"))
                val u = units["press"] ?: "bar"
                val pBar = when (u) {
                    "psi" -> rawP * 0.06894757
                    "kPa" -> rawP * 0.01
                    else -> rawP
                }
                val isAbsToGauge = units["mode"] == "Absolute → Gauge"
                if (isAbsToGauge && pBar < 0.0) {
                    throw BilingualValidationException(BilingualText("Absolute pressure cannot be negative.", "एब्सोल्यूट प्रेशर नेगेटिव नहीं हो सकता।"))
                }
                val resBar = if (isAbsToGauge) pBar - pAtmBar else pBar + pAtmBar
                if (!isAbsToGauge && resBar < 0.0) {
                    throw BilingualValidationException(BilingualText("Vacuum gauge cannot go below -P_atm.", "वैक्यूम मान -P_atm से कम नहीं हो सकता।"))
                }
                val resInUnit = when (u) {
                    "psi" -> resBar * 14.50377
                    "kPa" -> resBar * 100.0
                    else -> resBar
                }
                val outSuffix = if (isAbsToGauge) "$u (g)" else "$u (abs)"
                engOutput(
                    primaryLabel = BilingualText(if (isAbsToGauge) "Gauge Pressure" else "Absolute Pressure", if (isAbsToGauge) "गेज प्रेशर" else "एब्सोल्यूट प्रेशर"),
                    primaryValue = formatEng(resInUnit, 4),
                    primaryUnit = outSuffix,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("In Bar", "Bar में"), formatEng(resBar, 4), if (isAbsToGauge) "barg" else "bara"),
                        SecondaryMetric(BilingualText("In PSI", "PSI में"), formatEng(resBar * 14.50377, 3), if (isAbsToGauge) "psig" else "psia")
                    ),
                    formulaUsed = if (isAbsToGauge) "P_gauge = P_abs − P_atm" else "P_abs = P_gauge + P_atm",
                    substitutedFormula = "${formatEng(resInUnit, 4)} $outSuffix",
                    stepExplanation = BilingualText("Result = ${formatEng(resInUnit, 4)} $outSuffix", "परिणाम = ${formatEng(resInUnit, 4)} $outSuffix")
                )
            }
        }
    )
}
