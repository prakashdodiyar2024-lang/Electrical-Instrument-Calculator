package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val DarkEngineeringColorScheme = darkColorScheme(
    primary = ActionRed,
    onPrimary = PureWhite,
    primaryContainer = SoftRedTint,
    onPrimaryContainer = ErrorRedDark,
    secondary = TextPrimaryDark,
    onSecondary = PureWhite,
    secondaryContainer = CleanSurfaceAlt,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = ClearRed,
    onTertiary = PureWhite,
    tertiaryContainer = CleanSurfaceAlt,
    onTertiaryContainer = TextPrimaryDark,
    background = PureWhite,
    onBackground = TextPrimaryDark,
    surface = PureWhite,
    onSurface = TextPrimaryDark,
    surfaceVariant = CleanSurfaceAlt,
    onSurfaceVariant = TextSecondaryDark,
    outline = LightGreyBorder,
    outlineVariant = HairlineGrey,
    error = ErrorRedDark,
    onError = PureWhite,
    errorContainer = SoftRedTint,
    onErrorContainer = ErrorRedDark
)

private val LightColorScheme = lightColorScheme(
    primary = ActionRed,
    onPrimary = PureWhite,
    primaryContainer = SoftRedTint,
    onPrimaryContainer = ErrorRedDark,
    secondary = TextPrimaryDark,
    onSecondary = PureWhite,
    secondaryContainer = CleanSurfaceAlt,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = ClearRed,
    onTertiary = PureWhite,
    tertiaryContainer = CleanSurfaceAlt,
    onTertiaryContainer = TextPrimaryDark,
    background = PureWhite,
    onBackground = TextPrimaryDark,
    surface = PureWhite,
    onSurface = TextPrimaryDark,
    surfaceVariant = CleanSurfaceAlt,
    onSurfaceVariant = TextSecondaryDark,
    outline = LightGreyBorder,
    outlineVariant = HairlineGrey,
    error = ErrorRedDark,
    onError = PureWhite,
    errorContainer = SoftRedTint,
    onErrorContainer = ErrorRedDark
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun EICalculatorTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkEngineeringColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
