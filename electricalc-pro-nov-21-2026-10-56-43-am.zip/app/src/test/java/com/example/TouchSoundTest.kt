package com.example

import android.content.Context
import android.media.AudioManager
import android.media.SoundPool
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.ui.audio.AndroidTouchSoundPlayer
import com.example.ui.audio.LocalTouchSoundPlayer
import com.example.ui.audio.TouchSoundDebounce
import com.example.ui.audio.TouchSoundPlayer
import com.example.ui.theme.EICalculatorTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TouchSoundTest {

    @get:Rule
    val composeRule = createComposeRule()

    private class RecordingTouchSoundPlayer : TouchSoundPlayer {
        var playCount: Int = 0
            private set

        override fun playClick() {
            playCount += 1
        }
    }

    @Test
    fun rawAudioResourceIsValidAndClearlyAudible() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val wavBytes = context.resources.openRawResource(R.raw.soft_touch_click).use { it.readBytes() }
        assertTrue("WAV file must exist with header + PCM payload", wavBytes.size > 44)

        val riffHeader = String(wavBytes.copyOfRange(0, 4), Charsets.US_ASCII)
        val waveHeader = String(wavBytes.copyOfRange(8, 12), Charsets.US_ASCII)
        assertEquals("RIFF", riffHeader)
        assertEquals("WAVE", waveHeader)

        val pcmBuffer = ByteBuffer.wrap(wavBytes, 44, wavBytes.size - 44)
            .order(ByteOrder.LITTLE_ENDIAN)
        var maxAbs = 0
        var sampleCount = 0
        while (pcmBuffer.remaining() >= 2) {
            val sample = kotlin.math.abs(pcmBuffer.short.toInt())
            if (sample > maxAbs) maxAbs = sample
            sampleCount += 1
        }

        val durationMs = (sampleCount * 1000.0) / 44100.0
        val peakRatio = maxAbs / 32767.0
        assertTrue("Click duration ($durationMs ms) should be >= 40 ms", durationMs >= 40.0)
        assertTrue("Peak amplitude ($peakRatio) should be >= 0.70 for clear audibility", peakRatio >= 0.70)
    }

    @Test
    fun soundPoolLoadsQueuesEarlyTapPlaysCleanlyAndPreventsOverlap() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var fakeClockMs = 1000L
        var capturedPool: SoundPool? = null

        val player = AndroidTouchSoundPlayer(
            context = context,
            clockMs = { fakeClockMs },
            soundPoolFactory = {
                SoundPool.Builder()
                    .setMaxStreams(1)
                    .build()
                    .also { capturedPool = it }
            }
        )

        try {
            val pool = requireNotNull(capturedPool)
            val shadowPool = Shadows.shadowOf(pool)
            assertNotEquals("SoundPool must return valid non-zero soundId", 0, player.soundId)
            assertFalse(shadowPool.wasResourcePlayed(R.raw.soft_touch_click))

            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT

            player.playClick()
            assertFalse(player.isSoundLoaded)
            assertEquals(0, player.playInvocations)

            shadowPool.notifyResourceLoaded(R.raw.soft_touch_click, true)
            assertTrue("SoundPool must mark isSoundLoaded = true after load completion", player.isSoundLoaded)
            assertTrue("SoundPool must play R.raw.soft_touch_click", shadowPool.wasResourcePlayed(R.raw.soft_touch_click))
            assertEquals("Queued early tap must play automatically when load finishes", 1, player.playInvocations)
            assertNotEquals(0, player.lastStreamId)

            fakeClockMs += 30L
            player.playClick()
            assertEquals(1, player.playInvocations)

            fakeClockMs += 60L
            player.playClick()
            assertEquals(2, player.playInvocations)
        } finally {
            player.release()
        }
    }

    @Test
    fun debouncePreventsOverlappingSoundsWithin85Ms() {
        assertTrue(TouchSoundDebounce.shouldPlay(nowElapsedMs = 1000L, lastPlayElapsedMs = 0L))
        assertFalse(TouchSoundDebounce.shouldPlay(nowElapsedMs = 1010L, lastPlayElapsedMs = 1000L))
        assertFalse(TouchSoundDebounce.shouldPlay(nowElapsedMs = 1084L, lastPlayElapsedMs = 1000L))
        assertTrue(TouchSoundDebounce.shouldPlay(nowElapsedMs = 1085L, lastPlayElapsedMs = 1000L))
    }

    @Test
    fun interactiveTapsPlaySoundWhileTypingAndScrollingDoNot() {
        val recorder = RecordingTouchSoundPlayer()
        composeRule.setContent {
            CompositionLocalProvider(LocalTouchSoundPlayer provides recorder) {
                EICalculatorTheme {
                    EICalculatorApp(showSplashInitially = false)
                }
            }
        }

        assertEquals(0, recorder.playCount)

        // 1. Tapping language toggle plays click sound
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        assertEquals(1, recorder.playCount)
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        assertEquals(2, recorder.playCount)

        // 2. Scrolling and typing in search box do NOT play sound
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("search_input"))
        assertEquals(2, recorder.playCount)
        composeRule.onNodeWithTag("search_input").performTextInput("Ohm")
        assertEquals(2, recorder.playCount)

        // 3. Tapping clear search button plays sound
        composeRule.onNodeWithTag("search_clear_button").performClick()
        assertEquals(3, recorder.playCount)

        // 4. Tapping category tab, then calculator card plays sound
        composeRule.onNodeWithTag("cat_tab_elec_basic").performClick()
        assertEquals(4, recorder.playCount)

        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_elec_ohms_law"))
        assertEquals(4, recorder.playCount)
        composeRule.onNodeWithTag("calc_card_elec_ohms_law").performClick()
        assertEquals(5, recorder.playCount)

        // 5. Typing inside input field does NOT play sound
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("input_field_val_a"))
        assertEquals(5, recorder.playCount)
        composeRule.onNodeWithTag("input_field_val_a").performTextInput("1")
        assertEquals(5, recorder.playCount)

        // 6. Tapping Calculate & Back navigation controls play sound
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("calculate_button"))
        composeRule.onNodeWithTag("calculate_button").performScrollTo().performClick()
        assertEquals(6, recorder.playCount)

        composeRule.onNodeWithTag("calculator_back_button").performClick()
        assertEquals(7, recorder.playCount)

        // 7. Bottom Nav About tab plays sound and displays Er. Prakash Dodiyar
        composeRule.onNodeWithTag("bottom_nav_about").performClick()
        assertEquals(8, recorder.playCount)
        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("developer_details_card"))
        composeRule.onNodeWithText("Er. Prakash Dodiyar").assertIsDisplayed()
        assertEquals(8, recorder.playCount)
    }
}
