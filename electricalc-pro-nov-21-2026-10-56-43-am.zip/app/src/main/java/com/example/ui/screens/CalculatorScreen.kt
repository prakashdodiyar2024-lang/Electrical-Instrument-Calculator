package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CalculationOutput
import com.example.model.CalculatorPreset
import com.example.model.StatusLevel
import com.example.ui.CalculatorScreenUiState
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.ClearRed
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.ErrorRedDark
import com.example.ui.theme.FavoriteGold
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.SoftBlueChip
import com.example.ui.theme.SoftRedBorder
import com.example.ui.theme.SoftRedTint
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalculatorScreen(
    uiState: CalculatorScreenUiState,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onFieldValueChange: (String, String) -> Unit,
    onToggleSign: (String) -> Unit,
    onFieldUnitChange: (String, String) -> Unit,
    onApplyPreset: (CalculatorPreset) -> Unit,
    onCalculate: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val calc = uiState.activeCalculator ?: return
    val lang = uiState.language
    val isFavorite = calc.id in uiState.favoriteIds
    val keyboardController = LocalSoftwareKeyboardController.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var scrollToOutcomeOnNextResult by remember { mutableStateOf(false) }
    val playClick = rememberTouchClickSound()

    LaunchedEffect(uiState.result, uiState.errorText, scrollToOutcomeOnNextResult) {
        if (scrollToOutcomeOnNextResult && (uiState.result != null || uiState.errorText != null)) {
            scrollToOutcomeOnNextResult = false
            val outcomeIndex = if (calc.presets.isNotEmpty()) 2 else 1
            listState.animateScrollToItem(outcomeIndex)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = PureWhite,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = calc.title.get(lang),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${calc.category.discipline.title.get(lang)} • ${calc.category.shortTitle.get(lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite.copy(alpha = 0.88f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                playClick()
                                onBack()
                            },
                            modifier = Modifier.testTag("calculator_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = if (lang == AppLanguage.ENGLISH) "Back" else "वापस",
                                tint = PureWhite
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                playClick()
                                onToggleFavorite(calc.id)
                            },
                            modifier = Modifier.testTag("calculator_favorite_button")
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                                contentDescription = if (isFavorite) "Remove favorite" else "Add favorite",
                                tint = if (isFavorite) FavoriteGold else PureWhite
                            )
                        }
                        LanguageToggleChip(
                            language = lang,
                            onToggle = onToggleLanguage,
                            darkSurface = true,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = RoyalBlue)
                )
                HorizontalDivider(color = DarkNavyBlue)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(PureWhite)
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 820.dp)
                    .align(Alignment.TopCenter)
                    .testTag("calculator_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Quick Examples (Presets) if available
                if (calc.presets.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) {
                                    "Quick Examples (Tap to fill)"
                                } else {
                                    "त्वरित उदाहरण (टेस्ट करने के लिए दबाएं)"
                                },
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = DarkNavyBlue
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(calc.presets) { preset ->
                                    Surface(
                                        onClick = {
                                            playClick()
                                            keyboardController?.hide()
                                            scrollToOutcomeOnNextResult = true
                                            onApplyPreset(preset)
                                        },
                                        shape = RoundedCornerShape(50),
                                        color = SoftBlueChip,
                                        border = BorderStroke(1.dp, LightBlueBorder),
                                        modifier = Modifier.testTag("preset_chip_${preset.label.en}")
                                    ) {
                                        Text(
                                            text = preset.label.get(lang),
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.SemiBold
                                            ),
                                            color = DarkNavyBlue,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Input Parameters Card
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = BorderStroke(1.dp, LightBlueBorder),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(RoyalBlueTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Tune,
                                        contentDescription = null,
                                        tint = RoyalBlue,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) "Input Parameters" else "इनपुट मान दर्ज करें",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = DarkNavyBlue
                                )
                            }

                            HorizontalDivider(color = HairlineGrey)

                            calc.fields.forEachIndexed { index, field ->
                                val currentValue = uiState.inputValues[field.id] ?: ""
                                val currentUnit = uiState.inputUnits[field.id] ?: field.defaultUnit
                                val isLast = index == calc.fields.lastIndex
                                val isModeOnlyField = field.isSelectorOnly

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (!isModeOnlyField) {
                                        OutlinedTextField(
                                            value = currentValue,
                                            onValueChange = { onFieldValueChange(field.id, it) },
                                            label = {
                                                Text(
                                                    text = field.label.get(lang),
                                                    color = TextSecondaryDark
                                                )
                                            },
                                            trailingIcon = if (field.allowNegative) {
                                                {
                                                    Surface(
                                                        onClick = {
                                                            playClick()
                                                            onToggleSign(field.id)
                                                        },
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = SoftBlueChip,
                                                        border = BorderStroke(1.dp, LightBlueBorder),
                                                        modifier = Modifier
                                                            .padding(end = 6.dp)
                                                            .testTag("sign_toggle_${field.id}")
                                                    ) {
                                                        Text(
                                                            text = "±",
                                                            style = MaterialTheme.typography.titleMedium.copy(
                                                                fontFamily = JetBrainsMonoFontFamily,
                                                                fontWeight = FontWeight.Bold
                                                            ),
                                                            color = DarkNavyBlue,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }
                                            } else null,
                                            suffix = {
                                                Text(
                                                    text = currentUnit,
                                                    style = MaterialTheme.typography.labelLarge.copy(
                                                        fontFamily = JetBrainsMonoFontFamily,
                                                        fontWeight = FontWeight.Bold
                                                    ),
                                                    color = RoyalBlue
                                                )
                                            },
                                            supportingText = field.helperText?.let { helper ->
                                                {
                                                    Text(
                                                        text = helper.get(lang),
                                                        color = TextSecondaryDark
                                                    )
                                                }
                                            },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Decimal,
                                                imeAction = if (isLast) ImeAction.Done else ImeAction.Next
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = {
                                                    keyboardController?.hide()
                                                    scrollToOutcomeOnNextResult = true
                                                    onCalculate()
                                                }
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedContainerColor = PureWhite,
                                                unfocusedContainerColor = CardLightGrey,
                                                focusedTextColor = TextPrimaryDark,
                                                unfocusedTextColor = TextPrimaryDark,
                                                focusedBorderColor = RoyalBlue,
                                                unfocusedBorderColor = LightBlueBorder,
                                                focusedLabelColor = RoyalBlue,
                                                unfocusedLabelColor = TextSecondaryDark,
                                                cursorColor = RoyalBlue
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_field_${field.id}")
                                        )
                                    } else {
                                        Text(
                                            text = field.label.get(lang),
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                            color = DarkNavyBlue
                                        )
                                    }

                                    if (field.unitOptions.size > 1) {
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            field.unitOptions.forEach { unitOpt ->
                                                val selected = currentUnit == unitOpt
                                                FilterChip(
                                                    selected = selected,
                                                    onClick = {
                                                        playClick()
                                                        onFieldUnitChange(field.id, unitOpt)
                                                    },
                                                    label = {
                                                        Text(
                                                            text = unitOpt,
                                                            style = MaterialTheme.typography.labelMedium.copy(
                                                                fontFamily = JetBrainsMonoFontFamily,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                        )
                                                    },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        containerColor = CardLightGrey,
                                                        labelColor = TextPrimaryDark,
                                                        selectedContainerColor = RoyalBlue,
                                                        selectedLabelColor = PureWhite
                                                    ),
                                                    border = FilterChipDefaults.filterChipBorder(
                                                        enabled = true,
                                                        selected = selected,
                                                        borderColor = LightBlueBorder,
                                                        selectedBorderColor = RoyalBlue,
                                                        borderWidth = 1.dp,
                                                        selectedBorderWidth = 1.dp
                                                    ),
                                                    modifier = Modifier.testTag("unit_chip_${field.id}_$unitOpt")
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Engineering Assumptions Hint (keeps assumptions clear without showing formulas)
                            val assumptionText = calc.assumptions ?: uiState.result?.assumptions
                            if (assumptionText != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = SoftBlueChip,
                                    border = BorderStroke(1.dp, LightBlueBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("assumptions_note")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.Top,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Info,
                                            contentDescription = null,
                                            tint = RoyalBlue,
                                            modifier = Modifier
                                                .padding(top = 1.dp)
                                                .size(16.dp)
                                        )
                                        Text(
                                            text = assumptionText.get(lang),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = DarkNavyBlue
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            // Clear (Red) & Calculate (Royal Blue) Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        playClick()
                                        keyboardController?.hide()
                                        onReset()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ClearRed,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(0.38f)
                                        .heightIn(min = 50.dp)
                                        .testTag("reset_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = null,
                                        tint = PureWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) "Clear" else "साफ़ करें",
                                        color = PureWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = {
                                        playClick()
                                        keyboardController?.hide()
                                        scrollToOutcomeOnNextResult = true
                                        onCalculate()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = RoyalBlue,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(0.62f)
                                        .heightIn(min = 50.dp)
                                        .testTag("calculate_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Calculate,
                                        contentDescription = null,
                                        tint = PureWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) "Calculate" else "गणना करें",
                                        color = PureWhite,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }

                // Error Message Banner
                if (uiState.errorText != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SoftRedTint,
                            border = BorderStroke(1.dp, SoftRedBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("error_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Warning,
                                    contentDescription = null,
                                    tint = ErrorRedDark
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = uiState.errorText.get(lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErrorRedDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // Clean Result Card ONLY (formulas remain internal to calculation logic)
                val currentOutput = uiState.result
                if (currentOutput != null) {
                    item(key = "result_card_item") {
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn() + expandVertically()
                        ) {
                            PrimaryResultCard(
                                output = currentOutput,
                                language = lang,
                                onCopyResult = {
                                    playClick()
                                    val summary = "${currentOutput.primaryLabel.get(lang)}: ${currentOutput.primaryValue} ${currentOutput.primaryUnit}"
                                    clipboard.setText(AnnotatedString(summary))
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (lang == AppLanguage.ENGLISH) "Result copied to clipboard"
                                            else "परिणाम कॉपी हो गया"
                                        )
                                    }
                                }
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PrimaryResultCard(
    output: CalculationOutput,
    language: AppLanguage,
    onCopyResult: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
        border = BorderStroke(1.5.dp, LightBlueBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("result_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = RoyalBlueTint,
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (output.statusLevel == StatusLevel.WARNING) {
                                Icons.Rounded.Warning
                            } else {
                                Icons.Rounded.CheckCircle
                            },
                            contentDescription = null,
                            tint = if (output.statusLevel == StatusLevel.WARNING) ErrorRedDark else RoyalBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (language == AppLanguage.ENGLISH) "RESULT" else "परिणाम",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.6.sp
                            ),
                            color = DarkNavyBlue
                        )
                    }
                }

                IconButton(
                    onClick = onCopyResult,
                    modifier = Modifier.testTag("copy_result_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = if (language == AppLanguage.ENGLISH) "Copy Result" else "परिणाम कॉपी करें",
                        tint = RoyalBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = output.primaryLabel.get(language),
                style = MaterialTheme.typography.titleSmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = output.primaryValue,
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp
                    ),
                    color = DarkNavyBlue,
                    modifier = Modifier.testTag("primary_result_value")
                )
                val unitDisplay = output.primaryUnitLocalized?.get(language) ?: output.primaryUnit
                if (unitDisplay.isNotBlank()) {
                    Text(
                        text = unitDisplay,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = RoyalBlue,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
            }

            if (output.secondaryMetrics.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = HairlineGrey)
                Spacer(modifier = Modifier.height(12.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    output.secondaryMetrics.forEach { metric ->
                        val metricVal = metric.localizedValue?.get(language) ?: metric.value
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PureWhite,
                            border = BorderStroke(1.dp, LightBlueBorder)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(
                                    text = metric.label.get(language),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondaryDark
                                )
                                Text(
                                    text = "$metricVal ${metric.unit}".trim(),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = TextPrimaryDark
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
