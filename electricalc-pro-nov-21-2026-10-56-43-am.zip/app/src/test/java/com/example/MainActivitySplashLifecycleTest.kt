package com.example

import android.content.Intent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ActivityScenario
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MainActivitySplashLifecycleTest {

    @get:Rule
    val composeRule = createEmptyComposeRule()

    @Test(timeout = 30_000)
    fun freshLaunchAndNonConfigRecreateShow5SecondSplash() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            composeRule.mainClock.autoAdvance = false
            try {
                // 1. Fresh launch shows 5-second Splash Screen
                composeRule.mainClock.advanceTimeByFrame()
                composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
                composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()
                composeRule.onNodeWithText("Electrical & Instrument Calculator").assertIsDisplayed()

                composeRule.mainClock.advanceTimeBy(4800L)
                composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()

                composeRule.mainClock.advanceTimeBy(1000L)
                composeRule.onNodeWithTag("home_list").assertIsDisplayed()
                composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()

                // 2. Non-configuration Activity recreate (simulating Reload app / state-preserving restart)
                scenario.recreate()
                composeRule.mainClock.advanceTimeByFrame()
                composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
                composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()

                composeRule.mainClock.advanceTimeBy(4800L)
                composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()

                composeRule.mainClock.advanceTimeBy(1000L)
                composeRule.onNodeWithTag("home_list").assertIsDisplayed()
                composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()
            } finally {
                composeRule.mainClock.autoAdvance = true
            }
        }
    }

    @Test(timeout = 30_000)
    fun relaunchIntentWhileOnHomeShows5SecondSplash() {
        composeRule.mainClock.autoAdvance = false
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        try {
            // Reach Home Screen after initial 5-second splash
            composeRule.mainClock.advanceTimeByFrame()
            composeRule.mainClock.advanceTimeBy(5800L)
            composeRule.onNodeWithTag("home_list").assertIsDisplayed()
            composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()

            // Simulate Reload / relaunch intent delivered to singleTask MainActivity
            controller.newIntent(Intent(Intent.ACTION_MAIN))
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
            composeRule.mainClock.advanceTimeByFrame()
            composeRule.mainClock.advanceTimeBy(700L)
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
            composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()

            composeRule.mainClock.advanceTimeBy(4100L)
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()

            composeRule.mainClock.advanceTimeBy(1000L)
            composeRule.onNodeWithTag("home_list").assertIsDisplayed()
            composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()
        } finally {
            composeRule.mainClock.autoAdvance = true
            controller.pause().stop().destroy()
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        }
    }

    @Test(timeout = 30_000)
    fun launcherSplashActivityShows5SecondsThenStartsMainActivityOnce() {
        composeRule.mainClock.autoAdvance = false
        val controller = org.robolectric.Robolectric.buildActivity(SplashActivity::class.java).setup()
        try {
            val activity = controller.get()
            val shadow = org.robolectric.Shadows.shadowOf(activity)

            composeRule.mainClock.advanceTimeByFrame()
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
            composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()
            composeRule.onNodeWithText("Electrical & Instrument Calculator").assertIsDisplayed()
            composeRule.onNodeWithText("100 Professional Engineering Tools").assertIsDisplayed()

            // Must still remain on SplashScreen before 5000ms elapses
            composeRule.mainClock.advanceTimeBy(4800L)
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
            org.junit.Assert.assertNull(shadow.peekNextStartedActivity())

            // After 5000ms elapses, navigates once to MainActivity and finishes SplashActivity
            composeRule.mainClock.advanceTimeBy(400L)
            val nextIntent = shadow.nextStartedActivity
            org.junit.Assert.assertNotNull(nextIntent)
            org.junit.Assert.assertEquals(MainActivity::class.java.name, nextIntent.component?.className)
            org.junit.Assert.assertTrue(nextIntent.getBooleanExtra(MainActivity.EXTRA_SKIP_SPLASH, false))
            org.junit.Assert.assertNull(shadow.nextStartedActivity)
            org.junit.Assert.assertTrue(activity.isFinishing)
        } finally {
            composeRule.mainClock.autoAdvance = true
            controller.pause().stop().destroy()
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        }
    }

    @Test(timeout = 30_000)
    fun splashActivityReloadIntentMidSplashRestartsFull5Seconds() {
        composeRule.mainClock.autoAdvance = false
        val controller = org.robolectric.Robolectric.buildActivity(SplashActivity::class.java).setup()
        try {
            val activity = controller.get()
            val shadow = org.robolectric.Shadows.shadowOf(activity)

            composeRule.mainClock.advanceTimeByFrame()
            composeRule.mainClock.advanceTimeBy(3000L)
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
            org.junit.Assert.assertNull(shadow.peekNextStartedActivity())

            // Simulate reload intent arriving while SplashActivity is still running
            controller.newIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
            composeRule.waitForIdle()

            // Must stay on splash for a fresh 5000ms (still visible at +3000ms after reload)
            composeRule.mainClock.advanceTimeBy(3000L)
            composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
            org.junit.Assert.assertNull(shadow.peekNextStartedActivity())

            // Finishes and navigates to MainActivity after remaining 2000ms elapses
            composeRule.mainClock.advanceTimeBy(2200L)
            val nextIntent = shadow.nextStartedActivity
            org.junit.Assert.assertNotNull(nextIntent)
            org.junit.Assert.assertEquals(MainActivity::class.java.name, nextIntent.component?.className)
            org.junit.Assert.assertTrue(activity.isFinishing)
        } finally {
            composeRule.mainClock.autoAdvance = true
            controller.pause().stop().destroy()
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        }
    }

    @Test(timeout = 30_000)
    fun mainActivityWithSkipSplashExtraOpensHomeWithoutDoubleSplash() {
        val intent = Intent(
            androidx.test.core.app.ApplicationProvider.getApplicationContext(),
            MainActivity::class.java
        ).apply {
            putExtra(MainActivity.EXTRA_SKIP_SPLASH, true)
        }
        ActivityScenario.launch<MainActivity>(intent).use {
            composeRule.onNodeWithTag("home_list").assertIsDisplayed()
            composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()
        }
    }
}
