package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onLast
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import com.example.domain.CalculatorRegistry
import com.example.model.CalculatorCategory
import com.example.ui.theme.EICalculatorTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CalculatorUiAndViewModelTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun homeCountersLanguageToggleAndDisciplineSwitchingWork() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Counters show 50 Electrical, 50 Instrumentation, 100 Combined
        composeRule.onNodeWithTag("counter_electrical").assertIsDisplayed()
        composeRule.onNodeWithTag("counter_instrumentation").assertIsDisplayed()
        composeRule.onNodeWithTag("counter_total").assertIsDisplayed()

        // Toggle Hindi & back to English
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("इलेक्ट्रिकल").assertIsDisplayed()
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.onNodeWithText("Electrical").assertIsDisplayed()

        // Switch to Instrumentation Calculator -> Signal tab & tools appear
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("discipline_instrumentation"))
        composeRule.onNodeWithTag("discipline_instrumentation").performClick()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("category_tabs_row"))
        composeRule.onNodeWithTag("cat_tab_inst_signal").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_sig_ma_to_pv"))
        composeRule.onNodeWithTag("calc_card_sig_ma_to_pv").assertIsDisplayed()

        // Switch back to Electrical Calculator
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("discipline_electrical"))
        composeRule.onNodeWithTag("discipline_electrical").performClick()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("category_tabs_row"))
        composeRule.onNodeWithTag("cat_tab_elec_basic").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun openCalculatorComputeValidateResetAndHideFormulaSection() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Search and open 4-20 mA to PV calculator
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("search_input"))
        composeRule.onNodeWithTag("search_input").performTextInput("4–20 mA to Process Value")
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_sig_ma_to_pv"))
        composeRule.onNodeWithTag("calc_card_sig_ma_to_pv").performClick()

        // Verify engineering assumptions note is visible & result card renders cleanly
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("assumptions_note"))
        composeRule.onNodeWithTag("assumptions_note").assertIsDisplayed()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
        composeRule.onNodeWithTag("primary_result_value").performScrollTo().assertIsDisplayed()

        // Clear mA field and tap Calculate -> expect error banner
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("input_field_ma"))
        composeRule.onNodeWithTag("input_field_ma").performScrollTo().performTextClearance()
        composeRule.onNodeWithTag("calculate_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("error_banner"))
        composeRule.onNodeWithTag("error_banner").assertIsDisplayed()

        // Clear resets defaults, Calculate shows result ONLY with NO formula section below results
        composeRule.onNodeWithTag("reset_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("calculate_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
        composeRule.onNodeWithTag("result_card").assertIsDisplayed()

        composeRule.onNodeWithTag("steps_card").assertDoesNotExist()
        composeRule.onNodeWithTag("substituted_formula_box").assertDoesNotExist()
        composeRule.onNodeWithTag("see_formula_button").assertDoesNotExist()
        composeRule.onNodeWithTag("formula_dialog").assertDoesNotExist()
    }

    @Test
    fun all10CategoriesShowAll100CalculatorsAndComputeCleanly() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        CalculatorCategory.entries.forEach { cat ->
            composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("discipline_${cat.discipline.id}"))
            composeRule.onNodeWithTag("discipline_${cat.discipline.id}").performClick()

            composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("category_tabs_row"))
            composeRule.onNodeWithTag("cat_tab_${cat.id}").performScrollTo().performClick()
            CalculatorRegistry.getByCategory(cat).forEach { calc ->
                composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("calc_card_${calc.id}"))
                composeRule.onNodeWithTag("calc_card_${calc.id}").performClick()

                composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("calculate_button"))
                composeRule.onNodeWithTag("calculate_button").performScrollTo().performClick()
                composeRule.onNodeWithTag("calculator_list").performScrollToNode(hasTestTag("result_card"))
                composeRule.onNodeWithTag("primary_result_value").performScrollTo().assertIsDisplayed()

                composeRule.onNodeWithTag("calculator_back_button").performClick()
            }
        }
    }

    @Test
    fun bottomNavigationTabsFavoritesAboutAndSettingsWork() {
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp(showSplashInitially = false)
            }
        }

        // Favorite Ohm's Law calculator from Home
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("fav_toggle_elec_ohms_law"))
        composeRule.onNodeWithTag("fav_toggle_elec_ohms_law").performClick()

        // Navigate to Favorite tab -> Ohm's Law appears
        composeRule.onNodeWithTag("bottom_nav_favorite").performClick()
        composeRule.onNodeWithTag("favorite_list").performScrollToNode(hasTestTag("calc_card_elec_ohms_law"))
        composeRule.onNodeWithTag("calc_card_elec_ohms_law").assertIsDisplayed()

        // Navigate to About tab -> Developer Er. Prakash Dodiyar & YouTube link shown
        composeRule.onNodeWithTag("bottom_nav_about").performClick()
        composeRule.onNodeWithTag("about_brand_logo").assertIsDisplayed()
        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("developer_details_card"))
        composeRule.onNodeWithText("Er. Prakash Dodiyar").assertIsDisplayed()
        composeRule.onNodeWithTag("about_list").performScrollToNode(hasTestTag("youtube_card"))
        composeRule.onNodeWithText("https://youtube.com/@Electricalandinstrument").assertIsDisplayed()

        // Navigate to Settings tab -> Language & Touch Sound controls work
        composeRule.onNodeWithTag("bottom_nav_settings").performClick()
        composeRule.onNodeWithTag("settings_list").performScrollToNode(hasTestTag("settings_touch_sound_switch"))
        composeRule.onNodeWithTag("settings_touch_sound_switch").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_lang_hi").performClick()
        composeRule.onNodeWithText("सेटिंग्स").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_lang_en").performClick()
        composeRule.onAllNodesWithText("Settings").onFirst().assertIsDisplayed()

        // Navigate back to Home tab
        composeRule.onNodeWithTag("bottom_nav_home").performClick()
        composeRule.onNodeWithTag("home_list").assertIsDisplayed()
    }

    @Test
    fun splashScreenDisplaysLogoAndTransitionsToHome() {
        composeRule.mainClock.autoAdvance = false
        composeRule.setContent {
            EICalculatorTheme {
                EICalculatorApp()
            }
        }

        composeRule.mainClock.advanceTimeByFrame()
        composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("splash_logo").assertIsDisplayed()
        composeRule.onNodeWithText("Electrical & Instrument Calculator").assertIsDisplayed()
        composeRule.onNodeWithText("100 Professional Engineering Tools").assertIsDisplayed()

        composeRule.mainClock.advanceTimeBy(4800L)
        composeRule.onNodeWithTag("splash_screen").assertIsDisplayed()

        composeRule.mainClock.advanceTimeBy(400L)
        composeRule.mainClock.autoAdvance = true
        composeRule.onNodeWithTag("home_list").assertIsDisplayed()
        composeRule.onNodeWithTag("home_brand_logo").assertIsDisplayed()
        composeRule.onNodeWithTag("splash_screen").assertDoesNotExist()
    }
}
