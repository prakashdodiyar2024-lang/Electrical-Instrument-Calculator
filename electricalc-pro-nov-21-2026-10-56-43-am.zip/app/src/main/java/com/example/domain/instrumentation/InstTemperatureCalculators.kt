package com.example.domain.instrumentation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Tune
import com.example.domain.engOutput
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireFinite
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

object InstTemperatureCalculators {

    // IEC 60751 Pt100 Callendar-Van Dusen constants (α = 0.00385)
    private const val RTD_A = 3.9083e-3
    private const val RTD_B = -5.775e-7
    private const val RTD_C = -4.183e-12

    // Type-K NIST ITS-90 polynomial coefficients (T in °C -> mV)
    private val TC_K_POS = doubleArrayOf(
        -0.17600413686e-1, 0.38921204975e-1, 0.18558770032e-4, -0.99457592874e-7,
        0.31840945719e-9, -0.56072844889e-12, 0.56075059059e-15, -0.32020720003e-18,
        0.97151147152e-22, -0.12104721275e-25
    )
    private val TC_K_NEG = doubleArrayOf(
        0.0, 0.39450128025e-1, 0.23622373598e-4, -0.32858906784e-6,
        -0.49904828777e-8, -0.67509059173e-10, -0.57410327428e-12, -0.31088872894e-14,
        -0.10451609365e-16, -0.19889266878e-19, -0.16322697486e-22
    )

    internal fun ptResistance(tempC: Double, r0: Double): Double = if (tempC >= 0.0) {
        r0 * (1.0 + RTD_A * tempC + RTD_B * tempC * tempC)
    } else {
        r0 * (1.0 + RTD_A * tempC + RTD_B * tempC * tempC + RTD_C * (tempC - 100.0) * tempC.pow(3))
    }

    internal fun ptTemperature(resOhm: Double, r0: Double): Double {
        val ratio = resOhm / r0
        return if (ratio >= 1.0) {
            val disc = RTD_A * RTD_A - 4.0 * RTD_B * (1.0 - ratio)
            (-RTD_A + sqrt(disc.coerceAtLeast(0.0))) / (2.0 * RTD_B)
        } else {
            var t = (ratio - 1.0) / 0.00385
            repeat(12) {
                val f = ptResistance(t, r0) - resOhm
                val df = r0 * (RTD_A + 2.0 * RTD_B * t + RTD_C * (4.0 * t.pow(3) - 300.0 * t * t))
                t -= f / df
            }
            t
        }
    }

    internal fun typeKTempToMv(t: Double): Double {
        return if (t >= 0.0) {
            var sum = 0.0
            var powT = 1.0
            for (c in TC_K_POS) {
                sum += c * powT
                powT *= t
            }
            sum + 0.1185976 * kotlin.math.exp(-0.1183432e-3 * (t - 126.9686).pow(2))
        } else {
            var sum = 0.0
            var powT = 1.0
            for (c in TC_K_NEG) {
                sum += c * powT
                powT *= t
            }
            sum
        }
    }

    internal fun typeKMvToTemp(mv: Double): Double {
        var lo = -200.0
        var hi = 1372.0
        repeat(60) {
            val mid = 0.5 * (lo + hi)
            if (typeKTempToMv(mid) < mv) lo = mid else hi = mid
        }
        return 0.5 * (lo + hi)
    }

    val all: List<CalculatorDefinition> = listOf(
        rtdPt100Resistance(),   // 41
        resToTempPt100(),       // 42
        tcTypeKMvToC(),         // 43
        tcTypeKCToMv(),         // 44
        tempUnitConverter(),    // 45
        tempTxRange(),          // 46
        thermalExpansion(),     // 47
        heatTransferQ(),        // 48
        tempDifferenceDt(),     // 49
        tempAveraging()         // 50
    )

    private fun rtdPt100Resistance() = CalculatorDefinition(
        id = "temp_rtd_res",
        serialNumber = 41,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.DeviceThermostat,
        title = BilingualText("RTD (PT100) Resistance Calculator", "RTD (PT100) रेजिस्टेंस कैलकुलेटर"),
        subtitle = BilingualText("Calculate Pt100 / Pt1000 Resistance (Ω) from Temperature (°C)", "तापमान (°C) से Pt100 / Pt1000 का सटीक रेजिस्टेंस (Ω) निकालें"),
        formulaPreview = "R(T) = R₀ × (1 + A·T + B·T² [+ C·(T−100)·T³])",
        assumptions = BilingualText(
            "Uses IEC 60751 Alpha = 0.00385 curve across -200 °C to +850 °C.",
            "मान्यता: IEC 60751 मानक (α = 0.00385, -200 से +850 °C)।"
        ),
        keywords = listOf("pt100", "pt1000", "rtd", "resistance", "iec 60751"),
        fields = listOf(
            CalculatorField("sensor", BilingualText("RTD Type", "RTD प्रकार"), "1", "Pt100 (100 Ω)", listOf("Pt100 (100 Ω)", "Pt1000 (1000 Ω)"), isSelectorOnly = true),
            CalculatorField("temp_c", BilingualText("Temperature (°C)", "तापमान (°C)"), "100", "°C", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val r0 = if (units["sensor"] == "Pt1000 (1000 Ω)") 1000.0 else 100.0
                val t = requireRange(values["temp_c"], -200.0, 850.0, BilingualText("Temperature", "तापमान"))
                val r = ptResistance(t, r0)
                val sens = (ptResistance(t + 1.0, r0) - r)
                engOutput(
                    primaryLabel = BilingualText("RTD Resistance (Ω)", "RTD रेजिस्टेंस (Ω)"),
                    primaryValue = formatEng(r, 2),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Temp (°F)", "तापमान (°F)"), formatEng(t * 9.0 / 5.0 + 32.0, 1), "°F"),
                        SecondaryMetric(BilingualText("Sensitivity", "संवेदनशीलता"), formatEng(sens, 3), "Ω/°C")
                    ),
                    formulaUsed = "IEC 60751 Callendar-Van Dusen",
                    substitutedFormula = "T = ${formatEng(t, 1)} °C → R = ${formatEng(r, 2)} Ω",
                    stepExplanation = BilingualText("At ${formatEng(t, 1)} °C, RTD = ${formatEng(r, 2)} Ω", "रेजिस्टेंस = ${formatEng(r, 2)} Ω")
                )
            }
        }
    )

    private fun resToTempPt100() = CalculatorDefinition(
        id = "temp_res_to_temp",
        serialNumber = 42,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.Thermostat,
        title = BilingualText("Resistance to Temperature (PT100)", "रेजिस्टेंस से तापमान (PT100)"),
        subtitle = BilingualText("Convert Measured Pt100 / Pt1000 Ohms to °C, °F & Kelvin", "मापे गए Pt100 / Pt1000 ओम (Ω) से तापमान (°C) निकालें"),
        formulaPreview = "T = (−A + √(A² − 4B(1 − R/R₀))) / (2B)",
        assumptions = BilingualText(
            "Valid for 3/4-wire compensated measurement (IEC 60751 α = 0.00385).",
            "मान्यता: 3-वायर/4-वायर मुआवजा सहित मापा गया शुद्ध रेजिस्टेंस।"
        ),
        keywords = listOf("resistance to temp", "pt100 ohm to c", "rtd lookup"),
        fields = listOf(
            CalculatorField("sensor", BilingualText("RTD Type", "RTD प्रकार"), "1", "Pt100 (100 Ω)", listOf("Pt100 (100 Ω)", "Pt1000 (1000 Ω)"), isSelectorOnly = true),
            CalculatorField("res", BilingualText("Measured Resistance (Ω)", "मापा गया रेजिस्टेंस (Ω)"), "138.51", "Ω")
        ),
        compute = { values, units ->
            runCatching {
                val isPt1000 = units["sensor"] == "Pt1000 (1000 Ω)"
                val r0 = if (isPt1000) 1000.0 else 100.0
                val minR = ptResistance(-200.0, r0)
                val maxR = ptResistance(850.0, r0)
                val r = requireRange(values["res"], minR, maxR, BilingualText("Resistance", "रेजिस्टेंस"))
                val tC = ptTemperature(r, r0)
                val tF = tC * 9.0 / 5.0 + 32.0
                val tK = tC + 273.15
                engOutput(
                    primaryLabel = BilingualText("Measured Temperature", "मापा गया तापमान"),
                    primaryValue = formatEng(tC, 2),
                    primaryUnit = "°C",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Fahrenheit", "फ़ारेनहाइट"), formatEng(tF, 2), "°F"),
                        SecondaryMetric(BilingualText("Kelvin", "केल्विन"), formatEng(tK, 2), "K")
                    ),
                    formulaUsed = "Inverse IEC 60751 Callendar-Van Dusen",
                    substitutedFormula = "R = ${formatEng(r, 2)} Ω (R₀=${formatEng(r0, 0)} Ω) → ${formatEng(tC, 2)} °C",
                    stepExplanation = BilingualText("${formatEng(r, 2)} Ω = ${formatEng(tC, 2)} °C (${formatEng(tF, 1)} °F)", "तापमान = ${formatEng(tC, 2)} °C")
                )
            }
        }
    )

    private fun tcTypeKMvToC() = CalculatorDefinition(
        id = "temp_tc_k_mv_to_c",
        serialNumber = 43,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.Sensors,
        title = BilingualText("Thermocouple (Type K) mV to °C", "थर्मोकपल (Type K) mV से °C"),
        subtitle = BilingualText("Convert Type-K Millivolts to °C with Cold Junction (CJC)", "CJC सहित Type-K थर्मोकपल mV रीडिंग से तापमान (°C) निकालें"),
        formulaPreview = "E_total(T) = E_measured + E_TypeK(T_cjc)  →  NIST ITS-90",
        assumptions = BilingualText(
            "NIST ITS-90 Type-K (Chromel-Alumel, -200 to +1372 °C); set CJC = 0 °C if ice-point referenced.",
            "मान्यता: NIST ITS-90 Type-K तालिका; आइस-पॉइंट हेतु CJC = 0 °C रखें।"
        ),
        keywords = listOf("thermocouple", "type k", "mv to c", "cjc", "nist"),
        fields = listOf(
            CalculatorField("mv", BilingualText("Measured Voltage (mV)", "मापा गया वोल्टेज (mV)"), "11.209", "mV", allowNegative = true),
            CalculatorField("cjc", BilingualText("Cold Junction Temp (CJC)", "कोल्ड जंक्शन तापमान (CJC)"), "25", "°C", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val mvMeas = requireFinite(values["mv"], BilingualText("Measured mV", "मापा गया mV"))
                val cjc = requireRange(values["cjc"], -50.0, 100.0, BilingualText("CJC Temp", "CJC तापमान"))
                val mvCjc = typeKTempToMv(cjc)
                val mvTotal = mvMeas + mvCjc
                val minMv = typeKTempToMv(-200.0)
                val maxMv = typeKTempToMv(1372.0)
                if (mvTotal < minMv || mvTotal > maxMv) {
                    throw BilingualValidationException(BilingualText("Total mV (${formatEng(mvTotal, 3)} mV) is outside Type-K range (-200 to +1372 °C).", "कुल mV Type-K रेंज से बाहर है।"))
                }
                val tC = typeKMvToTemp(mvTotal)
                val tF = tC * 9.0 / 5.0 + 32.0
                engOutput(
                    primaryLabel = BilingualText("Type-K Junction Temperature", "Type-K तापमान"),
                    primaryValue = formatEng(tC, 2),
                    primaryUnit = "°C",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Temp (°F)", "तापमान (°F)"), formatEng(tF, 1), "°F"),
                        SecondaryMetric(BilingualText("CJC Offset", "CJC मान"), formatEng(mvCjc, 3), "mV"),
                        SecondaryMetric(BilingualText("0°C Total mV", "कुल mV"), formatEng(mvTotal, 3), "mV")
                    ),
                    formulaUsed = "E_0°C = E_meas + E(T_cjc)",
                    substitutedFormula = "${formatEng(mvMeas, 3)} + ${formatEng(mvCjc, 3)} = ${formatEng(mvTotal, 3)} mV",
                    stepExplanation = BilingualText("Temperature = ${formatEng(tC, 2)} °C (${formatEng(tF, 1)} °F)", "तापमान = ${formatEng(tC, 2)} °C")
                )
            }
        }
    )

    private fun tcTypeKCToMv() = CalculatorDefinition(
        id = "temp_tc_k_c_to_mv",
        serialNumber = 44,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.CompareArrows,
        title = BilingualText("Thermocouple (Type K) °C to mV", "थर्मोकपल (Type K) °C से mV"),
        subtitle = BilingualText("Find Expected Type-K mV Output with Cold Junction Compensation", "तापमान (°C) से Type-K थर्मोकपल का mV आउटपुट निकालें"),
        formulaPreview = "E_terminals = E_TypeK(T_process) − E_TypeK(T_cjc)",
        assumptions = BilingualText(
            "NIST ITS-90 Type-K polynomial (-200 to +1372 °C).",
            "मान्यता: NIST ITS-90 Type-K मानक (-200 से +1372 °C)।"
        ),
        keywords = listOf("thermocouple", "type k", "c to mv", "millivolt"),
        fields = listOf(
            CalculatorField("temp_c", BilingualText("Process Temperature (°C)", "प्रोसेस तापमान (°C)"), "300", "°C", allowNegative = true),
            CalculatorField("cjc", BilingualText("Terminal / Ambient Temp (CJC)", "कोल्ड जंक्शन तापमान (CJC)"), "25", "°C", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val t = requireRange(values["temp_c"], -200.0, 1372.0, BilingualText("Process Temp", "प्रोसेस तापमान"))
                val cjc = requireRange(values["cjc"], -50.0, 100.0, BilingualText("CJC Temp", "CJC तापमान"))
                val mv0 = typeKTempToMv(t)
                val mvCjc = typeKTempToMv(cjc)
                val mvTerm = mv0 - mvCjc
                engOutput(
                    primaryLabel = BilingualText("Expected Terminal Voltage", "अपेक्षित टर्मिनल mV"),
                    primaryValue = formatEng(mvTerm, 3),
                    primaryUnit = "mV",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("0°C Ref EMF", "0°C रेफरेंस mV"), formatEng(mv0, 3), "mV"),
                        SecondaryMetric(BilingualText("CJC EMF", "CJC mV"), formatEng(mvCjc, 3), "mV")
                    ),
                    formulaUsed = "E_term = E(T) − E(T_cjc)",
                    substitutedFormula = "E_term = ${formatEng(mv0, 3)} − ${formatEng(mvCjc, 3)}",
                    stepExplanation = BilingualText("At ${formatEng(t, 1)} °C (CJC ${formatEng(cjc, 1)} °C): ${formatEng(mvTerm, 3)} mV", "टर्मिनल आउटपुट = ${formatEng(mvTerm, 3)} mV")
                )
            }
        }
    )

    private fun tempUnitConverter() = CalculatorDefinition(
        id = "temp_unit_conv",
        serialNumber = 45,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("Temperature Unit Converter (°C, °F, K)", "तापमान यूनिट कन्वर्टर (°C, °F, K)"),
        subtitle = BilingualText("Convert Between Celsius (°C), Fahrenheit (°F), Kelvin (K) & °R", "तापमान को °C, °F, K और Rankine में बदलें"),
        formulaPreview = "°F = (°C × 9/5) + 32   |   K = °C + 273.15",
        assumptions = BilingualText(
            "Enforces physical absolute zero limit (≥ 0 K / −273.15 °C).",
            "मान्यता: भौतिक परम शून्य सीमा (≥ 0 K / −273.15 °C) लागू।"
        ),
        keywords = listOf("temperature converter", "celsius", "fahrenheit", "kelvin", "rankine"),
        fields = listOf(
            CalculatorField("temp", BilingualText("Temperature Value", "तापमान मान"), "100", "°C", listOf("°C", "°F", "K", "°R"), allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val raw = requireFinite(values["temp"], BilingualText("Temperature", "तापमान"))
                val u = units["temp"] ?: "°C"
                val c = when (u) {
                    "°F" -> (raw - 32.0) * 5.0 / 9.0
                    "K" -> raw - 273.15
                    "°R" -> (raw - 491.67) * 5.0 / 9.0
                    else -> raw
                }
                if (c < -273.15) throw BilingualValidationException(BilingualText("Temperature cannot be below absolute zero (-273.15 °C).", "तापमान परम शून्य (-273.15 °C) से कम नहीं हो सकता।"))
                val f = c * 9.0 / 5.0 + 32.0
                val k = c + 273.15
                val r = (c + 273.15) * 9.0 / 5.0
                engOutput(
                    primaryLabel = BilingualText("Celsius (°C)", "सेल्सियस (°C)"),
                    primaryValue = formatEng(c, 2),
                    primaryUnit = "°C",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Fahrenheit", "फ़ारेनहाइट"), formatEng(f, 2), "°F"),
                        SecondaryMetric(BilingualText("Kelvin", "केल्विन"), formatEng(k, 2), "K"),
                        SecondaryMetric(BilingualText("Rankine", "रैंकिन"), formatEng(r, 2), "°R")
                    ),
                    formulaUsed = "°F = °C×1.8 + 32   |   K = °C + 273.15",
                    substitutedFormula = "${formatEng(raw, 2)} $u = ${formatEng(c, 2)} °C",
                    stepExplanation = BilingualText("${formatEng(c, 2)} °C = ${formatEng(f, 2)} °F = ${formatEng(k, 2)} K", "${formatEng(c, 2)} °C = ${formatEng(f, 2)} °F")
                )
            }
        }
    )

    private fun tempTxRange() = CalculatorDefinition(
        id = "temp_tx_range",
        serialNumber = 46,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.Tune,
        title = BilingualText("Temperature Transmitter Range Calculator", "टेम्परेचर ट्रांसमीटर रेंज कैलकुलेटर"),
        subtitle = BilingualText("Calculate 4–20 mA Output, Span & Pt100 Ohms for TT Range", "LRV/URV रेंज के अनुसार टेम्परेचर ट्रांसमीटर का mA आउटपुट निकालें"),
        formulaPreview = "mA = 4 + ((T − LRV) / (URV − LRV)) × 16",
        assumptions = BilingualText(
            "Assumes linearized temperature transmitter output (head-mount or smart HART TT).",
            "मान्यता: लीनियराइज्ड टेम्परेचर ट्रांसमीटर आउटपुट।"
        ),
        keywords = listOf("temperature transmitter", "lrv", "urv", "4-20ma", "tt"),
        fields = listOf(
            CalculatorField("temp_c", BilingualText("Measured Temperature (°C)", "वर्तमान तापमान (°C)"), "120", "°C", allowNegative = true),
            CalculatorField("lrv", BilingualText("Transmitter LRV (°C)", "LRV (°C)"), "0", "°C", allowNegative = true),
            CalculatorField("urv", BilingualText("Transmitter URV (°C)", "URV (°C)"), "300", "°C", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val t = requireFinite(values["temp_c"], BilingualText("Temperature", "तापमान"))
                val lrv = requireFinite(values["lrv"], BilingualText("LRV", "LRV"))
                val urv = requireFinite(values["urv"], BilingualText("URV", "URV"))
                val span = urv - lrv
                if (abs(span) < 1e-12) throw BilingualValidationException(BilingualText("LRV and URV cannot be equal.", "LRV और URV बराबर नहीं हो सकते।"))
                val ratio = (t - lrv) / span
                val ma = 4.0 + ratio * 16.0
                val ptOhm = if (t in -200.0..850.0) formatEng(ptResistance(t, 100.0), 2) else "—"
                engOutput(
                    primaryLabel = BilingualText("Transmitter Output Current", "ट्रांसमीटर आउटपुट करंट"),
                    primaryValue = formatEng(ma, 3),
                    primaryUnit = "mA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Span", "स्पैन"), formatEng(span, 1), "°C"),
                        SecondaryMetric(BilingualText("Output %", "आउटपुट %"), formatEng(ratio * 100.0, 2), "%"),
                        SecondaryMetric(BilingualText("Pt100 Ohms", "Pt100 ओम"), ptOhm, "Ω")
                    ),
                    formulaUsed = "mA = 4 + ((T − LRV)/(URV − LRV)) × 16",
                    substitutedFormula = "mA = 4 + ((${formatEng(t, 1)} − ${formatEng(lrv, 1)})/${formatEng(span, 1)}) × 16",
                    stepExplanation = BilingualText("${formatEng(t, 1)} °C → ${formatEng(ma, 3)} mA", "आउटपुट = ${formatEng(ma, 3)} mA"),
                    statusLevel = if (ma < 3.8 || ma > 20.5) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun thermalExpansion() = CalculatorDefinition(
        id = "temp_expansion",
        serialNumber = 47,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.Straighten,
        title = BilingualText("Expansion Calculation (ΔL)", "तापीय प्रसार गणना (ΔL)"),
        subtitle = BilingualText("Compute Linear Thermal Expansion ΔL for Pipes & Thermowells", "तापमान बढ़ने पर पाइप या धातु की लंबाई में वृद्धि (ΔL) निकालें"),
        formulaPreview = "ΔL (mm) = α (×10⁻⁶/°C) × L₀ (m) × ΔT (°C) / 1000",
        assumptions = BilingualText(
            "Linear α constants (×10⁻⁶/°C): Carbon Steel = 12, SS304/316 = 16, Copper = 17, Aluminum = 23.",
            "मान्यता: α (×10⁻⁶/°C): कार्बन स्टील = 12, SS316 = 16, कॉपर = 17, एल्युमिनियम = 23।"
        ),
        keywords = listOf("thermal expansion", "delta l", "pipe expansion", "linear expansion"),
        fields = listOf(
            CalculatorField("material", BilingualText("Pipe / Metal Material", "धातु का प्रकार"), "1", "Carbon Steel (12)", listOf("Carbon Steel (12)", "SS 304/316 (16)", "Copper (17)", "Aluminum (23)"), isSelectorOnly = true),
            CalculatorField("len_m", BilingualText("Initial Length (L₀)", "प्रारंभिक लंबाई (L₀)"), "50", "m"),
            CalculatorField("dt", BilingualText("Temperature Rise (ΔT)", "तापमान परिवर्तन (ΔT)"), "120", "°C", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val l0 = requirePositive(values["len_m"], BilingualText("Initial Length", "लंबाई"))
                val dt = requireFinite(values["dt"], BilingualText("Temperature Change", "तापमान अंतर"))
                val alphaMicro = when (units["material"]) {
                    "SS 304/316 (16)" -> 16.0
                    "Copper (17)" -> 17.0
                    "Aluminum (23)" -> 23.0
                    else -> 12.0
                }
                val dlMm = alphaMicro * 1e-6 * l0 * dt * 1000.0
                val finalM = l0 + dlMm / 1000.0
                val strainMicro = alphaMicro * dt
                engOutput(
                    primaryLabel = BilingualText("Linear Expansion (ΔL)", "रेखीय प्रसार (ΔL)"),
                    primaryValue = formatEng(dlMm, 2),
                    primaryUnit = "mm",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Final Length", "अंतिम लंबाई"), formatEng(finalM, 4), "m"),
                        SecondaryMetric(BilingualText("Thermal Strain", "थर्मल स्ट्रेन"), formatEng(strainMicro, 1), "µε")
                    ),
                    formulaUsed = "ΔL = α × L₀ × ΔT",
                    substitutedFormula = "ΔL = ${formatEng(alphaMicro, 0)}×10⁻⁶ × ${formatEng(l0, 1)} × ${formatEng(dt, 1)}",
                    stepExplanation = BilingualText("Expansion ΔL = ${formatEng(dlMm, 2)} mm", "लंबाई वृद्धि ΔL = ${formatEng(dlMm, 2)} mm")
                )
            }
        }
    )

    private fun heatTransferQ() = CalculatorDefinition(
        id = "temp_heat_transfer",
        serialNumber = 48,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.LocalFireDepartment,
        title = BilingualText("Heat Transfer Calculator (Q)", "हीट ट्रांसफर कैलकुलेटर (Q)"),
        subtitle = BilingualText("Compute Sensible Heat Duty Q = ṁ × C_p × ΔT in kW & BTU/hr", "मास फ्लो, विशिष्ट ऊष्मा Cp और ΔT से हीट ड्यूटी (kW) निकालें"),
        formulaPreview = "Q (kW) = ṁ (kg/s) × C_p (kJ/kg·°C) × ΔT (°C)",
        assumptions = BilingualText(
            "Sensible heat transfer (no phase change); Water C_p = 4.186 kJ/kg·°C.",
            "मान्यता: बिना अवस्था परिवर्तन के सेंसिबल हीट ट्रांसफर (पानी C_p = 4.186)।"
        ),
        keywords = listOf("heat transfer", "sensible heat", "m cp dt", "kw", "btu"),
        fields = listOf(
            CalculatorField("mass_flow", BilingualText("Mass Flow Rate (ṁ)", "मास फ्लो रेट (ṁ)"), "3600", "kg/hr", listOf("kg/hr", "kg/s")),
            CalculatorField("cp", BilingualText("Specific Heat (C_p)", "विशिष्ट ऊष्मा (C_p)"), "4.186", "kJ/kg·°C"),
            CalculatorField("dt", BilingualText("Temperature Change (ΔT)", "तापमान अंतर (ΔT)"), "25", "°C")
        ),
        compute = { values, units ->
            runCatching {
                val rawM = requirePositive(values["mass_flow"], BilingualText("Mass Flow", "मास फ्लो"))
                val cp = requirePositive(values["cp"], BilingualText("Specific Heat C_p", "विशिष्ट ऊष्मा"))
                val dt = requirePositive(values["dt"], BilingualText("ΔT", "ΔT"))
                val mKgS = if (units["mass_flow"] == "kg/s") rawM else rawM / 3600.0
                val qKw = mKgS * cp * dt
                val kcalHr = qKw * 859.845
                val btuHr = qKw * 3412.142
                engOutput(
                    primaryLabel = BilingualText("Heat Transfer Rate (Q)", "हीट ट्रांसफर दर (Q)"),
                    primaryValue = formatEng(qKw, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("kcal / hour", "kcal / घंटा"), formatEng(kcalHr, 0), "kcal/hr"),
                        SecondaryMetric(BilingualText("BTU / hour", "BTU / घंटा"), formatEng(btuHr, 0), "BTU/hr")
                    ),
                    formulaUsed = "Q = ṁ(kg/s) × C_p × ΔT",
                    substitutedFormula = "Q = ${formatEng(mKgS, 3)} × ${formatEng(cp, 3)} × ${formatEng(dt, 1)}",
                    stepExplanation = BilingualText("Heat Duty = ${formatEng(qKw, 2)} kW (${formatEng(kcalHr, 0)} kcal/hr)", "हीट ड्यूटी = ${formatEng(qKw, 2)} kW")
                )
            }
        }
    )

    private fun tempDifferenceDt() = CalculatorDefinition(
        id = "temp_delta_t",
        serialNumber = 49,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.AcUnit,
        title = BilingualText("Temperature Difference (ΔT) Calculator", "तापमान अंतर (ΔT) कैलकुलेटर"),
        subtitle = BilingualText("Compute ΔT = T₁ − T₂, Average Temp & Cross-Unit Equivalent", "दो तापमान T₁ व T₂ का अंतर (ΔT) और औसत तापमान निकालें"),
        formulaPreview = "ΔT = |T₁ − T₂|   |   ΔT(°F) = ΔT(°C) × 1.8",
        assumptions = BilingualText(
            "Both T₁ and T₂ are entered in the same selected temperature scale.",
            "मान्यता: T₁ और T₂ दोनों एक ही चुनी हुई इकाई में दर्ज करें।"
        ),
        keywords = listOf("temperature difference", "delta t", "differential temp", "chiller"),
        fields = listOf(
            CalculatorField("t1", BilingualText("Temperature 1 (T₁)", "तापमान 1 (T₁)"), "85", "°C", listOf("°C", "°F", "K"), allowNegative = true),
            CalculatorField("t2", BilingualText("Temperature 2 (T₂)", "तापमान 2 (T₂)"), "60", "°C", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val t1 = requireFinite(values["t1"], BilingualText("T₁", "T₁"))
                val t2 = requireFinite(values["t2"], BilingualText("T₂", "T₂"))
                val u = units["t1"] ?: "°C"
                val signedDiff = t1 - t2
                val absDiff = abs(signedDiff)
                val avg = (t1 + t2) / 2.0
                val dtC = if (u == "°F") absDiff * 5.0 / 9.0 else absDiff
                val dtF = if (u == "°F") absDiff else absDiff * 1.8
                engOutput(
                    primaryLabel = BilingualText("Temperature Difference (|ΔT|)", "तापमान अंतर (|ΔT|)"),
                    primaryValue = formatEng(absDiff, 2),
                    primaryUnit = u,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Signed (T₁ − T₂)", "अंतर (T₁−T₂)"), formatEng(signedDiff, 2), u),
                        SecondaryMetric(BilingualText("Average Temp", "औसत तापमान"), formatEng(avg, 2), u),
                        SecondaryMetric(BilingualText(if (u == "°F") "ΔT in °C/K" else "ΔT in °F", "अन्य इकाई में"), formatEng(if (u == "°F") dtC else dtF, 2), if (u == "°F") "°C" else "°F")
                    ),
                    formulaUsed = "ΔT = |T₁ − T₂|",
                    substitutedFormula = "|${formatEng(t1, 2)} − ${formatEng(t2, 2)}| = ${formatEng(absDiff, 2)} $u",
                    stepExplanation = BilingualText("|ΔT| = ${formatEng(absDiff, 2)} $u, Average = ${formatEng(avg, 2)} $u", "अंतर = ${formatEng(absDiff, 2)} $u")
                )
            }
        }
    )

    private fun tempAveraging() = CalculatorDefinition(
        id = "temp_averaging",
        serialNumber = 50,
        category = CalculatorCategory.INST_TEMPERATURE,
        icon = Icons.Rounded.Equalizer,
        title = BilingualText("Temperature Averaging Calculator", "तापमान औसत (Averaging) कैलकुलेटर"),
        subtitle = BilingualText("Compute Mean Temperature, Min, Max & Spread across 2–4 Sensors", "2 से 4 सेंसर रीडिंग का औसत और अधिकतम अंतर (Spread) निकालें"),
        formulaPreview = "T_avg = (T₁ + T₂ + ... + T_n) / n   |   Spread = T_max − T_min",
        assumptions = BilingualText(
            "Select active sensor count (2, 3, or 4); unused trailing sensor inputs are ignored.",
            "मान्यता: सक्रिय सेंसर संख्या (2, 3 या 4) चुनें; शेष खाली या अनदेखा किए जाएंगे।"
        ),
        keywords = listOf("temperature averaging", "multi sensor", "spread", "mean temperature"),
        fields = listOf(
            CalculatorField("count", BilingualText("Active Sensors", "सक्रिय सेंसर संख्या"), "1", "4 Sensors", listOf("2 Sensors", "3 Sensors", "4 Sensors"), isSelectorOnly = true),
            CalculatorField("t1", BilingualText("Sensor 1 (T₁)", "सेंसर 1 (T₁)"), "120", "°C", listOf("°C", "°F"), allowNegative = true),
            CalculatorField("t2", BilingualText("Sensor 2 (T₂)", "सेंसर 2 (T₂)"), "122", "°C", allowNegative = true),
            CalculatorField("t3", BilingualText("Sensor 3 (T₃)", "सेंसर 3 (T₃)"), "119", "°C", allowNegative = true),
            CalculatorField("t4", BilingualText("Sensor 4 (T₄)", "सेंसर 4 (T₄)"), "121", "°C", allowNegative = true)
        ),
        compute = { values, units ->
            runCatching {
                val n = when (units["count"]) {
                    "2 Sensors" -> 2
                    "3 Sensors" -> 3
                    else -> 4
                }
                val t1 = requireFinite(values["t1"], BilingualText("Sensor 1", "सेंसर 1"))
                val t2 = requireFinite(values["t2"], BilingualText("Sensor 2", "सेंसर 2"))
                val list = mutableListOf(t1, t2)
                if (n >= 3) list += requireFinite(values["t3"], BilingualText("Sensor 3", "सेंसर 3"))
                if (n >= 4) list += requireFinite(values["t4"], BilingualText("Sensor 4", "सेंसर 4"))
                val avg = list.average()
                val minT = list.min()
                val maxT = list.max()
                val spread = maxT - minT
                val u = units["t1"] ?: "°C"
                engOutput(
                    primaryLabel = BilingualText("Average Temperature ($n Sensors)", "औसत तापमान"),
                    primaryValue = formatEng(avg, 2),
                    primaryUnit = u,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Max − Min Spread", "अधिकतम अंतर"), formatEng(spread, 2), u),
                        SecondaryMetric(BilingualText("Minimum", "न्यूनतम"), formatEng(minT, 2), u),
                        SecondaryMetric(BilingualText("Maximum", "अधिकतम"), formatEng(maxT, 2), u)
                    ),
                    formulaUsed = "T_avg = ΣT_i / $n",
                    substitutedFormula = "T_avg = ${formatEng(list.sum(), 2)} / $n = ${formatEng(avg, 2)} $u",
                    stepExplanation = BilingualText("Mean = ${formatEng(avg, 2)} $u (Spread = ${formatEng(spread, 2)} $u)", "औसत = ${formatEng(avg, 2)} $u"),
                    statusLevel = if (spread > 10.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )
}
