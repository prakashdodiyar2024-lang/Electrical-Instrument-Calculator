package com.example.domain

import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition

object CalculatorRegistry {

    val allCalculators: List<CalculatorDefinition> =
        ElectricalMotorCalculators.all +
            DrivePlcSignalCalculators.all +
            InstrumentationProcessCalculators.all

    private val byIdMap: Map<String, CalculatorDefinition> =
        allCalculators.associateBy { it.id }

    fun getById(id: String): CalculatorDefinition? = byIdMap[id]

    fun getByCategory(category: CalculatorCategory): List<CalculatorDefinition> =
        allCalculators.filter { it.category == category }

    fun countForCategory(category: CalculatorCategory): Int =
        allCalculators.count { it.category == category }

    val popularIds: List<String> = listOf(
        "ma_pv_linear",
        "rtd_pt100_pt1000",
        "motor_flc",
        "cable_sizing_ac",
        "plc_analog_scaling",
        "vfd_freq_rpm"
    )

    val popularCalculators: List<CalculatorDefinition> =
        popularIds.mapNotNull { byIdMap[it] }

    private fun normalizeSearchText(text: String): String =
        text.lowercase()
            .replace('\u2013', '-') // en-dash –
            .replace('\u2014', '-') // em-dash —
            .replace('\u2212', '-') // minus −
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun compactSearchText(text: String): String =
        normalizeSearchText(text)
            .replace("-", "")
            .replace(" ", "")

    fun search(query: String, categoryFilter: CalculatorCategory? = null): List<CalculatorDefinition> {
        val normQuery = normalizeSearchText(query)
        val compactQuery = compactSearchText(query)
        val base = if (categoryFilter != null) {
            getByCategory(categoryFilter)
        } else {
            allCalculators
        }
        if (normQuery.isEmpty()) return base
        return base.filter { calc ->
            val fields = listOf(
                calc.title.en,
                calc.title.hi,
                calc.subtitle.en,
                calc.subtitle.hi,
                calc.formulaPreview,
                calc.category.title.en,
                calc.category.title.hi
            ) + calc.keywords

            fields.any { field ->
                val normField = normalizeSearchText(field)
                normField.contains(normQuery) ||
                    (compactQuery.isNotEmpty() && compactSearchText(field).contains(compactQuery))
            }
        }
    }
}
