package com.example

import com.example.domain.CalculatorRegistry
import com.example.domain.EngineeringExamples
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.StatusLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineeringCalculatorsTest {

    private fun runCalc(
        id: String,
        values: Map<String, Double>,
        units: Map<String, String> = emptyMap()
    ) = CalculatorRegistry.getById(id)!!.compute(values, units)

    @Test
    fun registryHas29CalculatorsAcross9Categories() {
        assertEquals(9, CalculatorCategory.entries.size)
        assertEquals(29, CalculatorRegistry.allCalculators.size)
        CalculatorCategory.entries.forEach { cat ->
            assertTrue("Category ${cat.id} empty", CalculatorRegistry.getByCategory(cat).isNotEmpty())
        }
    }

    @Test
    fun allCalculatorsHaveBilingualFieldsFormulasAndSteps() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            assertFalse(calc.title.en.isBlank())
            assertFalse(calc.title.hi.isBlank())
            assertFalse(calc.subtitle.en.isBlank())
            assertFalse(calc.subtitle.hi.isBlank())
            assertFalse(calc.formulaPreview.isBlank())
            val defVals = calc.fields.associate { it.id to (it.defaultValue.toDoubleOrNull() ?: 1.0) }
            val defUnits = calc.fields.associate { it.id to it.defaultUnit }
            val out = calc.compute(defVals, defUnits).getOrThrow()
            assertFalse(out.formulaUsed.isBlank())
            assertFalse("Missing substitutedFormula in ${calc.id}", out.substitutedFormula.isBlank())
            assertNotNull("Missing resultExplanation in ${calc.id}", out.resultExplanation)
            assertFalse("Blank EN resultExplanation in ${calc.id}", out.resultExplanation!!.en.isBlank())
            assertFalse("Blank HI resultExplanation in ${calc.id}", out.resultExplanation!!.hi.isBlank())
            assertTrue("Missing steps in ${calc.id}", out.steps.isNotEmpty())
            out.steps.forEach { step ->
                assertFalse(step.title.en.isBlank())
                assertFalse(step.title.hi.isBlank())
                assertFalse("Blank step expression in ${calc.id}", step.expression.isBlank())
                assertFalse(step.explanation.en.isBlank())
                assertFalse(step.explanation.hi.isBlank())
            }
        }
    }

    // --- 1. ELECTRICAL (4 Calculators x 3+ cases) ---

    @Test
    fun elecOhmsPower_3Cases() {
        // Case 1: 230V, 10A, PF 1.0 -> 2.3 kW, R=23 Ohm
        val r1 = runCalc("elec_ohms_power", mapOf("voltage" to 230.0, "current" to 10.0, "pf" to 1.0), mapOf("voltage" to "V", "current" to "A")).getOrThrow()
        assertEquals("2.3", r1.primaryValue)
        assertEquals("kW", r1.primaryUnit)
        assertEquals("23", r1.secondaryMetrics[0].value)

        // Case 2: 24V, 50mA, PF 1.0 -> 1.2 W, R=480 Ohm
        val r2 = runCalc("elec_ohms_power", mapOf("voltage" to 24.0, "current" to 50.0, "pf" to 1.0), mapOf("voltage" to "V", "current" to "mA")).getOrThrow()
        assertEquals("1.2", r2.primaryValue)
        assertEquals("W", r2.primaryUnit)
        assertEquals("480", r2.secondaryMetrics[0].value)

        // Case 3: Invalid PF > 1.0 throws BilingualValidationException
        val r3 = runCalc("elec_ohms_power", mapOf("voltage" to 230.0, "current" to 10.0, "pf" to 1.5))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun elec3PhasePower_3Cases() {
        // Case 1: 415V, 35A, 0.85 PF -> S=25.158 kVA, P=21.38 kW
        val r1 = runCalc("elec_3phase_power", mapOf("line_voltage" to 415.0, "line_current" to 35.0, "pf" to 0.85), mapOf("line_voltage" to "V")).getOrThrow()
        assertEquals("21.38", r1.primaryValue)

        // Case 2: 11kV, 80A, 0.92 PF -> 1402.27 kW
        val r2 = runCalc("elec_3phase_power", mapOf("line_voltage" to 11.0, "line_current" to 80.0, "pf" to 0.92), mapOf("line_voltage" to "kV")).getOrThrow()
        assertEquals("1402.27", r2.primaryValue)

        // Case 3: Zero current rejected
        val r3 = runCalc("elec_3phase_power", mapOf("line_voltage" to 415.0, "line_current" to 0.0, "pf" to 0.85))
        assertTrue(r3.isFailure)
    }

    @Test
    fun elecPfCapacitor_3Cases() {
        // Case 1: 100 kW, 0.75 -> 0.98 @ 415V -> 67.88 kVAR
        val r1 = runCalc("elec_pf_capacitor", mapOf("load_kw" to 100.0, "existing_pf" to 0.75, "target_pf" to 0.98, "voltage" to 415.0)).getOrThrow()
        assertEquals("67.89", r1.primaryValue)

        // Case 2: 50 kW, 0.80 -> 0.95 @ 415V -> 21.07 kVAR
        val r2 = runCalc("elec_pf_capacitor", mapOf("load_kw" to 50.0, "existing_pf" to 0.80, "target_pf" to 0.95, "voltage" to 415.0)).getOrThrow()
        assertEquals("21.07", r2.primaryValue)

        // Case 3: Target PF <= Existing PF rejected
        val r3 = runCalc("elec_pf_capacitor", mapOf("load_kw" to 50.0, "existing_pf" to 0.95, "target_pf" to 0.85, "voltage" to 415.0))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun elecVoltageDrop_3Cases() {
        // Case 1: 3ph Cu 415V, 40A, 120m, 16mm2 -> 10.91 V
        val r1 = runCalc("elec_voltage_drop", mapOf("voltage" to 415.0, "current" to 40.0, "length" to 120.0, "area" to 16.0), mapOf("system" to "3φ Copper")).getOrThrow()
        assertEquals("10.91", r1.primaryValue)
        assertEquals(StatusLevel.NORMAL, r1.statusLevel)

        // Case 2: 24V DC 4A 80m 1.5mm2 -> 8.96 V (>5% warning)
        val r2 = runCalc("elec_voltage_drop", mapOf("voltage" to 24.0, "current" to 4.0, "length" to 80.0, "area" to 1.5), mapOf("system" to "1φ/DC Copper")).getOrThrow()
        assertEquals("8.96", r2.primaryValue)
        assertEquals(StatusLevel.WARNING, r2.statusLevel)

        // Case 3: 3ph Al & zero area validation
        val r3Ok = runCalc("elec_voltage_drop", mapOf("voltage" to 415.0, "current" to 100.0, "length" to 100.0, "area" to 95.0), mapOf("system" to "3φ Aluminum")).getOrThrow()
        assertEquals("6.2", r3Ok.primaryValue)
        assertTrue(runCalc("elec_voltage_drop", mapOf("voltage" to 415.0, "current" to 40.0, "length" to 100.0, "area" to 0.0)).isFailure)
    }

    // --- 2. INSTRUMENTATION (3 Calculators x 3+ cases) ---

    @Test
    fun instControlValveCv_3Cases() {
        // Case 1: 25 m3/h (110.07 GPM), P1=6 bar, P2=4.5 bar (dP=21.756 psi), SG=1.0 -> Cv=23.60
        val r1 = runCalc("inst_control_valve_cv", mapOf("flow" to 25.0, "p1" to 6.0, "p2" to 4.5, "sg" to 1.0), mapOf("flow" to "m³/h", "p1" to "bar", "p2" to "bar")).getOrThrow()
        assertEquals("23.6", r1.primaryValue)

        // Case 2: 100 GPM, P1=60 psi, P2=44 psi (dP=16 psi), SG=1.0 -> Cv = 100 * sqrt(1/16) = 25
        val r2 = runCalc("inst_control_valve_cv", mapOf("flow" to 100.0, "p1" to 60.0, "p2" to 44.0, "sg" to 1.0), mapOf("flow" to "GPM", "p1" to "psi", "p2" to "psi")).getOrThrow()
        assertEquals("25", r2.primaryValue)

        // Case 3: P2 >= P1 rejected
        val r3 = runCalc("inst_control_valve_cv", mapOf("flow" to 25.0, "p1" to 4.0, "p2" to 5.0, "sg" to 1.0), mapOf("flow" to "m³/h", "p1" to "bar", "p2" to "bar"))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun instTxError_3Cases() {
        // Case 1: 50% on 0-100, measured 12.08 -> +0.5% (>0.25% warning)
        val r1 = runCalc("inst_tx_error", mapOf("applied_pv" to 50.0, "lrv" to 0.0, "urv" to 100.0, "measured_ma" to 12.08, "tolerance" to 0.25)).getOrThrow()
        assertEquals("+0.5 %", r1.primaryValue)
        assertEquals(StatusLevel.WARNING, r1.statusLevel)

        // Case 2: 50% on 0-100, measured 12.02 -> +0.125% (PASS)
        val r2 = runCalc("inst_tx_error", mapOf("applied_pv" to 50.0, "lrv" to 0.0, "urv" to 100.0, "measured_ma" to 12.02, "tolerance" to 0.25)).getOrThrow()
        assertEquals("+0.125 %", r2.primaryValue)
        assertEquals(StatusLevel.NORMAL, r2.statusLevel)

        // Case 3: Zero span rejected
        val r3 = runCalc("inst_tx_error", mapOf("applied_pv" to 50.0, "lrv" to 100.0, "urv" to 100.0, "measured_ma" to 12.0, "tolerance" to 0.25))
        assertTrue(r3.isFailure)
    }

    @Test
    fun instDpOrificeFlow_3Cases() {
        // Case 1: 1600 / 2500 -> 0.8 * 120 = 96 m3/h
        val r1 = runCalc("inst_dp_orifice_flow", mapOf("dp_actual" to 1600.0, "dp_max" to 2500.0, "q_max" to 120.0), mapOf("q_max" to "m³/h")).getOrThrow()
        assertEquals("96", r1.primaryValue)

        // Case 2: Zero DP -> 0 flow
        val r2 = runCalc("inst_dp_orifice_flow", mapOf("dp_actual" to 0.0, "dp_max" to 2500.0, "q_max" to 120.0)).getOrThrow()
        assertEquals("0", r2.primaryValue)

        // Case 3: Negative DP rejected
        val r3 = runCalc("inst_dp_orifice_flow", mapOf("dp_actual" to -10.0, "dp_max" to 2500.0, "q_max" to 120.0))
        assertTrue(r3.isFailure)
    }

    // --- 3. MOTOR (4 Calculators x 3+ cases) ---

    @Test
    fun motorFlc_3Cases() {
        // Case 1: 15 kW, 415V, 90% eff, 0.85 PF -> 27.27 A
        val r1 = runCalc("motor_flc", mapOf("power" to 15.0, "voltage" to 415.0, "efficiency" to 90.0, "pf" to 0.85), mapOf("power" to "kW")).getOrThrow()
        assertEquals("27.28", r1.primaryValue)

        // Case 2: 50 HP, 415V, 92% eff, 0.87 PF -> 64.81 A
        val r2 = runCalc("motor_flc", mapOf("power" to 50.0, "voltage" to 415.0, "efficiency" to 92.0, "pf" to 0.87), mapOf("power" to "HP")).getOrThrow()
        assertEquals("64.81", r2.primaryValue)

        // Case 3: Efficiency > 100% rejected
        val r3 = runCalc("motor_flc", mapOf("power" to 15.0, "voltage" to 415.0, "efficiency" to 105.0, "pf" to 0.85))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun motorSpeedSlip_3Cases() {
        // Case 1: 50Hz, 4 pole, 1440 RPM -> Ns=1500, Slip=4%
        val r1 = runCalc("motor_speed_slip", mapOf("freq" to 50.0, "poles" to 4.0, "rotor_rpm" to 1440.0)).getOrThrow()
        assertEquals("1500", r1.primaryValue)
        assertEquals("4", r1.secondaryMetrics[0].value)

        // Case 2: 60Hz, 2 pole, 3510 RPM -> Ns=3600, Slip=2.5%
        val r2 = runCalc("motor_speed_slip", mapOf("freq" to 60.0, "poles" to 2.0, "rotor_rpm" to 3510.0)).getOrThrow()
        assertEquals("3600", r2.primaryValue)
        assertEquals("2.5", r2.secondaryMetrics[0].value)

        // Case 3: Odd poles (3) rejected
        val r3 = runCalc("motor_speed_slip", mapOf("freq" to 50.0, "poles" to 3.0, "rotor_rpm" to 1440.0))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun motorStarterSizing_3Cases() {
        // Case 1: 40 A FLC, 1.15 SF -> SD Main=(40/1.732)*1.15=26.56 -> 32 A
        val r1 = runCalc("motor_starter_sizing", mapOf("flc" to 40.0, "service_factor" to 1.15)).getOrThrow()
        assertEquals("32 A", r1.primaryValue)

        // Case 2: 100 A FLC, 1.15 SF -> SD Main=66.4 -> 80 A
        val r2 = runCalc("motor_starter_sizing", mapOf("flc" to 100.0, "service_factor" to 1.15)).getOrThrow()
        assertEquals("80 A", r2.primaryValue)

        // Case 3: Safety factor < 1.0 rejected
        val r3 = runCalc("motor_starter_sizing", mapOf("flc" to 40.0, "service_factor" to 0.8))
        assertTrue(r3.isFailure)
    }

    @Test
    fun motorTorque_3Cases() {
        // Case 1: 15 kW @ 1460 RPM -> 98.11 N.m
        val r1 = runCalc("motor_torque", mapOf("power" to 15.0, "rpm" to 1460.0), mapOf("power" to "kW")).getOrThrow()
        assertEquals("98.11", r1.primaryValue)

        // Case 2: 20 HP (14.914 kW) @ 1460 RPM -> 97.55 N.m
        val r2 = runCalc("motor_torque", mapOf("power" to 20.0, "rpm" to 1460.0), mapOf("power" to "HP")).getOrThrow()
        assertEquals("97.55", r2.primaryValue)

        // Case 3: Zero RPM rejected
        val r3 = runCalc("motor_torque", mapOf("power" to 15.0, "rpm" to 0.0))
        assertTrue(r3.isFailure)
    }

    // --- 4. VFD (3 Calculators x 3+ cases) ---

    @Test
    fun vfdFreqRpm_3Cases() {
        // Case 1: 35 Hz on 50Hz 415V 4P 3% slip -> sync=1050, rotor=1018.5->1019
        val r1 = runCalc("vfd_freq_rpm", mapOf("vfd_freq" to 35.0, "base_freq" to 50.0, "base_volt" to 415.0, "poles" to 4.0, "slip_pct" to 3.0)).getOrThrow()
        assertEquals("1019", r1.primaryValue)
        assertEquals(StatusLevel.NORMAL, r1.statusLevel)

        // Case 2: 60 Hz overspeed -> warning status, output voltage capped at 415V
        val r2 = runCalc("vfd_freq_rpm", mapOf("vfd_freq" to 60.0, "base_freq" to 50.0, "base_volt" to 415.0, "poles" to 4.0, "slip_pct" to 3.0)).getOrThrow()
        assertEquals("415", r2.secondaryMetrics[1].value)
        assertEquals(StatusLevel.WARNING, r2.statusLevel)

        // Case 3: Odd poles rejected
        val r3 = runCalc("vfd_freq_rpm", mapOf("vfd_freq" to 35.0, "base_freq" to 50.0, "base_volt" to 415.0, "poles" to 5.0, "slip_pct" to 3.0))
        assertTrue(r3.isFailure)
    }

    @Test
    fun vfdAffinityLaws_3Cases() {
        // Case 1: 30 kW @ 80% speed -> 15.36 kW (48.8% saved)
        val r1 = runCalc("vfd_affinity_laws", mapOf("rated_kw" to 30.0, "speed_pct" to 80.0, "hours_day" to 16.0)).getOrThrow()
        assertEquals("15.36", r1.primaryValue)
        assertEquals(StatusLevel.NORMAL, r1.statusLevel)

        // Case 2: 30 kW @ 110% speed -> 39.93 kW (WARNING)
        val r2 = runCalc("vfd_affinity_laws", mapOf("rated_kw" to 30.0, "speed_pct" to 110.0, "hours_day" to 10.0)).getOrThrow()
        assertEquals("39.93", r2.primaryValue)
        assertEquals(StatusLevel.WARNING, r2.statusLevel)

        // Case 3: Hours > 24 rejected
        val r3 = runCalc("vfd_affinity_laws", mapOf("rated_kw" to 30.0, "speed_pct" to 80.0, "hours_day" to 26.0))
        assertTrue(r3.isFailure)
    }

    @Test
    fun vfdDcBusBrake_3Cases() {
        // Case 1: 415V AC -> 560.3 V DC
        val r1 = runCalc("vfd_dc_bus_brake", mapOf("vac" to 415.0, "motor_kw" to 15.0, "duty_pct" to 50.0)).getOrThrow()
        assertEquals("560.3", r1.primaryValue)

        // Case 2: 230V AC -> 310.5 V DC
        val r2 = runCalc("vfd_dc_bus_brake", mapOf("vac" to 230.0, "motor_kw" to 2.2, "duty_pct" to 100.0)).getOrThrow()
        assertEquals("310.5", r2.primaryValue)

        // Case 3: Zero VAC rejected
        val r3 = runCalc("vfd_dc_bus_brake", mapOf("vac" to 0.0, "motor_kw" to 15.0, "duty_pct" to 50.0))
        assertTrue(r3.isFailure)
    }

    // --- 5. PLC & DCS (3 Calculators x 3+ cases) ---

    @Test
    fun plcAnalogScaling_3Cases() {
        // Case 1: Siemens 13824 / 27648 (0-100) -> 50
        val r1 = runCalc("plc_analog_scaling", mapOf("raw_val" to 13824.0, "raw_min" to 0.0, "raw_max" to 27648.0, "lrv" to 0.0, "urv" to 100.0)).getOrThrow()
        assertEquals("50", r1.primaryValue)
        assertEquals(StatusLevel.NORMAL, r1.statusLevel)

        // Case 2: AB 12000 (4000-20000 -> 0-250) -> 125
        val r2 = runCalc("plc_analog_scaling", mapOf("raw_val" to 12000.0, "raw_min" to 4000.0, "raw_max" to 20000.0, "lrv" to 0.0, "urv" to 250.0)).getOrThrow()
        assertEquals("125", r2.primaryValue)

        // Case 3: Equal raw_min and raw_max rejected
        val r3 = runCalc("plc_analog_scaling", mapOf("raw_val" to 1000.0, "raw_min" to 4000.0, "raw_max" to 4000.0, "lrv" to 0.0, "urv" to 100.0))
        assertTrue(r3.isFailure)
    }

    @Test
    fun plcHscFrequency_3Cases() {
        // Case 1: 1500 RPM * 1024 PPR / 60 = 25.6 kHz
        val r1 = runCalc("plc_hsc_frequency", mapOf("rpm" to 1500.0, "ppr" to 1024.0)).getOrThrow()
        assertEquals("25.6", r1.primaryValue)
        assertEquals("kHz", r1.primaryUnit)

        // Case 2: 60 RPM * 100 PPR / 60 = 100 Hz
        val r2 = runCalc("plc_hsc_frequency", mapOf("rpm" to 60.0, "ppr" to 100.0)).getOrThrow()
        assertEquals("100", r2.primaryValue)
        assertEquals("Hz", r2.primaryUnit)

        // Case 3: Zero PPR rejected
        val r3 = runCalc("plc_hsc_frequency", mapOf("rpm" to 1500.0, "ppr" to 0.0))
        assertTrue(r3.isFailure)
    }

    @Test
    fun plcPanelPower_3Cases() {
        // Case 1: 2.2+3.5+1.8=7.5A * 1.3 = 9.75A -> 10 A SMPS
        val r1 = runCalc("plc_panel_power", mapOf("plc_load" to 2.2, "relay_solenoid" to 3.5, "field_tx" to 1.8, "margin_pct" to 30.0)).getOrThrow()
        assertEquals("10 A", r1.primaryValue)

        // Case 2: Large 35A + 30% = 45.5A -> parallel recommendation
        val r2 = runCalc("plc_panel_power", mapOf("plc_load" to 10.0, "relay_solenoid" to 20.0, "field_tx" to 5.0, "margin_pct" to 30.0)).getOrThrow()
        assertTrue(r2.primaryValue.contains("Parallel"))

        // Case 3: All zero currents rejected
        val r3 = runCalc("plc_panel_power", mapOf("plc_load" to 0.0, "relay_solenoid" to 0.0, "field_tx" to 0.0, "margin_pct" to 30.0))
        assertTrue(r3.isFailure)
    }

    // --- 6. 4-20 mA SIGNAL (3 Calculators x 3+ cases) ---

    @Test
    fun maLinearScaling_3Cases() {
        // Case 1: 12 mA on 0-16 bar -> 8 bar
        val r1 = runCalc("ma_pv_linear", mapOf("input_val" to 12.0, "lrv" to 0.0, "urv" to 16.0), mapOf("input_val" to "mA")).getOrThrow()
        assertEquals("8", r1.primaryValue)

        // Case 2: 75 °C on -50..150 °C -> 14 mA
        val r2 = runCalc("ma_pv_linear", mapOf("input_val" to 75.0, "lrv" to -50.0, "urv" to 150.0), mapOf("input_val" to "PV")).getOrThrow()
        assertEquals("14", r2.primaryValue)
        assertEquals("mA", r2.primaryUnit)

        // Case 3: mA > 25 rejected
        val r3 = runCalc("ma_pv_linear", mapOf("input_val" to 30.0, "lrv" to 0.0, "urv" to 100.0), mapOf("input_val" to "mA"))
        assertTrue(r3.isFailure)
    }

    @Test
    fun maDpSqrt_3Cases() {
        // Case 1: 12 mA -> 70.71 m3/h
        val r1 = runCalc("ma_dp_sqrt", mapOf("ma" to 12.0, "q_max" to 100.0, "dp_max" to 2500.0), mapOf("q_max" to "m³/h")).getOrThrow()
        assertEquals("70.71", r1.primaryValue)

        // Case 2: 8 mA -> 50% -> 250 LPM
        val r2 = runCalc("ma_dp_sqrt", mapOf("ma" to 8.0, "q_max" to 500.0, "dp_max" to 1000.0), mapOf("q_max" to "LPM")).getOrThrow()
        assertEquals("250", r2.primaryValue)
        assertTrue(r2.primaryUnit.startsWith("LPM"))

        // Case 3: Wire-break 2.0 mA rejected
        val r3 = runCalc("ma_dp_sqrt", mapOf("ma" to 2.0, "q_max" to 100.0, "dp_max" to 2500.0))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun maLoopResistance_3Cases() {
        // Case 1: 24V - 10.5V / 0.02 = 675 Ohm, actual 295 Ohm -> PASS
        val r1 = runCalc("ma_loop_resistance", mapOf("v_supply" to 24.0, "v_min_tx" to 10.5, "r_plc" to 250.0, "r_cable" to 45.0)).getOrThrow()
        assertEquals("675", r1.primaryValue)
        assertEquals(StatusLevel.NORMAL, r1.statusLevel)

        // Case 2: High cable resistance 600 Ohm -> WARNING (FAIL)
        val r2 = runCalc("ma_loop_resistance", mapOf("v_supply" to 24.0, "v_min_tx" to 10.5, "r_plc" to 250.0, "r_cable" to 600.0)).getOrThrow()
        assertEquals(StatusLevel.WARNING, r2.statusLevel)

        // Case 3: Supply <= Min Tx voltage rejected
        val r3 = runCalc("ma_loop_resistance", mapOf("v_supply" to 10.0, "v_min_tx" to 12.0, "r_plc" to 250.0, "r_cable" to 20.0))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    // --- 7. RTD & THERMOCOUPLE (3 Calculators x 3+ cases) ---

    @Test
    fun rtdPt100Pt1000_3Cases() {
        // Case 1: Pt100 @ 100 °C -> 138.51 Ohm
        val r1 = runCalc("rtd_pt100_pt1000", mapOf("input_val" to 100.0, "lead_ohm" to 0.0), mapOf("input_val" to "°C", "sensor_r0" to "Pt100 (100Ω)")).getOrThrow()
        assertEquals("138.51", r1.primaryValue)

        // Case 2: Pt100 @ 157.33 Ohm -> 150 °C
        val r2 = runCalc("rtd_pt100_pt1000", mapOf("input_val" to 157.33, "lead_ohm" to 0.0), mapOf("input_val" to "Ω", "sensor_r0" to "Pt100 (100Ω)")).getOrThrow()
        assertEquals("150.01", r2.primaryValue)

        // Case 3: Pt1000 @ -50 °C -> 803.06 Ohm & >850 °C rejected
        val r3 = runCalc("rtd_pt100_pt1000", mapOf("input_val" to -50.0, "lead_ohm" to 0.0), mapOf("input_val" to "°C", "sensor_r0" to "Pt1000 (1000Ω)")).getOrThrow()
        assertEquals("803.06", r3.primaryValue)
        assertTrue(runCalc("rtd_pt100_pt1000", mapOf("input_val" to 900.0, "lead_ohm" to 0.0), mapOf("input_val" to "°C")).isFailure)
    }

    @Test
    fun thermocoupleNist_3Cases() {
        // Case 1: Type K 11.209 mV @ 25°C CJC -> +1.000 = 12.209 mV -> exact 300.0 °C
        val r1 = runCalc("tc_mv_temp", mapOf("input_val" to 11.209, "cjc_temp" to 25.0), mapOf("tc_type" to "Type K", "input_val" to "mV")).getOrThrow()
        assertEquals("300", r1.primaryValue)

        // Case 2: Type K 500 °C @ 0°C CJC -> exact 20.644 mV
        val r2 = runCalc("tc_mv_temp", mapOf("input_val" to 500.0, "cjc_temp" to 0.0), mapOf("tc_type" to "Type K", "input_val" to "°C")).getOrThrow()
        assertEquals("20.644", r2.primaryValue)

        // Case 3: Type T above 400°C rejected
        val r3 = runCalc("tc_mv_temp", mapOf("input_val" to 600.0, "cjc_temp" to 25.0), mapOf("tc_type" to "Type T", "input_val" to "°C"))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun tempUnitConverter_3Cases() {
        // Case 1: 100 °C -> 212 °F
        val r1 = runCalc("temp_unit_converter", mapOf("temp" to 100.0), mapOf("temp" to "°C")).getOrThrow()
        assertEquals("100 °C", r1.primaryValue)
        assertEquals("/ 212 °F", r1.primaryUnit)

        // Case 2: 32 °F -> 0 °C
        val r2 = runCalc("temp_unit_converter", mapOf("temp" to 32.0), mapOf("temp" to "°F")).getOrThrow()
        assertEquals("0 °C", r2.primaryValue)

        // Case 3: Below absolute zero (-300 °C) rejected
        val r3 = runCalc("temp_unit_converter", mapOf("temp" to -300.0), mapOf("temp" to "°C"))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    // --- 8. PRESSURE, FLOW & LEVEL (4 Calculators x 3+ cases) ---

    @Test
    fun pflPressureConv_3Cases() {
        // Case 1: 6 bar -> 600 kPa
        val r1 = runCalc("pfl_pressure_conv", mapOf("pressure" to 6.0), mapOf("pressure" to "bar")).getOrThrow()
        assertEquals("6", r1.primaryValue)
        assertEquals("bar (600 kPa)", r1.primaryUnit)

        // Case 2: 14.5038 psi -> 1 bar
        val r2 = runCalc("pfl_pressure_conv", mapOf("pressure" to 14.5037738), mapOf("pressure" to "psi")).getOrThrow()
        assertEquals("1", r2.primaryValue)

        // Case 3: Below full vacuum (-2 bar) rejected
        val r3 = runCalc("pfl_pressure_conv", mapOf("pressure" to -2.0), mapOf("pressure" to "bar"))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun pflHydrostaticLevel_3Cases() {
        // Case 1: Open tank 0-5000mm SG 1.0 -> LRV=0, URV=5000
        val r1 = runCalc("pfl_hydrostatic_level", mapOf("max_height" to 5000.0, "sg_process" to 1.0, "wet_leg_h" to 0.0, "sg_seal" to 1.0, "cur_level" to 2500.0)).getOrThrow()
        assertEquals("0 .. 5000", r1.primaryValue)

        // Case 2: Wet-leg 5500mm SG 1.0, Tank 5000mm SG 0.85 -> LRV=-5500, Span=4250, URV=-1250
        val r2 = runCalc("pfl_hydrostatic_level", mapOf("max_height" to 5000.0, "sg_process" to 0.85, "wet_leg_h" to 5500.0, "sg_seal" to 1.0, "cur_level" to 2500.0)).getOrThrow()
        assertEquals("-5500 .. -1250", r2.primaryValue)

        // Case 3: Current level > max_height rejected
        val r3 = runCalc("pfl_hydrostatic_level", mapOf("max_height" to 5000.0, "sg_process" to 1.0, "wet_leg_h" to 0.0, "sg_seal" to 1.0, "cur_level" to 6000.0))
        assertTrue(r3.isFailure)
    }

    @Test
    fun pflPipeFlow_3Cases() {
        // Case 1: DN100 @ 2 m/s -> 56.55 m3/h
        val r1 = runCalc("pfl_pipe_flow", mapOf("diameter_mm" to 100.0, "vel_or_flow" to 2.0), mapOf("vel_or_flow" to "m/s")).getOrThrow()
        assertEquals("56.55", r1.primaryValue)

        // Case 2: DN100 @ 56.55 m3/h -> 2 m/s
        val r2 = runCalc("pfl_pipe_flow", mapOf("diameter_mm" to 100.0, "vel_or_flow" to 56.54867), mapOf("vel_or_flow" to "m³/h")).getOrThrow()
        assertEquals("2", r2.primaryValue)

        // Case 3: Zero pipe ID rejected
        val r3 = runCalc("pfl_pipe_flow", mapOf("diameter_mm" to 0.0, "vel_or_flow" to 2.0), mapOf("vel_or_flow" to "m/s"))
        assertTrue(r3.isFailure)
    }

    @Test
    fun pflReynolds_3Cases() {
        // Case 1: DN50, 1.8 m/s, water -> Re = 90000 (Turbulent)
        val r1 = runCalc("pfl_reynolds", mapOf("diameter_mm" to 50.0, "velocity" to 1.8, "density" to 1000.0, "viscosity_cp" to 1.0)).getOrThrow()
        assertEquals("90000", r1.primaryValue)
        assertEquals("Turbulent", r1.primaryUnit)

        // Case 2: Heavy oil (500 cP), DN50, 0.5 m/s -> Re = 50 (Laminar)
        val r2 = runCalc("pfl_reynolds", mapOf("diameter_mm" to 50.0, "velocity" to 0.5, "density" to 900.0, "viscosity_cp" to 500.0)).getOrThrow()
        assertEquals("Laminar", r2.primaryUnit)

        // Case 3: Zero viscosity rejected
        val r3 = runCalc("pfl_reynolds", mapOf("diameter_mm" to 50.0, "velocity" to 1.8, "density" to 1000.0, "viscosity_cp" to 0.0))
        assertTrue(r3.isFailure)
    }

    // --- 9. CABLE SIZE (2 Calculators x 3+ cases) ---

    @Test
    fun cableSizingAc_3Cases() {
        // Case 1: 42A, 415V, 90m, 3% drop, 3ph Cu -> A_drop=11.05 -> 16 mm2
        val r1 = runCalc("cable_sizing_ac", mapOf("current" to 42.0, "voltage" to 415.0, "length" to 90.0, "max_drop_pct" to 3.0), mapOf("cable_type" to "3φ Copper")).getOrThrow()
        assertEquals("16 mm²", r1.primaryValue)

        // Case 2: High current 700A -> suggests parallel runs (e.g., 2 x 240 mm2)
        val r2 = runCalc("cable_sizing_ac", mapOf("current" to 700.0, "voltage" to 415.0, "length" to 30.0, "max_drop_pct" to 3.0), mapOf("cable_type" to "3φ Copper")).getOrThrow()
        assertTrue(r2.primaryValue.contains("×"))

        // Case 3: Max drop > 15% rejected
        val r3 = runCalc("cable_sizing_ac", mapOf("current" to 42.0, "voltage" to 415.0, "length" to 90.0, "max_drop_pct" to 25.0), mapOf("cable_type" to "3φ Copper"))
        assertTrue(r3.exceptionOrNull() is BilingualValidationException)
    }

    @Test
    fun cableAmpacityDerate_3Cases() {
        // Case 1: 105 A * 0.87 * 0.75 = 68.5 A
        val r1 = runCalc("cable_ampacity_derate", mapOf("rated_amp" to 105.0, "k_temp" to 0.87, "k_group" to 0.75)).getOrThrow()
        assertEquals("68.5", r1.primaryValue)

        // Case 2: 200 A * 1.0 * 1.0 = 200 A
        val r2 = runCalc("cable_ampacity_derate", mapOf("rated_amp" to 200.0, "k_temp" to 1.0, "k_group" to 1.0)).getOrThrow()
        assertEquals("200", r2.primaryValue)

        // Case 3: Grouping factor > 1.0 rejected
        val r3 = runCalc("cable_ampacity_derate", mapOf("rated_amp" to 105.0, "k_temp" to 0.87, "k_group" to 1.5))
        assertTrue(r3.isFailure)
    }

    @Test
    fun searchSupportsEnglishHindiAndFormulas() {
        assertNotNull(CalculatorRegistry.getById("ma_pv_linear"))
        assertTrue(CalculatorRegistry.search("4-20mA").isNotEmpty())
        val fourToTwentyMatches = CalculatorRegistry.search("4-20 mA").map { it.id }.toSet()
        assertTrue(fourToTwentyMatches.containsAll(setOf("ma_pv_linear", "ma_dp_sqrt", "ma_loop_resistance")))
        assertTrue(CalculatorRegistry.search("4 20").any { it.id == "ma_pv_linear" })
        assertTrue(CalculatorRegistry.search("मोटर").any { it.category == CalculatorCategory.MOTOR })
        assertTrue(CalculatorRegistry.search("Pt100").any { it.id == "rtd_pt100_pt1000" })
    }

    @Test
    fun allCalculatorPresetsComputeCleanly() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            calc.presets.forEach { preset ->
                val values = calc.fields.associate { f ->
                    val raw = preset.values[f.id] ?: f.defaultValue
                    f.id to (raw.toDoubleOrNull() ?: 1.0)
                }
                val units = calc.fields.associate { f ->
                    f.id to (preset.units[f.id] ?: f.defaultUnit)
                }
                val output = calc.compute(values, units).getOrThrow()
                assertFalse("Empty primary value for ${calc.id} preset ${preset.label.en}", output.primaryValue.isBlank())
                assertFalse("Empty formula for ${calc.id} preset ${preset.label.en}", output.formulaUsed.isBlank())
                assertFalse("Empty substitutedFormula for ${calc.id} preset ${preset.label.en}", output.substitutedFormula.isBlank())
                assertNotNull("Missing resultExplanation for ${calc.id} preset ${preset.label.en}", output.resultExplanation)
                assertTrue("Missing steps for ${calc.id} preset ${preset.label.en}", output.steps.isNotEmpty())
            }
        }
    }

    @Test
    fun all29CalculatorsHaveBilingualPracticalExamples() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            val example = EngineeringExamples.forCalculator(calc.id)
            assertNotNull("Missing practical example for ${calc.id}", example)
            assertFalse("Blank EN practical example for ${calc.id}", example!!.en.isBlank())
            assertFalse("Blank HI practical example for ${calc.id}", example.hi.isBlank())
        }
    }

    @Test
    fun all29CalculatorsHandleInvalidAndZeroInputsSafely() {
        CalculatorRegistry.allCalculators.forEach { calc ->
            val defVals = calc.fields.associate { it.id to (it.defaultValue.toDoubleOrNull() ?: 1.0) }
            val defUnits = calc.fields.associate { it.id to it.defaultUnit }

            calc.fields.filterNot { it.isSelectorOnly }.forEach { field ->
                val nanRes = calc.compute(defVals + (field.id to Double.NaN), defUnits)
                assertTrue("NaN was not rejected for ${calc.id}.${field.id}", nanRes.isFailure)
                assertTrue(
                    "Expected BilingualValidationException for ${calc.id}.${field.id}",
                    nanRes.exceptionOrNull() is BilingualValidationException
                )

                val infRes = calc.compute(defVals + (field.id to Double.POSITIVE_INFINITY), defUnits)
                assertTrue("Infinity was not rejected for ${calc.id}.${field.id}", infRes.isFailure)

                val zeroRes = calc.compute(defVals + (field.id to 0.0), defUnits)
                zeroRes.onSuccess { out ->
                    assertFalse("NaN output on zero for ${calc.id}.${field.id}", out.primaryValue.contains("NaN"))
                    assertFalse("Infinity output on zero for ${calc.id}.${field.id}", out.primaryValue.contains("Infinity"))
                }
            }
        }
    }
}
