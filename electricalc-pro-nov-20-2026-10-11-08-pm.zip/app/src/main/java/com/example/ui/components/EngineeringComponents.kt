package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.theme.ActionRed
import com.example.ui.theme.CategoryCableSlate
import com.example.ui.theme.CategoryCableSlateDeep
import com.example.ui.theme.CategoryElectricalBlue
import com.example.ui.theme.CategoryElectricalBlueDeep
import com.example.ui.theme.CategoryInstrumentationTeal
import com.example.ui.theme.CategoryInstrumentationTealDeep
import com.example.ui.theme.CategoryMotorOrange
import com.example.ui.theme.CategoryMotorOrangeDeep
import com.example.ui.theme.CategoryPlcPurple
import com.example.ui.theme.CategoryPlcPurpleDeep
import com.example.ui.theme.CategoryProcessCyan
import com.example.ui.theme.CategoryProcessCyanDeep
import com.example.ui.theme.CategoryRtdCrimson
import com.example.ui.theme.CategoryRtdCrimsonDeep
import com.example.ui.theme.CategorySignalGreen
import com.example.ui.theme.CategorySignalGreenDeep
import com.example.ui.theme.CategoryVfdIndigo
import com.example.ui.theme.CategoryVfdIndigoDeep
import com.example.ui.theme.CleanSurfaceAlt
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightGreyBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftRedTint
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.sin

@Composable
fun LanguageToggleChip(
    language: AppLanguage,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    darkSurface: Boolean = false
) {
    val playClick = rememberTouchClickSound()
    val bg by animateColorAsState(
        targetValue = if (darkSurface) CleanSurfaceAlt else PureWhite,
        label = "langBg"
    )

    Surface(
        onClick = {
            playClick()
            onToggle()
        },
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(
            width = 1.dp,
            color = LightGreyBorder
        ),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("language_toggle_button")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Translate,
                contentDescription = if (language == AppLanguage.ENGLISH) {
                    "Switch language to Hindi"
                } else {
                    "भाषा बदलें"
                },
                tint = ActionRed,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = if (language == AppLanguage.ENGLISH) "EN | हिं" else "हिं | EN",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                ),
                color = TextPrimaryDark
            )
        }
    }
}

@Composable
fun BrandLogoBadge(
    size: Dp,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(percent = 14),
        color = PureWhite,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, LightGreyBorder)
    ) {
        Image(
            painter = painterResource(id = R.drawable.channel_logo),
            contentDescription = "Electrical & Instrumentation Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
        )
    }
}

@Composable
fun EngineeringHeroHeader(
    language: AppLanguage,
    totalCalculators: Int,
    onToggleLanguage: () -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(PureWhite)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Subtle Engineering Blueprint Watermark on Clean White Header
            Canvas(modifier = Modifier.matchParentSize()) {
                val step = 28.dp.toPx()
                val gridColor = HairlineGrey.copy(alpha = 0.55f)
                var x = 0f
                while (x < size.width) {
                    drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }

                val arcRadius = 72.dp.toPx()
                val center = Offset(size.width - 28.dp.toPx(), size.height * 0.65f)
                drawArc(
                    color = ActionRed.copy(alpha = 0.08f),
                    startAngle = 150f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = Offset(center.x - arcRadius, center.y - arcRadius),
                    size = androidx.compose.ui.geometry.Size(arcRadius * 2, arcRadius * 2),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )

                val wavePath = Path()
                val amp = 8.dp.toPx()
                val baseY = size.height - 14.dp.toPx()
                wavePath.moveTo(0f, baseY)
                var wx = 0f
                while (wx <= size.width) {
                    val wy = baseY + sin(wx / 36f) * amp
                    wavePath.lineTo(wx, wy)
                    wx += 8f
                }
                drawPath(
                    path = wavePath,
                    color = LightGreyBorder.copy(alpha = 0.45f),
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = CleanSurfaceAlt,
                        contentColor = TextPrimaryDark,
                        border = BorderStroke(1.dp, LightGreyBorder)
                    ) {
                        Text(
                            text = if (language == AppLanguage.ENGLISH) {
                                "PRO SUITE • $totalCalculators TOOLS"
                            } else {
                                "प्रो सूट • $totalCalculators टूल्स"
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = {
                                playClick()
                                onOpenAbout()
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("about_us_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = if (language == AppLanguage.ENGLISH) {
                                    "About Us & Developer"
                                } else {
                                    "हमारे बारे में"
                                },
                                tint = TextPrimaryDark
                            )
                        }

                        LanguageToggleChip(
                            language = language,
                            onToggle = onToggleLanguage,
                            darkSurface = false
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BrandLogoBadge(
                        size = 54.dp,
                        modifier = Modifier.testTag("home_brand_logo")
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Electrical & Instrumentation",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = ActionRed,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.4.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (language == AppLanguage.ENGLISH) {
                                "Electrical & Instrument\nCalculator"
                            } else {
                                "इलेक्ट्रिकल एवं इंस्ट्रूमेंट\nकैलकुलेटर"
                            },
                            style = MaterialTheme.typography.headlineMedium.copy(
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 21.sp,
                                lineHeight = 25.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (language == AppLanguage.ENGLISH) {
                        "Fast & accurate field calculations for engineers & technicians"
                    } else {
                        "इंजीनियरों और टेक्नीशियनों के लिए तेज़ व सटीक फील्ड गणनाएँ"
                    },
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondaryDark
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        HorizontalDivider(color = HairlineGrey)
    }
}

private data class CategoryCardPalette(
    val startColor: Color,
    val endColor: Color
)

private fun categoryCardPalette(category: CalculatorCategory): CategoryCardPalette = when (category) {
    CalculatorCategory.ELECTRICAL -> CategoryCardPalette(
        startColor = CategoryElectricalBlue,
        endColor = CategoryElectricalBlueDeep
    )
    CalculatorCategory.INSTRUMENTATION -> CategoryCardPalette(
        startColor = CategoryInstrumentationTeal,
        endColor = CategoryInstrumentationTealDeep
    )
    CalculatorCategory.MOTOR -> CategoryCardPalette(
        startColor = CategoryMotorOrange,
        endColor = CategoryMotorOrangeDeep
    )
    CalculatorCategory.VFD -> CategoryCardPalette(
        startColor = CategoryVfdIndigo,
        endColor = CategoryVfdIndigoDeep
    )
    CalculatorCategory.PLC_DCS -> CategoryCardPalette(
        startColor = CategoryPlcPurple,
        endColor = CategoryPlcPurpleDeep
    )
    CalculatorCategory.SIGNAL_4_20MA -> CategoryCardPalette(
        startColor = CategorySignalGreen,
        endColor = CategorySignalGreenDeep
    )
    CalculatorCategory.RTD_THERMOCOUPLE -> CategoryCardPalette(
        startColor = CategoryRtdCrimson,
        endColor = CategoryRtdCrimsonDeep
    )
    CalculatorCategory.PRESSURE_FLOW_LEVEL -> CategoryCardPalette(
        startColor = CategoryProcessCyan,
        endColor = CategoryProcessCyanDeep
    )
    CalculatorCategory.CABLE_SIZE -> CategoryCardPalette(
        startColor = CategoryCableSlate,
        endColor = CategoryCableSlateDeep
    )
}

@Composable
fun CategoryGridCard(
    category: CalculatorCategory,
    calculatorCount: Int,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()
    val palette = categoryCardPalette(category)

    Card(
        onClick = {
            playClick()
            onClick()
        },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 114.dp)
            .testTag("category_card_${category.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = palette.startColor
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 3.dp,
            pressedElevation = 1.dp
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 114.dp)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(palette.startColor, palette.endColor)
                    )
                )
        ) {
            // Subtle architectural watermark accent on card edge
            Canvas(modifier = Modifier.matchParentSize()) {
                drawCircle(
                    color = PureWhite.copy(alpha = 0.08f),
                    radius = size.height * 0.62f,
                    center = Offset(size.width - 14.dp.toPx(), size.height * 0.25f)
                )
                drawCircle(
                    color = PureWhite.copy(alpha = 0.05f),
                    radius = size.height * 0.42f,
                    center = Offset(size.width - 42.dp.toPx(), size.height * 0.92f)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = PureWhite.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.28f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.title.get(language),
                            tint = PureWhite,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = category.title.get(language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 19.sp,
                            lineHeight = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.2).sp
                        ),
                        color = PureWhite,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = category.description.get(language),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.5.sp,
                            lineHeight = 18.sp
                        ),
                        color = PureWhite.copy(alpha = 0.92f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = PureWhite.copy(alpha = 0.20f),
                        border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.30f))
                    ) {
                        Text(
                            text = if (language == AppLanguage.ENGLISH) {
                                "$calculatorCount Tools"
                            } else {
                                "$calculatorCount टूल्स"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            color = PureWhite,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(PureWhite.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = PureWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorListCard(
    calculator: CalculatorDefinition,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playClick = rememberTouchClickSound()

    Card(
        onClick = {
            playClick()
            onClick()
        },
        modifier = modifier
            .fillMaxWidth()
            .testTag("calc_card_${calculator.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, LightGreyBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SoftRedTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = calculator.category.icon,
                    contentDescription = calculator.title.get(language),
                    tint = ActionRed,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = calculator.title.get(language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = calculator.subtitle.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CleanSurfaceAlt),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = TextPrimaryDark,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
