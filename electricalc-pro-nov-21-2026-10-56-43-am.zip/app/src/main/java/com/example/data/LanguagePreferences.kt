package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.EngineeringDiscipline
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ei_calculator_prefs")

class LanguagePreferences(private val context: Context) {

    private val languageKey = stringPreferencesKey("app_language")
    private val favoriteIdsKey = stringSetPreferencesKey("favorite_calc_ids")
    private val touchSoundKey = booleanPreferencesKey("touch_sound_enabled")
    private val defaultDisciplineKey = stringPreferencesKey("default_discipline")

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        when (prefs[languageKey]) {
            AppLanguage.HINDI.name -> AppLanguage.HINDI
            else -> AppLanguage.ENGLISH
        }
    }

    val favoriteIdsFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[favoriteIdsKey] ?: emptySet()
    }

    val touchSoundEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[touchSoundKey] ?: true
    }

    val defaultDisciplineFlow: Flow<EngineeringDiscipline> = context.dataStore.data.map { prefs ->
        when (prefs[defaultDisciplineKey]) {
            EngineeringDiscipline.INSTRUMENTATION.name -> EngineeringDiscipline.INSTRUMENTATION
            else -> EngineeringDiscipline.ELECTRICAL
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[languageKey] = language.name
        }
    }

    suspend fun toggleFavorite(calculatorId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[favoriteIdsKey] ?: emptySet()
            prefs[favoriteIdsKey] = if (calculatorId in current) {
                current - calculatorId
            } else {
                current + calculatorId
            }
        }
    }

    suspend fun clearFavorites() {
        context.dataStore.edit { prefs ->
            prefs[favoriteIdsKey] = emptySet()
        }
    }

    suspend fun setTouchSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[touchSoundKey] = enabled
        }
    }

    suspend fun setDefaultDiscipline(discipline: EngineeringDiscipline) {
        context.dataStore.edit { prefs ->
            prefs[defaultDisciplineKey] = discipline.name
        }
    }
}
