package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.ui.components.CalculatorListCard
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueHeaderEnd
import com.example.ui.theme.RoyalBlueHeaderStart
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun FavoriteScreen(
    favoriteIds: Set<String>,
    language: AppLanguage,
    onToggleLanguage: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onOpenCalculator: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val favoriteCalculators = remember(favoriteIds) {
        CalculatorRegistry.allCalculators.filter { it.id in favoriteIds }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .align(Alignment.TopCenter)
                .testTag("favorite_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(RoyalBlueHeaderStart, RoyalBlueHeaderEnd)
                            )
                        )
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "Favorite Calculators"
                                } else {
                                    "पसंदीदा कैलकुलेटर"
                                },
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 21.sp
                                ),
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "${favoriteCalculators.size} saved engineering tools"
                                } else {
                                    "${favoriteCalculators.size} सहेजे गए इंजीनियरिंग टूल्स"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.88f)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = PureWhite.copy(alpha = 0.18f),
                                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.35f))
                            ) {
                                Text(
                                    text = "${favoriteCalculators.size}",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            LanguageToggleChip(
                                language = language,
                                onToggle = onToggleLanguage,
                                darkSurface = true
                            )
                        }
                    }
                }
            }

            if (favoriteCalculators.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("favorite_empty_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                        border = BorderStroke(1.dp, LightBlueBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                modifier = Modifier.size(60.dp),
                                shape = RoundedCornerShape(16.dp),
                                color = RoyalBlueTint,
                                border = BorderStroke(1.dp, LightBlueBorder)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.StarOutline,
                                        contentDescription = null,
                                        tint = RoyalBlue,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "No Favorite Calculators Yet"
                                } else {
                                    "अभी कोई पसंदीदा कैलकुलेटर नहीं है"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = DarkNavyBlue,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "Tap the star icon on any Electrical or Instrumentation calculator card to pin it here for quick field access."
                                } else {
                                    "किसी भी इलेक्ट्रिकल या इंस्ट्रूमेंटेशन कैलकुलेटर कार्ड पर स्टार आइकन दबाकर उसे त्वरित उपयोग के लिए यहाँ पिन करें।"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(favoriteCalculators, key = { it.id }) { calc ->
                    CalculatorListCard(
                        calculator = calc,
                        language = langOrDefault(language),
                        isFavorite = true,
                        onToggleFavorite = { onToggleFavorite(calc.id) },
                        showCategoryTag = true,
                        onClick = { onOpenCalculator(calc.id) },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        }
    }
}

private fun langOrDefault(language: AppLanguage): AppLanguage = language
