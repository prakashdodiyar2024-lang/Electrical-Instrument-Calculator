package com.example.ui.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import android.os.SystemClock
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import com.example.R

interface TouchSoundPlayer {
    fun playClick()
}

val LocalTouchSoundPlayer = staticCompositionLocalOf<TouchSoundPlayer?> { null }

@Composable
fun rememberTouchClickSound(): () -> Unit {
    val injectedPlayer = LocalTouchSoundPlayer.current
    val appContext = LocalContext.current.applicationContext
    val player = remember(injectedPlayer, appContext) {
        injectedPlayer ?: TouchSoundController.getOrCreate(appContext)
    }
    return remember(player) { { player.playClick() } }
}

internal object TouchSoundDebounce {
    // Greater than the 55 ms click duration so previous clicks finish naturally without stopping early or overlapping
    const val MIN_CLICK_INTERVAL_MS = 85L

    fun shouldPlay(
        nowElapsedMs: Long,
        lastPlayElapsedMs: Long,
        minIntervalMs: Long = MIN_CLICK_INTERVAL_MS
    ): Boolean {
        if (lastPlayElapsedMs <= 0L) return true
        return (nowElapsedMs - lastPlayElapsedMs) >= minIntervalMs
    }
}

object TouchSoundController {
    @Volatile
    private var instance: AndroidTouchSoundPlayer? = null

    fun getOrCreate(context: Context): TouchSoundPlayer {
        instance?.let { return it }
        return synchronized(this) {
            instance ?: AndroidTouchSoundPlayer(context.applicationContext).also {
                instance = it
            }
        }
    }
}

class AndroidTouchSoundPlayer(
    context: Context,
    private val clockMs: () -> Long = { SystemClock.elapsedRealtime() },
    soundPoolFactory: (() -> SoundPool)? = null
) : TouchSoundPlayer {

    private val appContext = context.applicationContext
    private var soundPool: SoundPool? = null
    private var staticFallbackTrack: AudioTrack? = null

    @Volatile
    var soundId: Int = 0
        private set

    @Volatile
    var isSoundLoaded: Boolean = false
        private set

    @Volatile
    private var loadFailed: Boolean = false

    @Volatile
    private var pendingPlayOnLoad: Boolean = false

    @Volatile
    var lastPlayElapsedMs: Long = 0L
        private set

    @Volatile
    var lastStreamId: Int = 0
        private set

    @Volatile
    var playInvocations: Int = 0
        private set

    private val lock = Any()

    init {
        runCatching {
            val pool = soundPoolFactory?.invoke() ?: buildMediaSoundPool()
            pool.setOnLoadCompleteListener { _, sampleId, status ->
                val shouldPlayNow: Boolean
                synchronized(lock) {
                    if (sampleId == soundId && status == 0) {
                        isSoundLoaded = true
                        loadFailed = false
                        shouldPlayNow = pendingPlayOnLoad
                        pendingPlayOnLoad = false
                    } else {
                        loadFailed = true
                        shouldPlayNow = pendingPlayOnLoad
                        pendingPlayOnLoad = false
                        Log.w(TAG, "SoundPool load failed sampleId=$sampleId status=$status")
                    }
                }
                if (shouldPlayNow) {
                    playInternal(allowQueueIfUnloaded = false)
                }
            }
            synchronized(lock) {
                soundPool = pool
                val loadedId = pool.load(appContext, R.raw.soft_touch_click, 1)
                soundId = loadedId
                if (loadedId == 0) {
                    loadFailed = true
                    Log.w(TAG, "SoundPool.load returned 0 for R.raw.soft_touch_click")
                }
            }
        }.onFailure { err ->
            loadFailed = true
            Log.w(TAG, "Failed to initialize SoundPool, fallback enabled", err)
        }
    }

    override fun playClick() {
        playInternal(allowQueueIfUnloaded = true)
    }

    private fun playInternal(allowQueueIfUnloaded: Boolean) {
        val now = clockMs()
        synchronized(lock) {
            if (!TouchSoundDebounce.shouldPlay(now, lastPlayElapsedMs)) {
                return
            }
            val pool = soundPool
            if (pool != null && soundId != 0 && isSoundLoaded) {
                lastPlayElapsedMs = now
                val streamId = runCatching {
                    pool.play(
                        soundId,
                        SOFT_CLICK_VOLUME,
                        SOFT_CLICK_VOLUME,
                        1,
                        0,
                        1.0f
                    )
                }.getOrDefault(0)
                if (streamId != 0) {
                    lastStreamId = streamId
                    playInvocations += 1
                    return
                }
            } else if (!loadFailed && pool != null && soundId != 0 && allowQueueIfUnloaded) {
                // Queue so the very first tap right after app launch plays as soon as loading completes
                pendingPlayOnLoad = true
                return
            }

            // Fallback to static PCM AudioTrack if SoundPool hasn't finished or failed on device
            lastPlayElapsedMs = now
            if (playStaticFallbackTrack()) {
                playInvocations += 1
            }
        }
    }

    private fun playStaticFallbackTrack(): Boolean {
        return runCatching {
            val track = staticFallbackTrack ?: buildStaticAudioTrack()?.also {
                staticFallbackTrack = it
            } ?: return false
            if (track.state != AudioTrack.STATE_INITIALIZED) return false
            if (track.playState != AudioTrack.PLAYSTATE_STOPPED) {
                track.stop()
            }
            track.reloadStaticData()
            track.setVolume(SOFT_CLICK_VOLUME)
            track.play()
            true
        }.getOrDefault(false)
    }

    private fun buildMediaSoundPool(): SoundPool {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        return SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(attrs)
            .build()
    }

    private fun buildStaticAudioTrack(): AudioTrack? {
        val wavBytes = appContext.resources.openRawResource(R.raw.soft_touch_click).use { it.readBytes() }
        if (wavBytes.size <= WAV_HEADER_BYTES) return null
        val pcmBytes = wavBytes.copyOfRange(WAV_HEADER_BYTES, wavBytes.size)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val format = AudioFormat.Builder()
            .setSampleRate(SAMPLE_RATE_HZ)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        return AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setBufferSizeInBytes(pcmBytes.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
            .apply {
                write(pcmBytes, 0, pcmBytes.size)
            }
    }

    fun release() {
        synchronized(lock) {
            runCatching { soundPool?.release() }
            runCatching { staticFallbackTrack?.release() }
            soundPool = null
            staticFallbackTrack = null
            soundId = 0
            isSoundLoaded = false
            pendingPlayOnLoad = false
            lastStreamId = 0
        }
    }

    private companion object {
        const val TAG = "TouchSoundPlayer"
        const val SOFT_CLICK_VOLUME = 0.85f
        const val WAV_HEADER_BYTES = 44
        const val SAMPLE_RATE_HZ = 44100
    }
}
