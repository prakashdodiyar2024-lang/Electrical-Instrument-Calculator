package com.example.domain

import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculationOutput
import com.example.model.CalculationStep
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.CalculatorPreset
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireEvenPoles
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

object ElectricalMotorCalculators {

    val all: List<CalculatorDefinition> = listOf(
        ohmsLawCalculator(),
        threePhasePowerCalculator(),
        powerFactorCorrectionCalculator(),
        voltageDropCalculator(),
        motorFlcCalculator(),
        motorSpeedSlipCalculator(),
        motorStarterSizingCalculator(),
        motorTorqueCalculator()
    )

    private fun ohmsLawCalculator() = CalculatorDefinition(
        id = "elec_ohms_power",
        category = CalculatorCategory.ELECTRICAL,
        title = BilingualText("Ohm's Law & DC/1-Ph Power", "ओम का नियम व DC/1-फेज़ पावर"),
        subtitle = BilingualText(
            "Find Resistance (Ω), Active Power (W/kW), Apparent VA & Conductance",
            "वोल्टेज और करंट से रेजिस्टेंस (Ω), एक्टिव पावर (W/kW) और VA निकालें"
        ),
        formulaPreview = "R = V / I  |  P = V × I × cos φ",
        keywords = listOf("ohm", "voltage", "current", "resistance", "watt", "power", "ओम", "वोल्टेज", "करंट"),
        fields = listOf(
            CalculatorField(
                id = "voltage",
                label = BilingualText("Voltage (V)", "वोल्टेज (V)"),
                defaultValue = "230",
                defaultUnit = "V",
                unitOptions = listOf("V", "mV", "kV")
            ),
            CalculatorField(
                id = "current",
                label = BilingualText("Current (I)", "करंट (I)"),
                defaultValue = "10",
                defaultUnit = "A",
                unitOptions = listOf("A", "mA")
            ),
            CalculatorField(
                id = "pf",
                label = BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"),
                defaultValue = "1.0",
                defaultUnit = "cos φ",
                helperText = BilingualText("0.1 to 1.0 (Use 1.0 for DC or heater)", "0.1 से 1.0 (DC या हीटर के लिए 1.0 रखें)")
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("24V DC Relay Coil", "24V DC रिले कॉइल"),
                values = mapOf("voltage" to "24", "current" to "50", "pf" to "1.0"),
                units = mapOf("voltage" to "V", "current" to "mA")
            ),
            CalculatorPreset(
                label = BilingualText("230V 1-Ph Heater", "230V 1-फेज़ हीटर"),
                values = mapOf("voltage" to "230", "current" to "8.7", "pf" to "1.0"),
                units = mapOf("voltage" to "V", "current" to "A")
            )
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val rawI = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))

                val v = when (units["voltage"]) {
                    "mV" -> rawV / 1000.0
                    "kV" -> rawV * 1000.0
                    else -> rawV
                }
                val i = when (units["current"]) {
                    "mA" -> rawI / 1000.0
                    else -> rawI
                }

                val r = v / i
                val pWatts = v * i * pf
                val va = v * i
                val pKw = pWatts / 1000.0
                val varReactive = sqrt((va * va - pWatts * pWatts).coerceAtLeast(0.0))

                val primaryStr = if (pWatts >= 1000.0) formatEng(pKw, 3) else formatEng(pWatts, 2)
                val primaryUnitStr = if (pWatts >= 1000.0) "kW" else "W"

                CalculationOutput(
                    primaryLabel = BilingualText("Active Power (P)", "एक्टिव पावर (P)"),
                    primaryValue = primaryStr,
                    primaryUnit = primaryUnitStr,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Impedance / R", "रेजिस्टेंस (R)"), formatEng(r, 2), "Ω"),
                        SecondaryMetric(BilingualText("Apparent Power", "अपैरेंट पावर"), formatEng(va, 2), "VA"),
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), formatEng(varReactive, 2), "VAR")
                    ),
                    formulaUsed = "R = V / I   |   S = V × I   |   P = V × I × cos(φ)",
                    substitutedFormula = "R = ${formatEng(v, 3)} / ${formatEng(i, 4)}   |   P = ${formatEng(v, 3)} × ${formatEng(i, 4)} × ${formatEng(pf, 2)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert to Base SI Units", "SI यूनिट (V और A) में बदलें"),
                            "V = ${formatEng(rawV, 3)} ${units["voltage"] ?: "V"} = ${formatEng(v, 3)} V,  I = ${formatEng(rawI, 4)} ${units["current"] ?: "A"} = ${formatEng(i, 4)} A",
                            BilingualText(
                                "Normalize voltage to Volts (V) and current to Amperes (A) before applying Ohm's Law.",
                                "ओम का नियम लगाने से पहले वोल्टेज को वोल्ट (V) और करंट को एम्पियर (A) में बदलें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Calculate Circuit Resistance / Impedance (R = V / I)", "रेजिस्टेंस / इम्पीडेंस निकालें (R = V / I)"),
                            "R = ${formatEng(v, 3)} / ${formatEng(i, 4)} = ${formatEng(r, 2)} Ω",
                            BilingualText(
                                "Divide voltage by current using Ohm's Law (represents impedance Z in AC circuits).",
                                "वोल्टेज को करंट से भाग देकर सर्किट रेजिस्टेंस (AC में इम्पीडेंस Z) प्राप्त करें।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Apparent Power (S = V × I)", "अपैरेंट पावर निकालें (S = V × I)"),
                            "S = ${formatEng(v, 3)} × ${formatEng(i, 4)} = ${formatEng(va, 2)} VA",
                            BilingualText(
                                "Multiply RMS voltage and current to obtain total apparent volt-amperes.",
                                "वोल्टेज और करंट को गुणा करके कुल अपैरेंट पावर (VA) निकालें।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Multiply by Power Factor for Active Power", "पावर फैक्टर से गुणा कर एक्टिव पावर निकालें"),
                            "P = ${formatEng(va, 2)} × ${formatEng(pf, 2)} = ${formatEng(pWatts, 2)} W (${formatEng(pKw, 3)} kW)  |  Q = ${formatEng(varReactive, 2)} VAR",
                            BilingualText(
                                "Active power is P = S × cos(φ); reactive power is Q = √(S² − P²).",
                                "एक्टिव पावर P = S × cos(φ) और रिएक्टिव पावर Q = √(S² − P²) होती है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        if (pf >= 0.999) {
                            "With cos(φ) = 1.0 (purely resistive/DC), all ${formatEng(va, 2)} VA converts directly into $primaryStr $primaryUnitStr across ${formatEng(r, 2)} Ω."
                        } else {
                            "At PF = ${formatEng(pf, 2)}, the load draws $primaryStr $primaryUnitStr of real power and ${formatEng(varReactive, 2)} VAR reactive power (effective Z = ${formatEng(r, 2)} Ω)."
                        },
                        if (pf >= 0.999) {
                            "cos(φ) = 1.0 (DC/रेजिस्टिव लोड) पर पूरी ${formatEng(va, 2)} VA पावर सीधे ${formatEng(r, 2)} Ω लोड में $primaryStr $primaryUnitStr के रूप में उपयोग होती है।"
                        } else {
                            "PF = ${formatEng(pf, 2)} पर लोड $primaryStr $primaryUnitStr वास्तविक पावर और ${formatEng(varReactive, 2)} VAR रिएक्टिव पावर लेता है (कुल Z = ${formatEng(r, 2)} Ω)।"
                        }
                    ),
                    assumptions = BilingualText(
                        "Assumes steady-state DC (cos φ = 1.0) or sinusoidal single-phase AC RMS values.",
                        "मान्यता: स्थिर DC (cos φ = 1.0) या साइनूसॉइडल सिंगल-फेज़ AC RMS मान।"
                    ),
                    engineeringNote = BilingualText(
                        "For DC circuits, power factor cos(φ) is always 1.0.",
                        "DC सर्किट में पावर फैक्टर cos(φ) हमेशा 1.0 होता है।"
                    )
                )
            }
        }
    )

    private fun threePhasePowerCalculator() = CalculatorDefinition(
        id = "elec_3phase_power",
        category = CalculatorCategory.ELECTRICAL,
        title = BilingualText("3-Phase AC Power & Current", "3-फेज़ AC पावर और करंट"),
        subtitle = BilingualText(
            "Calculate Active kW, Apparent kVA, Reactive kVAR & Phase Voltage",
            "3-फेज़ सिस्टम में एक्टिव kW, अपैरेंट kVA और रिएक्टिव kVAR निकालें"
        ),
        formulaPreview = "P = √3 × V_L × I_L × cos φ",
        keywords = listOf("3 phase", "three phase", "kva", "kw", "kvar", "415v", "पावर", "तीन फेज़"),
        fields = listOf(
            CalculatorField(
                id = "line_voltage",
                label = BilingualText("Line-to-Line Voltage (V_L)", "लाइन वोल्टेज (V_L)"),
                defaultValue = "415",
                defaultUnit = "V",
                unitOptions = listOf("V", "kV")
            ),
            CalculatorField(
                id = "line_current",
                label = BilingualText("Line Current (I_L)", "लाइन करंट (I_L)"),
                defaultValue = "35",
                defaultUnit = "A"
            ),
            CalculatorField(
                id = "pf",
                label = BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"),
                defaultValue = "0.85",
                defaultUnit = "cos φ",
                helperText = BilingualText("Range: 0.1 to 1.0", "सीमा: 0.1 से 1.0")
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("415V MCC Feeder (50A)", "415V पैनल फीडर (50A)"),
                values = mapOf("line_voltage" to "415", "line_current" to "50", "pf" to "0.85"),
                units = mapOf("line_voltage" to "V")
            ),
            CalculatorPreset(
                label = BilingualText("11 kV HT Feeder (80A)", "11 kV HT फीडर (80A)"),
                values = mapOf("line_voltage" to "11", "line_current" to "80", "pf" to "0.92"),
                units = mapOf("line_voltage" to "kV")
            )
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["line_voltage"], BilingualText("Line Voltage", "लाइन वोल्टेज"))
                val i = requirePositive(values["line_current"], BilingualText("Line Current", "लाइन करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val v = if (units["line_voltage"] == "kV") rawV * 1000.0 else rawV

                val sqrt3 = sqrt(3.0)
                val sKva = (sqrt3 * v * i) / 1000.0
                val pKw = sKva * pf
                val sinPhi = sqrt((1.0 - pf * pf).coerceAtLeast(0.0))
                val qKvar = sKva * sinPhi
                val vPhase = v / sqrt3

                CalculationOutput(
                    primaryLabel = BilingualText("3-Phase Active Power (kW)", "3-फेज़ एक्टिव पावर (kW)"),
                    primaryValue = formatEng(pKw, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Apparent Power", "अपैरेंट पावर"), formatEng(sKva, 2), "kVA"),
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), formatEng(qKvar, 2), "kVAR"),
                        SecondaryMetric(BilingualText("Phase Voltage (L-N)", "फेज़ वोल्टेज (L-N)"), formatEng(vPhase, 1), "V")
                    ),
                    formulaUsed = "S = (√3 × V_L × I_L) / 1000   |   P = S × cos(φ)   |   Q = S × sin(φ)",
                    substitutedFormula = "S = (1.732 × ${formatEng(v, 1)} × ${formatEng(i, 2)}) / 1000   |   P = ${formatEng(sKva, 2)} × ${formatEng(pf, 2)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Normalize Line Voltage & Find Phase Voltage", "लाइन वोल्टेज और फेज़ वोल्टेज निकालें"),
                            "V_L = ${formatEng(v, 1)} V  →  V_ph = ${formatEng(v, 1)} / 1.732 = ${formatEng(vPhase, 1)} V",
                            BilingualText(
                                "Convert voltage to Volts and divide by √3 (1.732) to get Star (L-N) phase voltage.",
                                "वोल्टेज को V में बदलें; स्टार सिस्टम में L-N फेज़ वोल्टेज निकालने के लिए √3 से भाग दें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Calculate Apparent Power (kVA)", "अपैरेंट पावर (kVA) निकालें"),
                            "S = (1.732 × ${formatEng(v, 1)} × ${formatEng(i, 2)}) / 1000 = ${formatEng(sKva, 2)} kVA",
                            BilingualText(
                                "Multiply √3 × Line Voltage × Line Current and divide by 1000 for total kVA.",
                                "√3, लाइन वोल्टेज और लाइन करंट को गुणा करके 1000 से भाग देने पर kVA मिलता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Active Power (kW)", "एक्टिव पावर (kW) निकालें"),
                            "P = ${formatEng(sKva, 2)} × ${formatEng(pf, 2)} = ${formatEng(pKw, 2)} kW",
                            BilingualText(
                                "Multiply apparent power (kVA) by power factor cos(φ) to get real useful work in kW.",
                                "kVA को पावर फैक्टर cos(φ) से गुणा करने पर वास्तविक उपयोगी पावर (kW) मिलती है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Calculate Reactive Power (kVAR)", "रिएक्टिव पावर (kVAR) निकालें"),
                            "sin(φ) = √(1 − ${formatEng(pf, 2)}²) = ${formatEng(sinPhi, 3)}  →  Q = ${formatEng(sKva, 2)} × ${formatEng(sinPhi, 3)} = ${formatEng(qKvar, 2)} kVAR",
                            BilingualText(
                                "Compute sin(φ) from cos(φ) and multiply by kVA for inductive magnetizing power.",
                                "cos(φ) से sin(φ) निकालकर kVA में गुणा करने पर रिएक्टिव पावर (kVAR) मिलती है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "The 3-phase feeder carries ${formatEng(sKva, 2)} kVA total load, delivering ${formatEng(pKw, 2)} kW active power and ${formatEng(qKvar, 2)} kVAR reactive power.",
                        "यह 3-फेज़ फीडर कुल ${formatEng(sKva, 2)} kVA लोड वहन कर रहा है, जिसमें ${formatEng(pKw, 2)} kW वास्तविक पावर और ${formatEng(qKvar, 2)} kVAR रिएक्टिव पावर है।"
                    ),
                    assumptions = BilingualText(
                        "Assumes balanced 3-phase sinusoidal system; Phase Voltage (V_L / √3) applies to Star (Wye) connection.",
                        "मान्यता: संतुलित 3-फेज़ सिस्टम; फेज़ वोल्टेज (V_L / √3) स्टार (Wye) कनेक्शन पर लागू होता है।"
                    ),
                    engineeringNote = BilingualText(
                        "Phase-to-Neutral voltage for a balanced 415V star system is 415 / 1.732 ≈ 240V.",
                        "415V स्टार सिस्टम में फेज़ से न्यूट्रल वोल्टेज 415 / 1.732 ≈ 240V होता है।"
                    )
                )
            }
        }
    )

    private fun powerFactorCorrectionCalculator() = CalculatorDefinition(
        id = "elec_pf_capacitor",
        category = CalculatorCategory.ELECTRICAL,
        title = BilingualText("PF Capacitor Bank (kVAR)", "पावर फैक्टर सुधार कैपेसिटर (kVAR)"),
        subtitle = BilingualText(
            "Required Capacitor kVAR, Delta Capacitance (µF) & Current Reduction",
            "पावर फैक्टर सुधारने के लिए जरूरी कैपेसिटर बैंक (kVAR) और µF निकालें"
        ),
        formulaPreview = "Qc = P × (tan φ₁ − tan φ₂)",
        keywords = listOf("power factor", "capacitor", "kvar", "apfc", "pf", "कैपेसिटर", "पावर फैक्टर"),
        fields = listOf(
            CalculatorField("load_kw", BilingualText("Active Load (kW)", "एक्टिव लोड (kW)"), "100", "kW"),
            CalculatorField("existing_pf", BilingualText("Existing PF (cos φ₁)", "वर्तमान PF (cos φ₁)"), "0.75", "cos φ"),
            CalculatorField("target_pf", BilingualText("Target PF (cos φ₂)", "लक्ष्य PF (cos φ₂)"), "0.98", "cos φ"),
            CalculatorField("voltage", BilingualText("System Line Voltage", "सिस्टम वोल्टेज"), "415", "V")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("100 kW Plant (0.75 → 0.98)", "100 kW प्लांट (0.75 → 0.98)"),
                values = mapOf("load_kw" to "100", "existing_pf" to "0.75", "target_pf" to "0.98", "voltage" to "415")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val pKw = requirePositive(values["load_kw"], BilingualText("Active Load", "एक्टिव लोड"))
                val pf1 = requireRange(values["existing_pf"], 0.1, 0.999, BilingualText("Existing PF", "वर्तमान PF"))
                val pf2 = requireRange(values["target_pf"], 0.1, 1.0, BilingualText("Target PF", "लक्ष्य PF"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))

                if (pf2 <= pf1) {
                    throw BilingualValidationException(
                        BilingualText(
                            "Target PF must be higher than Existing PF.",
                            "लक्ष्य PF (Target PF) वर्तमान PF से अधिक होना चाहिए।"
                        )
                    )
                }

                val tan1 = tan(acos(pf1))
                val tan2 = tan(acos(pf2))
                val qcKvar = pKw * (tan1 - tan2)
                val capCurrent = (qcKvar * 1000.0) / (sqrt(3.0) * v)
                val iBefore = (pKw * 1000.0) / (sqrt(3.0) * v * pf1)
                val iAfter = (pKw * 1000.0) / (sqrt(3.0) * v * pf2)
                // 3-phase Delta capacitance per phase at 50 Hz: C_uF = (Qc_var / (3 * 2 * pi * f * V_L^2)) * 1e6
                val capDeltaUf = (qcKvar * 1e9) / (3.0 * 2.0 * PI * 50.0 * v * v)

                val deltaTan = tan1 - tan2
                val iSaved = iBefore - iAfter

                CalculationOutput(
                    primaryLabel = BilingualText("Required Capacitor Bank", "आवश्यक कैपेसिटर बैंक"),
                    primaryValue = formatEng(qcKvar, 2),
                    primaryUnit = "kVAR",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Capacitor Current", "कैपेसिटर करंट"), formatEng(capCurrent, 1), "A"),
                        SecondaryMetric(BilingualText("Delta Cap (50Hz)", "डेल्टा कैपेसिटेंस"), formatEng(capDeltaUf, 1), "µF/ph"),
                        SecondaryMetric(BilingualText("Current Before", "पहले का करंट"), formatEng(iBefore, 1), "A"),
                        SecondaryMetric(BilingualText("Current After", "सुधार के बाद करंट"), formatEng(iAfter, 1), "A")
                    ),
                    formulaUsed = "Qc = P × [tan(acos PF₁) − tan(acos PF₂)]",
                    substitutedFormula = "Qc = ${formatEng(pKw, 1)} × [tan(acos ${formatEng(pf1, 3)}) − tan(acos ${formatEng(pf2, 3)})]",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Power Factors to tan(φ)", "दोनों पावर फैक्टर से tan(φ) निकालें"),
                            "tan(φ₁) = ${formatEng(tan1, 4)},  tan(φ₂) = ${formatEng(tan2, 4)}",
                            BilingualText(
                                "Find the phase angle φ = acos(PF) and compute tan(φ) = Q/P for both existing and target PF.",
                                "दोनों पावर फैक्टर का कोण φ = acos(PF) निकालकर उसका रिएक्टिव अनुपात tan(φ) निकालें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Subtract Target tan(φ₂) from Existing tan(φ₁)", "tan(φ₁) में से tan(φ₂) घटाएं"),
                            "Δtan = ${formatEng(tan1, 4)} − ${formatEng(tan2, 4)} = ${formatEng(deltaTan, 4)}",
                            BilingualText(
                                "This difference represents the reactive kVAR per kW that the capacitor bank must supply.",
                                "यह अंतर बताता है कि प्रति kW लोड पर कितनी रिएक्टिव पावर कैपेसिटर से कम करनी है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Multiply by Active Load (kW)", "एक्टिव लोड (kW) से गुणा कर kVAR निकालें"),
                            "Qc = ${formatEng(pKw, 1)} × ${formatEng(deltaTan, 4)} = ${formatEng(qcKvar, 2)} kVAR",
                            BilingualText(
                                "Multiply active power by Δtan to obtain the required capacitor bank rating in kVAR.",
                                "कुल लोड kW को Δtan से गुणा करने पर आवश्यक कैपेसिटर रेटिंग (kVAR) प्राप्त होती है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Capacitor Current, Delta µF & Line Current Drop", "कैपेसिटर करंट, µF और लाइन करंट में कमी"),
                            "Ic = ${formatEng(capCurrent, 1)} A (${formatEng(capDeltaUf, 1)} µF/ph)  |  Line I: ${formatEng(iBefore, 1)} → ${formatEng(iAfter, 1)} A",
                            BilingualText(
                                "Raising PF reduces feeder current by ${formatEng(iSaved, 1)} A, lowering cable I²R losses.",
                                "PF सुधारने से लाइन करंट में ${formatEng(iSaved, 1)} A की कमी आती है और बिजली लॉस घटता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Installing a ${formatEng(qcKvar, 2)} kVAR capacitor bank raises PF from ${formatEng(pf1, 2)} to ${formatEng(pf2, 2)}, cutting line current by ${formatEng(iSaved, 1)} A.",
                        "${formatEng(qcKvar, 2)} kVAR का कैपेसिटर लगाने से PF ${formatEng(pf1, 2)} से ${formatEng(pf2, 2)} हो जाएगा और लाइन करंट ${formatEng(iSaved, 1)} A कम हो जाएगा।"
                    ),
                    assumptions = BilingualText(
                        "Assumes balanced 3-phase lagging load; Delta µF calculated at 50 Hz supply.",
                        "मान्यता: संतुलित 3-फेज़ इंडक्टिव लोड; डेल्टा µF की गणना 50 Hz सप्लाई पर की गई है।"
                    ),
                    engineeringNote = BilingualText(
                        "Always select standard APFC capacitor steps (e.g. 5, 10, 15, 25 kVAR) slightly above calculated value.",
                        "APFC पैनल के लिए मानक रेटिंग (5, 10, 15, 25 kVAR) के स्टेप्स चुनें।"
                    )
                )
            }
        }
    )

    private fun voltageDropCalculator() = CalculatorDefinition(
        id = "elec_voltage_drop",
        category = CalculatorCategory.ELECTRICAL,
        title = BilingualText("Voltage Drop Calculator", "वोल्टेज ड्रॉप कैलकुलेटर"),
        subtitle = BilingualText(
            "Check AC 3-Phase / 1-Phase or DC cable voltage drop & % loss",
            "केबल की लंबाई व करंट के अनुसार वोल्टेज ड्रॉप और % लॉस जांचें"
        ),
        formulaPreview = "ΔV = K × I × L × ρ / A",
        keywords = listOf("voltage drop", "loss", "cable", "copper", "aluminum", "वोल्टेज ड्रॉप"),
        fields = listOf(
            CalculatorField(
                id = "system",
                label = BilingualText("Circuit & Conductor Type", "सर्किट और कंडक्टर चुनें"),
                defaultValue = "1",
                defaultUnit = "3φ Copper",
                unitOptions = listOf("3φ Copper", "1φ/DC Copper", "3φ Aluminum"),
                isSelectorOnly = true
            ),
            CalculatorField("voltage", BilingualText("Supply Voltage", "सप्लाई वोल्टेज"), "415", "V"),
            CalculatorField("current", BilingualText("Load Current (I)", "लोड करंट (I)"), "40", "A"),
            CalculatorField("length", BilingualText("One-Way Cable Length", "केबल की लंबाई (एक तरफ)"), "120", "m"),
            CalculatorField("area", BilingualText("Conductor Size (mm²)", "केबल क्रॉस-सेक्शन (mm²)"), "16", "mm²")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("3φ 415V 40A 120m (16mm² Cu)", "3φ 415V 40A 120m (16mm² Cu)"),
                values = mapOf("voltage" to "415", "current" to "40", "length" to "120", "area" to "16"),
                units = mapOf("system" to "3φ Copper")
            ),
            CalculatorPreset(
                label = BilingualText("24V DC 4A 80m (1.5mm² Cu)", "24V DC 4A 80m (1.5mm² Cu)"),
                values = mapOf("voltage" to "24", "current" to "4", "length" to "80", "area" to "1.5"),
                units = mapOf("system" to "1φ/DC Copper")
            )
        ),
        compute = { values, units ->
            runCatching {
                val v = requirePositive(values["voltage"], BilingualText("Supply Voltage", "सप्लाई वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Load Current", "लोड करंट"))
                val len = requirePositive(values["length"], BilingualText("Length", "लंबाई"))
                val area = requirePositive(values["area"], BilingualText("Area", "साइज"))
                val sysUnit = units["system"] ?: "3φ Copper"

                val isAl = sysUnit.contains("Aluminum")
                val is1Ph = sysUnit.contains("1φ")
                val rho = if (isAl) 0.034 else 0.021
                val factor = if (is1Ph) 2.0 else sqrt(3.0)
                val modeLabel = when {
                    is1Ph -> BilingualText("1-Phase / DC Copper", "1-फेज़ / DC कॉपर")
                    isAl -> BilingualText("3-Phase Aluminum", "3-फेज़ एल्युमिनियम")
                    else -> BilingualText("3-Phase Copper", "3-फेज़ कॉपर")
                }

                val vDrop = (factor * i * len * rho) / area
                val dropPct = (vDrop / v) * 100.0
                val vEnd = (v - vDrop).coerceAtLeast(0.0)
                val status = if (dropPct > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL

                val numerator = factor * i * len * rho

                CalculationOutput(
                    primaryLabel = BilingualText("Voltage Drop (ΔV)", "वोल्टेज ड्रॉप (ΔV)"),
                    primaryValue = formatEng(vDrop, 2),
                    primaryUnit = "V (${formatEng(dropPct, 2)}%)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Load End Voltage", "लोड पर वोल्टेज"), formatEng(vEnd, 2), "V"),
                        SecondaryMetric(BilingualText("Drop Percentage", "ड्रॉप प्रतिशत"), formatEng(dropPct, 2), "%"),
                        SecondaryMetric(BilingualText("System Type", "सिस्टम प्रकार"), modeLabel.en, localizedValue = modeLabel)
                    ),
                    formulaUsed = "ΔV = (K × I × L × ρ) / A   |   %Drop = (ΔV / V) × 100",
                    substitutedFormula = "ΔV = (${formatEng(factor, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 1)} × $rho) / ${formatEng(area, 1)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Select Phase Factor (K) & Resistivity (ρ)", "फेज़ फैक्टर (K) और रेजिस्टिविटी (ρ) चुनें"),
                            "K = ${formatEng(factor, 3)},  ρ = $rho Ω·mm²/m  (${modeLabel.en})",
                            BilingualText(
                                "Uses K = √3 (1.732) for 3-phase or 2.0 (go & return) for 1-phase/DC, with 70°C hot conductor resistivity.",
                                "3-फेज़ के लिए K = √3 और 1-फेज़/DC के लिए 2.0 (आने-जाने का रास्ता) तथा 70°C पर केबल रेजिस्टिविटी ली जाती है।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Multiply Current, Length & Conductor Constants", "करंट, लंबाई और स्थिरांक गुणा करें"),
                            "K × I × L × ρ = ${formatEng(factor, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 1)} × $rho = ${formatEng(numerator, 2)}",
                            BilingualText(
                                "Voltage drop rises proportionally with load current and cable run length.",
                                "करंट और केबल की लंबाई बढ़ने पर वोल्टेज ड्रॉप सीधा बढ़ता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Divide by Cable Area (mm²) for Voltage Drop", "केबल साइज (mm²) से भाग देकर ΔV निकालें"),
                            "ΔV = ${formatEng(numerator, 2)} / ${formatEng(area, 1)} = ${formatEng(vDrop, 2)} V",
                            BilingualText(
                                "Larger cable cross-section area reduces resistance and voltage drop.",
                                "बड़े क्रॉस-सेक्शन साइज (mm²) की केबल लगाने से वोल्टेज ड्रॉप कम होता है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Calculate % Drop & Receiving Voltage", "% ड्रॉप और लोड वोल्टेज निकालें"),
                            "%Drop = (${formatEng(vDrop, 2)} / ${formatEng(v, 1)}) × 100 = ${formatEng(dropPct, 2)}%  |  V_load = ${formatEng(vEnd, 2)} V",
                            BilingualText(
                                if (dropPct <= 3.0) "Within 3% limit — Excellent."
                                else if (dropPct <= 5.0) "Between 3%–5% — Acceptable for motor/power feeders."
                                else "Exceeds 5% — Consider increasing cable size!",
                                if (dropPct <= 3.0) "3% से कम है — बिल्कुल सुरक्षित।"
                                else if (dropPct <= 5.0) "3% से 5% के बीच — मोटर/पावर फीडर के लिए स्वीकार्य है।"
                                else "5% से अधिक है — कृपया मोटी केबल उपयोग करें!"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Along the ${formatEng(len, 0)} m run at ${formatEng(i, 1)} A, ${formatEng(vDrop, 2)} V (${formatEng(dropPct, 2)}%) drops in the cable, leaving ${formatEng(vEnd, 2)} V at the load.",
                        "${formatEng(len, 0)} m केबल में ${formatEng(i, 1)} A करंट पर ${formatEng(vDrop, 2)} V (${formatEng(dropPct, 2)}%) ड्रॉप होगा और लोड पर ${formatEng(vEnd, 2)} V पहुंचेगा।"
                    ),
                    assumptions = BilingualText(
                        "Assumes conductor temp 70°C (Cu ρ=0.021, Al ρ=0.034 Ω·mm²/m) and resistive drop (valid up to ~35 mm²).",
                        "मान्यता: 70°C कंडक्टर तापमान (Cu ρ=0.021, Al ρ=0.034) तथा रेजिस्टिव ड्रॉप (~35 mm² तक सटीक)।"
                    ),
                    engineeringNote = BilingualText(
                        "IEC/IS standards recommend max 3% drop for lighting and 5% for motor feeders.",
                        "IEC/IS मानकों के अनुसार लाइटिंग में अधिकतम 3% और मोटर में 5% वोल्टेज ड्रॉप होना चाहिए।"
                    ),
                    statusLevel = status
                )
            }
        }
    )

    private fun motorFlcCalculator() = CalculatorDefinition(
        id = "motor_flc",
        category = CalculatorCategory.MOTOR,
        title = BilingualText("3-Phase Motor FLC Current", "3-फेज़ मोटर FLC करंट"),
        subtitle = BilingualText(
            "Calculate Full Load Current (FLC) from Motor kW or HP rating",
            "मोटर की kW या HP रेटिंग से फुल लोड करंट (FLC) निकालें"
        ),
        formulaPreview = "I = (P_kW × 1000) / (√3 × V × η × cos φ)",
        keywords = listOf("motor", "flc", "full load current", "hp", "kw", "induction", "मोटर", "करंट"),
        fields = listOf(
            CalculatorField(
                id = "power",
                label = BilingualText("Motor Shaft Power", "मोटर पावर (kW या HP)"),
                defaultValue = "15",
                defaultUnit = "kW",
                unitOptions = listOf("kW", "HP")
            ),
            CalculatorField("voltage", BilingualText("Line Voltage (V)", "लाइन वोल्टेज (V)"), "415", "V"),
            CalculatorField("efficiency", BilingualText("Efficiency (%)", "एफिशिएंसी (%)"), "90", "%"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("15 kW (20 HP) 415V Motor", "15 kW (20 HP) 415V मोटर"),
                values = mapOf("power" to "15", "voltage" to "415", "efficiency" to "90", "pf" to "0.85"),
                units = mapOf("power" to "kW")
            ),
            CalculatorPreset(
                label = BilingualText("50 HP 415V Pump Motor", "50 HP 415V पंप मोटर"),
                values = mapOf("power" to "50", "voltage" to "415", "efficiency" to "92", "pf" to "0.87"),
                units = mapOf("power" to "HP")
            )
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Motor Power", "मोटर पावर"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val effPct = requireRange(values["efficiency"], 10.0, 100.0, BilingualText("Efficiency (%)", "एफिशिएंसी (%)"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))

                val pKw = if (units["power"] == "HP") rawP * 0.7457 else rawP
                val pHp = pKw / 0.7457
                val eff = effPct / 100.0
                val pInputKw = pKw / eff
                val flc = (pInputKw * 1000.0) / (sqrt(3.0) * v * pf)
                val lrcApprox = flc * 6.0

                val denom = sqrt(3.0) * v * pf

                CalculationOutput(
                    primaryLabel = BilingualText("Full Load Current (FLC)", "फुल लोड करंट (FLC)"),
                    primaryValue = formatEng(flc, 2),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Shaft Power", "शाफ्ट पावर"), formatEng(pKw, 2), "kW (${formatEng(pHp, 1)} HP)"),
                        SecondaryMetric(BilingualText("Input Power", "इनपुट पावर"), formatEng(pInputKw, 2), "kW"),
                        SecondaryMetric(BilingualText("Approx Starting (6×)", "स्टार्टिंग करंट (~6×)"), formatEng(lrcApprox, 1), "A")
                    ),
                    formulaUsed = "I_FLC = (P_kW × 1000) / (√3 × V × η × cos φ)",
                    substitutedFormula = "I_FLC = (${formatEng(pKw, 2)} × 1000) / (1.732 × ${formatEng(v, 0)} × ${formatEng(eff, 3)} × ${formatEng(pf, 2)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Mechanical Power to kW", "मोटर शाफ्ट पावर को kW में बदलें"),
                            if (units["power"] == "HP") "${formatEng(rawP, 2)} HP × 0.7457 = ${formatEng(pKw, 2)} kW"
                            else "P_shaft = ${formatEng(pKw, 2)} kW (${formatEng(pHp, 1)} HP)",
                            BilingualText(
                                "Convert HP to kW using 1 mechanical HP = 0.7457 kW.",
                                "1 मैकेनिकल HP = 0.7457 kW के नियम से पावर को kW में सुनिश्चित करें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Account for Motor Efficiency (P_in = P_shaft / η)", "एफिशिएंसी से इलेक्ट्रिकल इनपुट पावर निकालें"),
                            "P_in = ${formatEng(pKw, 2)} / ${formatEng(eff, 3)} = ${formatEng(pInputKw, 2)} kW (${formatEng(pInputKw * 1000.0, 0)} W)",
                            BilingualText(
                                "Electrical input power exceeds shaft output because of copper, iron, and friction losses.",
                                "मोटर लॉसेस के कारण इलेक्ट्रिकल इनपुट पावर शाफ्ट पावर से अधिक होती है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate 3-Phase Denominator (√3 × V × cos φ)", "भाजक (√3 × V × cos φ) निकालें"),
                            "1.732 × ${formatEng(v, 0)} × ${formatEng(pf, 2)} = ${formatEng(denom, 2)}",
                            BilingualText(
                                "Combines 3-phase factor √3 (1.732), line voltage, and power factor.",
                                "3-फेज़ गुणांक √3, लाइन वोल्टेज और पावर फैक्टर को गुणा करें।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Divide Input Watts to Get FLC & Inrush", "इनपुट वॉट को भाग देकर FLC निकालें"),
                            "I_FLC = ${formatEng(pInputKw * 1000.0, 0)} / ${formatEng(denom, 2)} = ${formatEng(flc, 2)} A  (6× Inrush ≈ ${formatEng(lrcApprox, 1)} A)",
                            BilingualText(
                                "Divide total input Watts by (√3 × V × cos φ) to get rated line current per phase.",
                                "कुल इनपुट वॉट को भाजक से भाग देने पर प्रति फेज़ फुल लोड करंट (FLC) प्राप्त होता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "At 100% rated load (${formatEng(pKw, 2)} kW), this 3-phase motor draws ${formatEng(flc, 2)} A continuously and up to ~${formatEng(lrcApprox, 1)} A during DOL startup.",
                        "पूर्ण लोड (${formatEng(pKw, 2)} kW) पर यह 3-फेज़ मोटर लगातार ${formatEng(flc, 2)} A और DOL स्टार्टिंग के समय ~${formatEng(lrcApprox, 1)} A करंट लेगी।"
                    ),
                    assumptions = BilingualText(
                        "Uses 1 mechanical HP = 0.7457 kW; DOL Locked-Rotor starting current estimated at 6× FLC.",
                        "मान्यता: 1 HP = 0.7457 kW; DOL स्टार्टिंग करंट लगभग 6× FLC माना गया है।"
                    ),
                    engineeringNote = BilingualText(
                        "Quick thumb rule at 415V: Motor FLC ≈ 1.8 × kW (or 1.35 × HP).",
                        "415V मोटर के लिए शॉर्टकट नियम: FLC ≈ 1.8 × kW (या 1.35 × HP) होता है।"
                    )
                )
            }
        }
    )

    private fun motorSpeedSlipCalculator() = CalculatorDefinition(
        id = "motor_speed_slip",
        category = CalculatorCategory.MOTOR,
        title = BilingualText("Motor RPM & % Slip", "मोटर RPM और स्लिप (%)"),
        subtitle = BilingualText(
            "Find Synchronous Speed (Ns), Rotor Frequency & % Slip",
            "पोल और फ्रीक्वेंसी से सिंक्रोनस स्पीड (Ns) व स्लिप (%) निकालें"
        ),
        formulaPreview = "Ns = (120 × f) / P   |   s% = (Ns − Nr) / Ns × 100",
        keywords = listOf("rpm", "slip", "pole", "frequency", "synchronous", "मोटर स्पीड", "स्लिप"),
        fields = listOf(
            CalculatorField("freq", BilingualText("Supply Frequency (f)", "फ्रीक्वेंसी (Hz)"), "50", "Hz"),
            CalculatorField("poles", BilingualText("Number of Poles (2,4,6,8...)", "मोटर पोल (2, 4, 6, 8...)"), "4", "Poles"),
            CalculatorField("rotor_rpm", BilingualText("Actual Rotor RPM (Nr)", "असली रोटर RPM (Nr)"), "1440", "RPM")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("4-Pole 50Hz (1440 RPM)", "4-पोल 50Hz (1440 RPM)"),
                values = mapOf("freq" to "50", "poles" to "4", "rotor_rpm" to "1440")
            ),
            CalculatorPreset(
                label = BilingualText("2-Pole 50Hz (2910 RPM)", "2-पोल 50Hz (2910 RPM)"),
                values = mapOf("freq" to "50", "poles" to "2", "rotor_rpm" to "2910")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val f = requireRange(values["freq"], 1.0, 400.0, BilingualText("Frequency", "फ्रीक्वेंसी"))
                val poles = requireEvenPoles(values["poles"], BilingualText("Number of Poles", "मोटर पोल"))
                val nr = requirePositive(values["rotor_rpm"], BilingualText("Rotor RPM", "रोटर RPM"))

                val ns = (120.0 * f) / poles
                val slipRpm = ns - nr
                val slipPct = (slipRpm / ns) * 100.0
                val rotorFreq = kotlin.math.abs(slipPct / 100.0) * f

                CalculationOutput(
                    primaryLabel = BilingualText("Synchronous Speed (Ns)", "सिंक्रोनस स्पीड (Ns)"),
                    primaryValue = formatEng(ns, 0),
                    primaryUnit = "RPM",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Motor Slip (%)", "मोटर स्लिप (%)"), formatEng(slipPct, 2), "%"),
                        SecondaryMetric(BilingualText("Slip Speed", "स्लिप स्पीड"), formatEng(slipRpm, 1), "RPM"),
                        SecondaryMetric(BilingualText("Rotor Frequency", "रोटर फ्रीक्वेंसी"), formatEng(rotorFreq, 2), "Hz")
                    ),
                    formulaUsed = "Ns = (120 × f) / P   |   Slip % = ((Ns − Nr) / Ns) × 100",
                    substitutedFormula = "Ns = (120 × ${formatEng(f, 1)}) / $poles   |   Slip % = ((${formatEng(ns, 0)} − ${formatEng(nr, 0)}) / ${formatEng(ns, 0)}) × 100",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Compute Synchronous Speed (Ns)", "सिंक्रोनस स्पीड (Ns) निकालें"),
                            "Ns = (120 × ${formatEng(f, 1)}) / $poles = ${formatEng(ns, 0)} RPM",
                            BilingualText(
                                "Stator rotating magnetic field speed depends strictly on supply frequency and pole count.",
                                "स्टेटर के चुंबकीय क्षेत्र की गति फ्रीक्वेंसी और पोल की संख्या से तय होती है।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Find Slip Speed Difference (Ns − Nr)", "स्लिप स्पीड अंतर (Ns − Nr) निकालें"),
                            "ΔN = ${formatEng(ns, 0)} − ${formatEng(nr, 0)} = ${formatEng(slipRpm, 1)} RPM",
                            BilingualText(
                                "Difference between magnetic field speed and actual rotor shaft speed.",
                                "चुंबकीय क्षेत्र की गति और रोटर की वास्तविक गति के बीच का अंतर।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate % Slip & Rotor Frequency", "स्लिप % और रोटर फ्रीक्वेंसी निकालें"),
                            "Slip = (${formatEng(slipRpm, 1)} / ${formatEng(ns, 0)}) × 100 = ${formatEng(slipPct, 2)}%  |  f_r = ${formatEng(rotorFreq, 2)} Hz",
                            BilingualText(
                                "Normal induction motor full-load slip is typically 2% to 5%.",
                                "सामान्य इंडक्शन मोटर में फुल-लोड स्लिप 2% से 5% के बीच होती है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        when {
                            slipPct < 0.0 -> "Negative slip (${formatEng(slipPct, 2)}%) means rotor spins faster than synchronous ${formatEng(ns, 0)} RPM (regenerative/overhauling load)."
                            slipPct > 8.0 -> "Slip of ${formatEng(slipPct, 2)}% below ${formatEng(ns, 0)} RPM is high (>8%), indicating heavy mechanical overload or low voltage."
                            else -> "Synchronous field rotates at ${formatEng(ns, 0)} RPM; at ${formatEng(nr, 0)} RPM the motor has normal ${formatEng(slipPct, 2)}% slip."
                        },
                        when {
                            slipPct < 0.0 -> "नेगेटिव स्लिप (${formatEng(slipPct, 2)}%) दर्शाती है कि रोटर ${formatEng(ns, 0)} RPM से तेज घूम रहा है (रीजेनरेटिव लोड)।"
                            slipPct > 8.0 -> "${formatEng(slipPct, 2)}% स्लिप (>8%) अधिक है, जो मोटर ओवरलोड या कम वोल्टेज का संकेत है।"
                            else -> "सिंक्रोनस स्पीड ${formatEng(ns, 0)} RPM है और ${formatEng(nr, 0)} RPM पर स्लिप सामान्य (${formatEng(slipPct, 2)}%) है।"
                        }
                    ),
                    statusLevel = if (slipPct < 0 || slipPct > 8.0) StatusLevel.WARNING else StatusLevel.NORMAL,
                    engineeringNote = BilingualText(
                        "If Nr > Ns, slip is negative (regenerative / generator mode). High slip (>8%) indicates overload.",
                        "यदि रोटर RPM, Ns से अधिक हो जाए तो मोटर जनरेटर की तरह काम करती है। 8% से अधिक स्लिप ओवरलोड दर्शाती है।"
                    )
                )
            }
        }
    )

    private fun motorStarterSizingCalculator() = CalculatorDefinition(
        id = "motor_starter_sizing",
        category = CalculatorCategory.MOTOR,
        title = BilingualText("DOL & Star-Delta Starter Sizing", "DOL व स्टार-डेल्टा स्टार्टर साइजिंग"),
        subtitle = BilingualText(
            "Select Main/Delta/Star Contactor, OLR Relay & MCCB Breaker rating",
            "मोटर करंट के अनुसार कॉन्टैक्टर, ओवरलोड रिले (OLR) और MCCB रेटिंग"
        ),
        formulaPreview = "I_phase(Δ) = FLC / √3  |  I_star = FLC / 3",
        keywords = listOf("starter", "dol", "star delta", "contactor", "olr", "mccb", "स्टार्टर", "कॉन्टैक्टर"),
        fields = listOf(
            CalculatorField("flc", BilingualText("Motor Nameplate FLC (A)", "मोटर नेमप्लेट FLC (A)"), "45", "A"),
            CalculatorField("service_factor", BilingualText("Safety Factor (1.0 – 2.0)", "सेफ्टी फैक्टर (1.0 – 2.0)"), "1.15", "×")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("22 kW Motor (40A FLC)", "22 kW मोटर (40A FLC)"),
                values = mapOf("flc" to "40", "service_factor" to "1.15")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val flc = requirePositive(values["flc"], BilingualText("Motor FLC", "मोटर FLC"))
                val sf = requireRange(values["service_factor"], 1.0, 2.0, BilingualText("Safety Factor", "सेफ्टी फैक्टर"))

                val dolContactor = flc * sf
                val sdMainDelta = (flc / sqrt(3.0)) * sf
                val sdStar = (flc / 3.0) * sf
                val olrDol = flc
                val olrSdPhase = flc / sqrt(3.0)
                val mccbMin = flc * 1.5

                val standardRatings = listOf(9, 12, 18, 25, 32, 40, 50, 63, 80, 95, 110, 150, 185, 225, 265, 300, 400, 500, 630)
                fun pickStd(req: Double): Int = standardRatings.firstOrNull { it >= req } ?: kotlin.math.ceil(req).toInt()

                val mainContactorStd = pickStd(sdMainDelta)
                val starContactorStd = pickStd(sdStar)
                val dolContactorStd = pickStd(dolContactor)
                val mccbStd = pickStd(mccbMin)

                CalculationOutput(
                    primaryLabel = BilingualText("Star-Delta Main/Delta Contactor", "स्टार-डेल्टा मेन/डेल्टा कॉन्टैक्टर"),
                    primaryValue = "$mainContactorStd A",
                    primaryUnit = "AC-3 (Calc: ${formatEng(sdMainDelta, 1)} A)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Star Contactor", "स्टार कॉन्टैक्टर"), "$starContactorStd A", "AC-3"),
                        SecondaryMetric(BilingualText("DOL Contactor", "DOL कॉन्टैक्टर"), "$dolContactorStd A", "AC-3"),
                        SecondaryMetric(BilingualText("SD OLR Setting", "स्टार-डेल्टा OLR"), formatEng(olrSdPhase, 1), "A"),
                        SecondaryMetric(BilingualText("MCCB Breaker (Min)", "MCCB ब्रेकर"), "$mccbStd A", "TP")
                    ),
                    formulaUsed = "I_main = I_delta = (FLC / √3) × SF   |   I_star = (FLC / 3) × SF   |   I_DOL = FLC × SF",
                    substitutedFormula = "I_main = (${formatEng(flc, 1)} / 1.732) × $sf   |   I_star = (${formatEng(flc, 1)} / 3) × $sf",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Compute Delta Phase Current (58% FLC)", "डेल्टा वाइंडिंग फेज़ करंट निकालें (58% FLC)"),
                            "I_phase = ${formatEng(flc, 1)} / 1.732 = ${formatEng(olrSdPhase, 1)} A",
                            BilingualText(
                                "In a Star-Delta starter, Main and Delta contactors sit inside the phase loop carrying 1/√3 (57.7%) of line FLC.",
                                "स्टार-डेल्टा में मेन और डेल्टा कॉन्टैक्टर फेज़ लूप में होते हैं, जहाँ केवल 57.7% (FLC/√3) करंट बहता है।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Size Star-Delta Main & Delta Contactors", "मेन और डेल्टा कॉन्टैक्टर चुनें"),
                            "I_main = ${formatEng(olrSdPhase, 1)} × $sf = ${formatEng(sdMainDelta, 1)} A → Next Std: $mainContactorStd A AC-3",
                            BilingualText(
                                "Multiply phase current by Safety Factor ($sf) and pick the next standard IEC AC-3 contactor rating.",
                                "फेज़ करंट को सेफ्टी फैक्टर ($sf) से गुणा कर अगला मानक IEC AC-3 कॉन्टैक्टर चुनें।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Size Star & DOL Contactors", "स्टार व DOL कॉन्टैक्टर की गणना"),
                            "I_star = (${formatEng(flc, 1)} / 3) × $sf = ${formatEng(sdStar, 1)} A → $starContactorStd A  |  DOL = ${formatEng(dolContactor, 1)} A → $dolContactorStd A",
                            BilingualText(
                                "Star contactor carries only 33% current during startup; DOL carries 100% line current continuously.",
                                "स्टार कॉन्टैक्टर केवल स्टार्टिंग में 33% करंट लेता है, जबकि DOL में पूरा 100% करंट बहता है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Determine OLR Relay & MCCB Breaker", "OLR रिले और MCCB ब्रेकर चुनें"),
                            "OLR (SD Phase) = ${formatEng(olrSdPhase, 1)} A  |  OLR (DOL) = ${formatEng(olrDol, 1)} A  |  MCCB ≥ 1.5 × ${formatEng(flc, 1)} = ${formatEng(mccbMin, 1)} A → $mccbStd A",
                            BilingualText(
                                "Set overload relay to motor current at its wired location; MCCB ≥ 1.5× FLC prevents inrush tripping.",
                                "OLR को उसकी वायरिंग के अनुसार सेट करें और स्टार्टिंग झटके से बचाने के लिए ≥1.5× FLC का MCCB चुनें।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "For a ${formatEng(flc, 1)} A motor: Star-Delta uses $mainContactorStd A (Main), $mainContactorStd A (Delta), $starContactorStd A (Star) with OLR at ${formatEng(olrSdPhase, 1)} A; DOL needs $dolContactorStd A contactor and $mccbStd A MCCB.",
                        "${formatEng(flc, 1)} A मोटर के लिए स्टार-डेल्टा में $mainContactorStd A मेन/डेल्टा व $starContactorStd A स्टार कॉन्टैक्टर (${formatEng(olrSdPhase, 1)} A OLR) और DOL में $dolContactorStd A कॉन्टैक्टर व $mccbStd A MCCB लगेगा।"
                    ),
                    assumptions = BilingualText(
                        "Contactor ratings follow IEC AC-3 motor duty; MCCB sized at ≥1.5× FLC (Type 2 coordination may require higher frame).",
                        "मान्यता: कॉन्टैक्टर IEC AC-3 ड्यूटी पर आधारित; MCCB ≥1.5× FLC पर चुना गया है।"
                    ),
                    engineeringNote = BilingualText(
                        "Verify whether OLR is wired on the main supply line (set 100% FLC) or inside the delta loop (set 58% FLC).",
                        "ध्यान दें: यदि OLR मेन सप्लाई पर है तो 100% FLC पर सेट करें, और मेन कॉन्टैक्टर के नीचे है तो 58% FLC पर सेट करें।"
                    )
                )
            }
        }
    )

    private fun motorTorqueCalculator() = CalculatorDefinition(
        id = "motor_torque",
        category = CalculatorCategory.MOTOR,
        title = BilingualText("Motor Shaft Torque (Nm)", "मोटर शाफ्ट टॉर्क (Nm)"),
        subtitle = BilingualText(
            "Calculate rated shaft torque from Power (kW/HP) & Speed (RPM)",
            "पावर (kW/HP) और गति (RPM) से मोटर का शाफ्ट टॉर्क निकालें"
        ),
        formulaPreview = "T = (9549.3 × kW) / RPM",
        keywords = listOf("torque", "nm", "shaft", "motor", "rpm", "टॉर्क"),
        fields = listOf(
            CalculatorField("power", BilingualText("Motor Power", "मोटर पावर"), "15", "kW", listOf("kW", "HP")),
            CalculatorField("rpm", BilingualText("Rated Speed (RPM)", "मोटर गति (RPM)"), "1460", "RPM")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("15 kW @ 1460 RPM", "15 kW @ 1460 RPM"),
                values = mapOf("power" to "15", "rpm" to "1460"),
                units = mapOf("power" to "kW")
            )
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Power", "पावर"))
                val rpm = requirePositive(values["rpm"], BilingualText("Speed (RPM)", "गति (RPM)"))
                val pKw = if (units["power"] == "HP") rawP * 0.7457 else rawP
                val torqueConst = 60000.0 / (2.0 * PI) // 9549.2966
                val torqueNm = (torqueConst * pKw) / rpm
                val torqueKgM = torqueNm / 9.80665

                val numTorque = torqueConst * pKw

                CalculationOutput(
                    primaryLabel = BilingualText("Rated Shaft Torque", "रेटेड शाफ्ट टॉर्क"),
                    primaryValue = formatEng(torqueNm, 2),
                    primaryUnit = "N·m",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Torque (kg·m)", "टॉर्क (kg·m)"), formatEng(torqueKgM, 2), "kg·m"),
                        SecondaryMetric(BilingualText("Mechanical Power", "मैकेनिकल पावर"), formatEng(pKw, 2), "kW")
                    ),
                    formulaUsed = "T (N·m) = (60,000 × P_kW) / (2π × N_rpm) ≈ (9549.3 × P_kW) / N_rpm",
                    substitutedFormula = "T = (9549.3 × ${formatEng(pKw, 2)}) / ${formatEng(rpm, 0)}",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert Mechanical Power to kW", "पावर को kW में बदलें"),
                            if (units["power"] == "HP") "${formatEng(rawP, 2)} HP × 0.7457 = ${formatEng(pKw, 2)} kW"
                            else "P_kW = ${formatEng(pKw, 2)} kW",
                            BilingualText(
                                "Torque formula requires shaft power in kilowatts (1 HP = 0.7457 kW).",
                                "टॉर्क सूत्र में शाफ्ट पावर किलोवाट (kW) में होनी चाहिए (1 HP = 0.7457 kW)।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Multiply by Rotational Constant (9549.3)", "रोटेशनल स्थिरांक (9549.3) से गुणा करें"),
                            "60,000 / 2π × ${formatEng(pKw, 2)} = ${formatEng(numTorque, 1)}",
                            BilingualText(
                                "Constant 9549.3 (= 60,000 / 2π) converts kW and RPM into Newton-meters.",
                                "स्थिरांक 9549.3 (= 60,000 / 2π) kW और RPM को सीधे न्यूटन-मीटर में बदलता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Divide by Speed (RPM) & Convert to kg·m", "स्पीड (RPM) से भाग दें और kg·m निकालें"),
                            "T = ${formatEng(numTorque, 1)} / ${formatEng(rpm, 0)} = ${formatEng(torqueNm, 2)} N·m  (${formatEng(torqueKgM, 2)} kg·m)",
                            BilingualText(
                                "Divide by shaft RPM for N·m; divide by 9.80665 for equivalent kg·m.",
                                "RPM से भाग देने पर N·m मिलता है और 9.80665 से भाग देने पर kg·m प्राप्त होता है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Delivering ${formatEng(pKw, 2)} kW at ${formatEng(rpm, 0)} RPM produces ${formatEng(torqueNm, 2)} N·m (${formatEng(torqueKgM, 2)} kg·m) of rotational force at the shaft.",
                        "${formatEng(rpm, 0)} RPM पर ${formatEng(pKw, 2)} kW पावर देने पर मोटर शाफ्ट पर ${formatEng(torqueNm, 2)} N·m (${formatEng(torqueKgM, 2)} kg·m) टॉर्क उत्पन्न होता है।"
                    ),
                    assumptions = BilingualText(
                        "Uses 1 HP = 0.7457 kW and g = 9.80665 m/s² for kg·m conversion.",
                        "मान्यता: 1 HP = 0.7457 kW और kg·m हेतु g = 9.80665 m/s²।"
                    )
                )
            }
        }
    )
}
