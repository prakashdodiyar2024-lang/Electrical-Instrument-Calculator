package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LanguagePreferences
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculationHistoryItem
import com.example.model.CalculationOutput
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorPreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CalculatorScreenUiState(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val searchQuery: String = "",
    val selectedCategoryChip: CalculatorCategory? = null,
    val searchResults: List<CalculatorDefinition> = CalculatorRegistry.allCalculators,
    val activeCalculator: CalculatorDefinition? = null,
    val inputValues: Map<String, String> = emptyMap(),
    val inputUnits: Map<String, String> = emptyMap(),
    val result: CalculationOutput? = null,
    val errorText: BilingualText? = null,
    val recentHistory: List<CalculationHistoryItem> = emptyList()
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val languagePrefs = LanguagePreferences(application.applicationContext)

    private val _uiState = MutableStateFlow(CalculatorScreenUiState())
    val uiState: StateFlow<CalculatorScreenUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            languagePrefs.languageFlow.collect { savedLang ->
                _uiState.update { it.copy(language = savedLang) }
            }
        }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.ENGLISH) {
            AppLanguage.HINDI
        } else {
            AppLanguage.ENGLISH
        }
        _uiState.update { it.copy(language = next) }
        viewModelScope.launch {
            languagePrefs.setLanguage(next)
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(language = lang) }
        viewModelScope.launch {
            languagePrefs.setLanguage(lang)
        }
    }

    fun onSearchQueryChange(query: String) {
        val currentCat = _uiState.value.selectedCategoryChip
        _uiState.update {
            it.copy(
                searchQuery = query,
                searchResults = CalculatorRegistry.search(query, currentCat)
            )
        }
    }

    fun onCategoryChipSelected(category: CalculatorCategory?) {
        val nextCat = if (_uiState.value.selectedCategoryChip == category) null else category
        val currentQuery = _uiState.value.searchQuery
        _uiState.update {
            it.copy(
                selectedCategoryChip = nextCat,
                searchResults = CalculatorRegistry.search(currentQuery, nextCat)
            )
        }
    }

    fun openCalculator(calculatorId: String) {
        val calc = CalculatorRegistry.getById(calculatorId) ?: return
        val defaultValues = calc.fields.associate { it.id to it.defaultValue }
        val defaultUnits = calc.fields.associate { it.id to it.defaultUnit }
        _uiState.update {
            it.copy(
                activeCalculator = calc,
                inputValues = defaultValues,
                inputUnits = defaultUnits,
                result = null,
                errorText = null
            )
        }
        calculate(addToHistory = false)
    }

    fun onFieldValueChange(fieldId: String, newValue: String) {
        val sanitized = newValue.filter { it.isDigit() || it == '.' || it == '-' }
        _uiState.update { state ->
            state.copy(
                inputValues = state.inputValues + (fieldId to sanitized),
                errorText = null
            )
        }
    }

    fun toggleFieldSign(fieldId: String) {
        _uiState.update { state ->
            val cur = state.inputValues[fieldId].orEmpty()
            val next = if (cur.startsWith("-")) cur.drop(1) else "-$cur"
            state.copy(
                inputValues = state.inputValues + (fieldId to next),
                errorText = null
            )
        }
    }

    fun onFieldUnitChange(fieldId: String, newUnit: String) {
        _uiState.update { state ->
            state.copy(
                inputUnits = state.inputUnits + (fieldId to newUnit),
                errorText = null
            )
        }
        calculate(addToHistory = false)
    }

    fun applyPreset(preset: CalculatorPreset) {
        val calc = _uiState.value.activeCalculator ?: return
        val updatedValues = _uiState.value.inputValues.toMutableMap()
        val updatedUnits = _uiState.value.inputUnits.toMutableMap()
        preset.values.forEach { (k, v) -> updatedValues[k] = v }
        preset.units.forEach { (k, u) -> updatedUnits[k] = u }
        // Ensure all fields still present
        calc.fields.forEach { f ->
            if (!updatedValues.containsKey(f.id)) updatedValues[f.id] = f.defaultValue
            if (!updatedUnits.containsKey(f.id)) updatedUnits[f.id] = f.defaultUnit
        }
        _uiState.update {
            it.copy(
                inputValues = updatedValues,
                inputUnits = updatedUnits,
                errorText = null
            )
        }
        calculate(addToHistory = true)
    }

    fun resetActiveCalculator() {
        val calc = _uiState.value.activeCalculator ?: return
        val defaultValues = calc.fields.associate { it.id to it.defaultValue }
        val defaultUnits = calc.fields.associate { it.id to it.defaultUnit }
        _uiState.update {
            it.copy(
                inputValues = defaultValues,
                inputUnits = defaultUnits,
                result = null,
                errorText = null
            )
        }
    }

    fun calculate(addToHistory: Boolean = true) {
        val state = _uiState.value
        val calc = state.activeCalculator ?: return

        val parsed = mutableMapOf<String, Double>()
        for (field in calc.fields) {
            if (field.isSelectorOnly) {
                parsed[field.id] = 1.0
                continue
            }
            val rawStr = state.inputValues[field.id]?.trim().orEmpty()
            val num = rawStr.toDoubleOrNull()
            if (num == null) {
                _uiState.update {
                    it.copy(
                        errorText = BilingualText(
                            "Please enter a valid number for ${field.label.en}",
                            "कृपया ${field.label.hi} के लिए सही संख्या दर्ज करें"
                        ),
                        result = null
                    )
                }
                return
            }
            parsed[field.id] = num
        }

        val outcome = calc.compute(parsed, state.inputUnits)
        outcome.onSuccess { output ->
            _uiState.update { current ->
                val nextHistory = if (addToHistory) {
                    val item = CalculationHistoryItem(
                        calculatorId = calc.id,
                        title = calc.title,
                        resultSummary = "${output.primaryValue} ${output.primaryUnit}",
                        category = calc.category
                    )
                    (listOf(item) + current.recentHistory.filterNot {
                        it.calculatorId == item.calculatorId && it.resultSummary == item.resultSummary
                    }).take(8)
                } else {
                    current.recentHistory
                }
                current.copy(
                    result = output,
                    errorText = null,
                    recentHistory = nextHistory
                )
            }
        }.onFailure { err ->
            val msg = if (err is BilingualValidationException) {
                err.bilingualMessage
            } else {
                BilingualText(
                    err.message ?: "Invalid input values",
                    err.message ?: "कृपया सही मान दर्ज करें"
                )
            }
            _uiState.update {
                it.copy(
                    result = null,
                    errorText = msg
                )
            }
        }
    }
}
