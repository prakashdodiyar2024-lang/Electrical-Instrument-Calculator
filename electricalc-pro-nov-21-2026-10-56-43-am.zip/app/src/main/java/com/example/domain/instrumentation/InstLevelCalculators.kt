package com.example.domain.instrumentation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Height
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Opacity
import androidx.compose.material.icons.rounded.Scale
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WaterDrop
import com.example.domain.engOutput
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.sqrt

object InstLevelCalculators {

    val all: List<CalculatorDefinition> = listOf(
        levelToVolVertical(),       // 31
        levelToVolHorizontal(),     // 32
        tankVolCylindrical(),       // 33
        tankVolRectangular(),       // 34
        levelTxRange(),             // 35
        specificGravityCalc(),      // 36
        liquidHeightFromPres(),     // 37
        volumeToLevel(),            // 38
        densityCorrectionLevel(),   // 39
        massFromLevelDensity()      // 40
    )

    private fun levelToVolVertical() = CalculatorDefinition(
        id = "lvl_to_vol_vertical",
        serialNumber = 31,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.WaterDrop,
        title = BilingualText("Level to Volume Calculator (Vertical Tank)", "लेवल से वॉल्यूम (वर्टिकल टैंक)"),
        subtitle = BilingualText("Compute Liquid Volume & % Fill in Vertical Cylindrical Tank", "वर्टिकल टैंक में द्रव की ऊँचाई से वॉल्यूम (m³ / लीटर) निकालें"),
        formulaPreview = "V = (π × D² / 4) × h",
        assumptions = BilingualText(
            "Flat-bottom vertical cylindrical vessel (dished heads neglected).",
            "मान्यता: समतल तली वाला वर्टिकल बेलनाकार टैंक।"
        ),
        keywords = listOf("vertical tank", "level to volume", "tank strapping", "liters"),
        fields = listOf(
            CalculatorField("dia", BilingualText("Tank Diameter (D)", "टैंक व्यास (D)"), "3.0", "m", listOf("m", "mm")),
            CalculatorField("total_h", BilingualText("Total Tank Height (H)", "टैंक की कुल ऊँचाई (H)"), "5.0", "m"),
            CalculatorField("level", BilingualText("Liquid Level (h)", "द्रव लेवल (h)"), "3.2", "m")
        ),
        compute = { values, units ->
            runCatching {
                val rawD = requirePositive(values["dia"], BilingualText("Diameter", "व्यास"))
                val totalH = requirePositive(values["total_h"], BilingualText("Total Height", "कुल ऊँचाई"))
                val lvl = requireNonNegative(values["level"], BilingualText("Liquid Level", "लेवल"))
                val dM = if (units["dia"] == "mm") rawD / 1000.0 else rawD
                if (lvl > totalH) throw BilingualValidationException(BilingualText("Liquid level cannot exceed tank height.", "लेवल टैंक की ऊँचाई से अधिक नहीं हो सकता।"))
                val area = PI * dM * dM / 4.0
                val volM3 = area * lvl
                val totalCapM3 = area * totalH
                val fillPct = (lvl / totalH) * 100.0
                engOutput(
                    primaryLabel = BilingualText("Liquid Volume", "द्रव वॉल्यूम"),
                    primaryValue = formatEng(volM3, 3),
                    primaryUnit = "m³",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters", "लीटर"), formatEng(volM3 * 1000.0, 0), "L"),
                        SecondaryMetric(BilingualText("Tank Fill %", "भराव %"), formatEng(fillPct, 1), "%"),
                        SecondaryMetric(BilingualText("Full Capacity", "कुल क्षमता"), formatEng(totalCapM3, 2), "m³")
                    ),
                    formulaUsed = "V = (π × D² / 4) × h",
                    substitutedFormula = "V = ${formatEng(area, 3)} × ${formatEng(lvl, 2)} = ${formatEng(volM3, 3)} m³",
                    stepExplanation = BilingualText("Volume = ${formatEng(volM3, 3)} m³ (${formatEng(fillPct, 1)}% full)", "वॉल्यूम = ${formatEng(volM3, 3)} m³")
                )
            }
        }
    )

    private fun levelToVolHorizontal() = CalculatorDefinition(
        id = "lvl_to_vol_horizontal",
        serialNumber = 32,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Storage,
        title = BilingualText("Level to Volume Calculator (Horizontal Tank)", "लेवल से वॉल्यूम (हॉरिजॉन्टल टैंक)"),
        subtitle = BilingualText("Exact Circular Segment Volume for Horizontal Drums", "हॉरिजॉन्टल टैंक/बुलेट में लेवल के अनुसार सटीक वॉल्यूम निकालें"),
        formulaPreview = "V = L × [R²·cos⁻¹((R−h)/R) − (R−h)·√(2Rh − h²)]",
        assumptions = BilingualText(
            "Flat-end horizontal cylinder (for hemispherical/torispherical ends, add head allowance).",
            "मान्यता: फ्लैट-एंड हॉरिजॉन्टल सिलेंडर सूत्र।"
        ),
        keywords = listOf("horizontal tank", "bullet", "drum volume", "level to volume"),
        fields = listOf(
            CalculatorField("dia", BilingualText("Tank Diameter (D)", "टैंक व्यास (D)"), "2.4", "m"),
            CalculatorField("len", BilingualText("Tank Length (L)", "टैंक लंबाई (L)"), "6.0", "m"),
            CalculatorField("level", BilingualText("Liquid Level (h)", "द्रव लेवल (h)"), "1.2", "m")
        ),
        compute = { values, _ ->
            runCatching {
                val d = requirePositive(values["dia"], BilingualText("Diameter", "व्यास"))
                val l = requirePositive(values["len"], BilingualText("Length", "लंबाई"))
                val h = requireNonNegative(values["level"], BilingualText("Liquid Level", "लेवल"))
                if (h > d) throw BilingualValidationException(BilingualText("Liquid level h cannot exceed tank diameter D.", "द्रव लेवल h, व्यास D से अधिक नहीं हो सकता।"))
                val r = d / 2.0
                val cosArg = ((r - h) / r).coerceIn(-1.0, 1.0)
                val segArea = r * r * acos(cosArg) - (r - h) * sqrt((2.0 * r * h - h * h).coerceAtLeast(0.0))
                val volM3 = segArea * l
                val fullM3 = PI * r * r * l
                val fillPct = (volM3 / fullM3) * 100.0
                engOutput(
                    primaryLabel = BilingualText("Horizontal Tank Volume", "हॉरिजॉन्टल टैंक वॉल्यूम"),
                    primaryValue = formatEng(volM3, 3),
                    primaryUnit = "m³",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters", "लीटर"), formatEng(volM3 * 1000.0, 0), "L"),
                        SecondaryMetric(BilingualText("Volume Fill %", "वॉल्यूम %"), formatEng(fillPct, 1), "%"),
                        SecondaryMetric(BilingualText("Full Capacity", "पूर्ण क्षमता"), formatEng(fullM3, 2), "m³")
                    ),
                    formulaUsed = "V = L × [R²·cos⁻¹((R−h)/R) − (R−h)·√(2Rh − h²)]",
                    substitutedFormula = "h = ${formatEng(h, 2)} m / D = ${formatEng(d, 2)} m → ${formatEng(volM3, 3)} m³",
                    stepExplanation = BilingualText("Volume = ${formatEng(volM3, 3)} m³ (${formatEng(fillPct, 1)}%)", "वॉल्यूम = ${formatEng(volM3, 3)} m³")
                )
            }
        }
    )

    private fun tankVolCylindrical() = CalculatorDefinition(
        id = "lvl_tank_vol_cyl",
        serialNumber = 33,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Inventory2,
        title = BilingualText("Tank Volume Calculator (Cylindrical)", "टैंक वॉल्यूम कैलकुलेटर (बेलनाकार)"),
        subtitle = BilingualText("Calculate Total Capacity of Cylindrical Vessel in m³, L & Gal", "बेलनाकार टैंक की कुल क्षमता m³, लीटर व गैलन में निकालें"),
        formulaPreview = "V = π × (D / 2)² × H",
        assumptions = BilingualText(
            "Internal cylindrical dimensions with flat ends.",
            "मान्यता: टैंक के अंदरूनी व्यास व लंबाई/ऊँचाई का मान।"
        ),
        keywords = listOf("tank volume", "cylindrical", "capacity", "liters", "gallons"),
        fields = listOf(
            CalculatorField("dia", BilingualText("Inner Diameter (D)", "आंतरिक व्यास (D)"), "2.5", "m", listOf("m", "mm")),
            CalculatorField("height", BilingualText("Height / Length (H)", "ऊँचाई / लंबाई (H)"), "4.0", "m", listOf("m", "mm"))
        ),
        compute = { values, units ->
            runCatching {
                val rawD = requirePositive(values["dia"], BilingualText("Diameter", "व्यास"))
                val rawH = requirePositive(values["height"], BilingualText("Height", "ऊँचाई"))
                val d = if (units["dia"] == "mm") rawD / 1000.0 else rawD
                val h = if (units["height"] == "mm") rawH / 1000.0 else rawH
                val area = PI * d * d / 4.0
                val volM3 = area * h
                val liters = volM3 * 1000.0
                val usGal = liters / 3.78541
                engOutput(
                    primaryLabel = BilingualText("Total Tank Volume", "कुल टैंक क्षमता"),
                    primaryValue = formatEng(volM3, 3),
                    primaryUnit = "m³",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters", "लीटर"), formatEng(liters, 0), "L"),
                        SecondaryMetric(BilingualText("US Gallons", "US गैलन"), formatEng(usGal, 1), "gal"),
                        SecondaryMetric(BilingualText("Cross-Section Area", "क्षेत्रफल"), formatEng(area, 2), "m²")
                    ),
                    formulaUsed = "V = (πD²/4) × H",
                    substitutedFormula = "V = ${formatEng(area, 3)} × ${formatEng(h, 2)}",
                    stepExplanation = BilingualText("Capacity = ${formatEng(volM3, 3)} m³ (${formatEng(liters, 0)} L)", "कुल क्षमता = ${formatEng(volM3, 3)} m³")
                )
            }
        }
    )

    private fun tankVolRectangular() = CalculatorDefinition(
        id = "lvl_tank_vol_rect",
        serialNumber = 34,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Layers,
        title = BilingualText("Tank Volume Calculator (Rectangular)", "टैंक वॉल्यूम कैलकुलेटर (आयताकार)"),
        subtitle = BilingualText("Compute Sump / Rectangular Tank Volume in m³, Liters & Gal", "आयताकार टैंक या सम्प की क्षमता m³ व लीटर में निकालें"),
        formulaPreview = "V = L × W × H",
        assumptions = BilingualText(
            "Uses internal tank dimensions Length × Width × Height.",
            "मान्यता: टैंक की आंतरिक लंबाई × चौड़ाई × ऊँचाई।"
        ),
        keywords = listOf("rectangular tank", "sump volume", "box tank", "liters"),
        fields = listOf(
            CalculatorField("len", BilingualText("Length (L)", "लंबाई (L)"), "4.0", "m"),
            CalculatorField("wid", BilingualText("Width (W)", "चौड़ाई (W)"), "3.0", "m"),
            CalculatorField("hei", BilingualText("Height / Level (H)", "ऊँचाई / लेवल (H)"), "2.5", "m")
        ),
        compute = { values, _ ->
            runCatching {
                val l = requirePositive(values["len"], BilingualText("Length", "लंबाई"))
                val w = requirePositive(values["wid"], BilingualText("Width", "चौड़ाई"))
                val h = requirePositive(values["hei"], BilingualText("Height", "ऊँचाई"))
                val volM3 = l * w * h
                val liters = volM3 * 1000.0
                val usGal = liters / 3.78541
                engOutput(
                    primaryLabel = BilingualText("Rectangular Volume", "आयताकार टैंक वॉल्यूम"),
                    primaryValue = formatEng(volM3, 3),
                    primaryUnit = "m³",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters", "लीटर"), formatEng(liters, 0), "L"),
                        SecondaryMetric(BilingualText("US Gallons", "US गैलन"), formatEng(usGal, 1), "gal"),
                        SecondaryMetric(BilingualText("Base Area", "आधार क्षेत्रफल"), formatEng(l * w, 2), "m²")
                    ),
                    formulaUsed = "V = L × W × H",
                    substitutedFormula = "V = ${formatEng(l, 2)} × ${formatEng(w, 2)} × ${formatEng(h, 2)}",
                    stepExplanation = BilingualText("Volume = ${formatEng(volM3, 3)} m³ (${formatEng(liters, 0)} L)", "वॉल्यूम = ${formatEng(volM3, 3)} m³")
                )
            }
        }
    )

    private fun levelTxRange() = CalculatorDefinition(
        id = "lvl_tx_range",
        serialNumber = 35,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Tune,
        title = BilingualText("Level Transmitter Range Calculator", "लेवल ट्रांसमीटर रेंज (LRV / URV)"),
        subtitle = BilingualText("Calculate DP Level LRV, URV & Span for Dry or Wet Leg", "ड्राई या वेट-लेग DP लेवल ट्रांसमीटर के LRV, URV व स्पैन निकालें"),
        formulaPreview = "LRV = −H_w × SG_w   |   URV = (H_span × SG_p) − (H_w × SG_w)",
        assumptions = BilingualText(
            "Enter Wet Leg Height = 0 for open/dry-leg tank; positive height applies wet-leg zero suppression.",
            "मान्यता: ओपन/ड्राई-लेग टैंक के लिए वेट-लेग ऊँचाई = 0 रखें।"
        ),
        keywords = listOf("level transmitter", "wet leg", "dry leg", "lrv", "urv", "dp level"),
        fields = listOf(
            CalculatorField("span_mm", BilingualText("Level Measurement Span (H)", "मापने की ऊँचाई (H)"), "3000", "mm", listOf("mm", "m")),
            CalculatorField("sg_p", BilingualText("Process Liquid SG", "प्रोसेस द्रव SG"), "0.9", "SG"),
            CalculatorField("wet_mm", BilingualText("Wet Leg Height (0 if Dry)", "वेट-लेग ऊँचाई (ड्राई=0)"), "3500", "mm"),
            CalculatorField("sg_w", BilingualText("Wet Leg Seal SG", "वेट-लेग सील SG"), "1.0", "SG")
        ),
        compute = { values, units ->
            runCatching {
                val rawSpan = requirePositive(values["span_mm"], BilingualText("Span Height", "लेवल स्पैन"))
                val sgP = requirePositive(values["sg_p"], BilingualText("Process SG", "प्रोसेस SG"))
                val rawWet = requireNonNegative(values["wet_mm"], BilingualText("Wet Leg Height", "वेट-लेग ऊँचाई"))
                val sgW = requirePositive(values["sg_w"], BilingualText("Wet Leg SG", "वेट-लेग SG"))
                val spanMm = if (units["span_mm"] == "m") rawSpan * 1000.0 else rawSpan
                val wetMm = if (units["span_mm"] == "m") rawWet * 1000.0 else rawWet
                val lrvMmh2o = -wetMm * sgW
                val dpSpanMmh2o = spanMm * sgP
                val urvMmh2o = dpSpanMmh2o + lrvMmh2o
                val spanMbar = dpSpanMmh2o * 0.0980665
                engOutput(
                    primaryLabel = BilingualText("Calibration Span (URV − LRV)", "कैलिब्रेशन स्पैन"),
                    primaryValue = formatEng(dpSpanMmh2o, 1),
                    primaryUnit = "mmH₂O",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("LRV (0% Level)", "LRV (0% लेवल)"), formatEng(lrvMmh2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("URV (100% Level)", "URV (100% लेवल)"), formatEng(urvMmh2o, 1), "mmH₂O"),
                        SecondaryMetric(BilingualText("Span (mbar)", "स्पैन (mbar)"), formatEng(spanMbar, 2), "mbar")
                    ),
                    formulaUsed = "LRV = −H_w·SG_w   |   URV = H·SG_p + LRV",
                    substitutedFormula = "LRV = ${formatEng(lrvMmh2o, 1)}, URV = ${formatEng(urvMmh2o, 1)} mmH₂O",
                    stepExplanation = BilingualText("LRV = ${formatEng(lrvMmh2o, 1)} mmH₂O, URV = ${formatEng(urvMmh2o, 1)} mmH₂O", "LRV = ${formatEng(lrvMmh2o, 1)}, URV = ${formatEng(urvMmh2o, 1)} mmH₂O")
                )
            }
        }
    )

    private fun specificGravityCalc() = CalculatorDefinition(
        id = "lvl_specific_gravity",
        serialNumber = 36,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Science,
        title = BilingualText("Specific Gravity (SG) Calculator", "स्पेसिफिक ग्रेविटी (SG) कैलकुलेटर"),
        subtitle = BilingualText("Determine Fluid SG from Density or Measured DP & Height", "घनत्व या प्रेशर (mmH₂O) व ऊँचाई से स्पेसिफिक ग्रेविटी निकालें"),
        formulaPreview = "SG = ρ / 1000   |   SG = ΔP (mmH₂O) / h (mm)",
        assumptions = BilingualText(
            "Reference water density = 1000 kg/m³ at 4 °C.",
            "मान्यता: संदर्भ जल घनत्व = 1000 kg/m³।"
        ),
        keywords = listOf("specific gravity", "sg", "density", "api"),
        fields = listOf(
            CalculatorField("mode", BilingualText("Method", "विधि"), "1", "From DP & Height", listOf("From DP & Height", "From Density (kg/m³)"), isSelectorOnly = true),
            CalculatorField("val_a", BilingualText("Measured ΔP (mmH₂O) or Density (kg/m³)", "ΔP (mmH₂O) या घनत्व"), "2550", "unit"),
            CalculatorField("height_mm", BilingualText("Liquid Height (mm) [for DP mode]", "द्रव ऊँचाई (mm)"), "3000", "mm")
        ),
        compute = { values, units ->
            runCatching {
                val a = requirePositive(values["val_a"], BilingualText("Input Value", "इनपुट मान"))
                val mode = units["mode"] ?: "From DP & Height"
                val sg = if (mode == "From Density (kg/m³)") {
                    a / 1000.0
                } else {
                    val hMm = requirePositive(values["height_mm"], BilingualText("Height", "ऊँचाई"))
                    a / hMm
                }
                val density = sg * 1000.0
                val api = (141.5 / sg) - 131.5
                engOutput(
                    primaryLabel = BilingualText("Specific Gravity (SG)", "स्पेसिफिक ग्रेविटी (SG)"),
                    primaryValue = formatEng(sg, 4),
                    primaryUnit = "SG",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Fluid Density", "द्रव घनत्व"), formatEng(density, 1), "kg/m³"),
                        SecondaryMetric(BilingualText("Est. API Gravity", "API ग्रेविटी"), formatEng(api, 1), "°API")
                    ),
                    formulaUsed = if (mode == "From Density (kg/m³)") "SG = ρ / 1000" else "SG = ΔP_mmH₂O / h_mm",
                    substitutedFormula = "SG = ${formatEng(sg, 4)} (${formatEng(density, 1)} kg/m³)",
                    stepExplanation = BilingualText("SG = ${formatEng(sg, 4)} (ρ = ${formatEng(density, 1)} kg/m³)", "SG = ${formatEng(sg, 4)}")
                )
            }
        }
    )

    private fun liquidHeightFromPres() = CalculatorDefinition(
        id = "lvl_height_from_pres",
        serialNumber = 37,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Height,
        title = BilingualText("Liquid Height from Pressure Calculator", "प्रेशर से द्रव ऊँचाई (Height) निकालें"),
        subtitle = BilingualText("Compute Liquid Column Height (m / mm) from Tank Pressure", "बॉटम प्रेशर और SG से टैंक में द्रव की ऊँचाई निकालें"),
        formulaPreview = "h (m) = P (kPa) / (9.80665 × SG)",
        assumptions = BilingualText(
            "Open atmospheric vessel above liquid surface (g = 9.80665 m/s²).",
            "मान्यता: खुला टैंक (वायुमंडलीय सतह दाब) और g = 9.80665 m/s²।"
        ),
        keywords = listOf("liquid height", "level from pressure", "hydrostatic head"),
        fields = listOf(
            CalculatorField("press", BilingualText("Measured Gauge Pressure", "मापा गया प्रेशर"), "45", "kPa", listOf("kPa", "bar", "mbar", "mmH₂O", "psi")),
            CalculatorField("sg", BilingualText("Fluid Specific Gravity (SG)", "द्रव SG"), "1.0", "SG")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requireNonNegative(values["press"], BilingualText("Pressure", "प्रेशर"))
                val sg = requirePositive(values["sg"], BilingualText("SG", "SG"))
                val pKpa = when (units["press"]) {
                    "bar" -> rawP * 100.0
                    "mbar" -> rawP * 0.1
                    "mmH₂O" -> rawP * 0.00980665
                    "psi" -> rawP * 6.894757
                    else -> rawP
                }
                val hM = pKpa / (9.80665 * sg)
                val hMm = hM * 1000.0
                val hFt = hM * 3.28084
                engOutput(
                    primaryLabel = BilingualText("Liquid Column Height (h)", "द्रव की ऊँचाई (h)"),
                    primaryValue = formatEng(hM, 3),
                    primaryUnit = "m",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Height (mm)", "ऊँचाई (mm)"), formatEng(hMm, 1), "mm"),
                        SecondaryMetric(BilingualText("Height (ft)", "ऊँचाई (ft)"), formatEng(hFt, 2), "ft")
                    ),
                    formulaUsed = "h = P_kPa / (9.80665 × SG)",
                    substitutedFormula = "h = ${formatEng(pKpa, 3)} / (9.80665 × ${formatEng(sg, 3)})",
                    stepExplanation = BilingualText("Liquid Height = ${formatEng(hM, 3)} m (${formatEng(hMm, 0)} mm)", "ऊँचाई = ${formatEng(hM, 3)} m")
                )
            }
        }
    )

    private fun volumeToLevel() = CalculatorDefinition(
        id = "lvl_vol_to_level",
        serialNumber = 38,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Analytics,
        title = BilingualText("Volume to Level Calculator", "वॉल्यूम से लेवल (Height) कैलकुलेटर"),
        subtitle = BilingualText("Find Required Liquid Height for a Target Batch Volume", "वांछित वॉल्यूम (m³/लीटर) के लिए टैंक में आवश्यक लेवल निकालें"),
        formulaPreview = "h = Volume / Cross_Section_Area",
        assumptions = BilingualText(
            "Supports Vertical Cylindrical (uses Diameter) and Rectangular (uses Width × Length) tanks.",
            "मान्यता: वर्टिकल बेलनाकार (व्यास) या आयताकार (चौड़ाई × लंबाई) टैंक।"
        ),
        keywords = listOf("volume to level", "batch level", "target level"),
        fields = listOf(
            CalculatorField("shape", BilingualText("Tank Shape", "टैंक आकार"), "1", "Vertical Cylindrical", listOf("Vertical Cylindrical", "Rectangular"), isSelectorOnly = true),
            CalculatorField("vol", BilingualText("Target Liquid Volume", "लक्ष्य वॉल्यूम"), "15", "m³", listOf("m³", "Liters")),
            CalculatorField("dim_a", BilingualText("Diameter (Cyl) or Width (Rect)", "व्यास या चौड़ाई (m)"), "3.0", "m"),
            CalculatorField("dim_b", BilingualText("Length (Rect only)", "लंबाई (केवल आयताकार हेतु)"), "4.0", "m")
        ),
        compute = { values, units ->
            runCatching {
                val rawVol = requireNonNegative(values["vol"], BilingualText("Volume", "वॉल्यूम"))
                val dimA = requirePositive(values["dim_a"], BilingualText("Diameter / Width", "व्यास / चौड़ाई"))
                val dimB = requirePositive(values["dim_b"], BilingualText("Length", "लंबाई"))
                val volM3 = if (units["vol"] == "Liters") rawVol / 1000.0 else rawVol
                val isRect = units["shape"] == "Rectangular"
                val area = if (isRect) dimA * dimB else PI * dimA * dimA / 4.0
                val hM = volM3 / area
                engOutput(
                    primaryLabel = BilingualText("Required Liquid Level (h)", "आवश्यक द्रव लेवल (h)"),
                    primaryValue = formatEng(hM, 3),
                    primaryUnit = "m",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Level (mm)", "लेवल (mm)"), formatEng(hM * 1000.0, 1), "mm"),
                        SecondaryMetric(BilingualText("Base Area", "आधार क्षेत्रफल"), formatEng(area, 3), "m²")
                    ),
                    formulaUsed = "h = V / Area",
                    substitutedFormula = "h = ${formatEng(volM3, 3)} / ${formatEng(area, 3)}",
                    stepExplanation = BilingualText("Target Level = ${formatEng(hM, 3)} m (${formatEng(hM * 1000, 0)} mm)", "आवश्यक लेवल = ${formatEng(hM, 3)} m")
                )
            }
        }
    )

    private fun densityCorrectionLevel() = CalculatorDefinition(
        id = "lvl_density_corr",
        serialNumber = 39,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Opacity,
        title = BilingualText("Density Correction for Level", "लेवल के लिए डेंसिटी करेक्शन"),
        subtitle = BilingualText("Correct Hydrostatic Level Transmitter Reading When SG Changes", "द्रव SG बदलने पर हाइड्रोस्टैटिक लेवल रीडिंग को सही करें"),
        formulaPreview = "h_true = h_indicated × (SG_calibrated / SG_actual)",
        assumptions = BilingualText(
            "Applies to hydrostatic/DP level transmitters calibrated for a fixed design SG.",
            "मान्यता: निश्चित SG पर कैलिब्रेटेड हाइड्रोस्टैटिक या DP लेवल ट्रांसमीटर।"
        ),
        keywords = listOf("density correction", "level error", "sg change", "hydrostatic level"),
        fields = listOf(
            CalculatorField("h_ind", BilingualText("Indicated Level Reading", "ट्रांसमीटर द्वारा दिखाया गया लेवल"), "4.0", "m", listOf("m", "mm", "%")),
            CalculatorField("sg_cal", BilingualText("Calibrated Design SG", "कैलिब्रेटेड SG"), "1.0", "SG"),
            CalculatorField("sg_act", BilingualText("Actual Process SG", "वास्तविक प्रोसेस SG"), "0.85", "SG")
        ),
        compute = { values, units ->
            runCatching {
                val hInd = requireNonNegative(values["h_ind"], BilingualText("Indicated Level", "दिखाया गया लेवल"))
                val sgCal = requirePositive(values["sg_cal"], BilingualText("Calibrated SG", "कैलिब्रेटेड SG"))
                val sgAct = requirePositive(values["sg_act"], BilingualText("Actual SG", "वास्तविक SG"))
                val hTrue = hInd * (sgCal / sgAct)
                val diff = hTrue - hInd
                val unit = units["h_ind"] ?: "m"
                engOutput(
                    primaryLabel = BilingualText("True Physical Level", "वास्तविक सही लेवल"),
                    primaryValue = formatEng(hTrue, 3),
                    primaryUnit = unit,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Level Correction", "लेवल अंतर"), "${if (diff >= 0) "+" else ""}${formatEng(diff, 3)}", unit),
                        SecondaryMetric(BilingualText("Error Ratio", "त्रुटि %"), formatEng(((hTrue - hInd) / hTrue.coerceAtLeast(1e-9)) * 100.0, 2), "%")
                    ),
                    formulaUsed = "h_true = h_ind × (SG_cal / SG_act)",
                    substitutedFormula = "h_true = ${formatEng(hInd, 3)} × (${formatEng(sgCal, 3)} / ${formatEng(sgAct, 3)})",
                    stepExplanation = BilingualText("True Level = ${formatEng(hTrue, 3)} $unit (Indicated ${formatEng(hInd, 3)} $unit)", "सही लेवल = ${formatEng(hTrue, 3)} $unit"),
                    statusLevel = if (kotlin.math.abs(sgCal - sgAct) / sgCal > 0.05) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun massFromLevelDensity() = CalculatorDefinition(
        id = "lvl_mass_from_level",
        serialNumber = 40,
        category = CalculatorCategory.INST_LEVEL,
        icon = Icons.Rounded.Scale,
        title = BilingualText("Mass from Level & Density Calculator", "लेवल और घनत्व से मास (Mass) निकालें"),
        subtitle = BilingualText("Calculate Tank Product Inventory Mass (kg / Tons) from Level", "टैंक व्यास, लेवल व घनत्व से कुल वजन (kg / टन) निकालें"),
        formulaPreview = "Mass (kg) = (π × D² / 4) × h × ρ",
        assumptions = BilingualText(
            "Vertical cylindrical tank with uniform liquid density ρ at tank temperature.",
            "मान्यता: वर्टिकल बेलनाकार टैंक और एकसमान द्रव घनत्व ρ।"
        ),
        keywords = listOf("tank mass", "inventory", "tons", "level density"),
        fields = listOf(
            CalculatorField("dia", BilingualText("Tank Diameter (D)", "टैंक व्यास (D)"), "4.0", "m"),
            CalculatorField("level", BilingualText("Liquid Level (h)", "द्रव लेवल (h)"), "3.5", "m"),
            CalculatorField("rho", BilingualText("Fluid Density (ρ)", "द्रव घनत्व (ρ)"), "920", "kg/m³")
        ),
        compute = { values, _ ->
            runCatching {
                val d = requirePositive(values["dia"], BilingualText("Diameter", "व्यास"))
                val h = requireNonNegative(values["level"], BilingualText("Level", "लेवल"))
                val rho = requirePositive(values["rho"], BilingualText("Density", "घनत्व"))
                val volM3 = (PI * d * d / 4.0) * h
                val massKg = volM3 * rho
                val tons = massKg / 1000.0
                val pBottomKpa = (rho * 9.80665 * h) / 1000.0
                engOutput(
                    primaryLabel = BilingualText("Total Liquid Mass", "कुल द्रव वजन (Mass)"),
                    primaryValue = formatEng(tons, 3),
                    primaryUnit = "Tons",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Mass (kg)", "वजन (kg)"), formatEng(massKg, 0), "kg"),
                        SecondaryMetric(BilingualText("Volume", "वॉल्यूम"), formatEng(volM3, 2), "m³"),
                        SecondaryMetric(BilingualText("Bottom Pressure", "तली पर प्रेशर"), formatEng(pBottomKpa, 2), "kPa")
                    ),
                    formulaUsed = "Mass = (πD²/4) × h × ρ",
                    substitutedFormula = "Mass = ${formatEng(volM3, 2)} m³ × ${formatEng(rho, 0)} kg/m³",
                    stepExplanation = BilingualText("Inventory = ${formatEng(tons, 3)} Metric Tons (${formatEng(massKg, 0)} kg)", "कुल वजन = ${formatEng(tons, 3)} टन")
                )
            }
        }
    )
}
