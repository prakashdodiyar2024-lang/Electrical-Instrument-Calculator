package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.EngineeringExamples
import com.example.model.AppLanguage
import com.example.model.CalculationOutput
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorPreset
import com.example.model.StatusLevel
import com.example.ui.CalculatorScreenUiState
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.BrightOrangeAccent
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CrispLightText
import com.example.ui.theme.DarkBlueprintBg
import com.example.ui.theme.DarkBlueprintSurface
import com.example.ui.theme.DarkBlueprintSurfaceElevated
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkElectricTint
import com.example.ui.theme.DarkOrangeTint
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueBright
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBluePrimary
import com.example.ui.theme.MutedLightText
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SafetyOrange
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusErrorRed
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusSuccessGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.StatusWarningBg
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalculatorScreen(
    uiState: CalculatorScreenUiState,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onFieldValueChange: (String, String) -> Unit,
    onToggleSign: (String) -> Unit,
    onFieldUnitChange: (String, String) -> Unit,
    onApplyPreset: (CalculatorPreset) -> Unit,
    onCalculate: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val calc = uiState.activeCalculator ?: return
    val lang = uiState.language
    val keyboardController = LocalSoftwareKeyboardController.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var scrollToOutcomeOnNextResult by remember { mutableStateOf(false) }
    val playClick = rememberTouchClickSound()

    LaunchedEffect(uiState.result, uiState.errorText, scrollToOutcomeOnNextResult) {
        if (scrollToOutcomeOnNextResult && (uiState.result != null || uiState.errorText != null)) {
            scrollToOutcomeOnNextResult = false
            val outcomeIndex = if (calc.presets.isNotEmpty()) 3 else 2
            listState.animateScrollToItem(outcomeIndex)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ObsidianBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = calc.title.get(lang),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = calc.category.shortTitle.get(lang),
                            style = MaterialTheme.typography.labelSmall,
                            color = BrightOrangeAccent,
                            maxLines = 1
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            playClick()
                            onBack()
                        },
                        modifier = Modifier.testTag("calculator_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = if (lang == AppLanguage.ENGLISH) "Back" else "वापस",
                            tint = PureWhite
                        )
                    }
                },
                actions = {
                    LanguageToggleChip(
                        language = lang,
                        onToggle = onToggleLanguage,
                        darkSurface = true,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepNavy)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DarkBlueprintBg, ObsidianBlack)
                    )
                )
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 820.dp)
                    .align(Alignment.TopCenter)
                    .testTag("calculator_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // SECTION 1: Formula Card
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = DarkBlueprintSurface,
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(DarkElectricTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Functions,
                                        contentDescription = null,
                                        tint = LightBluePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) "FORMULA" else "मुख्य सूत्र (FORMULA)",
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.6.sp
                                        ),
                                        color = LightBluePrimary
                                    )
                                    Text(
                                        text = calc.subtitle.get(lang),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedLightText,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkBlueprintSurfaceElevated,
                                border = BorderStroke(1.dp, DarkBorderSubtle),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = calc.formulaPreview,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = CrispLightText,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }

                // Quick Examples (Presets) if available
                if (calc.presets.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) "Quick Examples (Tap to fill)" else "त्वरित उदाहरण (टेस्ट करने के लिए दबाएं)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MutedLightText
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(calc.presets) { preset ->
                                    Surface(
                                        onClick = {
                                            playClick()
                                            keyboardController?.hide()
                                            scrollToOutcomeOnNextResult = true
                                            onApplyPreset(preset)
                                        },
                                        shape = RoundedCornerShape(50),
                                        color = DarkOrangeTint,
                                        border = BorderStroke(1.dp, SafetyOrange.copy(alpha = 0.55f)),
                                        modifier = Modifier.testTag("preset_chip_${preset.label.en}")
                                    ) {
                                        Text(
                                            text = preset.label.get(lang),
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.SemiBold
                                            ),
                                            color = BrightOrangeAccent,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // SECTION 2: Input Parameters Card
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkBlueprintSurface),
                        border = BorderStroke(1.dp, DarkBorderSubtle),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(DarkElectricTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Tune,
                                        contentDescription = null,
                                        tint = LightBluePrimary,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) "Input Parameters" else "इनपुट मान दर्ज करें",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = CrispLightText
                                )
                            }

                            HorizontalDivider(color = DarkBorderSubtle)

                            calc.fields.forEachIndexed { index, field ->
                                val currentValue = uiState.inputValues[field.id] ?: ""
                                val currentUnit = uiState.inputUnits[field.id] ?: field.defaultUnit
                                val isLast = index == calc.fields.lastIndex
                                val isModeOnlyField = field.isSelectorOnly

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (!isModeOnlyField) {
                                        OutlinedTextField(
                                            value = currentValue,
                                            onValueChange = { onFieldValueChange(field.id, it) },
                                            label = {
                                                Text(
                                                    text = field.label.get(lang),
                                                    color = MutedLightText
                                                )
                                            },
                                            trailingIcon = if (field.allowNegative) {
                                                {
                                                    Surface(
                                                        onClick = {
                                                            playClick()
                                                            onToggleSign(field.id)
                                                        },
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = DarkElectricTint,
                                                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.5f)),
                                                        modifier = Modifier
                                                            .padding(end = 6.dp)
                                                            .testTag("sign_toggle_${field.id}")
                                                    ) {
                                                        Text(
                                                            text = "±",
                                                            style = MaterialTheme.typography.titleMedium.copy(
                                                                fontFamily = JetBrainsMonoFontFamily,
                                                                fontWeight = FontWeight.Bold
                                                            ),
                                                            color = LightBluePrimary,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }
                                            } else null,
                                            suffix = {
                                                Text(
                                                    text = currentUnit,
                                                    style = MaterialTheme.typography.labelLarge.copy(
                                                        fontFamily = JetBrainsMonoFontFamily,
                                                        fontWeight = FontWeight.Bold
                                                    ),
                                                    color = BrightOrangeAccent
                                                )
                                            },
                                            supportingText = field.helperText?.let { helper ->
                                                {
                                                    Text(
                                                        text = helper.get(lang),
                                                        color = MutedLightText
                                                    )
                                                }
                                            },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Decimal,
                                                imeAction = if (isLast) ImeAction.Done else ImeAction.Next
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = {
                                                    keyboardController?.hide()
                                                    scrollToOutcomeOnNextResult = true
                                                    onCalculate()
                                                }
                                            ),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedContainerColor = DarkBlueprintSurfaceElevated,
                                                unfocusedContainerColor = DarkBlueprintSurfaceElevated,
                                                focusedTextColor = CrispLightText,
                                                unfocusedTextColor = CrispLightText,
                                                focusedBorderColor = ElectricBlue,
                                                unfocusedBorderColor = DarkBorderSubtle,
                                                focusedLabelColor = LightBluePrimary,
                                                cursorColor = SafetyOrange
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_field_${field.id}")
                                        )
                                    } else {
                                        Text(
                                            text = field.label.get(lang),
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                            color = CrispLightText
                                        )
                                    }

                                    if (field.unitOptions.size > 1) {
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            field.unitOptions.forEach { unitOpt ->
                                                val selected = currentUnit == unitOpt
                                                FilterChip(
                                                    selected = selected,
                                                    onClick = {
                                                        playClick()
                                                        onFieldUnitChange(field.id, unitOpt)
                                                    },
                                                    label = {
                                                        Text(
                                                            text = unitOpt,
                                                            style = MaterialTheme.typography.labelMedium.copy(
                                                                fontFamily = JetBrainsMonoFontFamily,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                        )
                                                    },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        containerColor = DarkBlueprintSurfaceElevated,
                                                        labelColor = MutedLightText,
                                                        selectedContainerColor = ElectricBlue,
                                                        selectedLabelColor = PureWhite
                                                    ),
                                                    border = FilterChipDefaults.filterChipBorder(
                                                        enabled = true,
                                                        selected = selected,
                                                        borderColor = DarkBorderSubtle,
                                                        selectedBorderColor = ElectricBlueBright
                                                    ),
                                                    modifier = Modifier.testTag("unit_chip_${field.id}_$unitOpt")
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            // Calculate & Reset Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        playClick()
                                        keyboardController?.hide()
                                        onReset()
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.5.dp, LightBluePrimary),
                                    modifier = Modifier
                                        .weight(0.38f)
                                        .heightIn(min = 52.dp)
                                        .testTag("reset_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Refresh,
                                        contentDescription = null,
                                        tint = LightBluePrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) "Reset" else "रीसेट",
                                        color = LightBluePrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = {
                                        playClick()
                                        keyboardController?.hide()
                                        scrollToOutcomeOnNextResult = true
                                        onCalculate()
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SafetyOrange,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(0.62f)
                                        .heightIn(min = 52.dp)
                                        .testTag("calculate_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Calculate,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) "Calculate" else "गणना करें",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }

                // Error Message Banner
                if (uiState.errorText != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = StatusErrorBg,
                            border = BorderStroke(1.dp, StatusErrorRed.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("error_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Warning,
                                    contentDescription = null,
                                    tint = StatusErrorRed
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = uiState.errorText.get(lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StatusErrorRed,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // SECTION 3+: Final Answer, Input Values, Calculation Steps, Practical Example & Notes
                val currentOutput = uiState.result
                if (currentOutput != null) {
                    item(key = "result_card_item") {
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn() + expandVertically()
                        ) {
                            PrimaryResultCard(
                                output = currentOutput,
                                language = lang,
                                onCopyResult = {
                                    playClick()
                                    val summary = "${currentOutput.primaryLabel.get(lang)}: ${currentOutput.primaryValue} ${currentOutput.primaryUnit}"
                                    clipboard.setText(AnnotatedString(summary))
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (lang == AppLanguage.ENGLISH) "Result copied to clipboard"
                                            else "परिणाम कॉपी हो गया"
                                        )
                                    }
                                }
                            )
                        }
                    }

                    item(key = "input_values_summary_item") {
                        InputValuesSummaryCard(
                            calculator = calc,
                            inputValues = uiState.inputValues,
                            inputUnits = uiState.inputUnits,
                            language = lang
                        )
                    }

                    item(key = "steps_card_item") {
                        StepsCard(output = currentOutput, language = lang)
                    }

                    EngineeringExamples.forCalculator(calc.id)?.let { exampleText ->
                        item(key = "practical_example_item") {
                            PracticalExampleCard(
                                exampleText = exampleText.get(lang),
                                language = lang
                            )
                        }
                    }

                    currentOutput.engineeringNote?.let { note ->
                        item(key = "engineering_note_item") {
                            EngineeringNoteBanner(
                                noteText = note.get(lang),
                                isWarn = currentOutput.statusLevel == StatusLevel.WARNING
                            )
                        }
                    }

                    currentOutput.assumptions?.let { assumption ->
                        item(key = "assumptions_banner_item") {
                            AssumptionsBanner(text = assumption.get(lang))
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PrimaryResultCard(
    output: CalculationOutput,
    language: AppLanguage,
    onCopyResult: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, ElectricBlueBright.copy(alpha = 0.55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("result_card")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(DeepNavy, CobaltBlue)
                    )
                )
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (output.statusLevel == StatusLevel.WARNING) SafetyOrange else ElectricBlue
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (output.statusLevel == StatusLevel.WARNING) {
                                    Icons.Rounded.Warning
                                } else {
                                    Icons.Rounded.CheckCircle
                                },
                                contentDescription = null,
                                tint = PureWhite,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "FINAL ANSWER" else "अंतिम उत्तर",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.6.sp
                                ),
                                color = PureWhite
                            )
                        }
                    }

                    IconButton(
                        onClick = onCopyResult,
                        modifier = Modifier.testTag("copy_result_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = if (language == AppLanguage.ENGLISH) "Copy Result" else "परिणाम कॉपी करें",
                            tint = PureWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = output.primaryLabel.get(language),
                    style = MaterialTheme.typography.titleSmall,
                    color = PureWhite.copy(alpha = 0.86f)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = output.primaryValue,
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 33.sp
                        ),
                        color = PureWhite,
                        modifier = Modifier.testTag("primary_result_value")
                    )
                    val unitDisplay = output.primaryUnitLocalized?.get(language) ?: output.primaryUnit
                    if (unitDisplay.isNotBlank()) {
                        Text(
                            text = unitDisplay,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = BrightOrangeAccent,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }

                if (output.secondaryMetrics.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = PureWhite.copy(alpha = 0.18f))
                    Spacer(modifier = Modifier.height(12.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        output.secondaryMetrics.forEach { metric ->
                            val metricVal = metric.localizedValue?.get(language) ?: metric.value
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = ObsidianBlack.copy(alpha = 0.35f),
                                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.16f))
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(
                                        text = metric.label.get(language),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PureWhite.copy(alpha = 0.78f)
                                    )
                                    Text(
                                        text = "$metricVal ${metric.unit}".trim(),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = PureWhite
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InputValuesSummaryCard(
    calculator: CalculatorDefinition,
    inputValues: Map<String, String>,
    inputUnits: Map<String, String>,
    language: AppLanguage
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkBlueprintSurface),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("input_values_summary_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkElectricTint),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = null,
                        tint = LightBluePrimary,
                        modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (language == AppLanguage.ENGLISH) "Given Input Values" else "दिए गए इनपुट मान",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = LightBluePrimary
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                calculator.fields.forEach { field ->
                    val unit = inputUnits[field.id] ?: field.defaultUnit
                    val displayVal = if (field.isSelectorOnly) {
                        unit
                    } else {
                        val raw = inputValues[field.id]?.trim().orEmpty().ifEmpty { field.defaultValue }
                        "$raw $unit".trim()
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkBlueprintSurfaceElevated,
                        border = BorderStroke(1.dp, DarkBorderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                            Text(
                                text = field.label.get(language),
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedLightText
                            )
                            Text(
                                text = displayVal,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = CrispLightText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepsCard(
    output: CalculationOutput,
    language: AppLanguage
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkBlueprintSurface),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("steps_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkElectricTint),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Functions,
                            contentDescription = null,
                            tint = LightBluePrimary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            "Formula & Step-by-Step Solution"
                        } else {
                            "सूत्र और स्टेप-बाय-स्टेप समाधान"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = LightBluePrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = DarkOrangeTint,
                    border = BorderStroke(1.dp, SafetyOrange.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) "${output.steps.size} STEPS" else "${output.steps.size} चरण",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = BrightOrangeAccent,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // Sub-block 1: Formula
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = if (language == AppLanguage.ENGLISH) "FORMULA" else "सूत्र (FORMULA)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp
                    ),
                    color = MutedLightText
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkBlueprintSurfaceElevated,
                    border = BorderStroke(1.dp, DarkBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = output.formulaUsed,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = CrispLightText,
                        modifier = Modifier.padding(11.dp)
                    )
                }
            }

            // Sub-block 2: Substitution
            if (output.substitutedFormula.isNotBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) "SUBSTITUTION" else "मान प्रतिस्थापन (SUBSTITUTION)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        ),
                        color = LightBluePrimary
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkElectricTint,
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("substituted_formula_box")
                    ) {
                        Text(
                            text = output.substitutedFormula,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = LightBluePrimary,
                            modifier = Modifier.padding(11.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = DarkBorderSubtle)

            // Sub-block 3: Step-by-Step Calculation
            Text(
                text = if (language == AppLanguage.ENGLISH) "STEP-BY-STEP CALCULATION" else "चरणबद्ध गणना (STEPS)",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.6.sp
                ),
                color = BrightOrangeAccent
            )

            output.steps.forEach { step ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(SafetyOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${step.stepNumber}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = step.title.get(language),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = CrispLightText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkBlueprintSurfaceElevated,
                            border = BorderStroke(1.dp, DarkBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = step.expression,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = LightBluePrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = step.explanation.get(language),
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedLightText
                        )
                    }
                }
            }

            // Sub-block 4: Final Answer Summary Bar
            val unitDisplay = output.primaryUnitLocalized?.get(language) ?: output.primaryUnit
            val finalSummary = "${output.primaryLabel.get(language)} = ${output.primaryValue} $unitDisplay".trim()
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkOrangeTint,
                border = BorderStroke(1.dp, SafetyOrange.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("solution_final_answer")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = BrightOrangeAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (language == AppLanguage.ENGLISH) "FINAL ANSWER" else "अंतिम उत्तर",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = BrightOrangeAccent
                        )
                        Text(
                            text = finalSummary,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = PureWhite
                        )
                    }
                }
            }

            // Sub-block 5: Practical Result Explanation
            output.resultExplanation?.let { explanation ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkBlueprintSurfaceElevated,
                    border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("result_explanation_box")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = LightBluePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "RESULT EXPLANATION" else "परिणाम की व्याख्या",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = LightBluePrimary
                            )
                            Text(
                                text = explanation.get(language),
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispLightText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PracticalExampleCard(
    exampleText: String,
    language: AppLanguage
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkBlueprintSurface),
        border = BorderStroke(1.dp, SafetyOrange.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("practical_example_card")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkOrangeTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lightbulb,
                    contentDescription = null,
                    tint = BrightOrangeAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (language == AppLanguage.ENGLISH) {
                        "Practical Engineering Example"
                    } else {
                        "व्यावहारिक इंजीनियरिंग उदाहरण"
                    },
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = BrightOrangeAccent
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = exampleText,
                    style = MaterialTheme.typography.bodySmall,
                    color = CrispLightText
                )
            }
        }
    }
}

@Composable
private fun EngineeringNoteBanner(
    noteText: String,
    isWarn: Boolean
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isWarn) StatusWarningBg else StatusSuccessBg,
        border = BorderStroke(
            1.dp,
            if (isWarn) StatusWarningAmber.copy(alpha = 0.5f) else StatusSuccessGreen.copy(alpha = 0.45f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = if (isWarn) Icons.Rounded.Warning else Icons.Rounded.Info,
                contentDescription = null,
                tint = if (isWarn) StatusWarningAmber else StatusSuccessGreen,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = noteText,
                style = MaterialTheme.typography.bodySmall,
                color = if (isWarn) StatusWarningAmber else StatusSuccessGreen,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun AssumptionsBanner(text: String) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = DarkBlueprintSurface,
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("assumptions_banner")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Rounded.Info,
                contentDescription = null,
                tint = LightBluePrimary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = MutedLightText
            )
        }
    }
}
