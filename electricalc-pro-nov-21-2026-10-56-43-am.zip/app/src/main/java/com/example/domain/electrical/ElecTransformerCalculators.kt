package com.example.domain.electrical

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.ElectricMeter
import androidx.compose.material.icons.rounded.ElectricalServices
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Warning
import com.example.domain.STANDARD_BREAKER_A
import com.example.domain.STANDARD_XFMR_KVA
import com.example.domain.engOutput
import com.example.domain.nearestStandardRating
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.sqrt

object ElecTransformerCalculators {

    val all: List<CalculatorDefinition> = listOf(
        transformerKva(),           // 11
        kvaToKw(),                  // 12
        kwToKva(),                  // 13
        transformerFlc(),           // 14
        transformerEfficiency(),    // 15
        transformerVoltageReg(),    // 16
        transformerTurnsRatio(),    // 17
        priSecCurrent(),            // 18
        transformerCoreArea(),      // 19
        transformerLosses()         // 20
    )

    private fun transformerKva() = CalculatorDefinition(
        id = "xfmr_kva",
        serialNumber = 11,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.ElectricalServices,
        title = BilingualText("Transformer kVA Calculator", "ट्रांसफॉर्मर kVA कैलकुलेटर"),
        subtitle = BilingualText("Size Transformer kVA from Load Current, Voltage & Margin", "लोड करंट व वोल्टेज से ट्रांसफॉर्मर की kVA क्षमता निकालें"),
        formulaPreview = "kVA_3φ = (√3 × V × I) / 1000   |   kVA_1φ = (V × I) / 1000",
        assumptions = BilingualText(
            "Applies 20% recommended continuous growth margin and selects standard IEC kVA rating.",
            "मान्यता: 20% सेफ्टी मार्जिन के साथ मानक IEC kVA रेटिंग चुनी जाती है।"
        ),
        keywords = listOf("transformer", "kva", "sizing", "rating", "ट्रांसफॉर्मर"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Phase System", "फेज़ सिस्टम"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("voltage", BilingualText("Secondary Voltage", "सेकेंडरी वोल्टेज"), "415", "V", listOf("V", "kV")),
            CalculatorField("current", BilingualText("Load Current (I)", "लोड करंट (I)"), "280", "A"),
            CalculatorField("margin", BilingualText("Safety Margin (%)", "सेफ्टी मार्जिन (%)"), "20", "%")
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val margin = requireRange(values["margin"], 0.0, 100.0, BilingualText("Safety Margin", "सेफ्टी मार्जिन"))
                val v = if (units["voltage"] == "kV") rawV * 1000.0 else rawV
                val is3Ph = (units["phase"] ?: "3φ") == "3φ"
                val mult = if (is3Ph) sqrt(3.0) else 1.0
                val netKva = (mult * v * i) / 1000.0
                val withMargin = netKva * (1.0 + margin / 100.0)
                val stdKva = nearestStandardRating(withMargin, STANDARD_XFMR_KVA)
                engOutput(
                    primaryLabel = BilingualText("Recommended Standard Rating", "सुझावित मानक ट्रांसफॉर्मर"),
                    primaryValue = formatEng(stdKva, 0),
                    primaryUnit = "kVA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Net Load kVA", "वास्तविक लोड"), formatEng(netKva, 2), "kVA"),
                        SecondaryMetric(BilingualText("With Margin", "मार्जिन सहित"), formatEng(withMargin, 2), "kVA"),
                        SecondaryMetric(BilingualText("Loading at Std Rating", "लोडिंग %"), formatEng((netKva / stdKva) * 100.0, 1), "%")
                    ),
                    formulaUsed = "S = (k × V × I) / 1000 × (1 + margin%)",
                    substitutedFormula = "S = (${formatEng(mult, 3)} × ${formatEng(v, 1)} × ${formatEng(i, 1)}) / 1000",
                    stepExplanation = BilingualText("Net = ${formatEng(netKva, 2)} kVA → Select ${formatEng(stdKva, 0)} kVA unit", "कुल लोड = ${formatEng(netKva, 2)} kVA → मानक ${formatEng(stdKva, 0)} kVA चुनें")
                )
            }
        }
    )

    private fun kvaToKw() = CalculatorDefinition(
        id = "xfmr_kva_to_kw",
        serialNumber = 12,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("kVA to kW Calculator", "kVA से kW कैलकुलेटर"),
        subtitle = BilingualText("Convert Transformer Apparent kVA to Active kW Load", "kVA रेटिंग को वास्तविक उपयोग योग्य kW में बदलें"),
        formulaPreview = "P (kW) = S (kVA) × cos φ",
        assumptions = BilingualText(
            "Assumes lagging industrial power factor cos φ between 0.1 and 1.0.",
            "मान्यता: पावर फैक्टर cos φ 0.1 से 1.0 के बीच।"
        ),
        keywords = listOf("kva to kw", "apparent", "active power", "transformer"),
        fields = listOf(
            CalculatorField("kva", BilingualText("Apparent Power (kVA)", "अपैरेंट पावर (kVA)"), "500", "kVA"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, _ ->
            runCatching {
                val kva = requirePositive(values["kva"], BilingualText("kVA", "kVA"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val kw = kva * pf
                val kvar = sqrt((kva * kva - kw * kw).coerceAtLeast(0.0))
                engOutput(
                    primaryLabel = BilingualText("Active Power (kW)", "एक्टिव पावर (kW)"),
                    primaryValue = formatEng(kw, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), formatEng(kvar, 2), "kVAr"),
                        SecondaryMetric(BilingualText("Power Factor", "पावर फैक्टर"), formatEng(pf, 2), "cos φ")
                    ),
                    formulaUsed = "kW = kVA × cos φ",
                    substitutedFormula = "kW = ${formatEng(kva, 2)} × ${formatEng(pf, 2)}",
                    stepExplanation = BilingualText("${formatEng(kva, 2)} kVA at ${formatEng(pf, 2)} PF = ${formatEng(kw, 2)} kW", "${formatEng(kva, 2)} kVA = ${formatEng(kw, 2)} kW")
                )
            }
        }
    )

    private fun kwToKva() = CalculatorDefinition(
        id = "xfmr_kw_to_kva",
        serialNumber = 13,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.CompareArrows,
        title = BilingualText("kW to kVA Calculator", "kW से kVA कैलकुलेटर"),
        subtitle = BilingualText("Find Required Transformer / DG kVA from kW Load", "kW लोड से आवश्यक ट्रांसफॉर्मर / DG kVA निकालें"),
        formulaPreview = "S (kVA) = P (kW) / cos φ",
        assumptions = BilingualText(
            "Does not add spare diversity margin; usually size 20–25% higher for growth.",
            "मान्यता: बिना अतिरिक्त मार्जिन के शुद्ध kVA मान (बढ़ोतरी हेतु 20% जोड़ें)।"
        ),
        keywords = listOf("kw to kva", "transformer", "generator", "sizing"),
        fields = listOf(
            CalculatorField("kw", BilingualText("Active Load (kW)", "एक्टिव लोड (kW)"), "200", "kW"),
            CalculatorField("pf", BilingualText("Load Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.8", "cos φ")
        ),
        compute = { values, _ ->
            runCatching {
                val kw = requirePositive(values["kw"], BilingualText("kW Load", "kW लोड"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val kva = kw / pf
                val kvar = sqrt((kva * kva - kw * kw).coerceAtLeast(0.0))
                val std = nearestStandardRating(kva, STANDARD_XFMR_KVA)
                engOutput(
                    primaryLabel = BilingualText("Required Apparent Power", "आवश्यक अपैरेंट पावर"),
                    primaryValue = formatEng(kva, 2),
                    primaryUnit = "kVA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Reactive Demand", "रिएक्टिव लोड"), formatEng(kvar, 2), "kVAr"),
                        SecondaryMetric(BilingualText("Nearest Std Xfmr", "निकटतम मानक Xfmr"), formatEng(std, 0), "kVA")
                    ),
                    formulaUsed = "kVA = kW / cos φ",
                    substitutedFormula = "kVA = ${formatEng(kw, 2)} / ${formatEng(pf, 2)}",
                    stepExplanation = BilingualText("${formatEng(kw, 2)} kW at ${formatEng(pf, 2)} PF requires ${formatEng(kva, 2)} kVA", "आवश्यक क्षमता = ${formatEng(kva, 2)} kVA")
                )
            }
        }
    )

    private fun transformerFlc() = CalculatorDefinition(
        id = "xfmr_flc",
        serialNumber = 14,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.ElectricMeter,
        title = BilingualText("Transformer Full Load Current (FLC)", "ट्रांसफॉर्मर फुल लोड करंट (FLC)"),
        subtitle = BilingualText("Calculate Primary & Secondary Rated Amps from kVA", "kVA रेटिंग से प्राइमरी और सेकेंडरी फुल लोड करंट निकालें"),
        formulaPreview = "FLC_3φ = (kVA × 1000) / (√3 × V)   |   FLC_1φ = (kVA × 1000) / V",
        assumptions = BilingualText(
            "Assumes rated line-to-line voltages on primary and secondary windings at nominal tap.",
            "मान्यता: नॉमिनल टैप पर रेटेड प्राइमरी व सेकेंडरी वोल्टेज।"
        ),
        keywords = listOf("transformer flc", "full load current", "primary current", "secondary current"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Phase System", "फेज़ सिस्टम"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("kva", BilingualText("Transformer Rating", "ट्रांसफॉर्मर क्षमता"), "500", "kVA"),
            CalculatorField("v1", BilingualText("Primary Voltage (V₁)", "प्राइमरी वोल्टेज (V₁)"), "11", "kV", listOf("kV", "V")),
            CalculatorField("v2", BilingualText("Secondary Voltage (V₂)", "सेकेंडरी वोल्टेज (V₂)"), "415", "V", listOf("V", "kV"))
        ),
        compute = { values, units ->
            runCatching {
                val kva = requirePositive(values["kva"], BilingualText("kVA Rating", "kVA रेटिंग"))
                val rawV1 = requirePositive(values["v1"], BilingualText("Primary Voltage", "प्राइमरी वोल्टेज"))
                val rawV2 = requirePositive(values["v2"], BilingualText("Secondary Voltage", "सेकेंडरी वोल्टेज"))
                val v1 = if (units["v1"] == "kV") rawV1 * 1000.0 else rawV1
                val v2 = if (units["v2"] == "kV") rawV2 * 1000.0 else rawV2
                val is3Ph = (units["phase"] ?: "3φ") == "3φ"
                val mult = if (is3Ph) sqrt(3.0) else 1.0
                val i1 = (kva * 1000.0) / (mult * v1)
                val i2 = (kva * 1000.0) / (mult * v2)
                val secBreaker = nearestStandardRating(i2 * 1.15, STANDARD_BREAKER_A)
                engOutput(
                    primaryLabel = BilingualText("Secondary FLC (I₂)", "सेकेंडरी FLC (I₂)"),
                    primaryValue = formatEng(i2, 2),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Primary FLC (I₁)", "प्राइमरी FLC (I₁)"), formatEng(i1, 2), "A"),
                        SecondaryMetric(BilingualText("LT Main ACB/MCCB", "LT मेन ब्रेकर"), formatEng(secBreaker, 0), "A")
                    ),
                    formulaUsed = "FLC = (kVA × 1000) / (k × V)",
                    substitutedFormula = "I₂ = (${formatEng(kva, 1)} × 1000) / (${formatEng(mult, 3)} × ${formatEng(v2, 1)})",
                    stepExplanation = BilingualText("Primary FLC = ${formatEng(i1, 2)} A, Secondary FLC = ${formatEng(i2, 2)} A", "प्राइमरी FLC = ${formatEng(i1, 2)} A, सेकेंडरी FLC = ${formatEng(i2, 2)} A")
                )
            }
        }
    )

    private fun transformerEfficiency() = CalculatorDefinition(
        id = "xfmr_efficiency",
        serialNumber = 15,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.TrendingUp,
        title = BilingualText("Transformer Efficiency Calculator", "ट्रांसफॉर्मर एफिशिएंसी कैलकुलेटर"),
        subtitle = BilingualText("Compute Efficiency %, Total Losses & Max Efficiency Load", "आयरन व कॉपर लॉस से ट्रांसफॉर्मर एफिशिएंसी (%) निकालें"),
        formulaPreview = "η = (x·S·PF) / (x·S·PF + P_fe + x²·P_cu) × 100",
        assumptions = BilingualText(
            "Core/Iron loss (P_fe) stays constant with voltage; copper loss scales with load² (x²).",
            "मान्यता: आयरन लॉस (P_fe) स्थिर और कॉपर लॉस लोड के वर्ग (x²) से बदलता है।"
        ),
        keywords = listOf("transformer efficiency", "iron loss", "copper loss", "max efficiency"),
        fields = listOf(
            CalculatorField("kva", BilingualText("Transformer Rating (kVA)", "रेटेड क्षमता (kVA)"), "500", "kVA"),
            CalculatorField("load_pct", BilingualText("Load Fraction (%)", "लोड प्रतिशत (%)"), "75", "%"),
            CalculatorField("pf", BilingualText("Load Power Factor", "लोड पावर फैक्टर"), "0.85", "cos φ"),
            CalculatorField("pfe_w", BilingualText("No-Load / Core Loss (P_fe)", "कोर / आयरन लॉस (W)"), "950", "W", listOf("W", "kW")),
            CalculatorField("pcu_w", BilingualText("Full-Load Copper Loss (P_cu)", "फुल-लोड कॉपर लॉस (W)"), "5500", "W", listOf("W", "kW"))
        ),
        compute = { values, units ->
            runCatching {
                val kva = requirePositive(values["kva"], BilingualText("kVA Rating", "kVA रेटिंग"))
                val loadPct = requireRange(values["load_pct"], 1.0, 150.0, BilingualText("Load %", "लोड %"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val rawFe = requireNonNegative(values["pfe_w"], BilingualText("Core Loss", "कोर लॉस"))
                val rawCu = requireNonNegative(values["pcu_w"], BilingualText("Copper Loss", "कॉपर लॉस"))

                val pFeKw = if (units["pfe_w"] == "kW") rawFe else rawFe / 1000.0
                val pCuFlKw = if (units["pcu_w"] == "kW") rawCu else rawCu / 1000.0
                val x = loadPct / 100.0
                val pOut = x * kva * pf
                val pCuActual = x * x * pCuFlKw
                val totalLossKw = pFeKw + pCuActual
                val eff = (pOut / (pOut + totalLossKw)) * 100.0
                val maxEffPct = if (pCuFlKw > 0.0) sqrt(pFeKw / pCuFlKw) * 100.0 else 100.0

                engOutput(
                    primaryLabel = BilingualText("Transformer Efficiency (η)", "ट्रांसफॉर्मर एफिशिएंसी (η)"),
                    primaryValue = formatEng(eff, 2),
                    primaryUnit = "%",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Output Power", "आउटपुट पावर"), formatEng(pOut, 2), "kW"),
                        SecondaryMetric(BilingualText("Total Losses", "कुल लॉस"), formatEng(totalLossKw, 3), "kW"),
                        SecondaryMetric(BilingualText("Max Eff. Load", "अधिकतम दक्षता लोड"), formatEng(maxEffPct, 1), "%")
                    ),
                    formulaUsed = "η = (x·kVA·PF) / (x·kVA·PF + P_fe + x²·P_cu) × 100",
                    substitutedFormula = "η = ${formatEng(pOut, 2)} / (${formatEng(pOut, 2)} + ${formatEng(totalLossKw, 3)}) × 100",
                    stepExplanation = BilingualText("Efficiency = ${formatEng(eff, 2)}%, Losses = ${formatEng(totalLossKw, 3)} kW", "एफिशिएंसी = ${formatEng(eff, 2)}%")
                )
            }
        }
    )

    private fun transformerVoltageReg() = CalculatorDefinition(
        id = "xfmr_voltage_reg",
        serialNumber = 16,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.Equalizer,
        title = BilingualText("Transformer Voltage Regulation", "ट्रांसफॉर्मर वोल्टेज रेगुलेशन"),
        subtitle = BilingualText("Compute % Voltage Drop from No-Load to Full-Load", "नो-लोड से फुल-लोड के बीच वोल्टेज रेगुलेशन % निकालें"),
        formulaPreview = "%VR = ((V_NL − V_FL) / V_FL) × 100",
        assumptions = BilingualText(
            "Positive %VR indicates voltage drop under lagging/resistive load; lower %VR means stiffer regulation.",
            "मान्यता: कम %VR का अर्थ बेहतर वोल्टेज स्थिरता है।"
        ),
        keywords = listOf("voltage regulation", "no load", "full load", "transformer"),
        fields = listOf(
            CalculatorField("v_nl", BilingualText("No-Load Secondary Voltage (V_NL)", "नो-लोड वोल्टेज (V_NL)"), "433", "V"),
            CalculatorField("v_fl", BilingualText("Full-Load Secondary Voltage (V_FL)", "फुल-लोड वोल्टेज (V_FL)"), "415", "V")
        ),
        compute = { values, _ ->
            runCatching {
                val vNl = requirePositive(values["v_nl"], BilingualText("No-Load Voltage", "नो-लोड वोल्टेज"))
                val vFl = requirePositive(values["v_fl"], BilingualText("Full-Load Voltage", "फुल-लोड वोल्टेज"))
                val vrPct = ((vNl - vFl) / vFl) * 100.0
                val vrDownPct = ((vNl - vFl) / vNl) * 100.0
                val dropV = vNl - vFl
                engOutput(
                    primaryLabel = BilingualText("Voltage Regulation (%VR)", "वोल्टेज रेगुलेशन (%VR)"),
                    primaryValue = formatEng(vrPct, 2),
                    primaryUnit = "%",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Voltage Drop (ΔV)", "वोल्टेज ड्रॉप"), formatEng(dropV, 2), "V"),
                        SecondaryMetric(BilingualText("Regulation-Down", "रेगुलेशन-डाउन"), formatEng(vrDownPct, 2), "%")
                    ),
                    formulaUsed = "%VR = ((V_NL − V_FL) / V_FL) × 100",
                    substitutedFormula = "%VR = ((${formatEng(vNl, 2)} − ${formatEng(vFl, 2)}) / ${formatEng(vFl, 2)}) × 100",
                    stepExplanation = BilingualText("Voltage Regulation = ${formatEng(vrPct, 2)}% (ΔV = ${formatEng(dropV, 2)} V)", "वोल्टेज रेगुलेशन = ${formatEng(vrPct, 2)}%"),
                    statusLevel = if (vrPct > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun transformerTurnsRatio() = CalculatorDefinition(
        id = "xfmr_turns_ratio",
        serialNumber = 17,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.GridOn,
        title = BilingualText("Transformer Turns Ratio (N1/N2)", "ट्रांसफॉर्मर टर्न रेशियो (N1/N2)"),
        subtitle = BilingualText("Calculate Turns Ratio a = V₁/V₂ & Secondary Winding Turns", "प्राइमरी/सेकेंडरी वोल्टेज से टर्न रेशियो और N₂ निकालें"),
        formulaPreview = "a = N₁ / N₂ = V₁ / V₂   |   N₂ = N₁ × (V₂ / V₁)",
        assumptions = BilingualText(
            "Assumes ideal transformer coupling (K ≈ 1.0) at no-load.",
            "मान्यता: नो-लोड पर आदर्श चुंबकीय कपलिंग।"
        ),
        keywords = listOf("turns ratio", "n1/n2", "winding turns", "transformer"),
        fields = listOf(
            CalculatorField("v1", BilingualText("Primary Voltage (V₁)", "प्राइमरी वोल्टेज (V₁)"), "11", "kV", listOf("kV", "V")),
            CalculatorField("v2", BilingualText("Secondary Voltage (V₂)", "सेकेंडरी वोल्टेज (V₂)"), "415", "V", listOf("V", "kV")),
            CalculatorField("n1", BilingualText("Primary Turns (N₁)", "प्राइमरी टर्न्स (N₁)"), "1100", "turns")
        ),
        compute = { values, units ->
            runCatching {
                val rawV1 = requirePositive(values["v1"], BilingualText("Primary Voltage", "प्राइमरी वोल्टेज"))
                val rawV2 = requirePositive(values["v2"], BilingualText("Secondary Voltage", "सेकेंडरी वोल्टेज"))
                val n1 = requirePositive(values["n1"], BilingualText("Primary Turns", "प्राइमरी टर्न्स"))
                val v1 = if (units["v1"] == "kV") rawV1 * 1000.0 else rawV1
                val v2 = if (units["v2"] == "kV") rawV2 * 1000.0 else rawV2
                val ratio = v1 / v2
                val n2 = n1 / ratio
                val vPerTurn = v1 / n1
                val modeText = when {
                    ratio > 1.001 -> BilingualText("Step-Down Transformer", "स्टेप-डाउन ट्रांसफॉर्मर")
                    ratio < 0.999 -> BilingualText("Step-Up Transformer", "स्टेप-अप ट्रांसफॉर्मर")
                    else -> BilingualText("1:1 Isolation Transformer", "1:1 आइसोलेशन ट्रांसफॉर्मर")
                }
                engOutput(
                    primaryLabel = BilingualText("Turns Ratio (N₁ / N₂)", "टर्न रेशियो (N₁ / N₂)"),
                    primaryValue = "${formatEng(ratio, 3)} : 1",
                    primaryUnit = "",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Secondary Turns (N₂)", "सेकेंडरी टर्न्स (N₂)"), formatEng(n2, 1), "turns"),
                        SecondaryMetric(BilingualText("Volts / Turn", "वोल्ट प्रति टर्न"), formatEng(vPerTurn, 3), "V/turn"),
                        SecondaryMetric(BilingualText("Type", "प्रकार"), modeText.en, "", localizedValue = modeText)
                    ),
                    formulaUsed = "a = V₁ / V₂ = N₁ / N₂",
                    substitutedFormula = "a = ${formatEng(v1, 1)} / ${formatEng(v2, 1)} = ${formatEng(ratio, 3)}",
                    stepExplanation = BilingualText("Ratio = ${formatEng(ratio, 3)}:1, N₂ = ${formatEng(n2, 1)} turns", "रेशियो = ${formatEng(ratio, 3)}:1, N₂ = ${formatEng(n2, 1)}")
                )
            }
        }
    )

    private fun priSecCurrent() = CalculatorDefinition(
        id = "xfmr_pri_sec_current",
        serialNumber = 18,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Primary / Secondary Current Calculator", "प्राइमरी / सेकेंडरी करंट कैलकुलेटर"),
        subtitle = BilingualText("Find Primary Line Current from Secondary Load Current", "सेकेंडरी लोड करंट से प्राइमरी साइड करंट निकालें"),
        formulaPreview = "I₁ = I₂ × (V₂ / V₁)   |   S = k × V₂ × I₂",
        assumptions = BilingualText(
            "Neglects no-load magnetizing current (< 2% of FLC) for load transfer calculation.",
            "मान्यता: लोड गणना में नो-लोड मैग्नेटाइजिंग करंट नगण्य माना गया है।"
        ),
        keywords = listOf("primary current", "secondary current", "transformer ratio"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Phase System", "फेज़ सिस्टम"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("v1", BilingualText("Primary Voltage (V₁)", "प्राइमरी वोल्टेज (V₁)"), "11", "kV", listOf("kV", "V")),
            CalculatorField("v2", BilingualText("Secondary Voltage (V₂)", "सेकेंडरी वोल्टेज (V₂)"), "415", "V", listOf("V", "kV")),
            CalculatorField("i2", BilingualText("Secondary Current (I₂)", "सेकेंडरी करंट (I₂)"), "400", "A")
        ),
        compute = { values, units ->
            runCatching {
                val rawV1 = requirePositive(values["v1"], BilingualText("Primary Voltage", "प्राइमरी वोल्टेज"))
                val rawV2 = requirePositive(values["v2"], BilingualText("Secondary Voltage", "सेकेंडरी वोल्टेज"))
                val i2 = requirePositive(values["i2"], BilingualText("Secondary Current", "सेकेंडरी करंट"))
                val v1 = if (units["v1"] == "kV") rawV1 * 1000.0 else rawV1
                val v2 = if (units["v2"] == "kV") rawV2 * 1000.0 else rawV2
                val is3Ph = (units["phase"] ?: "3φ") == "3φ"
                val mult = if (is3Ph) sqrt(3.0) else 1.0
                val i1 = i2 * (v2 / v1)
                val kva = (mult * v2 * i2) / 1000.0
                engOutput(
                    primaryLabel = BilingualText("Primary Current (I₁)", "प्राइमरी करंट (I₁)"),
                    primaryValue = formatEng(i1, 3),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Secondary Current (I₂)", "सेकेंडरी करंट (I₂)"), formatEng(i2, 2), "A"),
                        SecondaryMetric(BilingualText("Apparent Load", "लोड (kVA)"), formatEng(kva, 2), "kVA")
                    ),
                    formulaUsed = "I₁ = I₂ × (V₂ / V₁)",
                    substitutedFormula = "I₁ = ${formatEng(i2, 2)} × (${formatEng(v2, 1)} / ${formatEng(v1, 1)})",
                    stepExplanation = BilingualText("Primary Current = ${formatEng(i1, 3)} A for ${formatEng(kva, 2)} kVA load", "प्राइमरी करंट = ${formatEng(i1, 3)} A")
                )
            }
        }
    )

    private fun transformerCoreArea() = CalculatorDefinition(
        id = "xfmr_core_area",
        serialNumber = 19,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.Power,
        title = BilingualText("Transformer Core Area Calculator", "ट्रांसफॉर्मर कोर एरिया कैलकुलेटर"),
        subtitle = BilingualText("Estimate Core Cross-Section (cm²) & Turns per Volt", "ट्रांसफॉर्मर kVA/VA से कोर क्रॉस-सेक्शन (cm²) व टर्न/वोल्ट निकालें"),
        formulaPreview = "A_net (cm²) = 1.152 × √VA   |   T/V = 1 / (4.44 × f × B_m × A_m²)",
        assumptions = BilingualText(
            "Uses standard CRGO silicon steel core (stacking factor 0.90, flux density B_m ≈ 1.2 T).",
            "मान्यता: मानक CRGO सिलिकॉन स्टील कोर (स्टैकिंग फैक्टर 0.90)।"
        ),
        keywords = listOf("core area", "bobbin", "turns per volt", "transformer design"),
        fields = listOf(
            CalculatorField("power", BilingualText("Transformer Rating", "ट्रांसफॉर्मर क्षमता"), "1000", "VA", listOf("VA", "kVA")),
            CalculatorField("freq", BilingualText("Frequency (f)", "फ्रीक्वेंसी (f)"), "50", "Hz"),
            CalculatorField("bm", BilingualText("Flux Density (B_m)", "फ्लक्स डेंसिटी (B_m)"), "1.2", "Tesla")
        ),
        compute = { values, units ->
            runCatching {
                val rawS = requirePositive(values["power"], BilingualText("Rating", "क्षमता"))
                val f = requireRange(values["freq"], 20.0, 1000.0, BilingualText("Frequency", "फ्रीक्वेंसी"))
                val bm = requireRange(values["bm"], 0.4, 1.8, BilingualText("Flux Density", "फ्लक्स डेंसिटी"))
                val va = if (units["power"] == "kVA") rawS * 1000.0 else rawS
                val netAreaCm2 = 1.152 * sqrt(va)
                val grossAreaCm2 = netAreaCm2 / 0.90
                val netAreaM2 = netAreaCm2 * 1e-4
                val ePerTurn = 4.44 * f * bm * netAreaM2
                val turnsPerVolt = 1.0 / ePerTurn
                engOutput(
                    primaryLabel = BilingualText("Net Core Area (A_net)", "नेट कोर एरिया (A_net)"),
                    primaryValue = formatEng(netAreaCm2, 2),
                    primaryUnit = "cm²",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Gross Core Area (0.9 SF)", "ग्रॉस कोर एरिया"), formatEng(grossAreaCm2, 2), "cm²"),
                        SecondaryMetric(BilingualText("Turns per Volt", "टर्न्स प्रति वोल्ट"), formatEng(turnsPerVolt, 3), "T/V")
                    ),
                    formulaUsed = "A_net = 1.152 × √VA   |   E_t = 4.44 × f × B_m × A",
                    substitutedFormula = "A_net = 1.152 × √${formatEng(va, 0)} = ${formatEng(netAreaCm2, 2)} cm²",
                    stepExplanation = BilingualText("Net Core = ${formatEng(netAreaCm2, 2)} cm², Gross = ${formatEng(grossAreaCm2, 2)} cm², ${formatEng(turnsPerVolt, 2)} T/V", "नेट कोर = ${formatEng(netAreaCm2, 2)} cm²")
                )
            }
        }
    )

    private fun transformerLosses() = CalculatorDefinition(
        id = "xfmr_losses",
        serialNumber = 20,
        category = CalculatorCategory.ELEC_TRANSFORMER,
        icon = Icons.Rounded.Warning,
        title = BilingualText("Transformer Loss (Cu & Fe) Calculator", "ट्रांसफॉर्मर लॉस (Cu व Fe) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Total Cu + Core Losses at Any % Load & Daily kWh", "किसी भी लोड % पर कुल कॉपर + आयरन लॉस और दैनिक खपत निकालें"),
        formulaPreview = "P_total = P_fe + (Load%/100)² × P_cu(FL)",
        assumptions = BilingualText(
            "Assumes rated primary excitation (constant P_fe) and 75 °C winding reference for P_cu.",
            "मान्यता: स्थिर कोर लॉस और मानक 75 °C वाइंडिंग तापमान पर कॉपर लॉस।"
        ),
        keywords = listOf("copper loss", "iron loss", "core loss", "transformer loss"),
        fields = listOf(
            CalculatorField("pfe", BilingualText("Iron / Core Loss (P_fe)", "आयरन / कोर लॉस (P_fe)"), "800", "W"),
            CalculatorField("pcu_fl", BilingualText("Full-Load Copper Loss (P_cu)", "फुल-लोड कॉपर लॉस"), "4500", "W"),
            CalculatorField("load_pct", BilingualText("Operating Load (%)", "वर्तमान लोड (%)"), "80", "%")
        ),
        compute = { values, _ ->
            runCatching {
                val pFe = requireNonNegative(values["pfe"], BilingualText("Core Loss", "कोर लॉस"))
                val pCuFl = requireNonNegative(values["pcu_fl"], BilingualText("Full-Load Copper Loss", "कॉपर लॉस"))
                val loadPct = requireRange(values["load_pct"], 0.0, 150.0, BilingualText("Operating Load (%)", "लोड (%)"))
                if (pFe + pCuFl <= 0.0) {
                    throw BilingualValidationException(
                        BilingualText("At least one loss value must be greater than 0.", "कम से कम एक लॉस मान 0 से बड़ा होना चाहिए।")
                    )
                }
                val x = loadPct / 100.0
                val pCuActual = x * x * pCuFl
                val totalW = pFe + pCuActual
                val dailyKwh = (totalW / 1000.0) * 24.0
                engOutput(
                    primaryLabel = BilingualText("Total Loss at ${formatEng(loadPct, 0)}% Load", "कुल ट्रांसफॉर्मर लॉस"),
                    primaryValue = formatEng(totalW, 1),
                    primaryUnit = "W",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Copper Loss (x²·P_cu)", "कॉपर लॉस"), formatEng(pCuActual, 1), "W"),
                        SecondaryMetric(BilingualText("Constant Core Loss", "स्थिर कोर लॉस"), formatEng(pFe, 1), "W"),
                        SecondaryMetric(BilingualText("24-Hr Energy Loss", "24 घंटे में लॉस"), formatEng(dailyKwh, 2), "kWh/day")
                    ),
                    formulaUsed = "P_total = P_fe + (x² × P_cu_FL)",
                    substitutedFormula = "P_total = ${formatEng(pFe, 0)} + (${formatEng(x, 2)}² × ${formatEng(pCuFl, 0)})",
                    stepExplanation = BilingualText("Total Loss = ${formatEng(totalW, 1)} W (${formatEng(dailyKwh, 2)} kWh/day)", "कुल लॉस = ${formatEng(totalW, 1)} W")
                )
            }
        }
    )
}
