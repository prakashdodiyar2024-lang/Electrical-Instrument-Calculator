package com.example.domain

import com.example.model.BilingualText

object EngineeringExamples {

    private val examples: Map<String, BilingualText> = mapOf(
        "elec_ohms_power" to BilingualText(
            en = "Field Case: A 24 V DC PLC solenoid valve draws 500 mA (0.5 A) at PF = 1.0. Coil resistance R = 24 / 0.5 = 48 Ω and power P = 24 × 0.5 = 12 W, confirming a standard 2 A relay output contact can switch it safely.",
            hi = "फील्ड उदाहरण: एक 24 V DC PLC सोलेनॉइड वाल्व 500 mA (0.5 A) करंट लेता है (PF = 1.0)। कॉइल रेजिस्टेंस R = 24 / 0.5 = 48 Ω और पावर P = 12 W होगी, जिसे 2 A का रिले कॉन्टैक्ट आसानी से चला सकता है।"
        ),
        "elec_3phase_power" to BilingualText(
            en = "Field Case: An MCC feeder at 415 V draws 50 A at 0.85 PF. Apparent load S = 1.732 × 415 × 50 / 1000 = 35.94 kVA, active power P = 30.55 kW, and reactive load Q = 18.93 kVAR for transformer sizing.",
            hi = "फील्ड उदाहरण: 415 V पैनल फीडर पर 50 A करंट और 0.85 PF है। कुल लोड S = 35.94 kVA, वास्तविक पावर P = 30.55 kW और रिएक्टिव पावर Q = 18.93 kVAR होगी, जिससे ट्रांसफॉर्मर/जनरेटर क्षमता तय होती है।"
        ),
        "elec_pf_capacitor" to BilingualText(
            en = "Field Case: A 100 kW plant running at 0.75 PF draws 185.5 A at 415 V. Adding a 68 kVAR (≈ 70 kVAR) APFC capacitor bank raises PF to 0.98 and drops line current to 142 A, avoiding utility PF penalties.",
            hi = "फील्ड उदाहरण: 100 kW लोड 0.75 PF पर 185.5 A करंट लेता है। 68 kVAR (मानक 70 kVAR) APFC कैपेसिटर बैंक लगाने से PF 0.98 हो जाता है और करंट घटकर 142 A रह जाता है, जिससे बिजली बिल की पेनल्टी बचती है।"
        ),
        "elec_voltage_drop" to BilingualText(
            en = "Field Case: A 415 V, 40 A pump fed over 120 m of 16 mm² 3-phase copper cable drops ΔV = 10.91 V (2.63%), leaving 404.1 V at the motor — well inside the 5% industrial motor limit.",
            hi = "फील्ड उदाहरण: 120 मीटर दूर 16 mm² कॉपर केबल से चल रही 415 V, 40 A मोटर में ΔV = 10.91 V (2.63%) ड्रॉप होता है और मोटर पर 404.1 V मिलता है, जो 5% सीमा के अंदर सुरक्षित है।"
        ),
        "inst_control_valve_cv" to BilingualText(
            en = "Field Case: Controlling 25 m³/h (110.1 GPM) cooling water (SG = 1.0) with P₁ = 6 bar and P₂ = 4.5 bar (ΔP = 21.76 psi) requires Cv = 23.60. Engineers pick a globe valve with rated Cv ≈ 32 so it controls near 70–75% travel.",
            hi = "फील्ड उदाहरण: 25 m³/h पानी (SG = 1.0) को P₁ = 6 bar से P₂ = 4.5 bar पर कंट्रोल करने के लिए Cv = 23.60 चाहिए। इसके लिए लगभग 32 Cv वाला कंट्रोल वाल्व चुनते हैं ताकि वह 70–75% ओपनिंग पर सटीक चले।"
        ),
        "inst_tx_error" to BilingualText(
            en = "Field Case: During 5-point calibration on a 0–100 bar pressure transmitter, applying 50 bar should read 12.000 mA. A reading of 12.080 mA gives +0.50% span error — exceeding ±0.25% tolerance, so a Zero/Span trim is needed.",
            hi = "फील्ड उदाहरण: 0–100 bar ट्रांसमीटर पर 50 bar प्रेशर देने पर 12.000 mA आना चाहिए। यदि मीटर 12.080 mA दिखाता है, तो त्रुटि +0.50% है जो ±0.25% सीमा से अधिक है — अतः HART से कैलिब्रेशन ट्रिम करना होगा।"
        ),
        "inst_dp_orifice_flow" to BilingualText(
            en = "Field Case: An orifice flow loop is designed for 120 m³/h at 2500 mmH₂O. If field DP reads 1600 mmH₂O (64% ΔP), actual flow is 120 × √(1600/2500) = 96 m³/h (80% of full scale).",
            hi = "फील्ड उदाहरण: यदि ऑरिफिस फ्लो मीटर 2500 mmH₂O पर 120 m³/h के लिए डिजाइन है और अभी ΔP = 1600 mmH₂O मिल रहा है, तो असली फ्लो = 120 × √(1600/2500) = 96 m³/h (80%) होगा।"
        ),
        "motor_flc" to BilingualText(
            en = "Field Case: A 15 kW, 415 V 3-phase motor (90% efficiency, 0.85 PF) draws FLC = 27.28 A at full load, with DOL starting surge around 6 × 27.28 ≈ 164 A — matching standard nameplate values (~27–28 A).",
            hi = "फील्ड उदाहरण: 15 kW, 415 V 3-फेज़ मोटर (90% एफिशिएंसी, 0.85 PF) का फुल लोड करंट 27.28 A और DOL स्टार्टिंग करंट ~164 A होता है, जो मोटर की नेमप्लेट से मेल खाता है।"
        ),
        "motor_speed_slip" to BilingualText(
            en = "Field Case: A 4-pole motor on 50 Hz mains has synchronous magnetic speed Ns = 1500 RPM. Measuring shaft speed 1440 RPM with a tachometer gives 4.0% slip (2.0 Hz rotor frequency), normal for full load.",
            hi = "फील्ड उदाहरण: 50 Hz पर 4-पोल मोटर की सिंक्रोनस स्पीड Ns = 1500 RPM होती है। यदि टैकोमीटर से शाफ्ट स्पीड 1440 RPM आती है, तो स्लिप 4.0% है जो सामान्य फुल-लोड स्थिति दर्शाती है।"
        ),
        "motor_starter_sizing" to BilingualText(
            en = "Field Case: For a 22 kW motor (FLC = 40 A, safety factor 1.15), a DOL starter needs a 50 A AC-3 contactor, whereas a Star-Delta starter uses 32 A Main/Delta contactors, an 18 A Star contactor, and OLR set at 23.1 A (58% FLC).",
            hi = "फील्ड उदाहरण: 22 kW मोटर (40 A FLC) के लिए DOL स्टार्टर में 50 A कॉन्टैक्टर लगता है, जबकि स्टार-डेल्टा स्टार्टर में 32 A मेन/डेल्टा कॉन्टैक्टर, 18 A स्टार कॉन्टैक्टर और 23.1 A पर OLR सेट होता है।"
        ),
        "motor_torque" to BilingualText(
            en = "Field Case: A 15 kW conveyor motor running at 1460 RPM develops T = 9549.3 × 15 / 1460 = 98.11 N·m (10.0 kg·m) rated torque, used to size couplings and gearbox input shafts.",
            hi = "फील्ड उदाहरण: 1460 RPM पर चलने वाली 15 kW मोटर शाफ्ट पर 98.11 N·m (10.0 kg·m) टॉर्क उत्पन्न करती है, जिसका उपयोग गियरबॉक्स और कपलिंग चुनने में होता है।"
        ),
        "vfd_freq_rpm" to BilingualText(
            en = "Field Case: Slowing a 50 Hz, 415 V, 4-pole pump motor to 35 Hz on a VFD lowers output voltage proportionally (8.3 V/Hz × 35 = 290.5 V) to maintain full torque at ~1019 RPM.",
            hi = "फील्ड उदाहरण: 50 Hz, 415 V मोटर को VFD से 35 Hz पर चलाने पर आउटपुट वोल्टेज अनुपात में 290.5 V (8.3 V/Hz) हो जाता है और मोटर ~1019 RPM पर पूरा टॉर्क देती है।"
        ),
        "vfd_affinity_laws" to BilingualText(
            en = "Field Case: Reducing a 30 kW cooling-tower fan from 100% to 80% speed (40 Hz) cuts flow to 80%, static pressure to 64%, and shaft power to 30 × 0.8³ = 15.36 kW — saving 48.8% electricity (234 kWh per 16-hr day).",
            hi = "फील्ड उदाहरण: 30 kW फैन को 100% के बजाय 80% स्पीड (40 Hz) पर चलाने से फ्लो 80% रहता है, लेकिन पावर खपत घटकर मात्र 15.36 kW रह जाती है — यानी रोज़ 48.8% (234 kWh) बिजली की बचत!"
        ),
        "vfd_dc_bus_brake" to BilingualText(
            en = "Field Case: On a 415 V AC supply, a VFD DC bus sits around 560 V DC (peak 587 V). For a 15 kW hoist at 50% braking torque (7.5 kW peak), brake chopper trigger (~726 V DC) requires ≈ 70 Ω braking resistor.",
            hi = "फील्ड उदाहरण: 415 V AC सप्लाई पर VFD का DC बस वोल्टेज ~560 V DC होता है। 15 kW होइस्ट में 50% ब्रेकिंग लोड के लिए लगभग 70 Ω का डायनेमिक ब्रेकिंग रेजिस्टर उपयोग किया जाता है।"
        ),
        "plc_analog_scaling" to BilingualText(
            en = "Field Case: A Siemens S7-1200/1500 AI card reads raw count 13824 (0–27648 range) from a 0–100 °C temperature transmitter; PLC scales it to exactly 50.0% = 50 °C (12.0 mA).",
            hi = "फील्ड उदाहरण: सीमेंस S7 PLC एनालॉग इनपुट पर 0–27648 रेंज में रॉ काउंट 13824 मिलने पर 0–100 °C ट्रांसमीटर का मान ठीक 50.0% = 50 °C (12.0 mA) स्केल होता है।"
        ),
        "plc_hsc_frequency" to BilingualText(
            en = "Field Case: A 1024 PPR incremental encoder on a 1500 RPM motor produces (1500 × 1024) / 60 = 25.6 kHz pulses (102.4 kHz in 4× quadrature). Standard 5 ms DI cards will miss pulses — a 100+ kHz HSC input is mandatory.",
            hi = "फील्ड उदाहरण: 1500 RPM पर घूमता 1024 PPR एनकोडर 25.6 kHz (4× मोड में 102.4 kHz) पल्स देता है। सामान्य DI कार्ड इसे नहीं पढ़ पाएगा — इसके लिए हाई-स्पीड काउंटर (HSC) इनपुट अनिवार्य है।"
        ),
        "plc_panel_power" to BilingualText(
            en = "Field Case: A marshalling cabinet draws 2.2 A (PLC/IO) + 3.5 A (relays/solenoids) + 1.8 A (transmitters/HMI) = 7.5 A continuous. Adding 30% spare margin gives 9.75 A → install a standard 24 V DC 10 A (240 W) SMPS.",
            hi = "फील्ड उदाहरण: कंट्रोल पैनल में PLC (2.2 A) + रिले/वाल्व (3.5 A) + ट्रांसमीटर (1.8 A) = 7.5 A लोड है। 30% सेफ्टी मार्जिन जोड़ने पर 9.75 A आता है, अतः मानक 24 V DC 10 A (240 W) SMPS चुनें।"
        ),
        "ma_pv_linear" to BilingualText(
            en = "Field Case: Measuring 12.0 mA in a loop for a 0–16 bar pressure transmitter equals 50% span = 8.0 bar (3.00 V across a 250 Ω HART resistor).",
            hi = "फील्ड उदाहरण: 0–16 bar प्रेशर ट्रांसमीटर के लूप में मल्टीमीटर से 12.0 mA करंट आने का अर्थ है 50% स्पैन = 8.0 bar (और 250 Ω रेजिस्टर पर 3.00 V वोल्टेज)।"
        ),
        "ma_dp_sqrt" to BilingualText(
            en = "Field Case: A linear DP flow transmitter (0–100 m³/h, 0–2500 mmH₂O) outputs 12.0 mA (50% DP = 1250 mmH₂O). After PLC square-root extraction, actual flow is √0.5 = 70.71% → 70.71 m³/h.",
            hi = "फील्ड उदाहरण: लीनियर DP ट्रांसमीटर (0–100 m³/h) से 12.0 mA (50% DP) मिलने पर PLC में वर्गमूल (√) निकालने के बाद वास्तविक फ्लो 70.71% यानी 70.71 m³/h मिलता है।"
        ),
        "ma_loop_resistance" to BilingualText(
            en = "Field Case: A 24 V loop powers a transmitter needing min 10.5 V through a 250 Ω AI/HART resistor + 45 Ω cable (295 Ω total). Max limit is (24 − 10.5) / 0.02 = 675 Ω; transmitter gets 18.1 V at 20 mA — loop & HART pass.",
            hi = "फील्ड उदाहरण: 24 V लूप में 250 Ω HART रेजिस्टर + 45 Ω केबल (कुल 295 Ω) है। अधिकतम सीमा 675 Ω है और 20 mA पर ट्रांसमीटर को 18.1 V मिलता है — अतः लूप और HART दोनों सही काम करेंगे।"
        ),
        "rtd_pt100_pt1000" to BilingualText(
            en = "Field Case: Disconnecting a Pt100 RTD at 100 °C and measuring with a multimeter reads 138.51 Ω (3-wire/4-wire compensated). On a 2-wire RTD with 1 Ω per lead, meter reads 140.51 Ω (~5.2 °C false high error).",
            hi = "फील्ड उदाहरण: 100 °C पर Pt100 RTD सेंसर का शुद्ध रेजिस्टेंस 138.51 Ω होता है। यदि 2-वायर केबल में हर तार का रेजिस्टेंस 1 Ω हो, तो मल्टीमीटर 140.51 Ω दिखाएगा (लगभग 5.2 °C अधिक गलत रीडिंग)।"
        ),
        "tc_mv_temp" to BilingualText(
            en = "Field Case: A Type-K thermocouple furnace reads 11.209 mV on a multimeter at 25 °C terminal box (CJC = 1.000 mV). Total 0 °C equivalent is 12.209 mV = 300.0 °C (without CJC it would falsely read ~275 °C).",
            hi = "फील्ड उदाहरण: 25 °C कमरे के तापमान (CJC = 1.000 mV) पर Type-K थर्मोकपल में 11.209 mV मापने पर कुल मान 12.209 mV = 300.0 °C होता है। बिना CJC जोड़े तापमान ~25 °C कम दिखेगा।"
        ),
        "temp_unit_converter" to BilingualText(
            en = "Field Case: Steam header setpoint of 100 °C converts to 212 °F (North American datasheets), 373.15 K (thermodynamic gas laws), and 671.67 °R.",
            hi = "फील्ड उदाहरण: प्रोसेस में 100 °C तापमान विदेशी डेटाशीट में 212 °F, थर्मोडायनामिक गणना में 373.15 K और रैंकिन स्केल में 671.67 °R के बराबर होता है।"
        ),
        "pfl_pressure_conv" to BilingualText(
            en = "Field Case: Plant instrument air header at 6.0 bar equals 600 kPa, 87.02 psi, 6.118 kg/cm², and 61,183 mmH₂O for pneumatic actuator sizing.",
            hi = "फील्ड उदाहरण: प्लांट इंस्ट्रूमेंट एयर का 6.0 bar प्रेशर न्यूमैटिक एक्चुएटर के लिए 600 kPa, 87.02 psi और 6.118 kg/cm² के बराबर होता है।"
        ),
        "pfl_hydrostatic_level" to BilingualText(
            en = "Field Case: A closed boiler drum (0–5000 mm, SG = 0.85) has a 5500 mm condensate wet-leg (SG = 1.0). DP transmitter calibrates with LRV = −5500 mmH₂O (at 0% level) and URV = −1250 mmH₂O (at 100% level).",
            hi = "फील्ड उदाहरण: 0–5000 mm बंद बॉयलर ड्रम (SG = 0.85) में 5500 mm वेट-लेग होने पर DP लेवल ट्रांसमीटर को LRV = −5500 mmH₂O और URV = −1250 mmH₂O पर कैलिब्रेट किया जाता है।"
        ),
        "pfl_pipe_flow" to BilingualText(
            en = "Field Case: Water flowing at 2.0 m/s inside a DN100 (100 mm ID) header delivers 56.55 m³/h (942.5 LPM), ideal velocity for mag-flowmeters without pipe erosion.",
            hi = "फील्ड उदाहरण: DN100 (100 mm) पाइप में 2.0 m/s वेग से बहने वाले पानी का फ्लो 56.55 m³/h (942.5 LPM) होता है, जो मैग्नेटिक फ्लो मीटर के लिए आदर्श गति है।"
        ),
        "pfl_reynolds" to BilingualText(
            en = "Field Case: Water (1000 kg/m³, 1.0 cP) at 1.8 m/s in a 50 mm pipe gives Re = 90,000 (Turbulent > 4000), ensuring accurate vortex/orifice metering; heavy lube oil (500 cP) drops Re to < 2100 (Laminar).",
            hi = "फील्ड उदाहरण: 50 mm पाइप में 1.8 m/s से बहते पानी का Re = 90,000 (टर्बुलेंट) आता है, जो ऑरिफिस/वोर्टेक्स मीटर के लिए सटीक है; वहीं गाढ़ा तेल लैमिनार फ्लो में जा सकता है।"
        ),
        "cable_sizing_ac" to BilingualText(
            en = "Field Case: Feeding a 22 kW 415 V motor (42 A) over 90 m with max 3% voltage drop requires 11.05 mm² minimum area → selects standard 16 mm² Cu XLPE cable (80 A rating, actual drop 2.38%).",
            hi = "फील्ड उदाहरण: 90 मीटर दूर 22 kW मोटर (42 A, अधिकतम 3% ड्रॉप) के लिए न्यूनतम साइज 11.05 mm² आता है, अतः मानक 16 mm² कॉपर XLPE केबल (80 A क्षमता, वास्तविक ड्रॉप 2.38%) चुनी जाती है।"
        ),
        "cable_ampacity_derate" to BilingualText(
            en = "Field Case: A 25 mm² Cu XLPE cable rated 105 A at 30 °C laid with 4 touching cables (Kg = 0.75) in a 45 °C boiler room (Kt = 0.87) safely carries only 105 × 0.87 × 0.75 = 68.5 A continuous.",
            hi = "फील्ड उदाहरण: 30 °C पर 105 A क्षमता वाली 25 mm² केबल यदि 45 °C तापमान (Kt = 0.87) और 4 केबलों के ग्रुप (Kg = 0.75) में बिछाई जाए, तो उसकी सुरक्षित क्षमता घटकर 68.5 A रह जाती है।"
        )
    )

    fun forCalculator(id: String): BilingualText? = examples[id]
}
