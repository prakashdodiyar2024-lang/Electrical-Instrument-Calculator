package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Industrial Dark Navy & Midnight Black Surfaces
val ObsidianBlack = Color(0xFF040811)
val DarkBlueprintBg = Color(0xFF070D1A)
val DarkBlueprintSurface = Color(0xFF0E192D)
val DarkBlueprintSurfaceElevated = Color(0xFF13233F)
val DarkBlueprintSurfaceVariant = Color(0xFF192D4E)
val DarkBorderSubtle = Color(0xFF233B63)

// Primary Engineering & Electric Blue Accents
val DeepNavy = Color(0xFF08265C)
val CobaltBlue = Color(0xFF0D47A1)
val ElectricBlue = Color(0xFF1E88E5)
val ElectricBlueBright = Color(0xFF4DA3FF)
val LightBluePrimary = Color(0xFF7BB7FF)
val LightBlueContainer = Color(0xFF123266)
val DarkElectricTint = Color(0xFF10284E)
val SkyBlueTint = Color(0xFFE8F1FC)
val BlueBorder = Color(0xFF2B4D82)

// Secondary / Accent Safety Orange Palette
val SafetyOrange = Color(0xFFFF6D00)
val WarmOrange = Color(0xFFFF8F2B)
val BrightOrangeAccent = Color(0xFFFF9E40)
val DarkOrangeContainer = Color(0xFF3E1E06)
val DarkOrangeTint = Color(0xFF2D1807)
val SoftOrangeTint = Color(0xFFFFF3E0)
val OrangeBorder = Color(0xFFFFB74D)

// High-Contrast Text & Neutral Tokens
val PureWhite = Color(0xFFFFFFFF)
val CrispLightText = Color(0xFFF1F5FC)
val MutedLightText = Color(0xFFA0B4D0)
val CoolIceBackground = Color(0xFFF4F7FB)
val ElevatedWhite = Color(0xFFFFFFFF)
val SlateSurfaceVariant = Color(0xFFE7EEF8)
val InkDark = Color(0xFF0F1B2D)
val SlateMuted = Color(0xFF4E607A)
val OutlineSubtle = Color(0xFFD0DCEB)

// Semantic Engineering Status Colors (Dark-Theme Optimized)
val StatusSuccessGreen = Color(0xFF4ADE80)
val StatusSuccessBg = Color(0xFF0B291B)
val StatusWarningAmber = Color(0xFFFFB74D)
val StatusWarningBg = Color(0xFF2E1C07)
val StatusErrorRed = Color(0xFFFF7B7B)
val StatusErrorBg = Color(0xFF341117)
