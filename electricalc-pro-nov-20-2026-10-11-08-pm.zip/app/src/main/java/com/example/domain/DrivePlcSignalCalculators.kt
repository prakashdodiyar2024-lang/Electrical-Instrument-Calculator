package com.example.domain

import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculationOutput
import com.example.model.CalculationStep
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.CalculatorPreset
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireEvenPoles
import com.example.model.requireFinite
import com.example.model.requireNonNegative
import com.example.model.requireNonZero
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.pow
import kotlin.math.sqrt

object DrivePlcSignalCalculators {

    val all: List<CalculatorDefinition> = listOf(
        vfdFreqRpmCalculator(),
        vfdAffinityLawsCalculator(),
        vfdDcBusBrakeCalculator(),
        plcAnalogScalingCalculator(),
        plcHscEncoderCalculator(),
        plcPanelSmpsCalculator(),
        maLinearScalingCalculator(),
        maSquareRootFlowCalculator(),
        maLoopResistanceCalculator()
    )

    private fun vfdFreqRpmCalculator() = CalculatorDefinition(
        id = "vfd_freq_rpm",
        category = CalculatorCategory.VFD,
        title = BilingualText("VFD Frequency, RPM & V/f Ratio", "VFD फ्रीक्वेंसी, RPM और V/f अनुपात"),
        subtitle = BilingualText(
            "Calculate motor speed, output voltage & V/f ratio at any VFD Hz",
            "VFD की किसी भी फ्रीक्वेंसी (Hz) पर मोटर RPM, आउटपुट वोल्टेज और V/f निकालें"
        ),
        formulaPreview = "N = (120 × f_vfd / P) × (1 − slip)   |   V/f = V_rated / f_rated",
        keywords = listOf("vfd", "frequency", "hz", "rpm", "vf ratio", "drive", "वीएफडी", "फ्रीक्वेंसी"),
        fields = listOf(
            CalculatorField("vfd_freq", BilingualText("VFD Output Frequency (Hz)", "VFD आउटपुट फ्रीक्वेंसी (Hz)"), "35", "Hz"),
            CalculatorField("base_freq", BilingualText("Motor Base Frequency (Hz)", "मोटर बेस फ्रीक्वेंसी (Hz)"), "50", "Hz"),
            CalculatorField("base_volt", BilingualText("Motor Rated Voltage (V)", "मोटर रेटेड वोल्टेज (V)"), "415", "V"),
            CalculatorField("poles", BilingualText("Motor Poles (2/4/6/8)", "मोटर पोल (2/4/6/8)"), "4", "Poles"),
            CalculatorField("slip_pct", BilingualText("Rated Slip (%)", "मोटर स्लिप (%)"), "3.0", "%")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("35 Hz on 50Hz 415V 4P Motor", "35 Hz (50Hz 415V 4-पोल मोटर)"),
                values = mapOf("vfd_freq" to "35", "base_freq" to "50", "base_volt" to "415", "poles" to "4", "slip_pct" to "3.0")
            ),
            CalculatorPreset(
                label = BilingualText("60 Hz Overspeed Check", "60 Hz ओवरस्पीड जांच"),
                values = mapOf("vfd_freq" to "60", "base_freq" to "50", "base_volt" to "415", "poles" to "4", "slip_pct" to "3.0")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val fVfd = requireRange(values["vfd_freq"], 0.1, 400.0, BilingualText("VFD Frequency", "VFD फ्रीक्वेंसी"))
                val fBase = requireRange(values["base_freq"], 10.0, 400.0, BilingualText("Base Frequency", "बेस फ्रीक्वेंसी"))
                val vBase = requirePositive(values["base_volt"], BilingualText("Base Voltage", "बेस वोल्टेज"))
                val poles = requireEvenPoles(values["poles"], BilingualText("Motor Poles", "मोटर पोल"))
                val slipPct = requireRange(values["slip_pct"], 0.0, 20.0, BilingualText("Rated Slip (%)", "मोटर स्लिप (%)"))

                val syncRpm = (120.0 * fVfd) / poles
                val rotorRpm = syncRpm * (1.0 - slipPct / 100.0)
                val vfRatio = vBase / fBase
                val vOut = (vfRatio * fVfd).coerceAtMost(vBase)
                val region = if (fVfd <= fBase) {
                    BilingualText("Constant Torque Region (0–Base Hz)", "कॉन्स्टेंट टॉर्क क्षेत्र")
                } else {
                    BilingualText("Field Weakening / Reduced Torque (>Base Hz)", "फील्ड वीकनिंग (कम टॉर्क क्षेत्र)")
                }

                CalculationOutput(
                    primaryLabel = BilingualText("Estimated Motor Speed", "अनुमानित मोटर स्पीड"),
                    primaryValue = formatEng(rotorRpm, 0),
                    primaryUnit = "RPM",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Synchronous Speed", "सिंक्रोनस स्पीड"), formatEng(syncRpm, 0), "RPM"),
                        SecondaryMetric(BilingualText("VFD Output Voltage", "VFD आउटपुट वोल्टेज"), formatEng(vOut, 1), "V"),
                        SecondaryMetric(BilingualText("V/f Ratio", "V/f अनुपात"), formatEng(vfRatio, 2), "V/Hz")
                    ),
                    formulaUsed = "N_sync = (120 × f_vfd) / P   |   N_rotor = N_sync × (1 − slip%/100)   |   V_out = min(V_rated, (V_rated/f_rated) × f_vfd)",
                    substitutedFormula = "N_rotor = ((120 × ${formatEng(fVfd, 1)}) / $poles) × (1 − ${formatEng(slipPct, 2)}/100)   |   V_out = min(${formatEng(vBase, 0)}, ${formatEng(vfRatio, 2)} × ${formatEng(fVfd, 1)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Calculate Rated V/f Ratio", "रेटेड V/f अनुपात निकालें"),
                            "V/f = ${formatEng(vBase, 0)} / ${formatEng(fBase, 0)} = ${formatEng(vfRatio, 2)} V/Hz",
                            BilingualText(
                                "Nominal volts-per-hertz ratio maintains full magnetic flux inside the stator.",
                                "वोल्ट-प्रति-हर्ट्ज (V/f) अनुपात मोटर के अंदर चुंबकीय फ्लक्स को स्थिर रखता है।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Determine VFD Output Voltage", "VFD आउटपुट वोल्टेज निकालें"),
                            "V_out = min(${formatEng(vBase, 0)}, ${formatEng(vfRatio, 2)} × ${formatEng(fVfd, 1)}) = ${formatEng(vOut, 1)} V",
                            BilingualText(
                                "Voltage scales linearly with Hz up to ${formatEng(fBase, 0)} Hz, then caps at supply voltage ${formatEng(vBase, 0)} V.",
                                "${formatEng(fBase, 0)} Hz तक वोल्टेज अनुपात में बढ़ता है, उसके बाद सप्लाई वोल्टेज (${formatEng(vBase, 0)} V) पर सीमित हो जाता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Synchronous Speed (N_sync)", "सिंक्रोनस स्पीड (N_sync) निकालें"),
                            "N_sync = (120 × ${formatEng(fVfd, 1)}) / $poles = ${formatEng(syncRpm, 0)} RPM",
                            BilingualText(
                                "Stator magnetic field RPM at ${formatEng(fVfd, 1)} Hz for a $poles-pole motor.",
                                "${formatEng(fVfd, 1)} Hz पर $poles-पोल मोटर के चुंबकीय क्षेत्र की गति।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Apply Rotor Slip for Actual Shaft Speed", "स्लिप घटाकर वास्तविक शाफ्ट RPM निकालें"),
                            "N_rotor = ${formatEng(syncRpm, 0)} × (1 − ${formatEng(slipPct, 2)}/100) = ${formatEng(rotorRpm, 0)} RPM",
                            BilingualText(
                                "Operating mode: ${region.en}",
                                "ऑपरेटिंग मोड: ${region.hi}"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        if (fVfd > fBase) {
                            "At ${formatEng(fVfd, 1)} Hz (overspeed), the motor runs at ~${formatEng(rotorRpm, 0)} RPM with voltage capped at ${formatEng(vOut, 1)} V (reduced torque region)."
                        } else {
                            "At ${formatEng(fVfd, 1)} Hz, the VFD supplies ${formatEng(vOut, 1)} V (${formatEng(vfRatio, 2)} V/Hz) and drives the shaft at ~${formatEng(rotorRpm, 0)} RPM with full rated torque."
                        },
                        if (fVfd > fBase) {
                            "${formatEng(fVfd, 1)} Hz (ओवरस्पीड) पर मोटर ~${formatEng(rotorRpm, 0)} RPM पर चलेगी, लेकिन वोल्टेज ${formatEng(vOut, 1)} V पर सीमित रहने से टॉर्क कम होगा।"
                        } else {
                            "${formatEng(fVfd, 1)} Hz पर VFD ${formatEng(vOut, 1)} V देगा और मोटर पूरे टॉर्क के साथ ~${formatEng(rotorRpm, 0)} RPM पर चलेगी।"
                        }
                    ),
                    assumptions = BilingualText(
                        "Assumes scalar V/f control with constant percentage slip; vector control maintains tighter speed regulation.",
                        "मान्यता: स्केलर V/f कंट्रोल और स्थिर स्लिप % माना गया है।"
                    ),
                    statusLevel = if (fVfd > fBase) StatusLevel.WARNING else StatusLevel.NORMAL,
                    engineeringNote = BilingualText(
                        "Above base frequency (${formatEng(fBase, 0)} Hz), voltage cannot exceed supply voltage so motor torque drops inversely with speed.",
                        "बेस फ्रीक्वेंसी से ऊपर जाने पर वोल्टेज नहीं बढ़ पाता, इसलिए मोटर का टॉर्क कम होने लगता है।"
                    )
                )
            }
        }
    )

    private fun vfdAffinityLawsCalculator() = CalculatorDefinition(
        id = "vfd_affinity_laws",
        category = CalculatorCategory.VFD,
        title = BilingualText("VFD Pump/Fan Energy Savings", "VFD पंप/फैन ऊर्जा बचत (Affinity Law)"),
        subtitle = BilingualText(
            "Calculate Flow, Head & Power change using Cubic Affinity Law (P ∝ N³)",
            "VFD से स्पीड बदलने पर फ्लो, प्रेशर और बिजली की बचत (%) निकालें"
        ),
        formulaPreview = "Q₂/Q₁ = N₂/N₁  |  H₂/H₁ = (N₂/N₁)²  |  P₂/P₁ = (N₂/N₁)³",
        keywords = listOf("affinity", "vfd", "energy saving", "pump", "fan", "power", "ऊर्जा बचत", "पंप"),
        fields = listOf(
            CalculatorField("rated_kw", BilingualText("Rated Power at 100% Speed (kW)", "100% स्पीड पर रेटेड पावर (kW)"), "30", "kW"),
            CalculatorField("speed_pct", BilingualText("Target Speed (%)", "चलाने की स्पीड (%)"), "80", "%"),
            CalculatorField("hours_day", BilingualText("Operating Hours / Day", "प्रतिदिन चलने के घंटे"), "16", "hr/day")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("30 kW Fan @ 80% Speed (40 Hz)", "30 kW फैन @ 80% स्पीड (40 Hz)"),
                values = mapOf("rated_kw" to "30", "speed_pct" to "80", "hours_day" to "16")
            ),
            CalculatorPreset(
                label = BilingualText("45 kW Pump @ 70% Speed (35 Hz)", "45 kW पंप @ 70% स्पीड (35 Hz)"),
                values = mapOf("rated_kw" to "45", "speed_pct" to "70", "hours_day" to "20")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val p1 = requirePositive(values["rated_kw"], BilingualText("Rated Power", "रेटेड पावर"))
                val speedPct = requireRange(values["speed_pct"], 5.0, 120.0, BilingualText("Target Speed (%)", "चलाने की स्पीड (%)"))
                val hrs = requireRange(values["hours_day"], 0.1, 24.0, BilingualText("Operating Hours", "चलने के घंटे"))

                val ratio = speedPct / 100.0
                val flowPct = ratio * 100.0
                val headPct = ratio.pow(2) * 100.0
                val p2 = p1 * ratio.pow(3)
                val deltaKw = p1 - p2
                val deltaPct = (deltaKw / p1) * 100.0
                val dailyKwhDelta = deltaKw * hrs
                val isOverspeed = speedPct > 100.0

                val ratioSq = ratio.pow(2)
                val ratioCube = ratio.pow(3)

                CalculationOutput(
                    primaryLabel = BilingualText("New VFD Power Consumption", "VFD पर नई पावर खपत"),
                    primaryValue = formatEng(p2, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(
                            if (isOverspeed) BilingualText("Extra Power Load", "अतिरिक्त पावर खपत") else BilingualText("Power Saved", "बिजली बचत"),
                            "${formatEng(kotlin.math.abs(deltaKw), 2)} kW",
                            "(${formatEng(kotlin.math.abs(deltaPct), 1)}%)"
                        ),
                        SecondaryMetric(BilingualText("Flow Output", "फ्लो आउटपुट"), formatEng(flowPct, 1), "%"),
                        SecondaryMetric(BilingualText("Head / Pressure", "हेड / प्रेशर"), formatEng(headPct, 1), "%"),
                        SecondaryMetric(
                            if (isOverspeed) BilingualText("Extra Daily Energy", "अतिरिक्त दैनिक ऊर्जा") else BilingualText("Daily Energy Saved", "दैनिक ऊर्जा बचत"),
                            formatEng(kotlin.math.abs(dailyKwhDelta), 1),
                            "kWh/day"
                        )
                    ),
                    formulaUsed = "Q₂/Q₁ = N₂/N₁   |   H₂/H₁ = (N₂/N₁)²   |   P₂ = P₁ × (N₂/N₁)³",
                    substitutedFormula = "P₂ = ${formatEng(p1, 1)} × (${formatEng(speedPct, 1)} / 100)³",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Compute Speed Ratio (r = Speed% / 100)", "स्पीड अनुपात निकालें (r = Speed% / 100)"),
                            "r = ${formatEng(speedPct, 1)} / 100 = ${formatEng(ratio, 3)}",
                            BilingualText(
                                "Express target operating speed as a fraction of full 100% speed.",
                                "लक्ष्य स्पीड को 100% स्पीड के अनुपात (दशमलव) में बदलें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Calculate Flow % & Head/Pressure %", "फ्लो % और हेड/प्रेशर % निकालें"),
                            "Flow = ${formatEng(flowPct, 1)}%,  Head = (${formatEng(ratio, 3)})² = ${formatEng(ratioSq, 4)} (${formatEng(headPct, 1)}%)",
                            BilingualText(
                                "Flow varies linearly with speed; static/dynamic head varies with speed squared.",
                                "फ्लो स्पीड के साथ सीधा बदलता है, जबकि प्रेशर स्पीड के वर्ग (r²) के अनुसार बदलता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Apply Cube Law for Shaft Power (P₂ = P₁ × r³)", "क्यूब लॉ (r³) से नई पावर P₂ निकालें"),
                            "r³ = ${formatEng(ratioCube, 4)}  →  P₂ = ${formatEng(p1, 1)} × ${formatEng(ratioCube, 4)} = ${formatEng(p2, 2)} kW",
                            BilingualText(
                                if (isOverspeed) "Above 100% speed, power rises cubically and can overload the motor!"
                                else "Power is proportional to the cube of speed — a small speed drop yields huge energy savings.",
                                if (isOverspeed) "100% से अधिक स्पीड पर पावर घन नियम से बहुत तेजी से बढ़ती है!"
                                else "पावर स्पीड के घन (तीसरी घात) पर निर्भर करती है, इसलिए थोड़ी स्पीड घटाने पर भारी बिजली बचत होती है।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Calculate Daily Energy (kWh/day)", "दैनिक ऊर्जा बचत / खपत निकालें"),
                            "ΔP = |${formatEng(p1, 1)} − ${formatEng(p2, 2)}| = ${formatEng(kotlin.math.abs(deltaKw), 2)} kW  →  ΔE = ${formatEng(kotlin.math.abs(deltaKw), 2)} × ${formatEng(hrs, 1)} = ${formatEng(kotlin.math.abs(dailyKwhDelta), 1)} kWh/day",
                            BilingualText(
                                "Multiply power difference by daily operating hours to get daily kWh impact.",
                                "पावर के अंतर को रोज़ाना चलने के घंटों से गुणा करने पर दैनिक यूनिट (kWh) मिलते हैं।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        if (isOverspeed) {
                            "Running at ${formatEng(speedPct, 0)}% speed raises load to ${formatEng(p2, 2)} kW (+${formatEng(kotlin.math.abs(deltaPct), 1)}%), consuming ${formatEng(kotlin.math.abs(dailyKwhDelta), 1)} extra kWh/day."
                        } else {
                            "Reducing speed to ${formatEng(speedPct, 0)}% drops power from ${formatEng(p1, 1)} kW to ${formatEng(p2, 2)} kW, saving ${formatEng(deltaPct, 1)}% (${formatEng(dailyKwhDelta, 1)} kWh/day)."
                        },
                        if (isOverspeed) {
                            "${formatEng(speedPct, 0)}% स्पीड पर पावर बढ़कर ${formatEng(p2, 2)} kW (+${formatEng(kotlin.math.abs(deltaPct), 1)}%) हो जाएगी, जिससे ${formatEng(kotlin.math.abs(dailyKwhDelta), 1)} kWh/दिन अतिरिक्त खपत होगी।"
                        } else {
                            "स्पीड को ${formatEng(speedPct, 0)}% करने पर पावर ${formatEng(p1, 1)} kW से घटकर ${formatEng(p2, 2)} kW रह जाती है, जिससे ${formatEng(deltaPct, 1)}% (${formatEng(dailyKwhDelta, 1)} kWh/दिन) बचत होती है।"
                        }
                    ),
                    assumptions = BilingualText(
                        "Applies to centrifugal variable-torque loads (pumps/fans) with negligible static head and constant efficiency.",
                        "मान्यता: यह नियम सेंट्रीफ्यूगल पंप/फैन (Variable Torque) और बिना स्थिर हेड वाले सिस्टम पर लागू होता है।"
                    ),
                    statusLevel = if (isOverspeed) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun vfdDcBusBrakeCalculator() = CalculatorDefinition(
        id = "vfd_dc_bus_brake",
        category = CalculatorCategory.VFD,
        title = BilingualText("VFD DC Bus & Braking Resistor", "VFD DC बस और ब्रेकिंग रेजिस्टर"),
        subtitle = BilingualText(
            "Calculate nominal DC link voltage, overvoltage trip & braking resistor Ω",
            "VFD का DC बस वोल्टेज, ओवरवोल्टेज ट्रिप और ब्रेकिंग रेजिस्टर Ω निकालें"
        ),
        formulaPreview = "V_DC = 1.35 × V_AC   |   R_brake = V_chop² / P_brake",
        keywords = listOf("dc bus", "braking resistor", "vfd", "overvoltage", "ब्रेकिंग रेजिस्टर", "डीसी बस"),
        fields = listOf(
            CalculatorField("vac", BilingualText("AC Line Input Voltage (V)", "AC इनपुट वोल्टेज (V)"), "415", "V"),
            CalculatorField("motor_kw", BilingualText("Motor Rating (kW)", "मोटर पावर (kW)"), "15", "kW"),
            CalculatorField("duty_pct", BilingualText("Braking Torque / Duty (%)", "ब्रेकिंग ड्यूटी (%)"), "50", "%")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("415V 15kW Hoist/Conveyor", "415V 15kW होइस्ट/कन्वेयर"),
                values = mapOf("vac" to "415", "motor_kw" to "15", "duty_pct" to "50")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val vac = requirePositive(values["vac"], BilingualText("AC Voltage", "AC वोल्टेज"))
                val kw = requirePositive(values["motor_kw"], BilingualText("Motor kW", "मोटर kW"))
                val duty = requireRange(values["duty_pct"], 5.0, 200.0, BilingualText("Braking Duty (%)", "ब्रेकिंग ड्यूटी (%)"))

                val vDcNominal = vac * 1.35
                val vDcPeak = vac * sqrt(2.0)
                val vBrakeThreshold = vac * 1.75
                val pPeakKw = kw * (duty / 100.0)
                val rMinOhm = (vBrakeThreshold * vBrakeThreshold) / (pPeakKw * 1000.0)
                val iBrake = vBrakeThreshold / rMinOhm

                CalculationOutput(
                    primaryLabel = BilingualText("Nominal VFD DC Bus Voltage", "VFD DC बस वोल्टेज (Nominal)"),
                    primaryValue = formatEng(vDcNominal, 1),
                    primaryUnit = "V DC",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Peak DC Link", "पीक DC वोल्टेज"), formatEng(vDcPeak, 1), "V DC"),
                        SecondaryMetric(BilingualText("Braking Trigger", "ब्रेकिंग थ्रेशोल्ड"), formatEng(vBrakeThreshold, 0), "V DC"),
                        SecondaryMetric(BilingualText("Braking Resistor (Approx)", "ब्रेकिंग रेजिस्टर"), formatEng(rMinOhm, 1), "Ω"),
                        SecondaryMetric(BilingualText("Braking Peak Power", "ब्रेकिंग पावर"), formatEng(pPeakKw, 2), "kW (${formatEng(iBrake, 1)} A)")
                    ),
                    formulaUsed = "V_DC = 1.35 × V_AC   |   V_chop = 1.75 × V_AC   |   R_brake = V_chop² / (P_kW × Duty% × 1000)",
                    substitutedFormula = "V_DC = 1.35 × ${formatEng(vac, 0)}   |   R_brake = (${formatEng(vBrakeThreshold, 0)})² / (${formatEng(kw, 1)} × ${formatEng(duty, 0)}% × 1000)",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Calculate Nominal & Peak DC Bus Voltage", "नॉमिनल व पीक DC बस वोल्टेज निकालें"),
                            "V_DC = 1.35 × ${formatEng(vac, 0)} = ${formatEng(vDcNominal, 1)} V DC  |  Peak = √2 × ${formatEng(vac, 0)} = ${formatEng(vDcPeak, 1)} V DC",
                            BilingualText(
                                "A 3-phase 6-pulse diode rectifier produces average DC bus ≈ 1.35 × V_AC under load (√2 × V_AC at no-load).",
                                "3-फेज़ रेक्टिफायर लोड पर ~1.35 × V_AC और नो-लोड पर √2 × V_AC DC वोल्टेज बनाता है।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Compute Brake Chopper Trigger & Peak Power", "ब्रेकिंग चॉपर वोल्टेज व पावर निकालें"),
                            "V_chop = 1.75 × ${formatEng(vac, 0)} = ${formatEng(vBrakeThreshold, 0)} V DC  |  P_brake = ${formatEng(kw, 1)} × (${formatEng(duty, 0)}/100) = ${formatEng(pPeakKw, 2)} kW",
                            BilingualText(
                                "Dynamic brake IGBT switches on near ${formatEng(vBrakeThreshold, 0)} V DC to dump regenerative energy.",
                                "रीजेनरेटिव ऊर्जा खपाने के लिए ब्रेकिंग IGBT लगभग ${formatEng(vBrakeThreshold, 0)} V DC पर चालू होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Braking Resistor Ω & Current", "ब्रेकिंग रेजिस्टर (Ω) और करंट निकालें"),
                            "R_brake = (${formatEng(vBrakeThreshold, 0)})² / (${formatEng(pPeakKw, 2)} × 1000) = ${formatEng(rMinOhm, 1)} Ω  |  I = ${formatEng(iBrake, 1)} A",
                            BilingualText(
                                "Never install a resistor below the VFD datasheet minimum Ω rating to protect the braking IGBT.",
                                "ब्रेकिंग IGBT की सुरक्षा के लिए VFD मैन्युअल में दिए न्यूनतम Ω से कम रेजिस्टर कभी न लगाएं।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "On a ${formatEng(vac, 0)} V AC supply, expect ~${formatEng(vDcNominal, 1)}–${formatEng(vDcPeak, 1)} V DC across +DC/−DC terminals; ${formatEng(duty, 0)}% braking on ${formatEng(kw, 1)} kW requires ~${formatEng(rMinOhm, 1)} Ω (${formatEng(pPeakKw, 2)} kW peak).",
                        "${formatEng(vac, 0)} V AC पर VFD के +DC/−DC टर्मिनल पर ~${formatEng(vDcNominal, 1)}–${formatEng(vDcPeak, 1)} V DC मिलेगा; ${formatEng(kw, 1)} kW के ${formatEng(duty, 0)}% ब्रेकिंग हेतु ~${formatEng(rMinOhm, 1)} Ω रेजिस्टर चाहिए।"
                    ),
                    assumptions = BilingualText(
                        "Assumes 3-phase 6-pulse rectifier (1.35× V_AC) and brake chopper threshold ≈ 1.75× V_AC.",
                        "मान्यता: 3-फेज़ रेक्टिफायर (1.35× V_AC) और ब्रेक चॉपर थ्रेशोल्ड ≈ 1.75× V_AC।"
                    )
                )
            }
        }
    )

    private fun plcAnalogScalingCalculator() = CalculatorDefinition(
        id = "plc_analog_scaling",
        category = CalculatorCategory.PLC_DCS,
        title = BilingualText("PLC/DCS Raw Count Scaling", "PLC/DCS रॉ काउंट स्केलिंग"),
        subtitle = BilingualText(
            "Convert PLC Analog Raw Counts (Siemens 27648, AB 32767, Modicon 4095) to PV",
            "PLC एनालॉग काउंट्स (0-27648 / 0-32767) को असली प्रोसेस वैल्यू (PV) में बदलें"
        ),
        formulaPreview = "PV = LRV + ((Raw − Raw_min) / (Raw_max − Raw_min)) × (URV − LRV)",
        keywords = listOf("plc", "dcs", "siemens", "27648", "32767", "analog", "scaling", "counts", "पीएलसी", "स्केलिंग"),
        fields = listOf(
            CalculatorField("raw_val", BilingualText("PLC Raw Analog Count", "PLC रॉ काउंट मान"), "13824", "Counts", allowNegative = true),
            CalculatorField("raw_min", BilingualText("Raw Min (0 or 4000)", "न्यूनतम रॉ काउंट"), "0", "Counts", allowNegative = true),
            CalculatorField("raw_max", BilingualText("Raw Max (27648 / 32767 / 4095)", "अधिकतम रॉ काउंट"), "27648", "Counts"),
            CalculatorField("lrv", BilingualText("Engineering LRV (0%)", "मिनिमम रेंज (LRV)"), "0", "EU", allowNegative = true),
            CalculatorField("urv", BilingualText("Engineering URV (100%)", "मैक्सिमम रेंज (URV)"), "100", "EU", allowNegative = true)
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Siemens S7 (0–27648 @ 50%)", "सीमेंस S7 (0–27648 @ 50%)"),
                values = mapOf("raw_val" to "13824", "raw_min" to "0", "raw_max" to "27648", "lrv" to "0", "urv" to "100")
            ),
            CalculatorPreset(
                label = BilingualText("Allen-Bradley (4000–20000)", "एलन-ब्रैडली (4000–20000)"),
                values = mapOf("raw_val" to "12000", "raw_min" to "4000", "raw_max" to "20000", "lrv" to "0", "urv" to "250")
            ),
            CalculatorPreset(
                label = BilingualText("12-bit Modicon (0–4095)", "12-बिट मोडिकॉन (0–4095)"),
                values = mapOf("raw_val" to "3071", "raw_min" to "0", "raw_max" to "4095", "lrv" to "0", "urv" to "10")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val raw = requireFinite(values["raw_val"], BilingualText("PLC Raw Analog Count", "PLC रॉ काउंट मान"))
                val rMin = requireFinite(values["raw_min"] ?: 0.0, BilingualText("Raw Min", "न्यूनतम रॉ काउंट"))
                val rMax = requireFinite(values["raw_max"] ?: 27648.0, BilingualText("Raw Max", "अधिकतम रॉ काउंट"))
                val lrv = requireFinite(values["lrv"] ?: 0.0, BilingualText("Engineering LRV", "मिनिमम रेंज (LRV)"))
                val urv = requireFinite(values["urv"] ?: 100.0, BilingualText("Engineering URV", "मैक्सिमम रेंज (URV)"))

                val spanRaw = requireNonZero(rMax - rMin, BilingualText("Raw Span (Raw_max − Raw_min)", "रॉ स्पैन"))
                val spanEng = requireNonZero(urv - lrv, BilingualText("Engineering Span (URV − LRV)", "इंजीनियरिंग स्पैन"))

                val rawOffset = raw - rMin
                val fraction = rawOffset / spanRaw
                val pct = fraction * 100.0
                val scaledOffset = fraction * spanEng
                val pv = lrv + scaledOffset
                val maEquiv = 4.0 + fraction * 16.0
                val vEquiv = fraction * 10.0

                val isOutOfRange = pct < -2.0 || pct > 105.0
                val status = if (isOutOfRange) StatusLevel.WARNING else StatusLevel.NORMAL

                CalculationOutput(
                    primaryLabel = BilingualText("Scaled Engineering Value (PV)", "स्केल की गई वैल्यू (PV)"),
                    primaryValue = formatEng(pv, 3),
                    primaryUnit = "EU (${formatEng(pct, 2)}%)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Signal %", "सिग्नल %"), formatEng(pct, 2), "%"),
                        SecondaryMetric(BilingualText("4–20 mA Equiv.", "4–20 mA मान"), formatEng(maEquiv, 2), "mA"),
                        SecondaryMetric(BilingualText("0–10 V Equiv.", "0–10 V मान"), formatEng(vEquiv, 2), "V")
                    ),
                    formulaUsed = "PV = LRV + [(Raw − Raw_min) / (Raw_max − Raw_min)] × (URV − LRV)",
                    substitutedFormula = "PV = ${formatEng(lrv, 2)} + [(${formatEng(raw, 0)} − ${formatEng(rMin, 0)}) / (${formatEng(rMax, 0)} − ${formatEng(rMin, 0)})] × (${formatEng(urv, 2)} − ${formatEng(lrv, 2)})",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Subtract Raw_min from Input Raw Count", "रॉ काउंट में से Raw_min घटाएं"),
                            "Raw − Raw_min = ${formatEng(raw, 0)} − ${formatEng(rMin, 0)} = ${formatEng(rawOffset, 0)}",
                            BilingualText(
                                "Remove the zero-offset count (e.g., 4000 on 4–20 mA AB cards, 0 on Siemens S7).",
                                "रॉ काउंट में से बेस ऑफसेट (जैसे AB कार्ड में 4000 या सीमेंस में 0) घटाएं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Divide by Raw Count Span", "रॉ स्पैन (Raw_max − Raw_min) से भाग दें"),
                            "Fraction = ${formatEng(rawOffset, 0)} / ${formatEng(spanRaw, 0)} = ${formatEng(fraction, 4)}  (${formatEng(pct, 2)}%)",
                            BilingualText(
                                "Normalizes the ADC reading into a 0–100% span fraction.",
                                "इससे कुल ADC रेंज में सिग्नल का सटीक अनुपात व प्रतिशत (%) प्राप्त होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Multiply by Engineering Span (URV − LRV)", "इंजीनियरिंग स्पैन (URV − LRV) से गुणा करें"),
                            "${formatEng(fraction, 4)} × ${formatEng(spanEng, 2)} = ${formatEng(scaledOffset, 3)}",
                            BilingualText(
                                "Converts normalized fraction into engineering span units.",
                                "प्रतिशत अनुपात को कुल इंजीनियरिंग रेंज से गुणा करें।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Add LRV for Final Process Value (PV)", "अंतिम PV के लिए LRV जोड़ें"),
                            "PV = ${formatEng(lrv, 2)} + ${formatEng(scaledOffset, 3)} = ${formatEng(pv, 3)} EU  (≈ ${formatEng(maEquiv, 2)} mA / ${formatEng(vEquiv, 2)} V)",
                            BilingualText(
                                "Adding LRV shifts the scaled value to the transmitter's true calibrated zero.",
                                "LRV जोड़ने पर सही कैलिब्रेटेड प्रोसेस वैल्यू (PV) प्राप्त होती है।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "A PLC raw count of ${formatEng(raw, 0)} corresponds to ${formatEng(pct, 2)}% of input span, scaling to ${formatEng(pv, 3)} EU (equivalent to ${formatEng(maEquiv, 2)} mA).",
                        "PLC का ${formatEng(raw, 0)} रॉ काउंट इनपुट रेंज का ${formatEng(pct, 2)}% है, जो ${formatEng(pv, 3)} EU (${formatEng(maEquiv, 2)} mA के बराबर) दर्शाता है।"
                    ),
                    statusLevel = status,
                    engineeringNote = BilingualText(
                        if (isOutOfRange) "Warning: Raw count is outside normal 0–100% range — check for wire break, sensor fault, or overrange!"
                        else "Siemens S7 uses 0–27648 (rated), 27649–32511 (overrange), and >32512 (overflow/wire break).",
                        if (isOutOfRange) "चेतावनी: रॉ काउंट सामान्य 0–100% सीमा से बाहर है — वायर ब्रेक या सेंसर फॉल्ट जांचें!"
                        else "सीमेंस PLC में 0–27648 नॉर्मल रेंज है; 32767 या -32768 आने पर वायर ब्रेक/शॉर्ट चेक करें।"
                    )
                )
            }
        }
    )

    private fun plcHscEncoderCalculator() = CalculatorDefinition(
        id = "plc_hsc_frequency",
        category = CalculatorCategory.PLC_DCS,
        title = BilingualText("PLC Encoder Frequency & RPM", "PLC एनकोडर फ्रीक्वेंसी और RPM"),
        subtitle = BilingualText(
            "Calculate High-Speed Counter (HSC) pulse rate in kHz & pulse period",
            "एनकोडर PPR और RPM से PLC हाई-स्पीड काउंटर (HSC) फ्रीक्वेंसी (kHz) निकालें"
        ),
        formulaPreview = "f (Hz) = (RPM × PPR) / 60",
        keywords = listOf("encoder", "hsc", "pulse", "ppr", "khz", "plc", "एनकोडर", "पल्स"),
        fields = listOf(
            CalculatorField("rpm", BilingualText("Shaft Speed (RPM)", "शाफ्ट गति (RPM)"), "1500", "RPM"),
            CalculatorField("ppr", BilingualText("Encoder Resolution (PPR)", "एनकोडर PPR (Pulses/Rev)"), "1024", "PPR")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("1500 RPM × 1024 PPR", "1500 RPM × 1024 PPR"),
                values = mapOf("rpm" to "1500", "ppr" to "1024")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val rpm = requirePositive(values["rpm"], BilingualText("Speed RPM", "गति RPM"))
                val ppr = requirePositive(values["ppr"], BilingualText("Encoder PPR", "एनकोडर PPR"))

                val freqHz = (rpm * ppr) / 60.0
                val freqKhz = freqHz / 1000.0
                val periodUs = 1_000_000.0 / freqHz
                val quadHz = freqHz * 4.0

                val rps = rpm / 60.0
                val primaryStr = if (freqKhz >= 1.0) formatEng(freqKhz, 2) else formatEng(freqHz, 1)
                val primaryUnitStr = if (freqKhz >= 1.0) "kHz" else "Hz"

                CalculationOutput(
                    primaryLabel = BilingualText("Pulse Frequency (1×)", "पल्स फ्रीक्वेंसी (1×)"),
                    primaryValue = primaryStr,
                    primaryUnit = primaryUnitStr,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Frequency (Hz)", "फ्रीक्वेंसी (Hz)"), formatEng(freqHz, 1), "Hz"),
                        SecondaryMetric(BilingualText("4× Quadrature Rate", "4× क्वाड्रेचर रेट"), formatEng(quadHz / 1000.0, 2), "kHz"),
                        SecondaryMetric(BilingualText("Pulse Period", "पल्स समय"), formatEng(periodUs, 1), "µs")
                    ),
                    formulaUsed = "f (Hz) = (RPM × PPR) / 60   |   T (µs) = 1,000,000 / f",
                    substitutedFormula = "f = (${formatEng(rpm, 0)} × ${formatEng(ppr, 0)}) / 60",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Convert RPM to Revolutions per Second", "RPM को प्रति सेकंड चक्कर (RPS) में बदलें"),
                            "RPS = ${formatEng(rpm, 0)} / 60 = ${formatEng(rps, 2)} rev/s",
                            BilingualText(
                                "Divide shaft speed in RPM by 60 seconds per minute.",
                                "प्रति मिनट चक्कर (RPM) को 60 से भाग देकर प्रति सेकंड चक्कर निकालें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Multiply by Encoder PPR for Pulse Frequency", "PPR से गुणा कर पल्स फ्रीक्वेंसी निकालें"),
                            "f = ${formatEng(rps, 2)} × ${formatEng(ppr, 0)} = ${formatEng(freqHz, 1)} Hz (${formatEng(freqKhz, 2)} kHz)",
                            BilingualText(
                                "Each shaft revolution produces ${formatEng(ppr, 0)} pulses on channel A.",
                                "शाफ्ट के हर एक चक्कर में एनकोडर ${formatEng(ppr, 0)} पल्स देता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Calculate Pulse Period & 4× Quadrature Rate", "पल्स अवधि (T) व 4× क्वाड्रेचर रेट निकालें"),
                            "T = 1,000,000 / ${formatEng(freqHz, 1)} = ${formatEng(periodUs, 1)} µs  |  4× = ${formatEng(quadHz / 1000.0, 2)} kHz",
                            BilingualText(
                                "Set PLC HSC input filter time below half the pulse period (${formatEng(periodUs / 2.0, 1)} µs) to prevent lost counts.",
                                "पल्स मिस न हों इसके लिए PLC इनपुट फिल्टर टाइम ${formatEng(periodUs / 2.0, 1)} µs से कम रखें।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "At ${formatEng(rpm, 0)} RPM with a ${formatEng(ppr, 0)} PPR encoder, the PLC High-Speed Counter sees $primaryStr $primaryUnitStr (pulse every ${formatEng(periodUs, 1)} µs; ${formatEng(quadHz / 1000.0, 2)} kHz in 4× A/B mode).",
                        "${formatEng(rpm, 0)} RPM और ${formatEng(ppr, 0)} PPR एनकोडर पर PLC HSC कार्ड को $primaryStr $primaryUnitStr पल्स मिलेंगी (4× मोड में ${formatEng(quadHz / 1000.0, 2)} kHz)।"
                    )
                )
            }
        }
    )

    private fun plcPanelSmpsCalculator() = CalculatorDefinition(
        id = "plc_panel_power",
        category = CalculatorCategory.PLC_DCS,
        title = BilingualText("24V DC Panel SMPS Sizing", "24V DC पैनल SMPS साइजिंग"),
        subtitle = BilingualText(
            "Size 24V DC Power Supply for PLC, Relays, Solenoids & Transmitters",
            "PLC, रिले, सोलेनॉइड वाल्व और ट्रांसमीटर के लिए 24V DC SMPS साइज निकालें"
        ),
        formulaPreview = "I_SMPS = (I_plc + I_do + I_field) × (1 + Margin%)",
        keywords = listOf("smps", "24v dc", "power supply", "plc panel", "psu", "एसएमपीएस", "पैनल"),
        fields = listOf(
            CalculatorField("plc_load", BilingualText("PLC CPU + I/O Cards Current", "PLC और I/O कार्ड करंट"), "2.2", "A"),
            CalculatorField("relay_solenoid", BilingualText("Relays & Solenoid Valves", "रिले और सोलेनॉइड वाल्व करंट"), "3.5", "A"),
            CalculatorField("field_tx", BilingualText("Field Transmitters & HMI", "फील्ड ट्रांसमीटर व HMI करंट"), "1.8", "A"),
            CalculatorField("margin_pct", BilingualText("Design Spare Margin (%)", "सुरक्षा मार्जिन (%)"), "30", "%")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("Medium PLC Marshalling Panel", "मध्यम PLC कंट्रोल पैनल"),
                values = mapOf("plc_load" to "2.2", "relay_solenoid" to "3.5", "field_tx" to "1.8", "margin_pct" to "30")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val iPlc = requireNonNegative(values["plc_load"], BilingualText("PLC Current", "PLC करंट"))
                val iRelay = requireNonNegative(values["relay_solenoid"], BilingualText("Relay/Solenoid Current", "रिले/वाल्व करंट"))
                val iTx = requireNonNegative(values["field_tx"], BilingualText("Field/HMI Current", "फील्ड/HMI करंट"))
                val margin = requireRange(values["margin_pct"], 0.0, 200.0, BilingualText("Spare Margin (%)", "सुरक्षा मार्जिन (%)"))

                val totalLoadA = iPlc + iRelay + iTx
                if (totalLoadA <= 0.0) {
                    throw BilingualValidationException(
                        BilingualText("Total connected load must be > 0 A.", "कुल जुड़ा हुआ लोड 0 A से अधिक होना चाहिए।")
                    )
                }
                val reqA = totalLoadA * (1.0 + margin / 100.0)
                val reqWatts = reqA * 24.0
                val stdList = listOf(2.5, 5.0, 10.0, 20.0, 40.0)
                val stdSmps = stdList.firstOrNull { it >= reqA }
                val primaryDisplay = if (stdSmps != null) "${formatEng(stdSmps, 1)} A" else "2 × 40 A / Parallel"
                val primaryUnit = if (stdSmps != null) "(${formatEng(stdSmps * 24.0, 0)} W)" else "(Req: ${formatEng(reqA, 1)} A)"

                val marginMult = 1.0 + margin / 100.0

                CalculationOutput(
                    primaryLabel = BilingualText("Recommended 24V SMPS", "अनुशंसित 24V SMPS रेटिंग"),
                    primaryValue = primaryDisplay,
                    primaryUnit = primaryUnit,
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Connected Load", "कुल जुड़ा लोड"), formatEng(totalLoadA, 2), "A"),
                        SecondaryMetric(BilingualText("With Margin", "मार्जिन सहित"), formatEng(reqA, 2), "A"),
                        SecondaryMetric(BilingualText("Required Power", "जरूरी पावर"), formatEng(reqWatts, 0), "W")
                    ),
                    formulaUsed = "I_req = (I_PLC + I_Relays + I_Field) × (1 + Margin / 100)   |   P = I_req × 24 V",
                    substitutedFormula = "I_req = (${formatEng(iPlc, 2)} + ${formatEng(iRelay, 2)} + ${formatEng(iTx, 2)}) × (1 + ${formatEng(margin, 0)} / 100)",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Sum All Connected 24V DC Loads", "सभी 24V DC लोड जोड़ें"),
                            "I_total = ${formatEng(iPlc, 2)} + ${formatEng(iRelay, 2)} + ${formatEng(iTx, 2)} = ${formatEng(totalLoadA, 2)} A",
                            BilingualText(
                                "Add PLC CPU/I/O, relay/solenoid coils, and field transmitters/HMI.",
                                "PLC CPU/कार्ड, रिले/सोलेनॉइड वाल्व और सभी 4–20 mA ट्रांसमीटर का करंट जोड़ें।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Multiply by Design Spare Margin", "सुरक्षा मार्जिन से गुणा करें"),
                            "I_req = ${formatEng(totalLoadA, 2)} × ${formatEng(marginMult, 2)} = ${formatEng(reqA, 2)} A",
                            BilingualText(
                                "Adds ${formatEng(margin, 0)}% headroom for solenoid inrush and future expansion.",
                                "सोलेनॉइड इनरश व भविष्य के लोड हेतु ${formatEng(margin, 0)}% अतिरिक्त मार्जिन जोड़ा गया।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Compute Required Watts & Select Standard SMPS", "पावर (W) निकालें और मानक SMPS चुनें"),
                            "P_req = ${formatEng(reqA, 2)} × 24 = ${formatEng(reqWatts, 0)} W  →  Standard: $primaryDisplay $primaryUnit",
                            BilingualText(
                                "Standard industrial DIN-rail 24V SMPS ratings: 2.5A, 5A, 10A, 20A, 40A.",
                                "बाजार में मानक 24V SMPS साइज 2.5A, 5A, 10A, 20A, 40A में मिलते हैं।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "Total steady load is ${formatEng(totalLoadA, 2)} A; with ${formatEng(margin, 0)}% margin it needs ${formatEng(reqA, 2)} A (${formatEng(reqWatts, 0)} W), so a $primaryDisplay $primaryUnit 24V DC SMPS is recommended.",
                        "कुल जुड़ा लोड ${formatEng(totalLoadA, 2)} A है; ${formatEng(margin, 0)}% मार्जिन के साथ ${formatEng(reqA, 2)} A (${formatEng(reqWatts, 0)} W) चाहिए, इसलिए $primaryDisplay $primaryUnit 24V SMPS उपयुक्त है।"
                    ),
                    assumptions = BilingualText(
                        "Assumes continuous simultaneous load at 24V DC regulated output; consider 1+1 redundancy for critical ESD/DCS.",
                        "मान्यता: 24V DC पर निरंतर लोड माना गया है; क्रिटिकल DCS/ESD पैनल में 1+1 रिडंडेंसी उपयोग करें।"
                    )
                )
            }
        }
    )

    private fun maLinearScalingCalculator() = CalculatorDefinition(
        id = "ma_pv_linear",
        category = CalculatorCategory.SIGNAL_4_20MA,
        title = BilingualText("4–20 mA ↔ PV Linear Scaling", "4–20 mA ↔ PV लीनियर स्केलिंग"),
        subtitle = BilingualText(
            "Convert 4–20 mA to Process Variable (PV) OR PV to 4–20 mA",
            "4–20 mA को प्रोसेस वैल्यू (PV) में या PV को mA सिग्नल में बदलें"
        ),
        formulaPreview = "PV = LRV + ((mA − 4)/16)×(URV − LRV)  |  mA = 4 + 16×((PV − LRV)/Span)",
        keywords = listOf("4-20ma", "4 to 20", "ma", "pv", "lrv", "urv", "transmitter", "सिग्नल", "ट्रांसमीटर"),
        fields = listOf(
            CalculatorField(
                id = "input_val",
                label = BilingualText("Input Value (mA or PV)", "इनपुट मान (mA या PV)"),
                defaultValue = "12",
                defaultUnit = "mA",
                unitOptions = listOf("mA", "PV"),
                allowNegative = true,
                helperText = BilingualText("Switch unit between mA → PV or PV → mA", "यूनिट चुनें: mA से PV निकालना है या PV से mA")
            ),
            CalculatorField("lrv", BilingualText("Lower Range Value (LRV @ 4mA)", "मिनिमम रेंज (LRV @ 4mA)"), "0", "EU", allowNegative = true),
            CalculatorField("urv", BilingualText("Upper Range Value (URV @ 20mA)", "मैक्सिमम रेंज (URV @ 20mA)"), "100", "EU", allowNegative = true)
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("12 mA on 0–16 bar PT", "12 mA (0–16 bar प्रेशर ट्रांसमीटर)"),
                values = mapOf("input_val" to "12", "lrv" to "0", "urv" to "16"),
                units = mapOf("input_val" to "mA")
            ),
            CalculatorPreset(
                label = BilingualText("75 °C on -50 to 150 °C TT", "75 °C (-50 से 150 °C तापमान)"),
                values = mapOf("input_val" to "75", "lrv" to "-50", "urv" to "150"),
                units = mapOf("input_val" to "PV")
            )
        ),
        compute = { values, units ->
            runCatching {
                val input = requireFinite(values["input_val"], BilingualText("Input Value", "इनपुट मान"))
                val lrv = requireFinite(values["lrv"] ?: 0.0, BilingualText("Lower Range Value (LRV)", "मिनिमम रेंज (LRV)"))
                val urv = requireFinite(values["urv"] ?: 100.0, BilingualText("Upper Range Value (URV)", "मैक्सिमम रेंज (URV)"))
                val span = requireNonZero(urv - lrv, BilingualText("Span (URV − LRV)", "स्पैन (URV − LRV)"))

                val isInputMa = (units["input_val"] ?: "mA") == "mA"
                val ma: Double
                val pv: Double
                val pct: Double

                if (isInputMa) {
                    ma = requireRange(input, 0.0, 25.0, BilingualText("Loop Current (mA)", "लूप करंट (mA)"))
                    pct = ((ma - 4.0) / 16.0) * 100.0
                    pv = lrv + ((ma - 4.0) / 16.0) * span
                } else {
                    pv = input
                    pct = ((pv - lrv) / span) * 100.0
                    ma = 4.0 + (pct / 100.0) * 16.0
                }

                val vAcross250 = ma * 0.25
                val isFaultBand = ma < 3.6 || ma > 21.0
                val status = if (isFaultBand) StatusLevel.WARNING else StatusLevel.NORMAL

                if (isInputMa) {
                    val maAboveZero = ma - 4.0
                    val fraction = maAboveZero / 16.0
                    val pvDelta = fraction * span

                    CalculationOutput(
                        primaryLabel = BilingualText("Process Variable (PV)", "प्रोसेस वैल्यू (PV)"),
                        primaryValue = formatEng(pv, 3),
                        primaryUnit = "EU (${formatEng(pct, 2)}%)",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Output %", "प्रतिशत (%)"), formatEng(pct, 2), "%"),
                            SecondaryMetric(BilingualText("Input Current", "इनपुट करंट"), formatEng(ma, 3), "mA"),
                            SecondaryMetric(BilingualText("Across 250Ω Resistor", "250Ω पर वोल्टेज"), formatEng(vAcross250, 3), "V")
                        ),
                        formulaUsed = "PV = LRV + [(mA − 4) / 16] × (URV − LRV)",
                        substitutedFormula = "PV = ${formatEng(lrv, 2)} + [(${formatEng(ma, 3)} − 4) / 16] × (${formatEng(urv, 2)} − ${formatEng(lrv, 2)})",
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Subtract 4 from Input mA", "इनपुट mA में से 4 घटाएं"),
                                "mA − 4 = ${formatEng(ma, 3)} − 4 = ${formatEng(maAboveZero, 3)} mA",
                                BilingualText(
                                    "Removes the 4 mA live-zero baseline to get active signal current above 0%.",
                                    "0% बेसलाइन (4 mA लाइव-जीरो) हटाने पर 0–16 mA रेंज का सक्रिय सिग्नल मिलता है।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Divide by 16 (Span Fraction)", "16 से भाग दें (सिग्नल अनुपात)"),
                                "${formatEng(maAboveZero, 3)} / 16 = ${formatEng(fraction, 4)}  (${formatEng(pct, 2)}% of span)",
                                BilingualText(
                                    "Divides by the 16 mA span (20 − 4 mA) to find the normalized measurement fraction.",
                                    "कुल 16 mA स्पैन (20 − 4 mA) से भाग देने पर स्पैन का अनुपात व % प्राप्त होता है।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Multiply by Measurement Range (URV − LRV)", "माप रेंज (URV − LRV) से गुणा करें"),
                                "${formatEng(fraction, 4)} × ${formatEng(span, 2)} = ${formatEng(pvDelta, 3)} EU",
                                BilingualText(
                                    "Scales the normalized signal fraction to the calibrated span (${formatEng(span, 2)} EU).",
                                    "अनुपात को कुल कैलिब्रेटेड स्पैन (${formatEng(span, 2)} EU) से गुणा करें।"
                                )
                            ),
                            CalculationStep(
                                4,
                                BilingualText("Add LRV for Final Process Value", "अंतिम उत्तर के लिए LRV जोड़ें"),
                                "PV = ${formatEng(lrv, 2)} + ${formatEng(pvDelta, 3)} = ${formatEng(pv, 3)} EU",
                                BilingualText(
                                    "Adds the Lower Range Value (4 mA point) to obtain the exact process reading.",
                                    "4 mA वाले निचले मान (LRV) को जोड़ने पर अंतिम प्रोसेस वैल्यू (PV) प्राप्त होती है।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "At ${formatEng(ma, 3)} mA (${formatEng(pct, 2)}% of 4–20 mA span), the transmitter reads ${formatEng(pv, 3)} EU and drops ${formatEng(vAcross250, 3)} V DC across a 250 Ω HART resistor.",
                            "${formatEng(ma, 3)} mA (रेंज का ${formatEng(pct, 2)}%) पर ट्रांसमीटर ${formatEng(pv, 3)} EU दिखाता है और 250 Ω रेजिस्टर पर ${formatEng(vAcross250, 3)} V DC वोल्टेज बनाता है।"
                        ),
                        statusLevel = status,
                        engineeringNote = BilingualText(
                            if (isFaultBand) "NAMUR NE43 Alert: ${formatEng(ma, 2)} mA is in the fault/burnout band (<3.6 or >21.0 mA)!"
                            else "NAMUR NE43: < 3.6 mA or > 21.0 mA indicates transmitter fault or open/short loop.",
                            if (isFaultBand) "NAMUR NE43 चेतावनी: ${formatEng(ma, 2)} mA फॉल्ट बैंड (<3.6 या >21.0 mA) में है!"
                            else "NAMUR NE43 मानक: 3.6 mA से कम या 21.0 mA से अधिक करंट सेंसर फॉल्ट या वायर ब्रेक दर्शाता है।"
                        )
                    )
                } else {
                    val pvAboveLrv = pv - lrv
                    val fraction = pvAboveLrv / span
                    val maAboveZero = fraction * 16.0

                    CalculationOutput(
                        primaryLabel = BilingualText("Loop Signal Output (mA)", "लूप सिग्नल आउटपुट (mA)"),
                        primaryValue = formatEng(ma, 3),
                        primaryUnit = "mA",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Span %", "स्पैन %"), formatEng(pct, 2), "%"),
                            SecondaryMetric(BilingualText("Voltage on 250Ω", "250Ω पर वोल्टेज"), formatEng(vAcross250, 3), "V"),
                            SecondaryMetric(BilingualText("Span (URV−LRV)", "कुल स्पैन"), formatEng(span, 2), "EU")
                        ),
                        formulaUsed = "mA = 4 + 16 × [(PV − LRV) / (URV − LRV)]",
                        substitutedFormula = "mA = 4 + 16 × [(${formatEng(pv, 2)} − ${formatEng(lrv, 2)}) / (${formatEng(urv, 2)} − ${formatEng(lrv, 2)})]",
                        steps = listOf(
                            CalculationStep(
                                1,
                                BilingualText("Subtract LRV from Input PV", "इनपुट PV में से LRV घटाएं"),
                                "PV − LRV = ${formatEng(pv, 2)} − ${formatEng(lrv, 2)} = ${formatEng(pvAboveLrv, 2)}",
                                BilingualText(
                                    "Finds how far the process value sits above the zero-scale LRV.",
                                    "पता करें कि प्रोसेस वैल्यू निचले मान (LRV) से कितनी ऊपर है।"
                                )
                            ),
                            CalculationStep(
                                2,
                                BilingualText("Divide by Measurement Range (URV − LRV)", "माप रेंज (URV − LRV) से भाग दें"),
                                "${formatEng(pvAboveLrv, 2)} / ${formatEng(span, 2)} = ${formatEng(fraction, 4)}  (${formatEng(pct, 2)}%)",
                                BilingualText(
                                    "Converts the process value into a normalized 0–100% span fraction.",
                                    "प्रोसेस वैल्यू को 0–100% स्पैन अनुपात में बदलें।"
                                )
                            ),
                            CalculationStep(
                                3,
                                BilingualText("Multiply by 16 mA Span", "16 mA स्पैन से गुणा करें"),
                                "16 × ${formatEng(fraction, 4)} = ${formatEng(maAboveZero, 3)} mA",
                                BilingualText(
                                    "Calculates the active mA signal contribution above the 4 mA baseline.",
                                    "4 mA बेस के ऊपर अतिरिक्त करंट सिग्नल की गणना करें।"
                                )
                            ),
                            CalculationStep(
                                4,
                                BilingualText("Add 4 mA Live-Zero Offset", "4 mA बेसलाइन जोड़कर अंतिम mA निकालें"),
                                "mA = 4 + ${formatEng(maAboveZero, 3)} = ${formatEng(ma, 3)} mA  (${formatEng(vAcross250, 3)} V on 250Ω)",
                                BilingualText(
                                    "Adding 4 mA gives the final 4–20 mA transmitter output.",
                                    "4 mA लाइव-जीरो जोड़ने पर ट्रांसमीटर का अंतिम सिग्नल प्राप्त होता है।"
                                )
                            )
                        ),
                        resultExplanation = BilingualText(
                            "A process value of ${formatEng(pv, 2)} EU (${formatEng(pct, 2)}% of ${formatEng(lrv, 1)}..${formatEng(urv, 1)} range) outputs ${formatEng(ma, 3)} mA (${formatEng(vAcross250, 3)} V across 250 Ω).",
                            "${formatEng(lrv, 1)}..${formatEng(urv, 1)} रेंज में ${formatEng(pv, 2)} EU (${formatEng(pct, 2)}%) पर आउटपुट ${formatEng(ma, 3)} mA होगा (250 Ω पर ${formatEng(vAcross250, 3)} V)।"
                        ),
                        statusLevel = status,
                        engineeringNote = if (isFaultBand) BilingualText(
                            "Warning: PV is outside calibrated LRV–URV range, resulting in ${formatEng(ma, 2)} mA.",
                            "चेतावनी: दर्ज PV कैलिब्रेटेड रेंज (LRV–URV) से बाहर है (${formatEng(ma, 2)} mA)।"
                        ) else null
                    )
                }
            }
        }
    )

    private fun maSquareRootFlowCalculator() = CalculatorDefinition(
        id = "ma_dp_sqrt",
        category = CalculatorCategory.SIGNAL_4_20MA,
        title = BilingualText("4–20 mA Square-Root Flow Scaling", "4–20 mA वर्गमूल (√) फ्लो स्केलिंग"),
        subtitle = BilingualText(
            "Convert DP Transmitter 4–20 mA to Flow using Square-Root extraction",
            "ऑरिफिस DP ट्रांसमीटर के 4–20 mA सिग्नल से वर्गमूल (Square-Root) द्वारा असली फ्लो निकालें"
        ),
        formulaPreview = "Flow = Q_max × √((mA − 4) / 16)",
        keywords = listOf("square root", "dp flow", "orifice", "4-20ma", "वर्गमूल", "फ्लो"),
        fields = listOf(
            CalculatorField("ma", BilingualText("DP Transmitter Output (mA)", "DP ट्रांसमीटर करंट (mA)"), "12", "mA"),
            CalculatorField(
                id = "q_max",
                label = BilingualText("Max Flow at 20 mA (Q_max)", "20 mA पर अधिकतम फ्लो"),
                defaultValue = "100",
                defaultUnit = "m³/h",
                unitOptions = listOf("m³/h", "LPM", "kg/h", "TPH")
            ),
            CalculatorField(
                id = "dp_max",
                label = BilingualText("Max DP Range (at 20 mA)", "अधिकतम DP रेंज"),
                defaultValue = "2500",
                defaultUnit = "mmH₂O",
                unitOptions = listOf("mmH₂O", "mbar", "kPa", "psi")
            )
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("12 mA (50% DP → 70.7% Flow)", "12 mA (50% DP → 70.7% फ्लो)"),
                values = mapOf("ma" to "12", "q_max" to "100", "dp_max" to "2500"),
                units = mapOf("q_max" to "m³/h", "dp_max" to "mmH₂O")
            ),
            CalculatorPreset(
                label = BilingualText("8 mA (25% DP → 50% Flow)", "8 mA (25% DP → 50% फ्लो)"),
                values = mapOf("ma" to "8", "q_max" to "100", "dp_max" to "2500"),
                units = mapOf("q_max" to "m³/h", "dp_max" to "mmH₂O")
            )
        ),
        compute = { values, units ->
            runCatching {
                val ma = requireRange(values["ma"], 3.6, 22.0, BilingualText("Transmitter Current (mA)", "ट्रांसमीटर करंट (mA)"))
                val qMax = requirePositive(values["q_max"], BilingualText("Max Flow", "अधिकतम फ्लो"))
                val dpMax = requirePositive(values["dp_max"], BilingualText("Max DP", "अधिकतम DP"))
                val qUnit = units["q_max"] ?: "m³/h"
                val dpUnit = units["dp_max"] ?: "mmH₂O"

                val dpFraction = ((ma - 4.0) / 16.0).coerceAtLeast(0.0)
                val dpPct = dpFraction * 100.0
                val flowFraction = sqrt(dpFraction)
                val flowPct = flowFraction * 100.0
                val flowVal = qMax * flowFraction
                val dpVal = dpMax * dpFraction
                val sqrtOutMa = 4.0 + 16.0 * flowFraction
                val isOverOrUnder = ma < 4.0 || ma > 20.5

                val maAboveZero = (ma - 4.0).coerceAtLeast(0.0)

                CalculationOutput(
                    primaryLabel = BilingualText("Extracted Flow Rate", "वास्तविक फ्लो रेट (√ से)"),
                    primaryValue = formatEng(flowVal, 2),
                    primaryUnit = "$qUnit (${formatEng(flowPct, 2)}%)",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("DP % (Linear)", "DP % (लीनियर)"), formatEng(dpPct, 2), "%"),
                        SecondaryMetric(BilingualText("Actual DP", "वास्तविक DP"), formatEng(dpVal, 1), dpUnit),
                        SecondaryMetric(BilingualText("√ Extracted mA", "√ के बाद mA"), formatEng(sqrtOutMa, 2), "mA")
                    ),
                    formulaUsed = "Flow = Q_max × √((mA − 4) / 16)",
                    substitutedFormula = "Flow = ${formatEng(qMax, 1)} × √((${formatEng(ma, 2)} − 4) / 16)",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Subtract 4 mA Live-Zero Offset", "mA में से 4 mA घटाएं"),
                            "mA − 4 = ${formatEng(ma, 2)} − 4 = ${formatEng(maAboveZero, 2)} mA",
                            BilingualText(
                                "Removes the 4 mA baseline of the linear DP transmitter signal.",
                                "लीनियर DP ट्रांसमीटर सिग्नल से 4 mA बेसलाइन हटाएं।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Divide by 16 for Linear DP Fraction", "16 से भाग देकर लीनियर DP अनुपात निकालें"),
                            "DP_frac = ${formatEng(maAboveZero, 2)} / 16 = ${formatEng(dpFraction, 4)}  (${formatEng(dpPct, 2)}% → ${formatEng(dpVal, 1)} $dpUnit)",
                            BilingualText(
                                "When configured in Linear mode, mA represents differential pressure ΔP.",
                                "लीनियर मोड में ट्रांसमीटर का mA सीधे डिफ़रेंशियल प्रेशर (ΔP) दर्शाता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Take Square Root for Flow Fraction", "फ्लो अनुपात के लिए वर्गमूल (√) निकालें"),
                            "Flow_frac = √(${formatEng(dpFraction, 4)}) = ${formatEng(flowFraction, 4)}  (${formatEng(flowPct, 2)}%)",
                            BilingualText(
                                "Orifice flow is proportional to √ΔP; e.g., 50% DP (12 mA) equals 70.71% flow.",
                                "ऑरिफिस फ्लो √ΔP के समानुपाती होता है (जैसे 50% DP / 12 mA पर 70.71% फ्लो)।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Multiply by Q_max for Actual Flow", "Q_max से गुणा कर वास्तविक फ्लो निकालें"),
                            "Q = ${formatEng(qMax, 1)} × ${formatEng(flowFraction, 4)} = ${formatEng(flowVal, 2)} $qUnit  (√ mA = ${formatEng(sqrtOutMa, 2)} mA)",
                            BilingualText(
                                "Only extract square root once (either in transmitter OR in PLC/DCS, never both).",
                                "वर्गमूल (√) या तो ट्रांसमीटर में रखें या PLC/DCS में — दोनों जगह एक साथ नहीं!"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        "At ${formatEng(ma, 2)} mA linear DP (${formatEng(dpVal, 1)} $dpUnit, ${formatEng(dpPct, 1)}% DP), extracted flow is ${formatEng(flowPct, 2)}% = ${formatEng(flowVal, 2)} $qUnit.",
                        "${formatEng(ma, 2)} mA लीनियर DP (${formatEng(dpPct, 1)}% DP) पर वर्गमूल निकालने से वास्तविक फ्लो ${formatEng(flowPct, 2)}% = ${formatEng(flowVal, 2)} $qUnit मिलता है।"
                    ),
                    assumptions = BilingualText(
                        "Assumes DP transmitter outputs linear ΔP (4–20 mA) and incompressible/compensated fluid conditions.",
                        "मान्यता: DP ट्रांसमीटर लीनियर मोड में है और वर्गमूल (√) गणना PLC/DCS में की जा रही है।"
                    ),
                    statusLevel = if (isOverOrUnder) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun maLoopResistanceCalculator() = CalculatorDefinition(
        id = "ma_loop_resistance",
        category = CalculatorCategory.SIGNAL_4_20MA,
        title = BilingualText("4–20 mA Loop Resistance Check", "4–20 mA लूप रेजिस्टेंस जांच"),
        subtitle = BilingualText(
            "Verify max allowable loop Ω, HART 250Ω compatibility & terminal voltage",
            "24V लूप पावर सप्लाई और कुल लूप रेजिस्टेंस (HART 250Ω सहित) की जांच करें"
        ),
        formulaPreview = "R_max = (V_supply − V_min_tx) / 0.020 A",
        keywords = listOf("loop", "resistance", "hart", "250", "4-20ma", "power supply", "लूप रेजिस्टेंस"),
        fields = listOf(
            CalculatorField("v_supply", BilingualText("Loop Supply Voltage (V)", "लूप पावर सप्लाई (V)"), "24", "V"),
            CalculatorField("v_min_tx", BilingualText("Transmitter Min Lift Voltage (V)", "ट्रांसमीटर न्यूनतम वोल्टेज (V)"), "10.5", "V"),
            CalculatorField("r_plc", BilingualText("PLC AI Card + HART Resistor (Ω)", "PLC कार्ड + HART रेजिस्टर (Ω)"), "250", "Ω"),
            CalculatorField("r_cable", BilingualText("Total 2-Wire Cable Loop Resistance (Ω)", "केबल रेजिस्टेंस (आना+जाना Ω)"), "45", "Ω")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("24V Loop + 250Ω HART + 45Ω Cable", "24V सप्लाई + 250Ω + 45Ω केबल"),
                values = mapOf("v_supply" to "24", "v_min_tx" to "10.5", "r_plc" to "250", "r_cable" to "45")
            )
        ),
        compute = { values, _ ->
            runCatching {
                val vs = requirePositive(values["v_supply"], BilingualText("Supply Voltage", "सप्लाई वोल्टेज"))
                val vmin = requirePositive(values["v_min_tx"], BilingualText("Min Tx Voltage", "न्यूनतम वोल्टेज"))
                val rPlc = requireNonNegative(values["r_plc"], BilingualText("PLC/HART Resistance", "PLC/HART रेजिस्टेंस"))
                val rCable = requireNonNegative(values["r_cable"], BilingualText("Cable Resistance", "केबल रेजिस्टेंस"))

                if (vs <= vmin) {
                    throw BilingualValidationException(
                        BilingualText(
                            "Loop supply voltage ($vs V) must be higher than transmitter minimum lift voltage ($vmin V).",
                            "लूप सप्लाई वोल्टेज ($vs V) ट्रांसमीटर के न्यूनतम वोल्टेज ($vmin V) से अधिक होना चाहिए।"
                        )
                    )
                }

                val rMax = (vs - vmin) / 0.020
                val rActual = rPlc + rCable
                val vDropAt20ma = rActual * 0.020
                val vAtTx = vs - vDropAt20ma
                val pass = vAtTx >= vmin && rActual >= 250.0
                val status = if (vAtTx < vmin) StatusLevel.WARNING else StatusLevel.NORMAL

                val statusText = when {
                    vAtTx < vmin -> BilingualText("FAIL (Overload)", "फेल (ज्यादा Ω)")
                    rActual >= 250.0 -> BilingualText("PASS (HART OK)", "पास (HART OK)")
                    else -> BilingualText("OK (<250Ω HART)", "OK (<250Ω HART)")
                }

                val vHeadroom = vs - vmin

                CalculationOutput(
                    primaryLabel = BilingualText("Max Allowable Loop Resistance", "अधिकतम स्वीकार्य लूप रेजिस्टेंस"),
                    primaryValue = formatEng(rMax, 0),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Actual Loop Ω", "कुल वर्तमान लूप Ω"), formatEng(rActual, 1), "Ω"),
                        SecondaryMetric(BilingualText("Tx Terminal @ 20mA", "20mA पर Tx वोल्टेज"), formatEng(vAtTx, 2), "V"),
                        SecondaryMetric(BilingualText("Loop Status", "लूप स्थिति"), statusText.en, localizedValue = statusText)
                    ),
                    formulaUsed = "R_max = (V_supply − V_min_tx) / 0.020   |   V_tx = V_supply − (0.020 × (R_plc + R_cable))",
                    substitutedFormula = "R_max = (${formatEng(vs, 1)} − ${formatEng(vmin, 1)}) / 0.020   |   V_tx = ${formatEng(vs, 1)} − (0.020 × (${formatEng(rPlc, 1)} + ${formatEng(rCable, 1)}))",
                    steps = listOf(
                        CalculationStep(
                            1,
                            BilingualText("Find Available Voltage Headroom", "उपलब्ध वोल्टेज हेडरूम निकालें"),
                            "V_headroom = ${formatEng(vs, 1)} − ${formatEng(vmin, 1)} = ${formatEng(vHeadroom, 2)} V",
                            BilingualText(
                                "Voltage left to overcome loop resistance after reserving transmitter minimum lift voltage.",
                                "ट्रांसमीटर को चालू रखने के बाद लूप रेजिस्टेंस के लिए बचा हुआ वोल्टेज।"
                            )
                        ),
                        CalculationStep(
                            2,
                            BilingualText("Divide by 0.020 A (20 mA) for Max Resistance", "0.020 A (20 mA) से भाग देकर R_max निकालें"),
                            "R_max = ${formatEng(vHeadroom, 2)} / 0.020 = ${formatEng(rMax, 0)} Ω",
                            BilingualText(
                                "Worst-case voltage drop occurs at 20 mA (0.020 A) full-scale loop current.",
                                "अधिकतम वोल्टेज ड्रॉप 20 mA (0.020 A) फुल-स्केल करंट पर होता है।"
                            )
                        ),
                        CalculationStep(
                            3,
                            BilingualText("Sum Actual Loop Resistance & Drop @ 20 mA", "कुल लूप रेजिस्टर व 20 mA पर ड्रॉप निकालें"),
                            "R_total = ${formatEng(rPlc, 1)} + ${formatEng(rCable, 1)} = ${formatEng(rActual, 1)} Ω  →  V_drop = 0.020 × ${formatEng(rActual, 1)} = ${formatEng(vDropAt20ma, 2)} V",
                            BilingualText(
                                "Combines PLC AI input impedance, 250 Ω HART resistor, and go-and-return cable resistance.",
                                "PLC कार्ड, 250 Ω HART रेजिस्टर और केबल के आने-जाने का कुल रेजिस्टेंस जोड़ें।"
                            )
                        ),
                        CalculationStep(
                            4,
                            BilingualText("Verify Terminal Voltage at Transmitter", "ट्रांसमीटर टर्मिनल वोल्टेज की जांच करें"),
                            "V_tx = ${formatEng(vs, 1)} − ${formatEng(vDropAt20ma, 2)} = ${formatEng(vAtTx, 2)} V  (Need ≥ ${formatEng(vmin, 1)} V)",
                            BilingualText(
                                if (pass) "Healthy loop! Transmitter has enough voltage and ≥250Ω for HART."
                                else if (vAtTx < vmin) "Loop resistance is too high — transmitter will saturate below 20 mA!"
                                else "Loop is powered OK, add a 250Ω resistor in series if HART communication fails.",
                                if (pass) "लूप बिल्कुल सही है! ट्रांसमीटर को पर्याप्त वोल्टेज मिल रहा है और HART भी काम करेगा।"
                                else if (vAtTx < vmin) "रेजिस्टेंस ज्यादा है — 20 mA पर ट्रांसमीटर काम करना बंद कर देगा!"
                                else "वोल्टेज ठीक है, लेकिन HART कम्युनिकेशन के लिए कम से कम 250Ω सीरीज रेजिस्टेंस चाहिए।"
                            )
                        )
                    ),
                    resultExplanation = BilingualText(
                        when {
                            vAtTx < vmin -> "Loop fails: actual ${formatEng(rActual, 1)} Ω exceeds ${formatEng(rMax, 0)} Ω limit, leaving only ${formatEng(vAtTx, 2)} V (< ${formatEng(vmin, 1)} V) at 20 mA."
                            rActual >= 250.0 -> "Loop passes with HART OK: actual ${formatEng(rActual, 1)} Ω is below ${formatEng(rMax, 0)} Ω limit and leaves ${formatEng(vAtTx, 2)} V at the transmitter."
                            else -> "Loop voltage is OK (${formatEng(vAtTx, 2)} V), but total ${formatEng(rActual, 1)} Ω is below 250 Ω so HART communication may need a 250 Ω resistor."
                        },
                        when {
                            vAtTx < vmin -> "लूप फेल: कुल ${formatEng(rActual, 1)} Ω, अधिकतम सीमा ${formatEng(rMax, 0)} Ω से अधिक है; 20 mA पर ट्रांसमीटर को केवल ${formatEng(vAtTx, 2)} V मिलेगा।"
                            rActual >= 250.0 -> "लूप और HART पास हैं: ${formatEng(rActual, 1)} Ω, सीमा ${formatEng(rMax, 0)} Ω के अंदर है और ट्रांसमीटर पर ${formatEng(vAtTx, 2)} V उपलब्ध है।"
                            else -> "लूप वोल्टेज ठीक है (${formatEng(vAtTx, 2)} V), पर HART के लिए कम से कम 250 Ω सीरीज रेजिस्टर जरूरी है।"
                        }
                    ),
                    assumptions = BilingualText(
                        "Evaluated at 20 mA worst-case load; HART protocol requires minimum 230–250 Ω total loop resistance.",
                        "मान्यता: 20 mA अधिकतम करंट पर गणना की गई; HART के लिए न्यूनतम 250 Ω आवश्यक है।"
                    ),
                    statusLevel = status
                )
            }
        }
    )
}
