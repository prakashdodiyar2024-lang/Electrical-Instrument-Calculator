package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LanguagePreferences
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculationHistoryItem
import com.example.model.CalculationOutput
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorPreset
import com.example.model.EngineeringDiscipline
import com.example.ui.audio.TouchSoundController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CalculatorScreenUiState(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val selectedDiscipline: EngineeringDiscipline = EngineeringDiscipline.ELECTRICAL,
    val selectedCategory: CalculatorCategory = CalculatorCategory.ELEC_BASIC,
    val searchQuery: String = "",
    val searchResults: List<CalculatorDefinition> = CalculatorRegistry.allCalculators,
    val favoriteIds: Set<String> = emptySet(),
    val touchSoundEnabled: Boolean = true,
    val defaultDiscipline: EngineeringDiscipline = EngineeringDiscipline.ELECTRICAL,
    val activeCalculator: CalculatorDefinition? = null,
    val inputValues: Map<String, String> = emptyMap(),
    val inputUnits: Map<String, String> = emptyMap(),
    val result: CalculationOutput? = null,
    val errorText: BilingualText? = null,
    val recentHistory: List<CalculationHistoryItem> = emptyList()
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = LanguagePreferences(application.applicationContext)
    private var hasUserChangedDiscipline = false

    private val _uiState = MutableStateFlow(CalculatorScreenUiState())
    val uiState: StateFlow<CalculatorScreenUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.languageFlow.collect { savedLang ->
                _uiState.update { it.copy(language = savedLang) }
            }
        }
        viewModelScope.launch {
            prefs.favoriteIdsFlow.collect { favs ->
                _uiState.update { it.copy(favoriteIds = favs) }
            }
        }
        viewModelScope.launch {
            prefs.touchSoundEnabledFlow.collect { enabled ->
                TouchSoundController.isSoundEnabled = enabled
                _uiState.update { it.copy(touchSoundEnabled = enabled) }
            }
        }
        viewModelScope.launch {
            prefs.defaultDisciplineFlow.collect { savedDiscipline ->
                _uiState.update { state ->
                    if (!hasUserChangedDiscipline) {
                        val firstCat = CalculatorCategory.forDiscipline(savedDiscipline).first()
                        state.copy(
                            defaultDiscipline = savedDiscipline,
                            selectedDiscipline = savedDiscipline,
                            selectedCategory = firstCat
                        )
                    } else {
                        state.copy(defaultDiscipline = savedDiscipline)
                    }
                }
            }
        }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.ENGLISH) {
            AppLanguage.HINDI
        } else {
            AppLanguage.ENGLISH
        }
        setLanguage(next)
    }

    fun setLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(language = lang) }
        viewModelScope.launch {
            prefs.setLanguage(lang)
        }
    }

    fun selectDiscipline(discipline: EngineeringDiscipline) {
        hasUserChangedDiscipline = true
        val firstCat = CalculatorCategory.forDiscipline(discipline).first()
        _uiState.update { state ->
            val nextCat = if (state.selectedCategory.discipline == discipline) {
                state.selectedCategory
            } else {
                firstCat
            }
            state.copy(
                selectedDiscipline = discipline,
                selectedCategory = nextCat
            )
        }
    }

    fun selectCategoryTab(category: CalculatorCategory) {
        hasUserChangedDiscipline = true
        _uiState.update {
            it.copy(
                selectedDiscipline = category.discipline,
                selectedCategory = category
            )
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update {
            it.copy(
                searchQuery = query,
                searchResults = CalculatorRegistry.search(
                    query = query,
                    disciplineFilter = null,
                    categoryFilter = null
                )
            )
        }
    }

    fun toggleFavorite(calculatorId: String) {
        _uiState.update { state ->
            val updated = if (calculatorId in state.favoriteIds) {
                state.favoriteIds - calculatorId
            } else {
                state.favoriteIds + calculatorId
            }
            state.copy(favoriteIds = updated)
        }
        viewModelScope.launch {
            prefs.toggleFavorite(calculatorId)
        }
    }

    fun clearFavorites() {
        _uiState.update { it.copy(favoriteIds = emptySet()) }
        viewModelScope.launch {
            prefs.clearFavorites()
        }
    }

    fun setTouchSoundEnabled(enabled: Boolean) {
        TouchSoundController.isSoundEnabled = enabled
        _uiState.update { it.copy(touchSoundEnabled = enabled) }
        viewModelScope.launch {
            prefs.setTouchSoundEnabled(enabled)
        }
    }

    fun setDefaultDiscipline(discipline: EngineeringDiscipline) {
        _uiState.update { it.copy(defaultDiscipline = discipline) }
        viewModelScope.launch {
            prefs.setDefaultDiscipline(discipline)
        }
    }

    fun clearRecentHistory() {
        _uiState.update { it.copy(recentHistory = emptyList()) }
    }

    fun openCalculator(calculatorId: String) {
        val calc = CalculatorRegistry.getById(calculatorId) ?: return
        val defaultValues = calc.fields.associate { it.id to it.defaultValue }
        val defaultUnits = calc.fields.associate { it.id to it.defaultUnit }
        _uiState.update {
            it.copy(
                activeCalculator = calc,
                inputValues = defaultValues,
                inputUnits = defaultUnits,
                result = null,
                errorText = null
            )
        }
        calculate(addToHistory = false)
    }

    fun onFieldValueChange(fieldId: String, newValue: String) {
        val sanitized = newValue.filter { it.isDigit() || it == '.' || it == '-' }
        _uiState.update { state ->
            state.copy(
                inputValues = state.inputValues + (fieldId to sanitized),
                errorText = null
            )
        }
    }

    fun toggleFieldSign(fieldId: String) {
        _uiState.update { state ->
            val cur = state.inputValues[fieldId].orEmpty()
            val next = if (cur.startsWith("-")) cur.drop(1) else "-$cur"
            state.copy(
                inputValues = state.inputValues + (fieldId to next),
                errorText = null
            )
        }
    }

    fun onFieldUnitChange(fieldId: String, newUnit: String) {
        _uiState.update { state ->
            state.copy(
                inputUnits = state.inputUnits + (fieldId to newUnit),
                errorText = null
            )
        }
        calculate(addToHistory = false)
    }

    fun applyPreset(preset: CalculatorPreset) {
        val calc = _uiState.value.activeCalculator ?: return
        val updatedValues = _uiState.value.inputValues.toMutableMap()
        val updatedUnits = _uiState.value.inputUnits.toMutableMap()
        preset.values.forEach { (k, v) -> updatedValues[k] = v }
        preset.units.forEach { (k, u) -> updatedUnits[k] = u }
        calc.fields.forEach { f ->
            if (!updatedValues.containsKey(f.id)) updatedValues[f.id] = f.defaultValue
            if (!updatedUnits.containsKey(f.id)) updatedUnits[f.id] = f.defaultUnit
        }
        _uiState.update {
            it.copy(
                inputValues = updatedValues,
                inputUnits = updatedUnits,
                errorText = null
            )
        }
        calculate(addToHistory = true)
    }

    fun resetActiveCalculator() {
        val calc = _uiState.value.activeCalculator ?: return
        val defaultValues = calc.fields.associate { it.id to it.defaultValue }
        val defaultUnits = calc.fields.associate { it.id to it.defaultUnit }
        _uiState.update {
            it.copy(
                inputValues = defaultValues,
                inputUnits = defaultUnits,
                result = null,
                errorText = null
            )
        }
    }

    fun calculate(addToHistory: Boolean = true) {
        val state = _uiState.value
        val calc = state.activeCalculator ?: return

        val parsed = mutableMapOf<String, Double>()
        for (field in calc.fields) {
            if (field.isSelectorOnly) {
                parsed[field.id] = 1.0
                continue
            }
            val rawStr = state.inputValues[field.id]?.trim().orEmpty()
            val num = rawStr.toDoubleOrNull()
            if (num == null) {
                _uiState.update {
                    it.copy(
                        errorText = BilingualText(
                            "Please enter a valid number for ${field.label.en}",
                            "कृपया ${field.label.hi} के लिए सही संख्या दर्ज करें"
                        ),
                        result = null
                    )
                }
                return
            }
            parsed[field.id] = num
        }

        val outcome = calc.compute(parsed, state.inputUnits)
        outcome.onSuccess { output ->
            _uiState.update { current ->
                val nextHistory = if (addToHistory) {
                    val item = CalculationHistoryItem(
                        calculatorId = calc.id,
                        title = calc.title,
                        resultSummary = "${output.primaryValue} ${output.primaryUnit}",
                        category = calc.category
                    )
                    (listOf(item) + current.recentHistory.filterNot {
                        it.calculatorId == item.calculatorId && it.resultSummary == item.resultSummary
                    }).take(8)
                } else {
                    current.recentHistory
                }
                current.copy(
                    result = output,
                    errorText = null,
                    recentHistory = nextHistory
                )
            }
        }.onFailure { err ->
            val msg = if (err is BilingualValidationException) {
                err.bilingualMessage
            } else {
                BilingualText(
                    err.message ?: "Invalid input values",
                    err.message ?: "कृपया सही मान दर्ज करें"
                )
            }
            _uiState.update {
                it.copy(
                    result = null,
                    errorText = msg
                )
            }
        }
    }
}
