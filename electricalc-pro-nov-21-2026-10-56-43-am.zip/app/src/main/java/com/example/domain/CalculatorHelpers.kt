package com.example.domain

import com.example.model.BilingualText
import com.example.model.CalculationOutput
import com.example.model.CalculationStep
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel

internal fun engOutput(
    primaryLabel: BilingualText,
    primaryValue: String,
    primaryUnit: String,
    secondaryMetrics: List<SecondaryMetric> = emptyList(),
    formulaUsed: String,
    substitutedFormula: String,
    stepTitle: BilingualText = BilingualText("Engineering Computation", "इंजीनियरिंग गणना"),
    stepExpression: String = substitutedFormula,
    stepExplanation: BilingualText,
    assumptions: BilingualText? = null,
    engineeringNote: BilingualText? = null,
    statusLevel: StatusLevel = StatusLevel.NORMAL,
    primaryUnitLocalized: BilingualText? = null
): CalculationOutput = CalculationOutput(
    primaryLabel = primaryLabel,
    primaryValue = primaryValue,
    primaryUnit = primaryUnit,
    primaryUnitLocalized = primaryUnitLocalized,
    secondaryMetrics = secondaryMetrics,
    formulaUsed = formulaUsed,
    substitutedFormula = substitutedFormula,
    steps = listOf(
        CalculationStep(
            stepNumber = 1,
            title = stepTitle,
            expression = stepExpression,
            explanation = stepExplanation
        )
    ),
    resultExplanation = stepExplanation,
    assumptions = assumptions,
    engineeringNote = engineeringNote,
    statusLevel = statusLevel
)

internal fun nearestStandardRating(value: Double, standardList: List<Double>): Double =
    standardList.firstOrNull { it >= value } ?: standardList.last()

internal val STANDARD_XFMR_KVA = listOf(
    10.0, 16.0, 25.0, 40.0, 63.0, 100.0, 160.0, 200.0, 250.0, 315.0,
    400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0
)

internal val STANDARD_BREAKER_A = listOf(
    6.0, 10.0, 16.0, 20.0, 25.0, 32.0, 40.0, 50.0, 63.0, 80.0,
    100.0, 125.0, 160.0, 200.0, 250.0, 320.0, 400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600.0
)

internal val STANDARD_CABLE_MM2 = listOf(
    1.0, 1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0,
    70.0, 95.0, 120.0, 150.0, 185.0, 240.0, 300.0, 400.0
)
