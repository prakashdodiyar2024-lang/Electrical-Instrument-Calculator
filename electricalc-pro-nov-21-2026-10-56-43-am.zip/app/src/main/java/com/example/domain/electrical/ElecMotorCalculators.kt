package com.example.domain.electrical

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.ElectricMeter
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.PrecisionManufacturing
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Tune
import com.example.domain.STANDARD_BREAKER_A
import com.example.domain.STANDARD_CABLE_MM2
import com.example.domain.engOutput
import com.example.domain.nearestStandardRating
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireEvenPoles
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.sqrt

object ElecMotorCalculators {

    val all: List<CalculatorDefinition> = listOf(
        motorPowerKwHp(),       // 21
        kwToHp(),               // 22
        hpToKw(),               // 23
        motorFlc(),             // 24
        motorCableSize(),       // 25
        motorStarDelta(),       // 26
        motorStartingCurrent(), // 27
        motorEfficiency(),      // 28
        motorSlip(),            // 29
        motorTorque()           // 30
    )

    private fun motorPowerKwHp() = CalculatorDefinition(
        id = "motor_power_kw_hp",
        serialNumber = 21,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.ElectricMeter,
        title = BilingualText("Motor Power (kW / HP) Calculator", "मोटर पावर (kW / HP) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Shaft kW & HP from Voltage, Current, PF & Efficiency", "वोल्टेज, करंट, PF व एफिशिएंसी से मोटर पावर (kW / HP) निकालें"),
        formulaPreview = "P_shaft(kW) = (√3 × V × I × PF × η) / 1000   |   HP = kW / 0.7457",
        assumptions = BilingualText(
            "Uses Mechanical HP (1 HP = 0.7457 kW) and balanced supply voltage.",
            "मान्यता: मैकेनिकल HP (1 HP = 0.7457 kW) और संतुलित सप्लाई।"
        ),
        keywords = listOf("motor power", "kw", "hp", "shaft power", "मोटर पावर"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Supply Phase", "सप्लाई फेज़"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("voltage", BilingualText("Voltage (V)", "वोल्टेज (V)"), "415", "V"),
            CalculatorField("current", BilingualText("Motor Current (I)", "मोटर करंट (I)"), "27.3", "A"),
            CalculatorField("eff", BilingualText("Motor Efficiency (%)", "मोटर एफिशिएंसी (%)"), "90", "%"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val eff = requireRange(values["eff"], 10.0, 100.0, BilingualText("Efficiency", "एफिशिएंसी"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val mult = if ((units["phase"] ?: "3φ") == "3φ") sqrt(3.0) else 1.0
                val pInKw = (mult * v * i * pf) / 1000.0
                val pOutKw = pInKw * (eff / 100.0)
                val hp = pOutKw / 0.7457
                engOutput(
                    primaryLabel = BilingualText("Motor Shaft Power", "मोटर शाफ्ट पावर"),
                    primaryValue = formatEng(pOutKw, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Horsepower (HP)", "हॉर्सपावर (HP)"), formatEng(hp, 2), "HP"),
                        SecondaryMetric(BilingualText("Electrical Input", "इलेक्ट्रिकल इनपुट"), formatEng(pInKw, 2), "kW")
                    ),
                    formulaUsed = "P_out = (k × V × I × PF × η) / 1000",
                    substitutedFormula = "P_out = (${formatEng(mult, 3)} × ${formatEng(v, 0)} × ${formatEng(i, 1)} × ${formatEng(pf, 2)} × ${formatEng(eff / 100, 2)}) / 1000",
                    stepExplanation = BilingualText("Shaft Output = ${formatEng(pOutKw, 2)} kW (${formatEng(hp, 2)} HP)", "शाफ्ट पावर = ${formatEng(pOutKw, 2)} kW (${formatEng(hp, 2)} HP)")
                )
            }
        }
    )

    private fun kwToHp() = CalculatorDefinition(
        id = "motor_kw_to_hp",
        serialNumber = 22,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("kW to HP Converter", "kW से HP कन्वर्टर"),
        subtitle = BilingualText("Convert Kilowatts to Mechanical or Metric Horsepower", "किलोवाट (kW) को हॉर्सपावर (HP) में बदलें"),
        formulaPreview = "HP (Mech) = kW / 0.7457   |   HP (Metric) = kW / 0.7355",
        assumptions = BilingualText(
            "Mechanical (Imperial) HP = 745.7 W; Metric (PS/CV) HP = 735.5 W.",
            "मान्यता: मैकेनिकल HP = 745.7 W; मेट्रिक HP = 735.5 W।"
        ),
        keywords = listOf("kw to hp", "kilowatt", "horsepower", "converter"),
        fields = listOf(
            CalculatorField("kw", BilingualText("Motor Power (kW)", "मोटर पावर (kW)"), "15", "kW"),
            CalculatorField("std", BilingualText("HP Standard", "HP मानक"), "1", "Mechanical (745.7W)", listOf("Mechanical (745.7W)", "Metric (735.5W)"), isSelectorOnly = true)
        ),
        compute = { values, units ->
            runCatching {
                val kw = requirePositive(values["kw"], BilingualText("Power (kW)", "पावर (kW)"))
                val isMetric = units["std"] == "Metric (735.5W)"
                val factor = if (isMetric) 0.73549875 else 0.74569987
                val hp = kw / factor
                val otherHp = kw / (if (isMetric) 0.74569987 else 0.73549875)
                engOutput(
                    primaryLabel = BilingualText("Horsepower (HP)", "हॉर्सपावर (HP)"),
                    primaryValue = formatEng(hp, 2),
                    primaryUnit = "HP",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText(if (isMetric) "Mechanical HP" else "Metric HP", if (isMetric) "मैकेनिकल HP" else "मेट्रिक HP"), formatEng(otherHp, 2), "HP"),
                        SecondaryMetric(BilingualText("Power (Watts)", "पावर (वाट)"), formatEng(kw * 1000.0, 0), "W")
                    ),
                    formulaUsed = "HP = kW / ${formatEng(factor, 4)}",
                    substitutedFormula = "HP = ${formatEng(kw, 2)} / ${formatEng(factor, 4)}",
                    stepExplanation = BilingualText("${formatEng(kw, 2)} kW = ${formatEng(hp, 2)} HP", "${formatEng(kw, 2)} kW = ${formatEng(hp, 2)} HP")
                )
            }
        }
    )

    private fun hpToKw() = CalculatorDefinition(
        id = "motor_hp_to_kw",
        serialNumber = 23,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.CompareArrows,
        title = BilingualText("HP to kW Converter", "HP से kW कन्वर्टर"),
        subtitle = BilingualText("Convert Motor HP to Kilowatts (kW) & Watts", "हॉर्सपावर (HP) को किलोवाट (kW) में बदलें"),
        formulaPreview = "kW = HP × 0.7457 (Mech)   |   kW = HP × 0.7355 (Metric)",
        assumptions = BilingualText(
            "Mechanical (Imperial) HP = 0.7457 kW; Metric HP = 0.7355 kW.",
            "मान्यता: मैकेनिकल HP = 0.7457 kW; मेट्रिक HP = 0.7355 kW।"
        ),
        keywords = listOf("hp to kw", "horsepower", "kilowatt", "motor"),
        fields = listOf(
            CalculatorField("hp", BilingualText("Motor Power (HP)", "मोटर पावर (HP)"), "20", "HP"),
            CalculatorField("std", BilingualText("HP Standard", "HP मानक"), "1", "Mechanical (745.7W)", listOf("Mechanical (745.7W)", "Metric (735.5W)"), isSelectorOnly = true)
        ),
        compute = { values, units ->
            runCatching {
                val hp = requirePositive(values["hp"], BilingualText("Power (HP)", "पावर (HP)"))
                val isMetric = units["std"] == "Metric (735.5W)"
                val factor = if (isMetric) 0.73549875 else 0.74569987
                val kw = hp * factor
                val estFlc415 = (kw * 1000.0) / (sqrt(3.0) * 415.0 * 0.90 * 0.85)
                engOutput(
                    primaryLabel = BilingualText("Power (kW)", "पावर (kW)"),
                    primaryValue = formatEng(kw, 3),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Power (Watts)", "पावर (वाट)"), formatEng(kw * 1000.0, 0), "W"),
                        SecondaryMetric(BilingualText("Est. 415V 3φ FLC", "अनुमानित 415V FLC"), formatEng(estFlc415, 1), "A")
                    ),
                    formulaUsed = "kW = HP × ${formatEng(factor, 4)}",
                    substitutedFormula = "kW = ${formatEng(hp, 2)} × ${formatEng(factor, 4)}",
                    stepExplanation = BilingualText("${formatEng(hp, 2)} HP = ${formatEng(kw, 3)} kW", "${formatEng(hp, 2)} HP = ${formatEng(kw, 3)} kW")
                )
            }
        }
    )

    private fun motorFlc() = CalculatorDefinition(
        id = "motor_flc",
        serialNumber = 24,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Motor Full Load Current (FLC) Calculator", "मोटर फुल लोड करंट (FLC) कैलकुलेटर"),
        subtitle = BilingualText("Calculate 3φ / 1φ Motor Rated Current, Input kW & Breaker", "मोटर kW/HP से फुल लोड करंट (FLC) और इनपुट पावर निकालें"),
        formulaPreview = "FLC = (P_out × 1000) / (√3 × V × η × cos φ)",
        assumptions = BilingualText(
            "Assumes rated line voltage, IE2/IE3 nominal motor efficiency & lagging PF.",
            "मान्यता: रेटेड वोल्टेज, नाममात्र मोटर एफिशिएंसी और पावर फैक्टर।"
        ),
        keywords = listOf("motor flc", "full load current", "motor ampere", "मोटर करंट"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Phase System", "फेज़ सिस्टम"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("power", BilingualText("Rated Shaft Power", "मोटर पावर"), "15", "kW", listOf("kW", "HP")),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V"),
            CalculatorField("efficiency", BilingualText("Efficiency (%)", "एफिशिएंसी (%)"), "90", "%"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Motor Power", "मोटर पावर"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val eff = requireRange(values["efficiency"], 10.0, 100.0, BilingualText("Efficiency", "एफिशिएंसी"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val pKw = if (units["power"] == "HP") rawP * 0.7457 else rawP
                val pInW = (pKw * 1000.0) / (eff / 100.0)
                val mult = if ((units["phase"] ?: "3φ") == "3φ") sqrt(3.0) else 1.0
                val flc = pInW / (mult * v * pf)
                val breaker = nearestStandardRating(flc * 1.25, STANDARD_BREAKER_A)
                engOutput(
                    primaryLabel = BilingualText("Motor Full Load Current", "मोटर फुल लोड करंट (FLC)"),
                    primaryValue = formatEng(flc, 2),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Input Power", "इनपुट पावर"), formatEng(pInW / 1000.0, 2), "kW"),
                        SecondaryMetric(BilingualText("DOL Surge (~6×)", "DOL स्टार्टिंग (~6×)"), formatEng(flc * 6.0, 1), "A"),
                        SecondaryMetric(BilingualText("MCCB / MPCB", "सुझावित ब्रेकर"), formatEng(breaker, 0), "A")
                    ),
                    formulaUsed = "FLC = (P_kW × 1000) / (k × V × η × cos φ)",
                    substitutedFormula = "FLC = ${formatEng(pInW, 0)} / (${formatEng(mult, 3)} × ${formatEng(v, 0)} × ${formatEng(pf, 2)})",
                    stepExplanation = BilingualText("Motor FLC = ${formatEng(flc, 2)} A", "मोटर FLC = ${formatEng(flc, 2)} A")
                )
            }
        }
    )

    private fun motorCableSize() = CalculatorDefinition(
        id = "motor_cable_size",
        serialNumber = 25,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.Cable,
        title = BilingualText("Motor Cable Size Calculator", "मोटर केबल साइज कैलकुलेटर"),
        subtitle = BilingualText("Select Standard Cable mm² by Motor Power & Voltage Drop", "मोटर पावर, दूरी और वोल्टेज ड्रॉप से सही केबल mm² चुनें"),
        formulaPreview = "A_min = (√3 × I × L × ρ × 100) / (%ΔV × V)",
        assumptions = BilingualText(
            "3-phase motor (η=90%, PF=0.85), Cu ρ=0.0178 Ω·mm²/m, Al ρ=0.029 Ω·mm²/m, max 3% drop.",
            "मान्यता: 3-फेज़ मोटर (η=90%, PF=0.85), Cu ρ=0.0178, Al ρ=0.029 Ω·mm²/m।"
        ),
        keywords = listOf("motor cable", "cable size", "mm2", "voltage drop", "मोटर केबल"),
        fields = listOf(
            CalculatorField("power", BilingualText("Motor Power", "मोटर पावर"), "22", "kW", listOf("kW", "HP")),
            CalculatorField("voltage", BilingualText("Line Voltage (V)", "लाइन वोल्टेज (V)"), "415", "V"),
            CalculatorField("length", BilingualText("One-Way Cable Length", "केबल लंबाई (मीटर)"), "80", "m"),
            CalculatorField("drop_pct", BilingualText("Max Voltage Drop (%)", "अधिकतम वोल्टेज ड्रॉप (%)"), "3.0", "%"),
            CalculatorField("material", BilingualText("Conductor", "कंडक्टर धातु"), "1", "Copper", listOf("Copper", "Aluminum"), isSelectorOnly = true)
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Motor Power", "मोटर पावर"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val len = requirePositive(values["length"], BilingualText("Length", "लंबाई"))
                val maxDropPct = requireRange(values["drop_pct"], 0.5, 10.0, BilingualText("Max Drop %", "अधिकतम ड्रॉप %"))
                val pKw = if (units["power"] == "HP") rawP * 0.7457 else rawP
                val flc = (pKw * 1000.0) / (sqrt(3.0) * v * 0.90 * 0.85)
                val isAl = units["material"] == "Aluminum"
                val rho = if (isAl) 0.029 else 0.0178
                val maxDropV = v * (maxDropPct / 100.0)
                val minArea = (sqrt(3.0) * flc * len * rho) / maxDropV
                val stdCable = nearestStandardRating(minArea, STANDARD_CABLE_MM2)
                val actualDropV = (sqrt(3.0) * flc * len * rho) / stdCable
                val actualDropPct = (actualDropV / v) * 100.0
                engOutput(
                    primaryLabel = BilingualText("Recommended Motor Cable", "सुझावित मोटर केबल"),
                    primaryValue = "${formatEng(stdCable, 1)} mm²",
                    primaryUnit = if (isAl) "Al" else "Cu",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Est. Motor FLC", "अनुमानित FLC"), formatEng(flc, 1), "A"),
                        SecondaryMetric(BilingualText("Calculated Min Area", "न्यूनतम आवश्यक साइज"), formatEng(minArea, 2), "mm²"),
                        SecondaryMetric(BilingualText("Actual Drop", "वास्तविक वोल्टेज ड्रॉप"), "${formatEng(actualDropV, 2)} V (${formatEng(actualDropPct, 2)}%)", "")
                    ),
                    formulaUsed = "A_min = (√3 × FLC × L × ρ) / ΔV_max",
                    substitutedFormula = "A_min = (1.732 × ${formatEng(flc, 1)} × ${formatEng(len, 1)} × $rho) / ${formatEng(maxDropV, 2)}",
                    stepExplanation = BilingualText("Select ${formatEng(stdCable, 1)} mm² (${formatEng(actualDropPct, 2)}% drop)", "${formatEng(stdCable, 1)} mm² केबल चुनें")
                )
            }
        }
    )

    private fun motorStarDelta() = CalculatorDefinition(
        id = "motor_star_delta_current",
        serialNumber = 26,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.PrecisionManufacturing,
        title = BilingualText("Motor Star/Delta Current Calculator", "मोटर स्टार/डेल्टा करंट कैलकुलेटर"),
        subtitle = BilingualText("Size Contactors, OLR & Compare Star vs Delta Starting Amps", "स्टार-डेल्टा कॉन्टैक्टर, OLR सेटिंग और स्टार्टिंग करंट निकालें"),
        formulaPreview = "I_phase = FLC / √3   |   I_start(Star) = (k_LRC × FLC) / 3",
        assumptions = BilingualText(
            "Assumes 6-terminal 3-phase squirrel cage motor; Star start reduces line current and torque to 1/3.",
            "मान्यता: 6-टर्मिनल 3-फेज़ मोटर; स्टार स्टार्ट में करंट और टॉर्क 1/3 रह जाते हैं।"
        ),
        keywords = listOf("star delta", "starter", "contactor", "olr", "स्टार डेल्टा"),
        fields = listOf(
            CalculatorField("flc", BilingualText("Motor FLC (A)", "मोटर FLC (A)"), "45", "A"),
            CalculatorField("lrc_mult", BilingualText("DOL LRC Multiplier", "DOL स्टार्टिंग गुणक"), "6.0", "× FLC"),
            CalculatorField("sf", BilingualText("Contactor Safety Factor", "कॉन्टैक्टर सेफ्टी फैक्टर"), "1.15", "×")
        ),
        compute = { values, _ ->
            runCatching {
                val flc = requirePositive(values["flc"], BilingualText("Motor FLC", "मोटर FLC"))
                val lrcMult = requireRange(values["lrc_mult"], 3.0, 10.0, BilingualText("LRC Multiplier", "स्टार्टिंग गुणक"))
                val sf = requireRange(values["sf"], 1.0, 2.0, BilingualText("Safety Factor", "सेफ्टी फैक्टर"))
                val iPhase = flc / sqrt(3.0)
                val dolStart = flc * lrcMult
                val starStart = dolStart / 3.0
                val mainDeltaContactor = nearestStandardRating(iPhase * sf, STANDARD_BREAKER_A)
                val starContactor = nearestStandardRating((flc / 3.0) * sf, STANDARD_BREAKER_A)
                engOutput(
                    primaryLabel = BilingualText("Star-Delta Line Starting Current", "स्टार-डेल्टा स्टार्टिंग करंट"),
                    primaryValue = formatEng(starStart, 1),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("OLR Setting (58% FLC)", "OLR रिले सेटिंग"), formatEng(iPhase, 2), "A"),
                        SecondaryMetric(BilingualText("Main/Delta Contactor", "मेन/डेल्टा कॉन्टैक्टर"), formatEng(mainDeltaContactor, 0), "A"),
                        SecondaryMetric(BilingualText("Star Contactor", "स्टार कॉन्टैक्टर"), formatEng(starContactor, 0), "A")
                    ),
                    formulaUsed = "I_start(Y) = I_start(Δ) / 3   |   I_Main/OLR = FLC / √3",
                    substitutedFormula = "I_start(Y) = (${formatEng(lrcMult, 1)} × ${formatEng(flc, 1)}) / 3",
                    stepExplanation = BilingualText("Star start = ${formatEng(starStart, 1)} A (vs DOL ${formatEng(dolStart, 1)} A), OLR = ${formatEng(iPhase, 2)} A", "स्टार स्टार्ट करंट = ${formatEng(starStart, 1)} A")
                )
            }
        }
    )

    private fun motorStartingCurrent() = CalculatorDefinition(
        id = "motor_starting_current",
        serialNumber = 27,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.FlashOn,
        title = BilingualText("Motor Starting Current Calculator", "मोटर स्टार्टिंग करंट कैलकुलेटर"),
        subtitle = BilingualText("Compare Inrush Surge across DOL, Star-Delta, Soft Starter & VFD", "DOL, स्टार-डेल्टा, सॉफ्ट स्टार्टर व VFD में स्टार्टिंग करंट निकालें"),
        formulaPreview = "I_start = FLC × LRC_ratio × Starter_Factor",
        assumptions = BilingualText(
            "Typical locked-rotor current (LRC) is 6–7× FLC; Soft Starter ≈ 3.5× FLC; VFD ≈ 1.5× FLC.",
            "मान्यता: सामान्य LRC = 6–7× FLC; सॉफ्ट स्टार्टर ~3.5×; VFD ~1.5× FLC।"
        ),
        keywords = listOf("starting current", "inrush", "lrc", "dol", "soft starter", "vfd"),
        fields = listOf(
            CalculatorField("flc", BilingualText("Motor Rated FLC (A)", "मोटर रेटेड FLC (A)"), "50", "A"),
            CalculatorField("lrc", BilingualText("Motor LRC Ratio (× FLC)", "मोटर LRC अनुपात"), "6.5", "×"),
            CalculatorField("voltage", BilingualText("Line Voltage (V)", "लाइन वोल्टेज (V)"), "415", "V"),
            CalculatorField("starter", BilingualText("Starter Method", "स्टार्टर प्रकार"), "1", "DOL (100%)", listOf("DOL (100%)", "Star-Delta (33%)", "Soft Starter (350% FLC)", "VFD (150% FLC)"), isSelectorOnly = true)
        ),
        compute = { values, units ->
            runCatching {
                val flc = requirePositive(values["flc"], BilingualText("Motor FLC", "मोटर FLC"))
                val lrc = requireRange(values["lrc"], 3.0, 12.0, BilingualText("LRC Ratio", "LRC अनुपात"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val starter = units["starter"] ?: "DOL (100%)"
                val iStart = when (starter) {
                    "Star-Delta (33%)" -> (flc * lrc) / 3.0
                    "Soft Starter (350% FLC)" -> flc * 3.5
                    "VFD (150% FLC)" -> flc * 1.5
                    else -> flc * lrc
                }
                val startKva = (sqrt(3.0) * v * iStart) / 1000.0
                engOutput(
                    primaryLabel = BilingualText("Starting Line Current", "स्टार्टिंग लाइन करंट"),
                    primaryValue = formatEng(iStart, 1),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Ratio to FLC", "FLC का गुना"), formatEng(iStart / flc, 2), "× FLC"),
                        SecondaryMetric(BilingualText("Starting Demand", "स्टार्टिंग लोड"), formatEng(startKva, 1), "kVA")
                    ),
                    formulaUsed = "I_start = FLC × Method_Multiplier",
                    substitutedFormula = "$starter → ${formatEng(iStart, 1)} A",
                    stepExplanation = BilingualText("Starting surge = ${formatEng(iStart, 1)} A (${formatEng(startKva, 1)} kVA)", "स्टार्टिंग करंट = ${formatEng(iStart, 1)} A")
                )
            }
        }
    )

    private fun motorEfficiency() = CalculatorDefinition(
        id = "motor_efficiency",
        serialNumber = 28,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.TrendingUp,
        title = BilingualText("Motor Efficiency Calculator", "मोटर एफिशिएंसी कैलकुलेटर"),
        subtitle = BilingualText("Compute Actual Motor Efficiency % & Total Losses", "मोटर आउटपुट व इलेक्ट्रिकल इनपुट से एफिशिएंसी (%) निकालें"),
        formulaPreview = "η (%) = (P_shaft / P_elec_in) × 100",
        assumptions = BilingualText(
            "Validates P_shaft ≤ P_elec_in; shaft output cannot exceed electrical input power.",
            "मान्यता: शाफ्ट आउटपुट पावर, इलेक्ट्रिकल इनपुट से अधिक नहीं हो सकती।"
        ),
        keywords = listOf("motor efficiency", "losses", "shaft output", "मोटर एफिशिएंसी"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Supply Phase", "सप्लाई फेज़"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("p_out", BilingualText("Shaft Output Power", "शाफ्ट आउटपुट पावर"), "15", "kW", listOf("kW", "HP")),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V"),
            CalculatorField("current", BilingualText("Measured Current (A)", "मापा गया करंट (A)"), "27.3", "A"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawOut = requirePositive(values["p_out"], BilingualText("Shaft Output", "शाफ्ट आउटपुट"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val pOutKw = if (units["p_out"] == "HP") rawOut * 0.7457 else rawOut
                val mult = if ((units["phase"] ?: "3φ") == "3φ") sqrt(3.0) else 1.0
                val pInKw = (mult * v * i * pf) / 1000.0
                if (pOutKw > pInKw) {
                    throw BilingualValidationException(
                        BilingualText("Shaft output (${formatEng(pOutKw, 2)} kW) cannot exceed input power (${formatEng(pInKw, 2)} kW).", "शाफ्ट आउटपुट (${formatEng(pOutKw, 2)} kW), इनपुट पावर (${formatEng(pInKw, 2)} kW) से अधिक नहीं हो सकता।")
                    )
                }
                val eff = (pOutKw / pInKw) * 100.0
                val lossKw = pInKw - pOutKw
                engOutput(
                    primaryLabel = BilingualText("Motor Efficiency (η)", "मोटर एफिशिएंसी (η)"),
                    primaryValue = formatEng(eff, 2),
                    primaryUnit = "%",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Input Power", "इनपुट पावर"), formatEng(pInKw, 2), "kW"),
                        SecondaryMetric(BilingualText("Total Losses", "कुल लॉस"), formatEng(lossKw, 2), "kW")
                    ),
                    formulaUsed = "η = (P_out / P_in) × 100",
                    substitutedFormula = "η = (${formatEng(pOutKw, 2)} / ${formatEng(pInKw, 2)}) × 100",
                    stepExplanation = BilingualText("Efficiency = ${formatEng(eff, 2)}%, Losses = ${formatEng(lossKw, 2)} kW", "एफिशिएंसी = ${formatEng(eff, 2)}%"),
                    statusLevel = if (eff < 75.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun motorSlip() = CalculatorDefinition(
        id = "motor_slip",
        serialNumber = 29,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.Speed,
        title = BilingualText("Motor Slip Calculator", "मोटर स्लिप कैलकुलेटर"),
        subtitle = BilingualText("Calculate Synchronous Speed, Slip % & Rotor Frequency", "सिंक्रोनस स्पीड, स्लिप % और रोटर फ्रीक्वेंसी निकालें"),
        formulaPreview = "N_s = (120 × f) / P   |   Slip % = ((N_s − N_r) / N_s) × 100",
        assumptions = BilingualText(
            "Valid for induction motors where actual rotor RPM N_r ≤ synchronous speed N_s.",
            "मान्यता: इंडक्शन मोटर के लिए रोटर स्पीड N_r ≤ सिंक्रोनस स्पीड N_s।"
        ),
        keywords = listOf("motor slip", "synchronous speed", "rpm", "poles", "स्लिप"),
        fields = listOf(
            CalculatorField("freq", BilingualText("Supply Frequency (Hz)", "सप्लाई फ्रीक्वेंसी (Hz)"), "50", "Hz"),
            CalculatorField("poles", BilingualText("Motor Poles (2/4/6/8)", "मोटर पोल (2/4/6/8)"), "4", "Poles"),
            CalculatorField("rotor_rpm", BilingualText("Actual Rotor Speed (RPM)", "वास्तविक रोटर स्पीड (RPM)"), "1440", "RPM")
        ),
        compute = { values, _ ->
            runCatching {
                val f = requireRange(values["freq"], 1.0, 400.0, BilingualText("Frequency", "फ्रीक्वेंसी"))
                val poles = requireEvenPoles(values["poles"], BilingualText("Poles", "पोल"))
                val nr = requireRange(values["rotor_rpm"], 0.0, 25000.0, BilingualText("Rotor RPM", "रोटर RPM"))
                val ns = (120.0 * f) / poles
                if (nr > ns) {
                    throw BilingualValidationException(
                        BilingualText("Rotor speed (${formatEng(nr, 0)} RPM) cannot exceed synchronous speed (${formatEng(ns, 0)} RPM) in motoring mode.", "मोटरिंग मोड में रोटर स्पीड सिंक्रोनस स्पीड (${formatEng(ns, 0)} RPM) से अधिक नहीं हो सकती।")
                    )
                }
                val slipPct = ((ns - nr) / ns) * 100.0
                val slipRpm = ns - nr
                val rotorFreq = (slipPct / 100.0) * f
                engOutput(
                    primaryLabel = BilingualText("Motor Slip (%)", "मोटर स्लिप (%)"),
                    primaryValue = formatEng(slipPct, 2),
                    primaryUnit = "%",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Synchronous Speed", "सिंक्रोनस स्पीड"), formatEng(ns, 0), "RPM"),
                        SecondaryMetric(BilingualText("Slip RPM", "स्लिप RPM"), formatEng(slipRpm, 0), "RPM"),
                        SecondaryMetric(BilingualText("Rotor Frequency", "रोटर फ्रीक्वेंसी"), formatEng(rotorFreq, 2), "Hz")
                    ),
                    formulaUsed = "N_s = 120f/P   |   Slip% = ((N_s − N_r) / N_s) × 100",
                    substitutedFormula = "Slip% = ((${formatEng(ns, 0)} − ${formatEng(nr, 0)}) / ${formatEng(ns, 0)}) × 100",
                    stepExplanation = BilingualText("N_s = ${formatEng(ns, 0)} RPM, Slip = ${formatEng(slipPct, 2)}%", "सिंक्रोनस स्पीड = ${formatEng(ns, 0)} RPM, स्लिप = ${formatEng(slipPct, 2)}%")
                )
            }
        }
    )

    private fun motorTorque() = CalculatorDefinition(
        id = "motor_torque",
        serialNumber = 30,
        category = CalculatorCategory.ELEC_MOTOR,
        icon = Icons.Rounded.Tune,
        title = BilingualText("Motor Torque Calculator", "मोटर टॉर्क कैलकुलेटर"),
        subtitle = BilingualText("Calculate Rated Shaft Torque in N·m, kg·m & lb·ft", "मोटर पावर और RPM से शाफ्ट टॉर्क (N·m, kg·m) निकालें"),
        formulaPreview = "T (N·m) = (9549.3 × P_kW) / RPM",
        assumptions = BilingualText(
            "Constant 9549.3 = (60 × 1000) / (2π); gives full-load rated shaft torque.",
            "मान्यता: स्थिरांक 9549.3 = (60 × 1000) / (2π) से फुल-लोड शाफ्ट टॉर्क।"
        ),
        keywords = listOf("motor torque", "nm", "kgm", "lbft", "shaft", "टॉर्क"),
        fields = listOf(
            CalculatorField("power", BilingualText("Motor Power", "मोटर पावर"), "15", "kW", listOf("kW", "HP")),
            CalculatorField("rpm", BilingualText("Shaft Speed (RPM)", "शाफ्ट स्पीड (RPM)"), "1460", "RPM")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Motor Power", "मोटर पावर"))
                val rpm = requirePositive(values["rpm"], BilingualText("Speed (RPM)", "स्पीड (RPM)"))
                val pKw = if (units["power"] == "HP") rawP * 0.7457 else rawP
                val tNm = (9549.2966 * pKw) / rpm
                val tKgm = tNm / 9.80665
                val tLbFt = tNm * 0.737562
                engOutput(
                    primaryLabel = BilingualText("Shaft Torque (T)", "शाफ्ट टॉर्क (T)"),
                    primaryValue = formatEng(tNm, 2),
                    primaryUnit = "N·m",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Metric Torque", "मेट्रिक टॉर्क"), formatEng(tKgm, 2), "kg·m"),
                        SecondaryMetric(BilingualText("Imperial Torque", "इंपीरियल टॉर्क"), formatEng(tLbFt, 2), "lb·ft")
                    ),
                    formulaUsed = "T = (9549.3 × P_kW) / RPM",
                    substitutedFormula = "T = (9549.3 × ${formatEng(pKw, 2)}) / ${formatEng(rpm, 0)}",
                    stepExplanation = BilingualText("Torque = ${formatEng(tNm, 2)} N·m (${formatEng(tKgm, 2)} kg·m)", "टॉर्क = ${formatEng(tNm, 2)} N·m")
                )
            }
        }
    )
}
