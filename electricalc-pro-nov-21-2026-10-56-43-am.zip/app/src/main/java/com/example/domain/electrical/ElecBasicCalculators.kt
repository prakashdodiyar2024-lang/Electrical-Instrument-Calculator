package com.example.domain.electrical

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.ElectricalServices
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.Loop
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Waves
import com.example.domain.engOutput
import com.example.domain.nearestStandardRating
import com.example.domain.STANDARD_BREAKER_A
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.CalculatorPreset
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireEvenPoles
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.sqrt

object ElecBasicCalculators {

    val all: List<CalculatorDefinition> = listOf(
        ohmsLaw(),          // 1
        powerPvi(),         // 2
        currentCalc(),      // 3
        voltageCalc(),      // 4
        resistanceCalc(),   // 5
        reactanceCalc(),    // 6
        impedanceCalc(),    // 7
        powerFactorCalc(),  // 8
        energyKwhCalc(),    // 9
        frequencyCalc()     // 10
    )

    private fun ohmsLaw() = CalculatorDefinition(
        id = "elec_ohms_law",
        serialNumber = 1,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Ohm's Law Calculator", "ओम का नियम कैलकुलेटर"),
        subtitle = BilingualText("Solve V, I or R using V = I × R & Power", "V = I × R से वोल्टेज, करंट या रेजिस्टेंस निकालें"),
        formulaPreview = "V = I × R   |   I = V / R   |   R = V / I   |   P = V × I",
        assumptions = BilingualText(
            "Assumes linear ohmic load under steady-state DC or purely resistive AC.",
            "मान्यता: स्थिर DC या शुद्ध रेजिस्टिव AC लोड।"
        ),
        keywords = listOf("ohm", "voltage", "current", "resistance", "dc", "ओम का नियम"),
        fields = listOf(
            CalculatorField(
                id = "solve_for",
                label = BilingualText("Solve For", "क्या निकालना है"),
                defaultValue = "1",
                defaultUnit = "Current I = V/R",
                unitOptions = listOf("Current I = V/R", "Voltage V = I×R", "Resistance R = V/I"),
                isSelectorOnly = true
            ),
            CalculatorField("val_a", BilingualText("First Value (V for I/R, or I for V)", "पहला मान (V या I)"), "230", "unit"),
            CalculatorField("val_b", BilingualText("Second Value (R for I/V, or I for R)", "दूसरा मान (R या I)"), "46", "unit")
        ),
        presets = listOf(
            CalculatorPreset(
                label = BilingualText("230V / 46Ω → 5A", "230V / 46Ω → 5A"),
                values = mapOf("val_a" to "230", "val_b" to "46"),
                units = mapOf("solve_for" to "Current I = V/R")
            )
        ),
        compute = { values, units ->
            runCatching {
                val a = requirePositive(values["val_a"], BilingualText("First Value", "पहला मान"))
                val b = requirePositive(values["val_b"], BilingualText("Second Value", "दूसरा मान"))
                when (units["solve_for"]) {
                    "Voltage V = I×R" -> {
                        val v = a * b
                        val p = v * a
                        engOutput(
                            primaryLabel = BilingualText("Voltage (V)", "वोल्टेज (V)"),
                            primaryValue = formatEng(v, 3),
                            primaryUnit = "V",
                            secondaryMetrics = listOf(
                                SecondaryMetric(BilingualText("Power (P)", "पावर (P)"), formatEng(p, 2), "W"),
                                SecondaryMetric(BilingualText("Current (I)", "करंट (I)"), formatEng(a, 3), "A"),
                                SecondaryMetric(BilingualText("Resistance (R)", "रेजिस्टेंस (R)"), formatEng(b, 3), "Ω")
                            ),
                            formulaUsed = "V = I × R   |   P = V × I",
                            substitutedFormula = "V = ${formatEng(a, 3)} × ${formatEng(b, 3)}",
                            stepExplanation = BilingualText("Voltage = ${formatEng(v, 3)} V, Power = ${formatEng(p, 2)} W", "वोल्टेज = ${formatEng(v, 3)} V, पावर = ${formatEng(p, 2)} W")
                        )
                    }
                    "Resistance R = V/I" -> {
                        val r = a / b
                        val p = a * b
                        val g = 1.0 / r
                        engOutput(
                            primaryLabel = BilingualText("Resistance (R)", "रेजिस्टेंस (R)"),
                            primaryValue = formatEng(r, 3),
                            primaryUnit = "Ω",
                            secondaryMetrics = listOf(
                                SecondaryMetric(BilingualText("Power (P)", "पावर (P)"), formatEng(p, 2), "W"),
                                SecondaryMetric(BilingualText("Conductance (G)", "कंडक्टेंस (G)"), formatEng(g, 4), "S")
                            ),
                            formulaUsed = "R = V / I   |   P = V × I",
                            substitutedFormula = "R = ${formatEng(a, 3)} / ${formatEng(b, 3)}",
                            stepExplanation = BilingualText("Resistance = ${formatEng(r, 3)} Ω, Power = ${formatEng(p, 2)} W", "रेजिस्टेंस = ${formatEng(r, 3)} Ω, पावर = ${formatEng(p, 2)} W")
                        )
                    }
                    else -> {
                        val i = a / b
                        val p = a * i
                        engOutput(
                            primaryLabel = BilingualText("Current (I)", "करंट (I)"),
                            primaryValue = formatEng(i, 3),
                            primaryUnit = "A",
                            secondaryMetrics = listOf(
                                SecondaryMetric(BilingualText("Power (P)", "पावर (P)"), formatEng(p, 2), "W"),
                                SecondaryMetric(BilingualText("Power (kW)", "पावर (kW)"), formatEng(p / 1000.0, 3), "kW")
                            ),
                            formulaUsed = "I = V / R   |   P = V × I",
                            substitutedFormula = "I = ${formatEng(a, 3)} / ${formatEng(b, 3)}",
                            stepExplanation = BilingualText("Current = ${formatEng(i, 3)} A, Power = ${formatEng(p, 2)} W", "करंट = ${formatEng(i, 3)} A, पावर = ${formatEng(p, 2)} W")
                        )
                    }
                }
            }
        }
    )

    private fun powerPvi() = CalculatorDefinition(
        id = "elec_power_pvi",
        serialNumber = 2,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.FlashOn,
        title = BilingualText("Power (P=VI) Calculator", "पावर (P=VI) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Active Power (W/kW), Apparent VA & VAR", "DC, 1-फेज़ या 3-फेज़ पावर (W/kW) और VA निकालें"),
        formulaPreview = "P_DC = V × I  |  P_1φ = V × I × cos φ  |  P_3φ = √3 × V × I × cos φ",
        assumptions = BilingualText(
            "Assumes balanced sinusoidal AC RMS values (set cos φ = 1.0 for DC).",
            "मान्यता: संतुलित AC RMS मान (DC के लिए cos φ = 1.0 चुनें)।"
        ),
        keywords = listOf("power", "p=vi", "watt", "kw", "kva", "पावर"),
        fields = listOf(
            CalculatorField("system", BilingualText("System Type", "सिस्टम प्रकार"), "1", "1φ AC", listOf("DC", "1φ AC", "3φ AC"), isSelectorOnly = true),
            CalculatorField("voltage", BilingualText("Voltage (V)", "वोल्टेज (V)"), "230", "V", listOf("V", "kV")),
            CalculatorField("current", BilingualText("Current (I)", "करंट (I)"), "12", "A", listOf("A", "mA")),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.9", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val rawI = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pfInput = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val v = if (units["voltage"] == "kV") rawV * 1000.0 else rawV
                val i = if (units["current"] == "mA") rawI / 1000.0 else rawI
                val sys = units["system"] ?: "1φ AC"
                val pf = if (sys == "DC") 1.0 else pfInput
                val mult = if (sys == "3φ AC") sqrt(3.0) else 1.0
                val va = mult * v * i
                val w = va * pf
                val q = sqrt((va * va - w * w).coerceAtLeast(0.0))
                val useKw = w >= 1000.0
                engOutput(
                    primaryLabel = BilingualText("Active Power (P)", "एक्टिव पावर (P)"),
                    primaryValue = if (useKw) formatEng(w / 1000.0, 3) else formatEng(w, 2),
                    primaryUnit = if (useKw) "kW" else "W",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Apparent Power", "अपैरेंट पावर"), if (va >= 1000.0) formatEng(va / 1000.0, 3) else formatEng(va, 2), if (va >= 1000.0) "kVA" else "VA"),
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), if (q >= 1000.0) formatEng(q / 1000.0, 3) else formatEng(q, 2), if (q >= 1000.0) "kVAr" else "VAR")
                    ),
                    formulaUsed = if (sys == "3φ AC") "P = √3 × V × I × cos φ" else "P = V × I × cos φ",
                    substitutedFormula = "${formatEng(mult, 3)} × ${formatEng(v, 2)} × ${formatEng(i, 3)} × ${formatEng(pf, 2)}",
                    stepExplanation = BilingualText("Active Power = ${formatEng(w, 2)} W (${formatEng(w / 1000.0, 3)} kW)", "एक्टिव पावर = ${formatEng(w, 2)} W")
                )
            }
        }
    )

    private fun currentCalc() = CalculatorDefinition(
        id = "elec_current_calc",
        serialNumber = 3,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.ElectricBolt,
        title = BilingualText("Current (I) Calculator", "करंट (I) कैलकुलेटर"),
        subtitle = BilingualText("Find Load Current from Power, Voltage & Power Factor", "पावर, वोल्टेज और PF से लोड करंट (A) निकालें"),
        formulaPreview = "I_1φ = P / (V × cos φ)   |   I_3φ = P / (√3 × V × cos φ)",
        assumptions = BilingualText(
            "Assumes rated supply voltage and balanced phase current.",
            "मान्यता: रेटेड सप्लाई वोल्टेज और संतुलित लोड करंट।"
        ),
        keywords = listOf("current", "ampere", "flc", "load current", "करंट"),
        fields = listOf(
            CalculatorField("system", BilingualText("Supply Type", "सप्लाई प्रकार"), "1", "3φ AC", listOf("DC", "1φ AC", "3φ AC"), isSelectorOnly = true),
            CalculatorField("power", BilingualText("Load Power (P)", "लोड पावर (P)"), "10", "kW", listOf("kW", "W")),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V", listOf("V", "kV")),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Power", "पावर"))
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val pfIn = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val pW = if (units["power"] == "kW") rawP * 1000.0 else rawP
                val v = if (units["voltage"] == "kV") rawV * 1000.0 else rawV
                val sys = units["system"] ?: "3φ AC"
                val pf = if (sys == "DC") 1.0 else pfIn
                val mult = if (sys == "3φ AC") sqrt(3.0) else 1.0
                val i = pW / (mult * v * pf)
                val recBreaker = nearestStandardRating(i * 1.25, STANDARD_BREAKER_A)
                engOutput(
                    primaryLabel = BilingualText("Load Current (I)", "लोड करंट (I)"),
                    primaryValue = formatEng(i, 2),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Apparent kVA", "अपैरेंट kVA"), formatEng((pW / pf) / 1000.0, 2), "kVA"),
                        SecondaryMetric(BilingualText("Suggested Breaker (1.25×)", "सुझावित MCB/MCCB"), formatEng(recBreaker, 0), "A")
                    ),
                    formulaUsed = "I = P_W / (k × V × cos φ)",
                    substitutedFormula = "I = ${formatEng(pW, 0)} / (${formatEng(mult, 3)} × ${formatEng(v, 1)} × ${formatEng(pf, 2)})",
                    stepExplanation = BilingualText("Calculated Current = ${formatEng(i, 2)} A", "गणना करंट = ${formatEng(i, 2)} A")
                )
            }
        }
    )

    private fun voltageCalc() = CalculatorDefinition(
        id = "elec_voltage_calc",
        serialNumber = 4,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.ElectricalServices,
        title = BilingualText("Voltage (V) Calculator", "वोल्टेज (V) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Voltage from Power & Current or Current & Resistance", "पावर व करंट या I × R से वोल्टेज निकालें"),
        formulaPreview = "V = P / (I × cos φ)   |   V_3φ = P / (√3 × I × cos φ)",
        assumptions = BilingualText(
            "Assumes steady-state RMS voltage across the load terminals.",
            "मान्यता: लोड टर्मिनल पर स्थिर RMS वोल्टेज।"
        ),
        keywords = listOf("voltage", "volts", "potential", "वोल्टेज"),
        fields = listOf(
            CalculatorField("system", BilingualText("System Type", "सिस्टम प्रकार"), "1", "1φ AC", listOf("DC", "1φ AC", "3φ AC"), isSelectorOnly = true),
            CalculatorField("power", BilingualText("Active Power (P)", "एक्टिव पावर (P)"), "2.3", "kW", listOf("kW", "W")),
            CalculatorField("current", BilingualText("Load Current (I)", "लोड करंट (I)"), "10", "A"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "1.0", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Power", "पावर"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pfIn = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val pW = if (units["power"] == "kW") rawP * 1000.0 else rawP
                val sys = units["system"] ?: "1φ AC"
                val pf = if (sys == "DC") 1.0 else pfIn
                val mult = if (sys == "3φ AC") sqrt(3.0) else 1.0
                val v = pW / (mult * i * pf)
                val vPhase = if (sys == "3φ AC") v / sqrt(3.0) else v
                engOutput(
                    primaryLabel = BilingualText(if (sys == "3φ AC") "Line Voltage (V_L)" else "Voltage (V)", "वोल्टेज (V)"),
                    primaryValue = formatEng(v, 2),
                    primaryUnit = "V",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Phase Voltage (L-N)", "फेज़ वोल्टेज"), formatEng(vPhase, 2), "V"),
                        SecondaryMetric(BilingualText("Equivalent Impedance", "तुल्य इम्पीडेंस"), formatEng(v / i, 2), "Ω")
                    ),
                    formulaUsed = "V = P / (k × I × cos φ)",
                    substitutedFormula = "V = ${formatEng(pW, 1)} / (${formatEng(mult, 3)} × ${formatEng(i, 2)} × ${formatEng(pf, 2)})",
                    stepExplanation = BilingualText("Calculated Voltage = ${formatEng(v, 2)} V", "गणना वोल्टेज = ${formatEng(v, 2)} V")
                )
            }
        }
    )

    private fun resistanceCalc() = CalculatorDefinition(
        id = "elec_resistance_calc",
        serialNumber = 5,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Memory,
        title = BilingualText("Resistance (R) Calculator", "रेजिस्टेंस (R) कैलकुलेटर"),
        subtitle = BilingualText("Compute Resistance (Ω), Conductance & I²R Heat Loss", "रेजिस्टेंस (Ω), कंडक्टेंस और I²R लॉस निकालें"),
        formulaPreview = "R = V / I   |   G = 1 / R   |   P_loss = I² × R",
        assumptions = BilingualText(
            "Valid at constant conductor temperature (temperature coefficient α neglected unless specified).",
            "मान्यता: स्थिर तापमान पर कंडक्टर रेजिस्टेंस।"
        ),
        keywords = listOf("resistance", "ohm", "conductance", "रेजिस्टेंस"),
        fields = listOf(
            CalculatorField("voltage", BilingualText("Voltage Drop / Supply (V)", "वोल्टेज (V)"), "24", "V", listOf("V", "mV", "kV")),
            CalculatorField("current", BilingualText("Current (I)", "करंट (I)"), "0.5", "A", listOf("A", "mA"))
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val rawI = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val v = when (units["voltage"]) {
                    "mV" -> rawV / 1000.0
                    "kV" -> rawV * 1000.0
                    else -> rawV
                }
                val i = if (units["current"] == "mA") rawI / 1000.0 else rawI
                val r = v / i
                val g = 1.0 / r
                val p = v * i
                engOutput(
                    primaryLabel = BilingualText("Resistance (R)", "रेजिस्टेंस (R)"),
                    primaryValue = formatEng(r, 3),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Conductance (G)", "कंडक्टेंस (G)"), formatEng(g, 4), "S"),
                        SecondaryMetric(BilingualText("Power Dissipated", "पावर लॉस (I²R)"), formatEng(p, 3), "W")
                    ),
                    formulaUsed = "R = V / I   |   G = 1 / R",
                    substitutedFormula = "R = ${formatEng(v, 3)} / ${formatEng(i, 4)}",
                    stepExplanation = BilingualText("R = ${formatEng(r, 3)} Ω, Conductance = ${formatEng(g, 4)} S", "रेजिस्टेंस R = ${formatEng(r, 3)} Ω")
                )
            }
        }
    )

    private fun reactanceCalc() = CalculatorDefinition(
        id = "elec_reactance",
        serialNumber = 6,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Waves,
        title = BilingualText("Reactance (X) Calculator", "रिएक्टेंस (X) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Inductive X_L, Capacitive X_C & Resonance f_r", "इंडक्टिव (XL), कैपेसिटिव (XC) रिएक्टेंस और रेजोनेंस निकालें"),
        formulaPreview = "X_L = 2πfL   |   X_C = 1 / (2πfC)   |   X_net = X_L − X_C",
        assumptions = BilingualText(
            "Assumes ideal lossless inductor and capacitor in sinusoidal steady-state AC.",
            "मान्यता: शुद्ध साइनूसॉइडल AC में आदर्श इंडक्टर और कैपेसिटर।"
        ),
        keywords = listOf("reactance", "xl", "xc", "inductive", "capacitive", "resonance", "रिएक्टेंस"),
        fields = listOf(
            CalculatorField("freq", BilingualText("Frequency (f)", "फ्रीक्वेंसी (f)"), "50", "Hz", listOf("Hz", "kHz")),
            CalculatorField("inductance", BilingualText("Inductance (L)", "इंडक्टेंस (L)"), "100", "mH", listOf("mH", "H", "µH")),
            CalculatorField("capacitance", BilingualText("Capacitance (C)", "कैपेसिटेंस (C)"), "100", "µF", listOf("µF", "nF", "mF"))
        ),
        compute = { values, units ->
            runCatching {
                val rawF = requirePositive(values["freq"], BilingualText("Frequency", "फ्रीक्वेंसी"))
                val rawL = requirePositive(values["inductance"], BilingualText("Inductance", "इंडक्टेंस"))
                val rawC = requirePositive(values["capacitance"], BilingualText("Capacitance", "कैपेसिटेंस"))

                val f = if (units["freq"] == "kHz") rawF * 1000.0 else rawF
                val l = when (units["inductance"]) {
                    "H" -> rawL
                    "µH" -> rawL * 1e-6
                    else -> rawL * 1e-3
                }
                val c = when (units["capacitance"]) {
                    "nF" -> rawC * 1e-9
                    "mF" -> rawC * 1e-3
                    else -> rawC * 1e-6
                }

                val xl = 2.0 * PI * f * l
                val xc = 1.0 / (2.0 * PI * f * c)
                val xNet = xl - xc
                val fRes = 1.0 / (2.0 * PI * sqrt(l * c))
                engOutput(
                    primaryLabel = BilingualText("Net Reactance (X_L − X_C)", "नेट रिएक्टेंस (X_L − X_C)"),
                    primaryValue = formatEng(xNet, 3),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Inductive X_L", "इंडक्टिव X_L"), formatEng(xl, 3), "Ω"),
                        SecondaryMetric(BilingualText("Capacitive X_C", "कैपेसिटिव X_C"), formatEng(xc, 3), "Ω"),
                        SecondaryMetric(BilingualText("Resonant Freq (f_r)", "रेजोनेंस फ्रीक्वेंसी"), formatEng(fRes, 2), "Hz")
                    ),
                    formulaUsed = "X_L = 2πfL   |   X_C = 1 / (2πfC)   |   f_r = 1 / (2π√LC)",
                    substitutedFormula = "X_L = ${formatEng(xl, 3)} Ω, X_C = ${formatEng(xc, 3)} Ω",
                    stepExplanation = BilingualText("X_L = ${formatEng(xl, 3)} Ω, X_C = ${formatEng(xc, 3)} Ω, Net X = ${formatEng(xNet, 3)} Ω", "X_L = ${formatEng(xl, 3)} Ω, X_C = ${formatEng(xc, 3)} Ω")
                )
            }
        }
    )

    private fun impedanceCalc() = CalculatorDefinition(
        id = "elec_impedance",
        serialNumber = 7,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Equalizer,
        title = BilingualText("Impedance (Z) Calculator", "इम्पीडेंस (Z) कैलकुलेटर"),
        subtitle = BilingualText("Series RLC Impedance Z, Phase Angle θ & Power Factor", "R, X_L और X_C से इम्पीडेंस (Z), फेज़ एंगल और PF निकालें"),
        formulaPreview = "Z = √(R² + (X_L − X_C)²)   |   cos φ = R / Z",
        assumptions = BilingualText(
            "Assumes series R-L-C circuit under single-frequency AC excitation.",
            "मान्यता: सिंगल फ्रीक्वेंसी AC में सीरीज R-L-C सर्किट।"
        ),
        keywords = listOf("impedance", "rlc", "phase angle", "z", "इम्पीडेंस"),
        fields = listOf(
            CalculatorField("r", BilingualText("Resistance (R)", "रेजिस्टेंस (R)"), "12", "Ω"),
            CalculatorField("xl", BilingualText("Inductive Reactance (X_L)", "इंडक्टिव रिएक्टेंस (X_L)"), "18", "Ω"),
            CalculatorField("xc", BilingualText("Capacitive Reactance (X_C)", "कैपेसिटिव रिएक्टेंस (X_C)"), "9", "Ω")
        ),
        compute = { values, _ ->
            runCatching {
                val r = requireNonNegative(values["r"], BilingualText("Resistance", "रेजिस्टेंस"))
                val xl = requireNonNegative(values["xl"], BilingualText("Inductive Reactance", "इंडक्टिव रिएक्टेंस"))
                val xc = requireNonNegative(values["xc"], BilingualText("Capacitive Reactance", "कैपेसिटिव रिएक्टेंस"))
                val x = xl - xc
                val z = sqrt(r * r + x * x)
                if (z <= 0.0) {
                    throw BilingualValidationException(
                        BilingualText("At least one of R, X_L, or X_C must be greater than 0.", "R, X_L या X_C में से कम से कम एक 0 से बड़ा होना चाहिए।")
                    )
                }
                val angleDeg = Math.toDegrees(atan2(x, r))
                val pf = r / z
                engOutput(
                    primaryLabel = BilingualText("Total Impedance (Z)", "कुल इम्पीडेंस (Z)"),
                    primaryValue = formatEng(z, 3),
                    primaryUnit = "Ω",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Phase Angle (θ)", "फेज़ एंगल (θ)"), formatEng(angleDeg, 2), "°"),
                        SecondaryMetric(BilingualText("Power Factor", "पावर फैक्टर"), formatEng(pf, 3), "cos φ"),
                        SecondaryMetric(BilingualText("Admittance (Y)", "एडमिटेंस (Y)"), formatEng(1.0 / z, 4), "S")
                    ),
                    formulaUsed = "Z = √(R² + (X_L − X_C)²)",
                    substitutedFormula = "Z = √(${formatEng(r, 2)}² + (${formatEng(xl, 2)} − ${formatEng(xc, 2)})²)",
                    stepExplanation = BilingualText("Z = ${formatEng(z, 3)} Ω at ${formatEng(angleDeg, 2)}° (PF = ${formatEng(pf, 3)})", "इम्पीडेंस Z = ${formatEng(z, 3)} Ω")
                )
            }
        }
    )

    private fun powerFactorCalc() = CalculatorDefinition(
        id = "elec_power_factor",
        serialNumber = 8,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Speed,
        title = BilingualText("Power Factor Calculator", "पावर फैक्टर कैलकुलेटर"),
        subtitle = BilingualText("Compute cos φ, Phase Angle & Reactive kVAr from kW & kVA", "एक्टिव kW और अपैरेंट kVA से पावर फैक्टर (cos φ) निकालें"),
        formulaPreview = "PF = cos φ = P (kW) / S (kVA)   |   Q = √(S² − P²)",
        assumptions = BilingualText(
            "Assumes linear sinusoidal load (true PF equals displacement cos φ when THD is low).",
            "मान्यता: साइनूसॉइडल लोड (कम हार्मोनिक्स पर सही PF = cos φ)।"
        ),
        keywords = listOf("power factor", "cos phi", "kw", "kva", "kvar", "पावर फैक्टर"),
        fields = listOf(
            CalculatorField("kw", BilingualText("Active Power (P)", "एक्टिव पावर (P)"), "85", "kW", listOf("kW", "W")),
            CalculatorField("kva", BilingualText("Apparent Power (S)", "अपैरेंट पावर (S)"), "100", "kVA", listOf("kVA", "VA"))
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requireNonNegative(values["kw"], BilingualText("Active Power", "एक्टिव पावर"))
                val rawS = requirePositive(values["kva"], BilingualText("Apparent Power", "अपैरेंट पावर"))
                val pKw = if (units["kw"] == "W") rawP / 1000.0 else rawP
                val sKva = if (units["kva"] == "VA") rawS / 1000.0 else rawS
                if (pKw > sKva * 1.0001) {
                    throw BilingualValidationException(
                        BilingualText("Active Power (P) cannot exceed Apparent Power (S).", "एक्टिव पावर (P) अपैरेंट पावर (S) से अधिक नहीं हो सकती।")
                    )
                }
                val pf = (pKw / sKva).coerceIn(0.0, 1.0)
                val angle = Math.toDegrees(acos(pf))
                val qKvar = sqrt((sKva * sKva - pKw * pKw).coerceAtLeast(0.0))
                engOutput(
                    primaryLabel = BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"),
                    primaryValue = formatEng(pf, 3),
                    primaryUnit = "cos φ",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Reactive Power (Q)", "रिएक्टिव पावर (Q)"), formatEng(qKvar, 2), "kVAr"),
                        SecondaryMetric(BilingualText("Phase Angle (φ)", "फेज़ एंगल (φ)"), formatEng(angle, 2), "°")
                    ),
                    formulaUsed = "cos φ = P / S   |   Q = √(S² − P²)",
                    substitutedFormula = "cos φ = ${formatEng(pKw, 2)} / ${formatEng(sKva, 2)}",
                    stepExplanation = BilingualText("Power Factor = ${formatEng(pf, 3)}, Q = ${formatEng(qKvar, 2)} kVAr", "पावर फैक्टर = ${formatEng(pf, 3)}"),
                    statusLevel = if (pf < 0.85) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun energyKwhCalc() = CalculatorDefinition(
        id = "elec_energy_kwh",
        serialNumber = 9,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Power,
        title = BilingualText("Energy (kWh) Calculator", "ऊर्जा (kWh) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Total Electrical Units (kWh) & Megajoules", "लोड पावर और समय से बिजली यूनिट (kWh) निकालें"),
        formulaPreview = "Energy (kWh) = Power (kW) × Hours/Day × Days",
        assumptions = BilingualText(
            "Assumes constant average load over the specified operating hours.",
            "मान्यता: पूरे समय में औसत लोड स्थिर माना गया है।"
        ),
        keywords = listOf("energy", "kwh", "units", "consumption", "ऊर्जा", "यूनिट"),
        fields = listOf(
            CalculatorField("power", BilingualText("Load Power", "लोड पावर"), "5.5", "kW", listOf("kW", "W")),
            CalculatorField("hours", BilingualText("Hours per Day", "प्रतिदिन घंटे"), "8", "hr/day"),
            CalculatorField("days", BilingualText("Number of Days", "कुल दिन"), "30", "days")
        ),
        compute = { values, units ->
            runCatching {
                val rawP = requirePositive(values["power"], BilingualText("Load Power", "लोड पावर"))
                val hrs = requireRange(values["hours"], 0.1, 24.0, BilingualText("Hours per Day", "प्रतिदिन घंटे"))
                val days = requirePositive(values["days"], BilingualText("Number of Days", "कुल दिन"))
                val pKw = if (units["power"] == "W") rawP / 1000.0 else rawP
                val daily = pKw * hrs
                val totalKwh = daily * days
                val mj = totalKwh * 3.6
                engOutput(
                    primaryLabel = BilingualText("Total Energy Consumed", "कुल ऊर्जा खपत (यूनिट)"),
                    primaryValue = formatEng(totalKwh, 2),
                    primaryUnit = "kWh",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Daily Energy", "दैनिक खपत"), formatEng(daily, 2), "kWh/day"),
                        SecondaryMetric(BilingualText("Energy (MJ)", "ऊर्जा (मेगाजूल)"), formatEng(mj, 1), "MJ")
                    ),
                    formulaUsed = "E = P(kW) × h × days",
                    substitutedFormula = "E = ${formatEng(pKw, 3)} × ${formatEng(hrs, 1)} × ${formatEng(days, 0)}",
                    stepExplanation = BilingualText("Total Energy = ${formatEng(totalKwh, 2)} kWh (${formatEng(daily, 2)} kWh/day)", "कुल खपत = ${formatEng(totalKwh, 2)} kWh")
                )
            }
        }
    )

    private fun frequencyCalc() = CalculatorDefinition(
        id = "elec_frequency",
        serialNumber = 10,
        category = CalculatorCategory.ELEC_BASIC,
        icon = Icons.Rounded.Loop,
        title = BilingualText("Frequency (f) Calculator", "फ्रीक्वेंसी (f) कैलकुलेटर"),
        subtitle = BilingualText("Compute Frequency from Time Period (1/T) or Speed/Poles", "टाइम पीरियड T या RPM व पोल से फ्रीक्वेंसी (Hz) निकालें"),
        formulaPreview = "f = 1 / T   |   f = (N × P) / 120",
        assumptions = BilingualText(
            "Standard AC grids operate at 50 Hz (T = 20 ms) or 60 Hz (T = 16.67 ms).",
            "मान्यता: मानक AC सप्लाई 50 Hz (T = 20 ms) या 60 Hz होती है।"
        ),
        keywords = listOf("frequency", "hz", "period", "rpm", "poles", "फ्रीक्वेंसी"),
        fields = listOf(
            CalculatorField("mode", BilingualText("Calculation Mode", "गणना मोड"), "1", "From Period (T)", listOf("From Period (T)", "From RPM & Poles"), isSelectorOnly = true),
            CalculatorField("primary_in", BilingualText("Period T (for f=1/T) or Speed (RPM)", "पीरियड T या स्पीड (RPM)"), "20", "ms", listOf("ms", "s", "RPM")),
            CalculatorField("poles", BilingualText("Poles (for RPM mode)", "पोल संख्या (RPM मोड हेतु)"), "4", "Poles")
        ),
        compute = { values, units ->
            runCatching {
                val mode = units["mode"] ?: "From Period (T)"
                val inVal = requirePositive(values["primary_in"], BilingualText("Period / Speed", "पीरियड / स्पीड"))
                val poles = requireEvenPoles(values["poles"], BilingualText("Poles", "पोल"))
                if (mode == "From RPM & Poles") {
                    val f = (inVal * poles) / 120.0
                    val periodMs = 1000.0 / f
                    engOutput(
                        primaryLabel = BilingualText("AC Frequency (f)", "AC फ्रीक्वेंसी (f)"),
                        primaryValue = formatEng(f, 2),
                        primaryUnit = "Hz",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Time Period (T)", "टाइम पीरियड (T)"), formatEng(periodMs, 3), "ms"),
                            SecondaryMetric(BilingualText("Angular Freq (ω)", "कोणीय गति (ω)"), formatEng(2.0 * PI * f, 2), "rad/s")
                        ),
                        formulaUsed = "f = (N × P) / 120",
                        substitutedFormula = "f = (${formatEng(inVal, 1)} × $poles) / 120",
                        stepExplanation = BilingualText("Frequency = ${formatEng(f, 2)} Hz (T = ${formatEng(periodMs, 2)} ms)", "फ्रीक्वेंसी = ${formatEng(f, 2)} Hz")
                    )
                } else {
                    val tSec = when (units["primary_in"]) {
                        "s" -> inVal
                        else -> inVal / 1000.0
                    }
                    val f = 1.0 / tSec
                    engOutput(
                        primaryLabel = BilingualText("Frequency (f)", "फ्रीक्वेंसी (f)"),
                        primaryValue = formatEng(f, 3),
                        primaryUnit = "Hz",
                        secondaryMetrics = listOf(
                            SecondaryMetric(BilingualText("Period (ms)", "पीरियड (ms)"), formatEng(tSec * 1000.0, 3), "ms"),
                            SecondaryMetric(BilingualText("Angular Freq (ω)", "कोणीय गति (ω)"), formatEng(2.0 * PI * f, 2), "rad/s")
                        ),
                        formulaUsed = "f = 1 / T",
                        substitutedFormula = "f = 1 / ${formatEng(tSec, 5)}",
                        stepExplanation = BilingualText("Frequency = ${formatEng(f, 3)} Hz", "फ्रीक्वेंसी = ${formatEng(f, 3)} Hz")
                    )
                }
            }
        }
    )
}
