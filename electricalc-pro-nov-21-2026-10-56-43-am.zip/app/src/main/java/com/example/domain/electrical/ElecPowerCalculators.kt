package com.example.domain.electrical

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.ElectricMeter
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Warning
import com.example.domain.STANDARD_BREAKER_A
import com.example.domain.STANDARD_XFMR_KVA
import com.example.domain.engOutput
import com.example.domain.nearestStandardRating
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.sqrt
import kotlin.math.tan

object ElecPowerCalculators {

    val all: List<CalculatorDefinition> = listOf(
        threePhasePower(),      // 31
        singlePhasePower(),     // 32
        lineCurrent3Ph(),       // 33
        shortCircuitCurrent(),  // 34
        faultLevelMva(),        // 35
        voltageDropSimple(),    // 36
        cableVoltageDrop(),     // 37
        cableAmpacity(),        // 38
        maximumDemand(),        // 39
        pfCorrectionKvar()      // 40
    )

    private fun threePhasePower() = CalculatorDefinition(
        id = "power_three_phase",
        serialNumber = 31,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Power,
        title = BilingualText("Three Phase Power Calculator", "थ्री फेज़ पावर कैलकुलेटर"),
        subtitle = BilingualText("Compute 3φ Active kW, Apparent kVA, Reactive kVAr & V_ph", "3-फेज़ सिस्टम की एक्टिव kW, अपैरेंट kVA और रिएक्टिव kVAr निकालें"),
        formulaPreview = "P = √3 × V_L × I_L × cos φ   |   S = √3 × V_L × I_L",
        assumptions = BilingualText(
            "Assumes balanced 3-phase sinusoidal system with line-to-line voltage V_L.",
            "मान्यता: संतुलित 3-फेज़ सिस्टम व लाइन-टू-लाइन वोल्टेज (V_L)।"
        ),
        keywords = listOf("three phase", "3 phase", "kw", "kva", "kvar", "पावर"),
        fields = listOf(
            CalculatorField("line_voltage", BilingualText("Line Voltage (V_L)", "लाइन वोल्टेज (V_L)"), "415", "V", listOf("V", "kV")),
            CalculatorField("line_current", BilingualText("Line Current (I_L)", "लाइन करंट (I_L)"), "50", "A"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ")
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["line_voltage"], BilingualText("Line Voltage", "लाइन वोल्टेज"))
                val i = requirePositive(values["line_current"], BilingualText("Line Current", "लाइन करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val v = if (units["line_voltage"] == "kV") rawV * 1000.0 else rawV
                val sqrt3 = sqrt(3.0)
                val sKva = (sqrt3 * v * i) / 1000.0
                val pKw = sKva * pf
                val qKvar = sKva * sqrt((1.0 - pf * pf).coerceAtLeast(0.0))
                val vPhase = v / sqrt3
                engOutput(
                    primaryLabel = BilingualText("3-Phase Active Power (kW)", "3-फेज़ एक्टिव पावर (kW)"),
                    primaryValue = formatEng(pKw, 2),
                    primaryUnit = "kW",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Apparent Power", "अपैरेंट पावर"), formatEng(sKva, 2), "kVA"),
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), formatEng(qKvar, 2), "kVAr"),
                        SecondaryMetric(BilingualText("Phase Voltage (L-N)", "फेज़ वोल्टेज"), formatEng(vPhase, 1), "V")
                    ),
                    formulaUsed = "P = (√3 × V_L × I_L × cos φ) / 1000",
                    substitutedFormula = "P = (1.732 × ${formatEng(v, 0)} × ${formatEng(i, 1)} × ${formatEng(pf, 2)}) / 1000",
                    stepExplanation = BilingualText("3-Phase Power = ${formatEng(pKw, 2)} kW (${formatEng(sKva, 2)} kVA)", "3-फेज़ पावर = ${formatEng(pKw, 2)} kW")
                )
            }
        }
    )

    private fun singlePhasePower() = CalculatorDefinition(
        id = "power_single_phase",
        serialNumber = 32,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Bolt,
        title = BilingualText("Single Phase Power Calculator", "सिंगल फेज़ पावर कैलकुलेटर"),
        subtitle = BilingualText("Calculate 1φ Active Power (W/kW), Apparent VA & VAR", "सिंगल फेज़ AC लोड की एक्टिव पावर (W/kW) और VA निकालें"),
        formulaPreview = "P = V × I × cos φ   |   S = V × I",
        assumptions = BilingualText(
            "Assumes single-phase AC line-to-neutral supply voltage.",
            "मान्यता: सिंगल-फेज़ AC (L-N) सप्लाई वोल्टेज।"
        ),
        keywords = listOf("single phase", "1 phase", "power", "watt", "सिंगल फेज़"),
        fields = listOf(
            CalculatorField("voltage", BilingualText("Phase Voltage (V)", "फेज़ वोल्टेज (V)"), "230", "V"),
            CalculatorField("current", BilingualText("Current (I)", "करंट (I)"), "16", "A"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.9", "cos φ")
        ),
        compute = { values, _ ->
            runCatching {
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val va = v * i
                val w = va * pf
                val varReactive = sqrt((va * va - w * w).coerceAtLeast(0.0))
                val useKw = w >= 1000.0
                engOutput(
                    primaryLabel = BilingualText("1-Phase Active Power", "1-फेज़ एक्टिव पावर"),
                    primaryValue = if (useKw) formatEng(w / 1000.0, 3) else formatEng(w, 2),
                    primaryUnit = if (useKw) "kW" else "W",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Apparent Power", "अपैरेंट पावर"), formatEng(va, 1), "VA"),
                        SecondaryMetric(BilingualText("Reactive Power", "रिएक्टिव पावर"), formatEng(varReactive, 1), "VAR")
                    ),
                    formulaUsed = "P = V × I × cos φ",
                    substitutedFormula = "P = ${formatEng(v, 1)} × ${formatEng(i, 2)} × ${formatEng(pf, 2)}",
                    stepExplanation = BilingualText("1-Phase Power = ${formatEng(w, 1)} W (${formatEng(w / 1000.0, 3)} kW)", "1-फेज़ पावर = ${formatEng(w, 1)} W")
                )
            }
        }
    )

    private fun lineCurrent3Ph() = CalculatorDefinition(
        id = "power_line_current_3ph",
        serialNumber = 33,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.ElectricBolt,
        title = BilingualText("Line Current (3 Phase) Calculator", "लाइन करंट (3 फेज़) कैलकुलेटर"),
        subtitle = BilingualText("Find 3φ Feeder Current I_L from kW Load, Voltage & PF", "3-फेज़ kW लोड से लाइन करंट और फीडर ब्रेकर साइज निकालें"),
        formulaPreview = "I_L = (P_kW × 1000) / (√3 × V_L × cos φ × η)",
        assumptions = BilingualText(
            "Assumes balanced 3-phase feeder; set Efficiency = 100% for pure electrical feeder loads.",
            "मान्यता: संतुलित 3-फेज़ लोड; शुद्ध इलेक्ट्रिकल लोड के लिए एफिशिएंसी 100% रखें।"
        ),
        keywords = listOf("line current", "3 phase current", "feeder", "breaker"),
        fields = listOf(
            CalculatorField("kw", BilingualText("Active Power (kW)", "एक्टिव लोड (kW)"), "45", "kW"),
            CalculatorField("voltage", BilingualText("Line Voltage (V_L)", "लाइन वोल्टेज (V_L)"), "415", "V", listOf("V", "kV")),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ"),
            CalculatorField("eff", BilingualText("Efficiency (%)", "एफिशिएंसी (%)"), "100", "%")
        ),
        compute = { values, units ->
            runCatching {
                val kw = requirePositive(values["kw"], BilingualText("Active Power", "पावर"))
                val rawV = requirePositive(values["voltage"], BilingualText("Line Voltage", "लाइन वोल्टेज"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val eff = requireRange(values["eff"], 10.0, 100.0, BilingualText("Efficiency", "एफिशिएंसी"))
                val v = if (units["voltage"] == "kV") rawV * 1000.0 else rawV
                val iLine = (kw * 1000.0) / (sqrt(3.0) * v * pf * (eff / 100.0))
                val kva = (sqrt(3.0) * v * iLine) / 1000.0
                val breaker = nearestStandardRating(iLine * 1.25, STANDARD_BREAKER_A)
                engOutput(
                    primaryLabel = BilingualText("3-Phase Line Current (I_L)", "3-फेज़ लाइन करंट (I_L)"),
                    primaryValue = formatEng(iLine, 2),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Feeder Load", "फीडर लोड"), formatEng(kva, 2), "kVA"),
                        SecondaryMetric(BilingualText("Recommended Breaker", "सुझावित ब्रेकर"), formatEng(breaker, 0), "A")
                    ),
                    formulaUsed = "I_L = (P_kW × 1000) / (√3 × V_L × PF × η)",
                    substitutedFormula = "I_L = ${formatEng(kw * 1000, 0)} / (1.732 × ${formatEng(v, 0)} × ${formatEng(pf, 2)})",
                    stepExplanation = BilingualText("Line Current = ${formatEng(iLine, 2)} A", "लाइन करंट = ${formatEng(iLine, 2)} A")
                )
            }
        }
    )

    private fun shortCircuitCurrent() = CalculatorDefinition(
        id = "power_short_circuit",
        serialNumber = 34,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Warning,
        title = BilingualText("Short Circuit Current Calculator", "शॉर्ट सर्किट करंट कैलकुलेटर"),
        subtitle = BilingualText("Compute 3φ Symmetrical Fault Current (kA) & Peak Surge", "ट्रांसफॉर्मर kVA और %Z इम्पीडेंस से शॉर्ट सर्किट करंट (kA) निकालें"),
        formulaPreview = "I_sc = I_FLC / (%Z / 100)   |   I_peak ≈ 2.55 × I_sc",
        assumptions = BilingualText(
            "Assumes infinite primary bus MVA (conservative worst-case LT fault at transformer terminals).",
            "मान्यता: अनंत प्राइमरी बस मानकर ट्रांसफॉर्मर टर्मिनल पर अधिकतम फॉल्ट करंट।"
        ),
        keywords = listOf("short circuit", "fault current", "ka", "impedance", "शॉर्ट सर्किट"),
        fields = listOf(
            CalculatorField("kva", BilingualText("Transformer Rating", "ट्रांसफॉर्मर क्षमता"), "1000", "kVA"),
            CalculatorField("voltage", BilingualText("Secondary Voltage (V)", "सेकेंडरी वोल्टेज (V)"), "415", "V", listOf("V", "kV")),
            CalculatorField("z_pct", BilingualText("Transformer Impedance (%Z)", "इम्पीडेंस (%Z)"), "5.0", "%")
        ),
        compute = { values, units ->
            runCatching {
                val kva = requirePositive(values["kva"], BilingualText("Transformer kVA", "ट्रांसफॉर्मर kVA"))
                val rawV = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val zPct = requireRange(values["z_pct"], 0.5, 25.0, BilingualText("%Z Impedance", "%Z इम्पीडेंस"))
                val v = if (units["voltage"] == "kV") rawV * 1000.0 else rawV
                val flc = (kva * 1000.0) / (sqrt(3.0) * v)
                val iscA = flc / (zPct / 100.0)
                val iscKa = iscA / 1000.0
                val iPeakKa = iscKa * 2.55
                val faultMva = (sqrt(3.0) * v * iscA) / 1e6
                engOutput(
                    primaryLabel = BilingualText("Symmetrical Fault Current (I_sc)", "शॉर्ट सर्किट करंट (I_sc)"),
                    primaryValue = formatEng(iscKa, 2),
                    primaryUnit = "kA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Transformer FLC", "ट्रांसफॉर्मर FLC"), formatEng(flc, 1), "A"),
                        SecondaryMetric(BilingualText("Peak Asymmetric", "पीक फॉल्ट करंट"), formatEng(iPeakKa, 2), "kA"),
                        SecondaryMetric(BilingualText("Fault Level", "फॉल्ट लेवल"), formatEng(faultMva, 2), "MVA")
                    ),
                    formulaUsed = "I_sc = I_FLC / (%Z / 100)",
                    substitutedFormula = "I_sc = ${formatEng(flc, 1)} / (${formatEng(zPct, 2)} / 100)",
                    stepExplanation = BilingualText("I_sc = ${formatEng(iscKa, 2)} kA (${formatEng(faultMva, 2)} MVA)", "फॉल्ट करंट = ${formatEng(iscKa, 2)} kA"),
                    statusLevel = if (iscKa >= 50.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun faultLevelMva() = CalculatorDefinition(
        id = "power_fault_level_mva",
        serialNumber = 35,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Shield,
        title = BilingualText("Fault Level (MVA) Calculator", "फॉल्ट लेवल (MVA) कैलकुलेटर"),
        subtitle = BilingualText("Calculate 3φ Bus Fault Level MVA & Source Impedance Z_s", "सिस्टम वोल्टेज और फॉल्ट kA से फॉल्ट MVA व सोर्स इम्पीडेंस निकालें"),
        formulaPreview = "MVA_sc = √3 × V_kV × I_sc(kA)   |   Z_s = V_kV² / MVA_sc",
        assumptions = BilingualText(
            "Assumes balanced 3-phase bolted fault at nominal system RMS voltage.",
            "मान्यता: नॉमिनल वोल्टेज पर संतुलित 3-फेज़ बोल्टेड फॉल्ट।"
        ),
        keywords = listOf("fault level", "mva", "short circuit mva", "breaker", "फॉल्ट लेवल"),
        fields = listOf(
            CalculatorField("voltage", BilingualText("System Line Voltage", "सिस्टम वोल्टेज"), "11", "kV", listOf("kV", "V")),
            CalculatorField("isc_ka", BilingualText("Breaking / Fault Current", "फॉल्ट करंट (kA)"), "25", "kA")
        ),
        compute = { values, units ->
            runCatching {
                val rawV = requirePositive(values["voltage"], BilingualText("System Voltage", "सिस्टम वोल्टेज"))
                val iscKa = requirePositive(values["isc_ka"], BilingualText("Fault Current", "फॉल्ट करंट"))
                val vKv = if (units["voltage"] == "V") rawV / 1000.0 else rawV
                val mva = sqrt(3.0) * vKv * iscKa
                val zSource = (vKv * vKv) / mva
                engOutput(
                    primaryLabel = BilingualText("3-Phase Fault Level", "3-फेज़ फॉल्ट लेवल"),
                    primaryValue = formatEng(mva, 2),
                    primaryUnit = "MVA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Source Impedance (Z_s)", "सोर्स इम्पीडेंस"), formatEng(zSource, 4), "Ω/phase"),
                        SecondaryMetric(BilingualText("Symmetrical Breaking", "ब्रेकिंग करंट"), formatEng(iscKa, 2), "kA")
                    ),
                    formulaUsed = "MVA_sc = √3 × V_kV × I_sc(kA)",
                    substitutedFormula = "MVA_sc = 1.732 × ${formatEng(vKv, 3)} × ${formatEng(iscKa, 2)}",
                    stepExplanation = BilingualText("Fault Level = ${formatEng(mva, 2)} MVA, Source Z = ${formatEng(zSource, 4)} Ω", "फॉल्ट लेवल = ${formatEng(mva, 2)} MVA")
                )
            }
        }
    )

    private fun voltageDropSimple() = CalculatorDefinition(
        id = "power_voltage_drop",
        serialNumber = 36,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Equalizer,
        title = BilingualText("Voltage Drop Calculator", "वोल्टेज ड्रॉप कैलकुलेटर"),
        subtitle = BilingualText("Check Line Drop (V & %) & Receiving End Voltage", "केबल लंबाई, करंट और साइज से वोल्टेज ड्रॉप (V व %) जांचें"),
        formulaPreview = "ΔV_3φ = (√3 × I × L × ρ) / A   |   ΔV_1φ = (2 × I × L × ρ) / A",
        assumptions = BilingualText(
            "DC resistance model (Cu ρ = 0.0178, Al ρ = 0.029 Ω·mm²/m); warns above 5% drop.",
            "मान्यता: Cu ρ = 0.0178, Al ρ = 0.029 Ω·mm²/m; 5% से ऊपर चेतावनी।"
        ),
        keywords = listOf("voltage drop", "cable", "copper", "aluminum", "वोल्टेज ड्रॉप"),
        fields = listOf(
            CalculatorField("system", BilingualText("System & Conductor", "सिस्टम व कंडक्टर"), "1", "3φ Copper", listOf("3φ Copper", "1φ/DC Copper", "3φ Aluminum", "1φ/DC Aluminum"), isSelectorOnly = true),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V"),
            CalculatorField("current", BilingualText("Load Current (A)", "लोड करंट (A)"), "40", "A"),
            CalculatorField("length", BilingualText("One-Way Length (m)", "दूरी (मीटर)"), "120", "m"),
            CalculatorField("area", BilingualText("Cable Size (mm²)", "केबल साइज (mm²)"), "16", "mm²")
        ),
        compute = { values, units ->
            runCatching {
                val v = requirePositive(values["voltage"], BilingualText("Supply Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val len = requirePositive(values["length"], BilingualText("Length", "लंबाई"))
                val area = requirePositive(values["area"], BilingualText("Cable Size", "केबल साइज"))
                val sys = units["system"] ?: "3φ Copper"
                val is3Ph = sys.startsWith("3φ")
                val rho = if (sys.contains("Aluminum")) 0.029 else 0.0178
                val mult = if (is3Ph) sqrt(3.0) else 2.0
                val vDrop = (mult * i * len * rho) / area
                val pct = (vDrop / v) * 100.0
                val vRecv = (v - vDrop).coerceAtLeast(0.0)
                engOutput(
                    primaryLabel = BilingualText("Voltage Drop (ΔV)", "वोल्टेज ड्रॉप (ΔV)"),
                    primaryValue = formatEng(vDrop, 2),
                    primaryUnit = "V",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Drop Percentage", "ड्रॉप प्रतिशत"), formatEng(pct, 2), "%"),
                        SecondaryMetric(BilingualText("Receiving Voltage", "लोड पर वोल्टेज"), formatEng(vRecv, 1), "V")
                    ),
                    formulaUsed = "ΔV = (k × I × L × ρ) / A",
                    substitutedFormula = "ΔV = (${formatEng(mult, 3)} × ${formatEng(i, 1)} × ${formatEng(len, 1)} × $rho) / ${formatEng(area, 1)}",
                    stepExplanation = BilingualText("Drop = ${formatEng(vDrop, 2)} V (${formatEng(pct, 2)}%)", "ड्रॉप = ${formatEng(vDrop, 2)} V (${formatEng(pct, 2)}%)"),
                    statusLevel = if (pct > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun cableVoltageDrop() = CalculatorDefinition(
        id = "power_cable_vdrop",
        serialNumber = 37,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Cable,
        title = BilingualText("Cable Voltage Drop (3 Phase / 1 Phase)", "केबल वोल्टेज ड्रॉप (3-फेज़ / 1-फेज़)"),
        subtitle = BilingualText("Exact AC Impedance Voltage Drop using R, X & Power Factor", "R, X रिएक्टेंस और PF के साथ सटीक AC वोल्टेज ड्रॉप निकालें"),
        formulaPreview = "ΔV_3φ = √3 × I × L_km × (R·cos φ + X·sin φ)",
        assumptions = BilingualText(
            "Includes both cable resistance R (Ω/km) and inductive reactance X (Ω/km) per IEC 60364.",
            "मान्यता: केबल रेजिस्टेंस R और इंडक्टिव रिएक्टेंस X (Ω/km) सहित सटीक AC ड्रॉप।"
        ),
        keywords = listOf("cable voltage drop", "reactance", "impedance", "3 phase", "1 phase"),
        fields = listOf(
            CalculatorField("phase", BilingualText("Phase System", "फेज़ सिस्टम"), "1", "3φ", listOf("3φ", "1φ"), isSelectorOnly = true),
            CalculatorField("voltage", BilingualText("Supply Voltage (V)", "सप्लाई वोल्टेज (V)"), "415", "V"),
            CalculatorField("current", BilingualText("Load Current (A)", "लोड करंट (A)"), "120", "A"),
            CalculatorField("pf", BilingualText("Power Factor (cos φ)", "पावर फैक्टर (cos φ)"), "0.85", "cos φ"),
            CalculatorField("length", BilingualText("Route Length (m)", "केबल लंबाई (m)"), "150", "m"),
            CalculatorField("r_km", BilingualText("Conductor Resistance R", "रेजिस्टेंस R (Ω/km)"), "0.387", "Ω/km"),
            CalculatorField("x_km", BilingualText("Conductor Reactance X", "रिएक्टेंस X (Ω/km)"), "0.080", "Ω/km")
        ),
        compute = { values, units ->
            runCatching {
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                val i = requirePositive(values["current"], BilingualText("Current", "करंट"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val lenM = requirePositive(values["length"], BilingualText("Length", "लंबाई"))
                val rKm = requirePositive(values["r_km"], BilingualText("Resistance R", "रेजिस्टेंस R"))
                val xKm = requireRange(values["x_km"], 0.0, 2.0, BilingualText("Reactance X", "रिएक्टेंस X"))
                val sinPhi = sqrt((1.0 - pf * pf).coerceAtLeast(0.0))
                val lKm = lenM / 1000.0
                val is3Ph = (units["phase"] ?: "3φ") == "3φ"
                val mult = if (is3Ph) sqrt(3.0) else 2.0
                val vDrop = mult * i * lKm * (rKm * pf + xKm * sinPhi)
                val pct = (vDrop / v) * 100.0
                engOutput(
                    primaryLabel = BilingualText("AC Impedance Voltage Drop", "AC वोल्टेज ड्रॉप (ΔV)"),
                    primaryValue = formatEng(vDrop, 2),
                    primaryUnit = "V",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Drop %", "ड्रॉप %"), formatEng(pct, 2), "%"),
                        SecondaryMetric(BilingualText("Receiving Voltage", "लोड वोल्टेज"), formatEng((v - vDrop).coerceAtLeast(0.0), 1), "V")
                    ),
                    formulaUsed = "ΔV = k × I × (L/1000) × (R·cos φ + X·sin φ)",
                    substitutedFormula = "ΔV = ${formatEng(mult, 3)} × ${formatEng(i, 1)} × ${formatEng(lKm, 3)} × (${formatEng(rKm, 3)}×${formatEng(pf, 2)} + ${formatEng(xKm, 3)}×${formatEng(sinPhi, 2)})",
                    stepExplanation = BilingualText("Exact AC Drop = ${formatEng(vDrop, 2)} V (${formatEng(pct, 2)}%)", "सटीक AC ड्रॉप = ${formatEng(vDrop, 2)} V"),
                    statusLevel = if (pct > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun cableAmpacity() = CalculatorDefinition(
        id = "power_cable_ampacity",
        serialNumber = 38,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.ElectricMeter,
        title = BilingualText("Cable Ampacity (Current Rating)", "केबल एम्पैसिटी (करंट क्षमता)"),
        subtitle = BilingualText("Compute Derated Cable Ampacity for Temp & Grouping", "तापमान व केबल ग्रुपिंग के बाद केबल की सुरक्षित करंट क्षमता निकालें"),
        formulaPreview = "I_z = I_base × K_temp × K_group × K_soil",
        assumptions = BilingualText(
            "Follows IEC 60364 / IS 3961 derating factors relative to 30 °C base rating.",
            "मान्यता: 30 °C आधार रेटिंग पर IEC 60364 डीरेटिंग फैक्टर लागू।"
        ),
        keywords = listOf("ampacity", "cable rating", "derating", "temperature factor", "एम्पैसिटी"),
        fields = listOf(
            CalculatorField("base_a", BilingualText("Base Cable Ampacity (30°C)", "मूल केबल क्षमता (30°C पर)"), "105", "A"),
            CalculatorField("kt", BilingualText("Ambient Temp Factor (K_t)", "तापमान फैक्टर (K_t)"), "0.87", "K_t"),
            CalculatorField("kg", BilingualText("Grouping Factor (K_g)", "ग्रुपिंग फैक्टर (K_g)"), "0.75", "K_g"),
            CalculatorField("ks", BilingualText("Soil/Conduit Factor (K_s)", "सॉइल/कंड्यूट फैक्टर (K_s)"), "1.0", "K_s")
        ),
        compute = { values, _ ->
            runCatching {
                val base = requirePositive(values["base_a"], BilingualText("Base Ampacity", "मूल क्षमता"))
                val kt = requireRange(values["kt"], 0.2, 1.3, BilingualText("Temp Factor K_t", "K_t"))
                val kg = requireRange(values["kg"], 0.2, 1.0, BilingualText("Grouping Factor K_g", "K_g"))
                val ks = requireRange(values["ks"], 0.2, 1.2, BilingualText("Soil/Conduit Factor K_s", "K_s"))
                val kTotal = kt * kg * ks
                val derated = base * kTotal
                val continuous80 = derated * 0.80
                engOutput(
                    primaryLabel = BilingualText("Derated Safe Ampacity (I_z)", "सुरक्षित केबल क्षमता (I_z)"),
                    primaryValue = formatEng(derated, 1),
                    primaryUnit = "A",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("80% Continuous Limit", "80% निरंतर लोड"), formatEng(continuous80, 1), "A"),
                        SecondaryMetric(BilingualText("Total Derating", "कुल डीरेटिंग"), formatEng(kTotal * 100.0, 1), "%")
                    ),
                    formulaUsed = "I_z = I_base × K_t × K_g × K_s",
                    substitutedFormula = "I_z = ${formatEng(base, 1)} × ${formatEng(kt, 2)} × ${formatEng(kg, 2)} × ${formatEng(ks, 2)}",
                    stepExplanation = BilingualText("Safe Ampacity = ${formatEng(derated, 1)} A (${formatEng(kTotal * 100, 1)}% of base)", "सुरक्षित क्षमता = ${formatEng(derated, 1)} A")
                )
            }
        }
    )

    private fun maximumDemand() = CalculatorDefinition(
        id = "power_max_demand",
        serialNumber = 39,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.Analytics,
        title = BilingualText("Maximum Demand (MD) Calculator", "मैक्सिमम डिमांड (MD) कैलकुलेटर"),
        subtitle = BilingualText("Calculate Plant MD (kW & kVA) using Demand & Diversity", "डिमांड फैक्टर और डाइवर्सिटी से प्लांट की मैक्सिमम डिमांड निकालें"),
        formulaPreview = "MD (kW) = (Connected_kW × Demand_Factor) / Diversity_Factor",
        assumptions = BilingualText(
            "Demand Factor ≤ 1.0; Diversity Factor ≥ 1.0 for multiple non-simultaneous loads.",
            "मान्यता: डिमांड फैक्टर ≤ 1.0 और डाइवर्सिटी फैक्टर ≥ 1.0।"
        ),
        keywords = listOf("maximum demand", "md", "diversity factor", "connected load", "मैक्सिमम डिमांड"),
        fields = listOf(
            CalculatorField("conn_kw", BilingualText("Total Connected Load (kW)", "कुल कनेक्टेड लोड (kW)"), "500", "kW"),
            CalculatorField("df", BilingualText("Demand Factor (0.1–1.0)", "डिमांड फैक्टर"), "0.75", "DF"),
            CalculatorField("div", BilingualText("Diversity Factor (1.0–3.0)", "डाइवर्सिटी फैक्टर"), "1.2", "Div"),
            CalculatorField("pf", BilingualText("Average Power Factor", "औसत पावर फैक्टर"), "0.9", "cos φ")
        ),
        compute = { values, _ ->
            runCatching {
                val conn = requirePositive(values["conn_kw"], BilingualText("Connected Load", "कनेक्टेड लोड"))
                val df = requireRange(values["df"], 0.1, 1.0, BilingualText("Demand Factor", "डिमांड फैक्टर"))
                val div = requireRange(values["div"], 1.0, 5.0, BilingualText("Diversity Factor", "डाइवर्सिटी फैक्टर"))
                val pf = requireRange(values["pf"], 0.1, 1.0, BilingualText("Power Factor", "पावर फैक्टर"))
                val mdKw = (conn * df) / div
                val mdKva = mdKw / pf
                val stdXfmr = nearestStandardRating(mdKva * 1.15, STANDARD_XFMR_KVA)
                engOutput(
                    primaryLabel = BilingualText("Maximum Demand (kVA)", "मैक्सिमम डिमांड (kVA)"),
                    primaryValue = formatEng(mdKva, 2),
                    primaryUnit = "kVA",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Maximum Demand (kW)", "मैक्सिमम डिमांड (kW)"), formatEng(mdKw, 2), "kW"),
                        SecondaryMetric(BilingualText("Suggested Transformer", "सुझावित ट्रांसफॉर्मर"), formatEng(stdXfmr, 0), "kVA")
                    ),
                    formulaUsed = "MD_kVA = ((Load × DF) / Diversity) / PF",
                    substitutedFormula = "MD_kW = (${formatEng(conn, 1)} × ${formatEng(df, 2)}) / ${formatEng(div, 2)} = ${formatEng(mdKw, 2)} kW",
                    stepExplanation = BilingualText("MD = ${formatEng(mdKva, 2)} kVA (${formatEng(mdKw, 2)} kW)", "मैक्सिमम डिमांड = ${formatEng(mdKva, 2)} kVA")
                )
            }
        }
    )

    private fun pfCorrectionKvar() = CalculatorDefinition(
        id = "power_pf_correction",
        serialNumber = 40,
        category = CalculatorCategory.ELEC_POWER,
        icon = Icons.Rounded.FlashOn,
        title = BilingualText("Power Factor Correction (Capacitor kVAr)", "पावर फैक्टर सुधार (कैपेसिटर kVAr)"),
        subtitle = BilingualText("Size APFC Capacitor Bank & Phase µF to Improve cos φ", "पावर फैक्टर सुधारने हेतु आवश्यक कैपेसिटर kVAr और µF निकालें"),
        formulaPreview = "Q_c = P × (tan φ₁ − tan φ₂)",
        assumptions = BilingualText(
            "Assumes 50 Hz 3-phase Delta-connected capacitor bank at nominal line voltage.",
            "मान्यता: 50 Hz सप्लाई और 3-फेज़ डेल्टा-कनेक्टेड कैपेसिटर बैंक।"
        ),
        keywords = listOf("power factor correction", "capacitor", "kvar", "apfc", "कैपेसिटर"),
        fields = listOf(
            CalculatorField("load_kw", BilingualText("Active Load (kW)", "लोड पावर (kW)"), "100", "kW"),
            CalculatorField("pf1", BilingualText("Existing PF (cos φ₁)", "वर्तमान PF (cos φ₁)"), "0.75", "cos φ"),
            CalculatorField("pf2", BilingualText("Target PF (cos φ₂)", "लक्ष्य PF (cos φ₂)"), "0.98", "cos φ"),
            CalculatorField("voltage", BilingualText("Line Voltage (V)", "लाइन वोल्टेज (V)"), "415", "V")
        ),
        compute = { values, _ ->
            runCatching {
                val pKw = requirePositive(values["load_kw"], BilingualText("Active Load", "लोड"))
                val pf1 = requireRange(values["pf1"], 0.2, 0.99, BilingualText("Existing PF", "वर्तमान PF"))
                val pf2 = requireRange(values["pf2"], 0.25, 1.0, BilingualText("Target PF", "लक्ष्य PF"))
                val v = requirePositive(values["voltage"], BilingualText("Voltage", "वोल्टेज"))
                if (pf2 <= pf1) {
                    throw BilingualValidationException(
                        BilingualText("Target PF must be higher than Existing PF.", "लक्ष्य PF, वर्तमान PF से अधिक होना चाहिए।")
                    )
                }
                val qKvar = pKw * (tan(acos(pf1)) - tan(acos(pf2)))
                val capPerPhaseUf = (qKvar * 1e9) / (3.0 * 2.0 * PI * 50.0 * v * v)
                val iBefore = (pKw * 1000.0) / (sqrt(3.0) * v * pf1)
                val iAfter = (pKw * 1000.0) / (sqrt(3.0) * v * pf2)
                engOutput(
                    primaryLabel = BilingualText("Required Capacitor Bank", "आवश्यक कैपेसिटर बैंक"),
                    primaryValue = formatEng(qKvar, 2),
                    primaryUnit = "kVAr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Delta Cap / Phase", "डेल्टा क्षमता / फेज़"), formatEng(capPerPhaseUf, 1), "µF"),
                        SecondaryMetric(BilingualText("Current Before → After", "करंट कमी"), "${formatEng(iBefore, 1)} → ${formatEng(iAfter, 1)}", "A")
                    ),
                    formulaUsed = "Q_c = P × (tan φ₁ − tan φ₂)",
                    substitutedFormula = "Q_c = ${formatEng(pKw, 1)} × (${formatEng(tan(acos(pf1)), 3)} − ${formatEng(tan(acos(pf2)), 3)})",
                    stepExplanation = BilingualText("Add ${formatEng(qKvar, 2)} kVAr capacitor bank to cut current from ${formatEng(iBefore, 1)} A to ${formatEng(iAfter, 1)} A", "आवश्यक कैपेसिटर = ${formatEng(qKvar, 2)} kVAr")
                )
            }
        }
    )
}
