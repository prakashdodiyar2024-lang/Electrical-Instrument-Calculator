package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CalculatorRegistry
import com.example.model.AppLanguage
import com.example.model.CalculatorCategory
import com.example.ui.CalculatorScreenUiState
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.BrandLogoBadge
import com.example.ui.components.CalculatorListCard
import com.example.ui.components.CategoryGridCard
import com.example.ui.components.EngineeringHeroHeader
import com.example.ui.theme.ActionRed
import com.example.ui.theme.CleanSurfaceAlt
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightGreyBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftRedTint
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun HomeScreen(
    uiState: CalculatorScreenUiState,
    onToggleLanguage: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onCategoryChipSelected: (CalculatorCategory?) -> Unit,
    onOpenCategory: (CalculatorCategory) -> Unit,
    onOpenCalculator: (String) -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val isFiltering = uiState.searchQuery.isNotBlank() || uiState.selectedCategoryChip != null
    val keyboardController = LocalSoftwareKeyboardController.current
    val playClick = rememberTouchClickSound()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .align(Alignment.TopCenter)
                .testTag("home_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureWhite)
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    EngineeringHeroHeader(
                        language = lang,
                        totalCalculators = CalculatorRegistry.allCalculators.size,
                        onToggleLanguage = onToggleLanguage,
                        onOpenAbout = onOpenAbout
                    )
                }
            }

            // Clean White Engineering Search Bar
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("search_input"),
                    placeholder = {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) {
                                "Search calculators (e.g. 4-20mA, Motor, Pt100, Cable)..."
                            } else {
                                "कैलकुलेटर खोजें (जैसे 4-20mA, मोटर, Pt100, केबल)..."
                            },
                            color = TextSecondaryDark,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = TextSecondaryDark
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    playClick()
                                    onSearchQueryChange("")
                                },
                                modifier = Modifier.testTag("search_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = TextPrimaryDark
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = { keyboardController?.hide() }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark,
                        focusedBorderColor = ActionRed,
                        unfocusedBorderColor = LightGreyBorder,
                        cursorColor = ActionRed
                    )
                )
            }

            // Category Filter Chips
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        val allSelected = uiState.selectedCategoryChip == null
                        FilterChip(
                            selected = allSelected,
                            onClick = {
                                playClick()
                                onCategoryChipSelected(null)
                            },
                            label = {
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) "All" else "सभी",
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = PureWhite,
                                labelColor = TextPrimaryDark,
                                selectedContainerColor = ActionRed,
                                selectedLabelColor = PureWhite
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = allSelected,
                                borderColor = LightGreyBorder,
                                selectedBorderColor = ActionRed,
                                selectedBorderWidth = 1.dp
                            ),
                            modifier = Modifier.testTag("filter_chip_all")
                        )
                    }
                    items(CalculatorCategory.entries) { cat ->
                        val selected = uiState.selectedCategoryChip == cat
                        FilterChip(
                            selected = selected,
                            onClick = {
                                playClick()
                                onCategoryChipSelected(cat)
                            },
                            label = {
                                Text(
                                    text = cat.shortTitle.get(lang),
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = PureWhite,
                                labelColor = TextPrimaryDark,
                                selectedContainerColor = ActionRed,
                                selectedLabelColor = PureWhite
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = LightGreyBorder,
                                selectedBorderColor = ActionRed,
                                selectedBorderWidth = 1.dp
                            ),
                            modifier = Modifier.testTag("filter_chip_${cat.id}")
                        )
                    }
                }
            }

            if (isFiltering) {
                item {
                    Text(
                        text = if (lang == AppLanguage.ENGLISH) {
                            "Matching Calculators (${uiState.searchResults.size})"
                        } else {
                            "मिले हुए कैलकुलेटर (${uiState.searchResults.size})"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimaryDark,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                    )
                }

                if (uiState.searchResults.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, LightGreyBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.SearchOff,
                                    contentDescription = null,
                                    tint = ActionRed,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "No calculators found for \"${uiState.searchQuery}\""
                                    } else {
                                        "\"${uiState.searchQuery}\" के लिए कोई कैलकुलेटर नहीं मिला"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Try terms like Ohm, Motor, VFD, PLC, 4-20mA, RTD, Pressure, Cable"
                                    } else {
                                        "कृपया Motor, VFD, PLC, 4-20mA, RTD, Pressure या Cable खोजें"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                } else {
                    items(uiState.searchResults, key = { it.id }) { calc ->
                        CalculatorListCard(
                            calculator = calc,
                            language = lang,
                            onClick = { onOpenCalculator(calc.id) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                // Quick-Access Popular Calculators
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            tint = ActionRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "Quick Field Tools" else "त्वरित फील्ड कैलकुलेटर",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryDark
                        )
                    }
                }

                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(CalculatorRegistry.popularCalculators, key = { it.id }) { calc ->
                            Card(
                                onClick = {
                                    playClick()
                                    onOpenCalculator(calc.id)
                                },
                                modifier = Modifier
                                    .width(208.dp)
                                    .testTag("popular_card_${calc.id}"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                border = BorderStroke(1.dp, LightGreyBorder),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(modifier = Modifier.padding(13.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(SoftRedTint),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = calc.category.icon,
                                                contentDescription = null,
                                                tint = ActionRed,
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                        Text(
                                            text = calc.category.shortTitle.get(lang),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondaryDark,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = calc.title.get(lang),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = TextPrimaryDark,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                // Recent calculations if any
                if (uiState.recentHistory.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = null,
                                tint = ActionRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) "Recent Results" else "हाल के परिणाम",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimaryDark
                            )
                        }
                    }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(uiState.recentHistory) { item ->
                                Surface(
                                    onClick = {
                                        playClick()
                                        onOpenCalculator(item.calculatorId)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    color = PureWhite,
                                    border = BorderStroke(1.dp, LightGreyBorder),
                                    modifier = Modifier.testTag("recent_card_${item.calculatorId}")
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                        Text(
                                            text = item.title.get(lang),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextSecondaryDark,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = item.resultSummary,
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontFamily = JetBrainsMonoFontFamily,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = TextPrimaryDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Categories Section Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "Engineering Categories" else "इंजीनियरिंग श्रेणियाँ",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryDark
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = CleanSurfaceAlt,
                            border = BorderStroke(1.dp, LightGreyBorder)
                        ) {
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) "9 Modules" else "9 विभाग",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimaryDark,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Separate, Large, Colored Rounded Category Cards
                items(CalculatorCategory.entries, key = { it.id }) { category ->
                    CategoryGridCard(
                        category = category,
                        calculatorCount = CalculatorRegistry.countForCategory(category),
                        language = lang,
                        onClick = { onOpenCategory(category) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 2.dp)
                    )
                }

                // Branded About Us & Developer Card
                item {
                    Card(
                        onClick = {
                            playClick()
                            onOpenAbout()
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = BorderStroke(1.dp, LightGreyBorder),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("about_us_home_card")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PureWhite)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BrandLogoBadge(size = 46.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) {
                                            "About Us • Electrical & Instrumentation"
                                        } else {
                                            "हमारे बारे में • Electrical & Instrumentation"
                                        },
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = TextPrimaryDark
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (lang == AppLanguage.ENGLISH) {
                                            "Developer: Er. Prakash Dodiyar • YouTube & Contact"
                                        } else {
                                            "डेवलपर: Er. प्रकाश डोडियार • यूट्यूब व संपर्क"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondaryDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = SoftRedTint,
                                    border = BorderStroke(1.dp, LightGreyBorder)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                        contentDescription = if (lang == AppLanguage.ENGLISH) "Open About Us" else "हमारे बारे में खोलें",
                                        tint = ActionRed,
                                        modifier = Modifier
                                            .padding(8.dp)
                                            .size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
            }
        }
    }
}
