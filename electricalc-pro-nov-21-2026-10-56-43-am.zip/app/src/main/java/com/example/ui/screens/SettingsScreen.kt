package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.EngineeringDiscipline
import com.example.ui.CalculatorScreenUiState
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.ClearRed
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueHeaderEnd
import com.example.ui.theme.RoyalBlueHeaderStart
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.SoftRedBorder
import com.example.ui.theme.SubtleGreyBorder
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun SettingsScreen(
    uiState: CalculatorScreenUiState,
    onSetLanguage: (AppLanguage) -> Unit,
    onToggleTouchSound: (Boolean) -> Unit,
    onSetDefaultDiscipline: (EngineeringDiscipline) -> Unit,
    onClearFavorites: () -> Unit,
    onClearRecentHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val playClick = rememberTouchClickSound()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .align(Alignment.TopCenter)
                .testTag("settings_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(RoyalBlueHeaderStart, RoyalBlueHeaderEnd)
                            )
                        )
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "Settings" else "सेटिंग्स",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 21.sp
                            ),
                            color = PureWhite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) {
                                "Customize language, sound, startup section & saved data"
                            } else {
                                "भाषा, साउंड, स्टार्टअप सेक्शन और सहेजा गया डेटा कस्टमाइज़ करें"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = PureWhite.copy(alpha = 0.88f)
                        )
                    }
                }
            }

            // Language Preference Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(RoyalBlueTint),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Translate,
                                    contentDescription = null,
                                    tint = RoyalBlue
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) "App Language" else "ऐप की भाषा",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Switch between English and Hindi"
                                    } else {
                                        "अंग्रेजी और हिंदी के बीच बदलें"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_language_toggle"),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val isEn = lang == AppLanguage.ENGLISH
                            FilterChip(
                                selected = isEn,
                                onClick = {
                                    playClick()
                                    onSetLanguage(AppLanguage.ENGLISH)
                                },
                                label = {
                                    Text(
                                        text = "English",
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = PureWhite,
                                    labelColor = TextPrimaryDark,
                                    selectedContainerColor = RoyalBlue,
                                    selectedLabelColor = PureWhite
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isEn,
                                    borderColor = LightBlueBorder,
                                    selectedBorderColor = RoyalBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_lang_en")
                            )

                            val isHi = lang == AppLanguage.HINDI
                            FilterChip(
                                selected = isHi,
                                onClick = {
                                    playClick()
                                    onSetLanguage(AppLanguage.HINDI)
                                },
                                label = {
                                    Text(
                                        text = "हिन्दी (Hindi)",
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = PureWhite,
                                    labelColor = TextPrimaryDark,
                                    selectedContainerColor = RoyalBlue,
                                    selectedLabelColor = PureWhite
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isHi,
                                    borderColor = LightBlueBorder,
                                    selectedBorderColor = RoyalBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_lang_hi")
                            )
                        }
                    }
                }
            }

            // Touch Sound & Default Discipline Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(RoyalBlueTint),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.VolumeUp,
                                    contentDescription = null,
                                    tint = RoyalBlue
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) "Touch Click Sound" else "टच क्लिक साउंड",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Soft tactile sound on button taps"
                                    } else {
                                        "बटन दबाने पर सॉफ्ट क्लिक ध्वनि"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                            Switch(
                                checked = uiState.touchSoundEnabled,
                                onCheckedChange = { enabled ->
                                    onToggleTouchSound(enabled)
                                    if (enabled) playClick()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = PureWhite,
                                    checkedTrackColor = RoyalBlue,
                                    uncheckedThumbColor = RoyalBlue,
                                    uncheckedTrackColor = PureWhite,
                                    uncheckedBorderColor = LightBlueBorder
                                ),
                                modifier = Modifier.testTag("settings_touch_sound_switch")
                            )
                        }

                        HorizontalDivider(color = HairlineGrey)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) {
                                    "Default Startup Discipline"
                                } else {
                                    "डिफ़ॉल्ट स्टार्टअप सेक्शन"
                                },
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = DarkNavyBlue
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                EngineeringDiscipline.entries.forEach { discipline ->
                                    val selected = uiState.defaultDiscipline == discipline
                                    FilterChip(
                                        selected = selected,
                                        onClick = {
                                            playClick()
                                            onSetDefaultDiscipline(discipline)
                                        },
                                        label = {
                                            Text(
                                                text = if (discipline == EngineeringDiscipline.ELECTRICAL) {
                                                    if (lang == AppLanguage.ENGLISH) "Electrical (50)" else "इलेक्ट्रिकल (50)"
                                                } else {
                                                    if (lang == AppLanguage.ENGLISH) "Instrument (50)" else "इंस्ट्रूमेंट (50)"
                                                },
                                                fontWeight = FontWeight.Bold
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            containerColor = PureWhite,
                                            labelColor = TextPrimaryDark,
                                            selectedContainerColor = RoyalBlue,
                                            selectedLabelColor = PureWhite
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = selected,
                                            borderColor = LightBlueBorder,
                                            selectedBorderColor = RoyalBlue
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("settings_default_${discipline.id}")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Saved Data Management Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                    border = BorderStroke(1.dp, LightBlueBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(RoyalBlueTint),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteSweep,
                                    contentDescription = null,
                                    tint = RoyalBlue
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) "Manage Saved Data" else "सहेजा डेटा प्रबंधित करें",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimaryDark
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    playClick()
                                    onClearRecentHistory()
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, SubtleGreyBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = PureWhite,
                                    contentColor = DarkNavyBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_clear_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = null,
                                    tint = RoyalBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Clear History (${uiState.recentHistory.size})"
                                    } else {
                                        "हिस्ट्री साफ़ (${uiState.recentHistory.size})"
                                    },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    playClick()
                                    onClearFavorites()
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, SoftRedBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = PureWhite,
                                    contentColor = ClearRed
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_clear_favorites_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.StarOutline,
                                    contentDescription = null,
                                    tint = ClearRed,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == AppLanguage.ENGLISH) {
                                        "Clear Favs (${uiState.favoriteIds.size})"
                                    } else {
                                        "पसंदीदा साफ़ (${uiState.favoriteIds.size})"
                                    },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // Suite Info Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = RoyalBlueTint,
                    border = BorderStroke(1.dp, LightBlueBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Engineering,
                            contentDescription = null,
                            tint = RoyalBlue,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Electrical & Instrument Calculator (ElectricalCalc Pro)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = DarkNavyBlue
                            )
                            Text(
                                text = if (lang == AppLanguage.ENGLISH) {
                                    "100 Calculators • 50 Electrical + 50 Instrumentation • Developer: Er. Prakash Dodiyar"
                                } else {
                                    "100 कैलकुलेटर • 50 इलेक्ट्रिकल + 50 इंस्ट्रूमेंटेशन • डेवलपर: Er. प्रकाश डोडियार"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )
                        }
                    }
                }
            }
        }
    }
}
