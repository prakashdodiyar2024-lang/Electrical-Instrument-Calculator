package com.example.domain.instrumentation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.DonutLarge
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.PrecisionManufacturing
import androidx.compose.material.icons.rounded.Scale
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Water
import com.example.domain.engOutput
import com.example.model.BilingualText
import com.example.model.BilingualValidationException
import com.example.model.CalculatorCategory
import com.example.model.CalculatorDefinition
import com.example.model.CalculatorField
import com.example.model.SecondaryMetric
import com.example.model.StatusLevel
import com.example.model.formatEng
import com.example.model.requireNonNegative
import com.example.model.requirePositive
import com.example.model.requireRange
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sqrt

object InstFlowCalculators {

    val all: List<CalculatorDefinition> = listOf(
        flowRateM3h(),          // 21
        massFlowTph(),          // 22
        flowVelocity(),         // 23
        orificePlateFlow(),     // 24
        venturiFlow(),          // 25
        nozzleFlow(),           // 26
        rotameterSizing(),      // 27
        gasFlowCompensation(),  // 28
        flowTotalizer(),        // 29
        flowUnitConverter()     // 30
    )

    private fun dpElementFlow(
        id: String,
        serialNumber: Int,
        icon: androidx.compose.ui.graphics.vector.ImageVector,
        title: BilingualText,
        subtitle: BilingualText,
        defaultCd: String,
        permLossFactor: Double,
        assumptions: BilingualText
    ) = CalculatorDefinition(
        id = id,
        serialNumber = serialNumber,
        category = CalculatorCategory.INST_FLOW,
        icon = icon,
        title = title,
        subtitle = subtitle,
        formulaPreview = "Q = C_d × (πd²/4) / √(1 − β⁴) × √(2 × ΔP / ρ) × 3600",
        assumptions = assumptions,
        keywords = listOf("flow", "orifice", "venturi", "nozzle", "beta ratio", "dp flow"),
        fields = listOf(
            CalculatorField("d_mm", BilingualText("Throat / Bore Diameter (d)", "थ्रोट / बोर व्यास (d)"), "50", "mm"),
            CalculatorField("pipe_mm", BilingualText("Pipe Inner Diameter (D)", "पाइप आंतरिक व्यास (D)"), "100", "mm"),
            CalculatorField("dp", BilingualText("Differential Pressure (ΔP)", "डिफरेंशियल प्रेशर (ΔP)"), "25", "kPa", listOf("kPa", "mmH₂O", "bar")),
            CalculatorField("rho", BilingualText("Fluid Density (ρ)", "द्रव घनत्व (ρ)"), "1000", "kg/m³"),
            CalculatorField("cd", BilingualText("Discharge Coefficient (C_d)", "डिस्चार्ज गुणांक (C_d)"), defaultCd, "Cd")
        ),
        compute = { values, units ->
            runCatching {
                val dMm = requirePositive(values["d_mm"], BilingualText("Bore Diameter d", "बोर व्यास d"))
                val bigDMm = requirePositive(values["pipe_mm"], BilingualText("Pipe Diameter D", "पाइप व्यास D"))
                if (dMm >= bigDMm) {
                    throw BilingualValidationException(
                        BilingualText("Throat/bore diameter (d) must be smaller than pipe ID (D).", "थ्रोट व्यास (d), पाइप के आंतरिक व्यास (D) से कम होना चाहिए।")
                    )
                }
                val rawDp = requireNonNegative(values["dp"], BilingualText("Differential Pressure", "ΔP"))
                val rho = requirePositive(values["rho"], BilingualText("Fluid Density", "घनत्व"))
                val cd = requireRange(values["cd"], 0.3, 1.05, BilingualText("Discharge Coeff C_d", "C_d"))

                val dpPa = when (units["dp"]) {
                    "mmH₂O" -> rawDp * 9.80665
                    "bar" -> rawDp * 100000.0
                    else -> rawDp * 1000.0
                }
                val beta = dMm / bigDMm
                val areaM2 = PI * (dMm / 1000.0).pow(2) / 4.0
                val velocityApproachFactor = 1.0 / sqrt((1.0 - beta.pow(4)).coerceAtLeast(1e-9))
                val qM3s = cd * areaM2 * velocityApproachFactor * sqrt((2.0 * dpPa) / rho)
                val qM3h = qM3s * 3600.0
                val massKgH = qM3h * rho
                val permLossKpa = (dpPa / 1000.0) * permLossFactor

                engOutput(
                    primaryLabel = BilingualText("Volumetric Flow Rate", "वॉल्यूमेट्रिक फ्लो रेट"),
                    primaryValue = formatEng(qM3h, 2),
                    primaryUnit = "m³/hr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Mass Flow", "मास फ्लो"), formatEng(massKgH / 1000.0, 3), "TPH"),
                        SecondaryMetric(BilingualText("Beta Ratio (β = d/D)", "बीटा अनुपात (β)"), formatEng(beta, 3), ""),
                        SecondaryMetric(BilingualText("Est. Permanent Loss", "स्थायी प्रेशर लॉस"), formatEng(permLossKpa, 2), "kPa")
                    ),
                    formulaUsed = "Q = C_d × A_d / √(1 − β⁴) × √(2·ΔP / ρ) × 3600",
                    substitutedFormula = "β = ${formatEng(beta, 3)}, C_d = ${formatEng(cd, 3)}, Q = ${formatEng(qM3h, 2)} m³/hr",
                    stepExplanation = BilingualText("Flow = ${formatEng(qM3h, 2)} m³/hr (${formatEng(massKgH / 1000.0, 2)} TPH)", "फ्लो रेट = ${formatEng(qM3h, 2)} m³/hr"),
                    statusLevel = if (beta < 0.2 || beta > 0.75) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun flowRateM3h() = CalculatorDefinition(
        id = "flow_rate_m3h",
        serialNumber = 21,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Water,
        title = BilingualText("Flow Rate Calculator (m³/hr)", "फ्लो रेट कैलकुलेटर (m³/hr)"),
        subtitle = BilingualText("Calculate Pipe Volumetric Flow from Pipe ID & Velocity", "पाइप के व्यास और द्रव वेग (m/s) से फ्लो रेट (m³/hr) निकालें"),
        formulaPreview = "Q (m³/hr) = (π × D² / 4) × v × 3600",
        assumptions = BilingualText(
            "Assumes full-bore incompressible pipe flow with uniform average velocity profile.",
            "मान्यता: पूरी तरह भरे हुए पाइप में एकसमान औसत वेग।"
        ),
        keywords = listOf("flow rate", "m3/hr", "pipe flow", "lpm", "gpm"),
        fields = listOf(
            CalculatorField("dia", BilingualText("Pipe Inner Diameter (D)", "पाइप का आंतरिक व्यास (D)"), "100", "mm", listOf("mm", "inch")),
            CalculatorField("vel", BilingualText("Fluid Velocity (v)", "द्रव वेग (v)"), "2.0", "m/s")
        ),
        compute = { values, units ->
            runCatching {
                val rawD = requirePositive(values["dia"], BilingualText("Pipe Diameter", "पाइप व्यास"))
                val v = requireNonNegative(values["vel"], BilingualText("Velocity", "वेग"))
                val dM = if (units["dia"] == "inch") rawD * 0.0254 else rawD / 1000.0
                val area = PI * dM * dM / 4.0
                val qM3h = area * v * 3600.0
                val lpm = (qM3h * 1000.0) / 60.0
                val gpm = qM3h * 4.402868
                engOutput(
                    primaryLabel = BilingualText("Volumetric Flow Rate", "वॉल्यूमेट्रिक फ्लो रेट"),
                    primaryValue = formatEng(qM3h, 2),
                    primaryUnit = "m³/hr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters / Min", "लीटर / मिनट"), formatEng(lpm, 1), "LPM"),
                        SecondaryMetric(BilingualText("US Gallons / Min", "गैलन / मिनट"), formatEng(gpm, 1), "GPM"),
                        SecondaryMetric(BilingualText("Pipe Area", "पाइप क्षेत्रफल"), formatEng(area * 10000.0, 2), "cm²")
                    ),
                    formulaUsed = "Q = (πD²/4) × v × 3600",
                    substitutedFormula = "Q = ${formatEng(area, 5)} × ${formatEng(v, 2)} × 3600",
                    stepExplanation = BilingualText("Flow = ${formatEng(qM3h, 2)} m³/hr (${formatEng(lpm, 1)} LPM)", "फ्लो = ${formatEng(qM3h, 2)} m³/hr")
                )
            }
        }
    )

    private fun massFlowTph() = CalculatorDefinition(
        id = "flow_mass_tph",
        serialNumber = 22,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Scale,
        title = BilingualText("Mass Flow Calculator (TPH)", "मास फ्लो कैलकुलेटर (TPH)"),
        subtitle = BilingualText("Convert Volumetric Flow & Fluid Density to Tons/hr & kg/hr", "वॉल्यूम फ्लो और घनत्व से मास फ्लो (TPH व kg/hr) निकालें"),
        formulaPreview = "M (TPH) = (Q_m³/hr × ρ) / 1000",
        assumptions = BilingualText(
            "1 Metric Ton = 1000 kg; density ρ at actual operating pressure & temperature.",
            "मान्यता: 1 मीट्रिक टन = 1000 kg; वास्तविक तापमान/प्रेशर पर घनत्व ρ।"
        ),
        keywords = listOf("mass flow", "tph", "tons per hour", "kg/hr", "density"),
        fields = listOf(
            CalculatorField("q", BilingualText("Volumetric Flow Rate (Q)", "वॉल्यूम फ्लो (Q)"), "50", "m³/hr", listOf("m³/hr", "LPM")),
            CalculatorField("rho", BilingualText("Fluid Density (ρ)", "द्रव घनत्व (ρ)"), "1000", "kg/m³")
        ),
        compute = { values, units ->
            runCatching {
                val rawQ = requireNonNegative(values["q"], BilingualText("Flow Rate", "फ्लो रेट"))
                val rho = requirePositive(values["rho"], BilingualText("Density", "घनत्व"))
                val qM3h = if (units["q"] == "LPM") rawQ * 0.06 else rawQ
                val kgHr = qM3h * rho
                val tph = kgHr / 1000.0
                val kgSec = kgHr / 3600.0
                engOutput(
                    primaryLabel = BilingualText("Mass Flow Rate (TPH)", "मास फ्लो रेट (TPH)"),
                    primaryValue = formatEng(tph, 3),
                    primaryUnit = "TPH",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("kg / hour", "किलोग्राम / घंटा"), formatEng(kgHr, 1), "kg/hr"),
                        SecondaryMetric(BilingualText("kg / second", "किलोग्राम / सेकंड"), formatEng(kgSec, 3), "kg/s")
                    ),
                    formulaUsed = "TPH = (Q_m³/hr × ρ) / 1000",
                    substitutedFormula = "TPH = (${formatEng(qM3h, 2)} × ${formatEng(rho, 1)}) / 1000",
                    stepExplanation = BilingualText("Mass Flow = ${formatEng(tph, 3)} TPH (${formatEng(kgHr, 0)} kg/hr)", "मास फ्लो = ${formatEng(tph, 3)} TPH")
                )
            }
        }
    )

    private fun flowVelocity() = CalculatorDefinition(
        id = "flow_velocity",
        serialNumber = 23,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Speed,
        title = BilingualText("Flow Velocity Calculator", "फ्लो वेलोसिटी (वेग) कैलकुलेटर"),
        subtitle = BilingualText("Check Liquid / Gas Velocity (m/s) in Pipe for Sizing & Erosion", "फ्लो रेट और पाइप ID से द्रव वेग (m/s) की जांच करें"),
        formulaPreview = "v (m/s) = (Q_m³/hr / 3600) / (π × D² / 4)",
        assumptions = BilingualText(
            "Typical safe liquid pipe velocity: 1.0–3.0 m/s; warns above 5 m/s for erosion/noise.",
            "मान्यता: तरल पाइप में सुरक्षित वेग 1.0–3.0 m/s (5 m/s से ऊपर कटाव/शोर चेतावनी)।"
        ),
        keywords = listOf("flow velocity", "pipe velocity", "m/s", "ft/s", "erosion"),
        fields = listOf(
            CalculatorField("flow", BilingualText("Volumetric Flow Rate", "फ्लो रेट"), "56.5", "m³/hr", listOf("m³/hr", "LPM", "GPM")),
            CalculatorField("dia", BilingualText("Pipe Inner Diameter", "पाइप आंतरिक व्यास"), "100", "mm", listOf("mm", "inch"))
        ),
        compute = { values, units ->
            runCatching {
                val rawQ = requireNonNegative(values["flow"], BilingualText("Flow Rate", "फ्लो रेट"))
                val rawD = requirePositive(values["dia"], BilingualText("Pipe Diameter", "पाइप व्यास"))
                val qM3h = when (units["flow"]) {
                    "LPM" -> rawQ * 0.06
                    "GPM" -> rawQ * 0.2271247
                    else -> rawQ
                }
                val dM = if (units["dia"] == "inch") rawD * 0.0254 else rawD / 1000.0
                val area = PI * dM * dM / 4.0
                val velMs = (qM3h / 3600.0) / area
                val velFtS = velMs * 3.28084
                engOutput(
                    primaryLabel = BilingualText("Fluid Velocity (v)", "द्रव वेग (v)"),
                    primaryValue = formatEng(velMs, 2),
                    primaryUnit = "m/s",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Velocity (ft/s)", "वेग (ft/s)"), formatEng(velFtS, 2), "ft/s"),
                        SecondaryMetric(BilingualText("Pipe Bore Area", "पाइप क्षेत्रफल"), formatEng(area * 10000.0, 2), "cm²")
                    ),
                    formulaUsed = "v = Q_m³/s / (πD²/4)",
                    substitutedFormula = "v = ${formatEng(qM3h / 3600.0, 4)} / ${formatEng(area, 5)}",
                    stepExplanation = BilingualText("Velocity = ${formatEng(velMs, 2)} m/s (${formatEng(velFtS, 2)} ft/s)", "वेग = ${formatEng(velMs, 2)} m/s"),
                    statusLevel = if (velMs > 5.0) StatusLevel.WARNING else StatusLevel.NORMAL
                )
            }
        }
    )

    private fun orificePlateFlow() = dpElementFlow(
        id = "flow_orifice_plate",
        serialNumber = 24,
        icon = Icons.Rounded.DonutLarge,
        title = BilingualText("Orifice Plate Flow Calculator", "ऑरिफिस प्लेट फ्लो कैलकुलेटर"),
        subtitle = BilingualText("ISO 5167 Concentric Orifice Flow from Bore d, Pipe D & ΔP", "ऑरिफिस बोर, पाइप ID और ΔP से फ्लो रेट निकालें"),
        defaultCd = "0.61",
        permLossFactor = 0.65,
        assumptions = BilingualText(
            "Sharp-edged concentric orifice (default C_d ≈ 0.61, β recommended 0.20–0.75, ε=1.0).",
            "मान्यता: मानक ISO 5167 ऑरिफिस (C_d ≈ 0.61, अनुशंसित β = 0.20–0.75)।"
        )
    )

    private fun venturiFlow() = dpElementFlow(
        id = "flow_venturi",
        serialNumber = 25,
        icon = Icons.Rounded.FilterAlt,
        title = BilingualText("Venturi Flow Calculator", "वेंचुरी फ्लो कैलकुलेटर"),
        subtitle = BilingualText("Low-Loss Classical Venturi Tube Flow Calculation", "वेंचुरी मीटर के थ्रोट व्यास और ΔP से फ्लो रेट निकालें"),
        defaultCd = "0.985",
        permLossFactor = 0.12,
        assumptions = BilingualText(
            "Classical Venturi tube (C_d ≈ 0.985, low permanent head loss ~12% of ΔP).",
            "मान्यता: क्लासिकल वेंचुरी ट्यूब (C_d ≈ 0.985, केवल ~12% स्थायी प्रेशर लॉस)।"
        )
    )

    private fun nozzleFlow() = dpElementFlow(
        id = "flow_nozzle",
        serialNumber = 26,
        icon = Icons.Rounded.PrecisionManufacturing,
        title = BilingualText("Nozzle Flow Calculator", "फ्लो नोजल कैलकुलेटर"),
        subtitle = BilingualText("ISA 1932 / ASME Flow Nozzle Volumetric & Mass Flow", "हाई-वेलोसिटी फ्लो नोजल के लिए फ्लो रेट की गणना"),
        defaultCd = "0.96",
        permLossFactor = 0.40,
        assumptions = BilingualText(
            "Long-radius / ISA 1932 flow nozzle (default C_d ≈ 0.96, high-temperature steam/water).",
            "मान्यता: ISA/ASME फ्लो नोजल (C_d ≈ 0.96)।"
        )
    )

    private fun rotameterSizing() = CalculatorDefinition(
        id = "flow_rotameter",
        serialNumber = 27,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Analytics,
        title = BilingualText("Rotameter Sizing Calculator", "रोटामीटर साइजिंग कैलकुलेटर"),
        subtitle = BilingualText("Apply Fluid Density Correction to Variable-Area Rotameter", "वास्तविक द्रव घनत्व के लिए रोटामीटर रीडिंग का करेक्शन करें"),
        formulaPreview = "Q_actual = Q_ind × √(((ρ_f − ρ_act) × ρ_cal) / ((ρ_f − ρ_cal) × ρ_act))",
        assumptions = BilingualText(
            "Standard SS-316 float density = 7900 kg/m³ (Water cal = 1000 kg/m³, Air = 1.225 kg/m³).",
            "मान्यता: मानक SS-316 फ्लोट घनत्व = 7900 kg/m³।"
        ),
        keywords = listOf("rotameter", "variable area", "density correction", "float"),
        fields = listOf(
            CalculatorField("q_ind", BilingualText("Indicated Scale Reading", "रोटामीटर रीडिंग"), "50", "LPM"),
            CalculatorField("rho_cal", BilingualText("Calibration Fluid Density", "कैलिब्रेशन द्रव घनत्व"), "1000", "kg/m³"),
            CalculatorField("rho_act", BilingualText("Actual Process Fluid Density", "वास्तविक द्रव घनत्व"), "850", "kg/m³"),
            CalculatorField("rho_float", BilingualText("Float Material Density", "फ्लोट घनत्व (SS=7900)"), "7900", "kg/m³")
        ),
        compute = { values, _ ->
            runCatching {
                val qInd = requireNonNegative(values["q_ind"], BilingualText("Indicated Flow", "रीडिंग"))
                val rCal = requirePositive(values["rho_cal"], BilingualText("Cal Density", "कैलिब्रेशन घनत्व"))
                val rAct = requirePositive(values["rho_act"], BilingualText("Actual Density", "वास्तविक घनत्व"))
                val rFloat = requirePositive(values["rho_float"], BilingualText("Float Density", "फ्लोट घनत्व"))
                if (rFloat <= rCal || rFloat <= rAct) {
                    throw BilingualValidationException(BilingualText("Float density must be higher than both fluid densities.", "फ्लोट का घनत्व द्रव घनत्व से अधिक होना चाहिए।"))
                }
                val factor = sqrt(((rFloat - rAct) * rCal) / ((rFloat - rCal) * rAct))
                val qAct = qInd * factor
                engOutput(
                    primaryLabel = BilingualText("Density-Corrected Actual Flow", "सही वास्तविक फ्लो"),
                    primaryValue = formatEng(qAct, 2),
                    primaryUnit = "LPM",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Correction Factor", "करेक्शन फैक्टर"), formatEng(factor, 4), "×"),
                        SecondaryMetric(BilingualText("Flow in m³/hr", "m³/hr में"), formatEng(qAct * 0.06, 3), "m³/hr")
                    ),
                    formulaUsed = "Q_act = Q_ind × √(((ρ_f−ρ_act)·ρ_cal)/((ρ_f−ρ_cal)·ρ_act))",
                    substitutedFormula = "Factor = ${formatEng(factor, 4)} → Q_act = ${formatEng(qAct, 2)} LPM",
                    stepExplanation = BilingualText("Corrected Flow = ${formatEng(qAct, 2)} LPM (Factor ${formatEng(factor, 4)})", "सही फ्लो = ${formatEng(qAct, 2)} LPM")
                )
            }
        }
    )

    private fun gasFlowCompensation() = CalculatorDefinition(
        id = "flow_gas_comp",
        serialNumber = 28,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Compress,
        title = BilingualText("Gas Flow Compensation Calculator", "गैस फ्लो कम्पेनसेशन (P & T)"),
        subtitle = BilingualText("DP Gas Flow P & T Compensation to Standard Nm³/hr", "गैस के वास्तविक प्रेशर और तापमान के अनुसार Nm³/hr कम्पेनसेशन"),
        formulaPreview = "Q_comp = Q_uncomp × √((P_act / P_cal) × (T_cal_K / T_act_K) × (Z_cal / Z_act))",
        assumptions = BilingualText(
            "Requires absolute pressures (bara) and temperatures converted automatically to Kelvin.",
            "मान्यता: प्रेशर एब्सोल्यूट (bara) में और तापमान स्वतः केल्विन (K) में बदला जाता है।"
        ),
        keywords = listOf("gas compensation", "pressure temperature", "nm3/hr", "scfm"),
        fields = listOf(
            CalculatorField("q_raw", BilingualText("Uncompensated Flow", "रॉ गैस फ्लो"), "1000", "Nm³/hr"),
            CalculatorField("p_cal", BilingualText("Design Cal Pressure (abs)", "डिजाइन प्रेशर (bara)"), "6.0", "bara"),
            CalculatorField("t_cal", BilingualText("Design Cal Temp (°C)", "डिजाइन तापमान (°C)"), "25", "°C", allowNegative = true),
            CalculatorField("p_act", BilingualText("Actual Operating Pressure (abs)", "वास्तविक प्रेशर (bara)"), "7.5", "bara"),
            CalculatorField("t_act", BilingualText("Actual Operating Temp (°C)", "वास्तविक तापमान (°C)"), "45", "°C", allowNegative = true)
        ),
        compute = { values, _ ->
            runCatching {
                val qRaw = requireNonNegative(values["q_raw"], BilingualText("Uncompensated Flow", "रॉ फ्लो"))
                val pCal = requirePositive(values["p_cal"], BilingualText("Design Pressure", "डिजाइन प्रेशर"))
                val tCalC = requireRange(values["t_cal"], -270.0, 1500.0, BilingualText("Design Temp", "डिजाइन तापमान"))
                val pAct = requirePositive(values["p_act"], BilingualText("Actual Pressure", "वास्तविक प्रेशर"))
                val tActC = requireRange(values["t_act"], -270.0, 1500.0, BilingualText("Actual Temp", "वास्तविक तापमान"))
                val tCalK = tCalC + 273.15
                val tActK = tActC + 273.15
                val factor = sqrt((pAct / pCal) * (tCalK / tActK))
                val qComp = qRaw * factor
                engOutput(
                    primaryLabel = BilingualText("P & T Compensated Flow", "कम्पेनसेटेड गैस फ्लो"),
                    primaryValue = formatEng(qComp, 2),
                    primaryUnit = "Nm³/hr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Compensation Factor", "करेक्शन फैक्टर"), formatEng(factor, 4), "×"),
                        SecondaryMetric(BilingualText("Deviation vs Raw", "रॉ से अंतर"), formatEng((factor - 1.0) * 100.0, 2), "%")
                    ),
                    formulaUsed = "Q_comp = Q_raw × √((P_act/P_cal) × (T_cal_K/T_act_K))",
                    substitutedFormula = "Factor = √((${formatEng(pAct, 2)}/${formatEng(pCal, 2)}) × (${formatEng(tCalK, 1)}/${formatEng(tActK, 1)}))",
                    stepExplanation = BilingualText("Compensated Flow = ${formatEng(qComp, 2)} Nm³/hr", "सही गैस फ्लो = ${formatEng(qComp, 2)} Nm³/hr")
                )
            }
        }
    )

    private fun flowTotalizer() = CalculatorDefinition(
        id = "flow_totalizer",
        serialNumber = 29,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.Timer,
        title = BilingualText("Flow Totalizer Calculator", "फ्लो टोटलाइजर कैलकुलेटर"),
        subtitle = BilingualText("Compute Accumulated Batch Volume, Mass & Pulse Count", "औसत फ्लो रेट और समय से कुल वॉल्यूम और पल्स गिनती निकालें"),
        formulaPreview = "Total = Flow_Rate × Time   |   Pulses = Total_Liters / Pulse_Weight",
        assumptions = BilingualText(
            "Assumes steady average flow rate over the batch duration.",
            "मान्यता: बैच अवधि में औसत फ्लो रेट स्थिर माना गया है।"
        ),
        keywords = listOf("totalizer", "batch", "pulse output", "accumulated flow"),
        fields = listOf(
            CalculatorField("rate", BilingualText("Flow Rate", "फ्लो रेट"), "45", "m³/hr", listOf("m³/hr", "LPM")),
            CalculatorField("time", BilingualText("Run Duration", "चलने का समय"), "6", "hr", listOf("hr", "min")),
            CalculatorField("pulse_l", BilingualText("Pulse Weight (Liters/Pulse)", "पल्स वेट (लीटर/पल्स)"), "10", "L/pulse")
        ),
        compute = { values, units ->
            runCatching {
                val rawRate = requireNonNegative(values["rate"], BilingualText("Flow Rate", "फ्लो रेट"))
                val rawTime = requireNonNegative(values["time"], BilingualText("Duration", "समय"))
                val pulseL = requirePositive(values["pulse_l"], BilingualText("Pulse Weight", "पल्स वेट"))
                val qM3h = if (units["rate"] == "LPM") rawRate * 0.06 else rawRate
                val hrs = if (units["time"] == "min") rawTime / 60.0 else rawTime
                val totalM3 = qM3h * hrs
                val totalL = totalM3 * 1000.0
                val pulses = totalL / pulseL
                engOutput(
                    primaryLabel = BilingualText("Total Accumulated Volume", "कुल संचित वॉल्यूम"),
                    primaryValue = formatEng(totalM3, 2),
                    primaryUnit = "m³",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Total Liters", "कुल लीटर"), formatEng(totalL, 0), "L"),
                        SecondaryMetric(BilingualText("Totalizer Pulses", "कुल पल्स"), formatEng(pulses, 0), "pulses")
                    ),
                    formulaUsed = "Total = Q_m³/hr × Hours",
                    substitutedFormula = "Total = ${formatEng(qM3h, 2)} × ${formatEng(hrs, 2)} = ${formatEng(totalM3, 2)} m³",
                    stepExplanation = BilingualText("Accumulated = ${formatEng(totalM3, 2)} m³ (${formatEng(pulses, 0)} pulses)", "कुल वॉल्यूम = ${formatEng(totalM3, 2)} m³")
                )
            }
        }
    )

    private fun flowUnitConverter() = CalculatorDefinition(
        id = "flow_unit_conv",
        serialNumber = 30,
        category = CalculatorCategory.INST_FLOW,
        icon = Icons.Rounded.SwapHoriz,
        title = BilingualText("Flow Unit Converter (m³/hr, LPM, GPM)", "फ्लो यूनिट कन्वर्टर (m³/hr, LPM, GPM)"),
        subtitle = BilingualText("Convert Between m³/hr, LPM, US GPM, L/s & CFM", "फ्लो यूनिट m³/hr, LPM, US GPM, L/s और CFM आपस में बदलें"),
        formulaPreview = "1 m³/hr = 16.6667 LPM = 4.40287 US GPM = 0.27778 L/s",
        assumptions = BilingualText(
            "Volumetric flow conversion using US Liquid Gallon (3.78541 L).",
            "मान्यता: US गैलन (1 gal = 3.78541 L) के अनुसार वॉल्यूम फ्लो रूपांतरण।"
        ),
        keywords = listOf("flow converter", "m3/hr", "lpm", "gpm", "cfm"),
        fields = listOf(
            CalculatorField("val", BilingualText("Flow Value", "फ्लो मान"), "10", "m³/hr", listOf("m³/hr", "LPM", "US GPM", "L/s", "CFM"))
        ),
        compute = { values, units ->
            runCatching {
                val raw = requireNonNegative(values["val"], BilingualText("Flow Value", "फ्लो मान"))
                val u = units["val"] ?: "m³/hr"
                val m3h = when (u) {
                    "LPM" -> raw * 0.06
                    "US GPM" -> raw * 0.2271247
                    "L/s" -> raw * 3.6
                    "CFM" -> raw * 1.69901
                    else -> raw
                }
                val lpm = m3h * 16.66667
                val gpm = m3h * 4.402868
                val ls = m3h / 3.6
                val cfm = m3h / 1.69901
                engOutput(
                    primaryLabel = BilingualText("Flow in m³/hr", "m³/hr में फ्लो"),
                    primaryValue = formatEng(m3h, 3),
                    primaryUnit = "m³/hr",
                    secondaryMetrics = listOf(
                        SecondaryMetric(BilingualText("Liters / Min", "लीटर / मिनट"), formatEng(lpm, 2), "LPM"),
                        SecondaryMetric(BilingualText("US Gallons / Min", "US GPM"), formatEng(gpm, 2), "GPM"),
                        SecondaryMetric(BilingualText("Liters / Sec", "लीटर / सेकंड"), formatEng(ls, 3), "L/s"),
                        SecondaryMetric(BilingualText("Cubic Ft / Min", "CFM"), formatEng(cfm, 2), "CFM")
                    ),
                    formulaUsed = "1 m³/hr = 16.667 LPM = 4.403 GPM",
                    substitutedFormula = "${formatEng(raw, 2)} $u = ${formatEng(m3h, 3)} m³/hr",
                    stepExplanation = BilingualText("${formatEng(m3h, 3)} m³/hr = ${formatEng(lpm, 1)} LPM = ${formatEng(gpm, 1)} GPM", "${formatEng(m3h, 3)} m³/hr = ${formatEng(lpm, 1)} LPM")
                )
            }
        }
    )
}
