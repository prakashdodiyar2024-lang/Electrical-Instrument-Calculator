package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.audio.rememberTouchClickSound
import com.example.ui.components.BrandLogoBadge
import com.example.ui.components.LanguageToggleChip
import com.example.ui.theme.CardLightGrey
import com.example.ui.theme.DarkNavyBlue
import com.example.ui.theme.HairlineGrey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightBlueBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueHeaderEnd
import com.example.ui.theme.RoyalBlueHeaderStart
import com.example.ui.theme.RoyalBlueTint
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.launch

private const val YOUTUBE_URL = "https://youtube.com/@Electricalandinstrument"
private const val CONTACT_EMAIL = "prakashdodiyar785@gmail.com"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    language: AppLanguage,
    onBack: (() -> Unit)?,
    onToggleLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val playClick = rememberTouchClickSound()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = PureWhite,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (onBack != null) {
                Column {
                    TopAppBar(
                        title = {
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "About Us & Developer" else "हमारे बारे में और डेवलपर",
                                color = PureWhite,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    playClick()
                                    onBack()
                                },
                                modifier = Modifier.testTag("about_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = if (language == AppLanguage.ENGLISH) "Back" else "वापस",
                                    tint = PureWhite
                                )
                            }
                        },
                        actions = {
                            LanguageToggleChip(
                                language = language,
                                onToggle = onToggleLanguage,
                                darkSurface = true,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = RoyalBlue)
                    )
                    HorizontalDivider(color = DarkNavyBlue)
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(PureWhite)
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .align(Alignment.TopCenter)
                    .testTag("about_list"),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (onBack == null) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(RoyalBlueHeaderStart, RoyalBlueHeaderEnd)
                                    )
                                )
                                .windowInsetsPadding(WindowInsets.statusBars)
                                .padding(horizontal = 16.dp, vertical = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) {
                                            "About Us & Developer"
                                        } else {
                                            "हमारे बारे में और डेवलपर"
                                        },
                                        style = MaterialTheme.typography.headlineSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 21.sp
                                        ),
                                        color = PureWhite
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "ElectricalCalc Pro • 100 Tools",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PureWhite.copy(alpha = 0.88f)
                                    )
                                }
                                LanguageToggleChip(
                                    language = language,
                                    onToggle = onToggleLanguage,
                                    darkSurface = true
                                )
                            }
                        }
                    }
                } else {
                    item { Spacer(modifier = Modifier.height(2.dp)) }
                }

                // Hero App & Brand Card
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                        border = BorderStroke(1.dp, LightBlueBorder),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("about_brand_card")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                BrandLogoBadge(
                                    size = 88.dp,
                                    modifier = Modifier.testTag("about_brand_logo")
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = RoyalBlueTint,
                                    border = BorderStroke(1.dp, LightBlueBorder)
                                ) {
                                    Text(
                                        text = "Electrical & Instrumentation",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = RoyalBlue,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Electrical & Instrument Calculator",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (language == AppLanguage.ENGLISH) {
                                        "100 Calculators across 10 Categories (50 Electrical + 50 Instrumentation)"
                                    } else {
                                        "10 श्रेणियों में 100 कैलकुलेटर (50 इलेक्ट्रिकल + 50 इंस्ट्रूमेंटेशन)"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                }

                // Developer & Brand Details Card
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                        border = BorderStroke(1.dp, LightBlueBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("developer_details_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(RoyalBlueTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Engineering,
                                        contentDescription = null,
                                        tint = RoyalBlue
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (language == AppLanguage.ENGLISH) "Developer & App Information" else "डेवलपर और ऐप विवरण",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                            }

                            HorizontalDivider(color = HairlineGrey)

                            InfoRow(
                                label = if (language == AppLanguage.ENGLISH) "App Name" else "ऐप का नाम",
                                value = "Electrical & Instrument Calculator",
                                icon = Icons.Rounded.Verified
                            )
                            InfoRow(
                                label = if (language == AppLanguage.ENGLISH) "Developer" else "डेवलपर",
                                value = "Er. Prakash Dodiyar",
                                icon = Icons.Rounded.Code
                            )
                            InfoRow(
                                label = if (language == AppLanguage.ENGLISH) "Brand" else "ब्रांड",
                                value = "Electrical & Instrumentation",
                                icon = Icons.Rounded.Engineering
                            )

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = PureWhite,
                                border = BorderStroke(1.dp, LightBlueBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (language == AppLanguage.ENGLISH) {
                                        "Designed for electrical, instrumentation, automation, motor, transformer, flow, level, and temperature engineers who need reliable field calculations in English and Hindi."
                                    } else {
                                        "यह ऐप इलेक्ट्रिकल, इंस्ट्रूमेंटेशन, ऑटोमेशन, मोटर, ट्रांसफॉर्मर, फ्लो, लेवल और तापमान इंजीनियरों व टेक्नीशियन के लिए अंग्रेजी व हिंदी में सटीक गणनाओं के लिए बनाया गया है।"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }

                // YouTube Channel Card
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                        border = BorderStroke(1.dp, LightBlueBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("youtube_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(RoyalBlueTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayCircle,
                                        contentDescription = null,
                                        tint = RoyalBlue,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) "Official YouTube Channel" else "आधिकारिक यूट्यूब चैनल",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = TextPrimaryDark
                                    )
                                    Text(
                                        text = "@Electricalandinstrument",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        color = RoyalBlue
                                    )
                                }
                            }

                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "Watch practical industrial tutorials on 4–20 mA calibration, PLC/DCS wiring, VFD drives, motor starters, RTD/thermocouples, and plant troubleshooting."
                                } else {
                                    "4–20 mA कैलिब्रेशन, PLC/DCS वायरिंग, VFD ड्राइव, मोटर स्टार्टर, RTD/थर्मोकपल और प्लांट ट्रबलशूटिंग के प्रैक्टिकल वीडियो देखने के लिए हमारे चैनल से जुड़ें।"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PureWhite,
                                border = BorderStroke(1.dp, LightBlueBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = YOUTUBE_URL,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    color = TextPrimaryDark,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        playClick()
                                        clipboard.setText(AnnotatedString(YOUTUBE_URL))
                                        scope.launch {
                                            snackbarHostState.showSnackbar(
                                                if (language == AppLanguage.ENGLISH) "YouTube link copied"
                                                else "यूट्यूब लिंक कॉपी हो गया"
                                            )
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = PureWhite,
                                        contentColor = TextPrimaryDark
                                    ),
                                    border = BorderStroke(1.dp, LightBlueBorder),
                                    modifier = Modifier
                                        .weight(0.38f)
                                        .heightIn(min = 48.dp)
                                        .testTag("copy_youtube_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ContentCopy,
                                        contentDescription = null,
                                        tint = RoyalBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) "Copy" else "कॉपी",
                                        color = TextPrimaryDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = {
                                        playClick()
                                        val opened = runCatching {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(YOUTUBE_URL))
                                            context.startActivity(intent)
                                        }.isSuccess
                                        if (!opened) {
                                            clipboard.setText(AnnotatedString(YOUTUBE_URL))
                                            scope.launch {
                                                snackbarHostState.showSnackbar(
                                                    if (language == AppLanguage.ENGLISH) "Link copied: $YOUTUBE_URL"
                                                    else "लिंक कॉपी किया गया: $YOUTUBE_URL"
                                                )
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = RoyalBlue,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(0.62f)
                                        .heightIn(min = 48.dp)
                                        .testTag("youtube_channel_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) "Visit YouTube" else "यूट्यूब खोलें",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Contact Us Card
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardLightGrey),
                        border = BorderStroke(1.dp, LightBlueBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("contact_us_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(RoyalBlueTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Email,
                                        contentDescription = null,
                                        tint = RoyalBlue
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (language == AppLanguage.ENGLISH) "Contact Us" else "संपर्क करें (Contact Us)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                            }

                            Text(
                                text = if (language == AppLanguage.ENGLISH) {
                                    "Have a formula suggestion, feature request, or feedback? Reach out directly to the developer:"
                                } else {
                                    "कोई नया फॉर्मूला, सुझाव या फीडबैक भेजना हो तो सीधे डेवलपर से संपर्क करें:"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PureWhite,
                                border = BorderStroke(1.dp, LightBlueBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = CONTACT_EMAIL,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = TextPrimaryDark,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        playClick()
                                        clipboard.setText(AnnotatedString(CONTACT_EMAIL))
                                        scope.launch {
                                            snackbarHostState.showSnackbar(
                                                if (language == AppLanguage.ENGLISH) "Email address copied"
                                                else "ईमेल कॉपी हो गया"
                                            )
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = PureWhite,
                                        contentColor = TextPrimaryDark
                                    ),
                                    border = BorderStroke(1.dp, LightBlueBorder),
                                    modifier = Modifier
                                        .weight(0.38f)
                                        .heightIn(min = 48.dp)
                                        .testTag("copy_email_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ContentCopy,
                                        contentDescription = null,
                                        tint = RoyalBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) "Copy" else "कॉपी",
                                        color = TextPrimaryDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = {
                                        playClick()
                                        val sent = runCatching {
                                            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                                                data = Uri.parse("mailto:$CONTACT_EMAIL")
                                                putExtra(
                                                    Intent.EXTRA_SUBJECT,
                                                    "Electrical & Instrument Calculator Feedback"
                                                )
                                            }
                                            context.startActivity(emailIntent)
                                        }.isSuccess
                                        if (!sent) {
                                            clipboard.setText(AnnotatedString(CONTACT_EMAIL))
                                            scope.launch {
                                                snackbarHostState.showSnackbar(
                                                    if (language == AppLanguage.ENGLISH) "Email copied: $CONTACT_EMAIL"
                                                    else "ईमेल कॉपी किया गया: $CONTACT_EMAIL"
                                                )
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = RoyalBlue,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(0.62f)
                                        .heightIn(min = 48.dp)
                                        .testTag("contact_email_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Email,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (language == AppLanguage.ENGLISH) "Send Email" else "ईमेल भेजें",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = RoyalBlue,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondaryDark
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimaryDark
            )
        }
    }
}
